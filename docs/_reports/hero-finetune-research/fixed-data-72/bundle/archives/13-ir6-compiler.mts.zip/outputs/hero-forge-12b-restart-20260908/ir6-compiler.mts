/** Versioned IR6 lowering; legacy lowering copied without editing historical IR4. */
import assert from 'node:assert/strict';
import { resolveIR6 } from './ir-v6.mts';
import { NATIVE_ACTIONS, lowerNativeAction } from './native-mechanism-actions.mts';
import { hash, currentCatalog, checkEnginePins } from './ir-compiler.mts';
export { hash, currentCatalog, checkEnginePins };
import { SLOTS } from './intake.mjs';
import { compileReviewedProducts } from './compile-reviewed-products-v1.mts';

export function lowerIR6(input: unknown, source: any) {
  const checked = resolveIR6(input, source), ir = checked.resolvedIR;
  const namespace = `ir-${hash(source.id).slice(0, 10)}`;
  const symbol = (key: string) => `${namespace}.${key}`;
  const proposals: any[] = [];
  function proposed(a: any, field: string, fallback: any, location: string) {
    if (a[field] !== null) return a[field];
    proposals.push({ location, field, value: fallback, basis: 'research-preview-policy-not-source', requiresTuning: true });
    return fallback;
  }
  function effects(actions: any[], slot: string, prefix: string): any[] {
    return actions.flatMap((a, i) => {
      const loc = `${prefix}.${i}`, statusId = `${namespace}.${slot.toLowerCase()}.${hash(loc).slice(0, 8)}`;
      const dt = () => proposed(a, 'damageType', 'magic', loc);
      const amount = () => ({ damageTier: proposed(a, 'tier', '極小', loc) });
      const hit = () => ({ kind: 'damage', damageType: dt(), amount: amount() });
      const kb = (v: any) => ({ kind: 'knockback', distance: proposed(v, 'distance', 0.4, loc), speed: 8, from: v.direction, subtractGap: v.subtractGap });
      switch (a.op) {
        case 'damage': return [hit()];
        case 'dot': return [{ kind: 'dot', damageType: dt(), amountPerTick: amount(), durationSec: a.duration, intervalSec: a.interval, tickOnApply: false }];
        case 'heal_self': return [{ kind: 'heal', applyTo: 'self', amount: { flat: proposed(a, 'amount', 100, loc) } }];
        case 'shield_self': return [{ kind: 'shield', amount: { flat: proposed(a, 'amount', 100, loc) }, duration: a.duration,
          absorbs: a.absorbs, stackKey: statusId, onExisting: a.stacking === 'keep_larger' ? 'keepLarger' : 'replace' }];
        case 'buff_self': return [{ kind: 'applyBuff', applyTo: 'self', duration: a.duration, modifiers: [
          ...(a.moveSpeedTier ? [{ stat: 'ms', op: 'pctAdd', msBonusTier: a.moveSpeedTier }] : []),
          ...(a.attackSpeedPct ? [{ stat: 'as', op: 'pctAdd', value: a.attackSpeedPct }] : []),
        ] }];
        case 'control': return [{ kind: 'applyStatus', statusId, duration: a.duration,
          ...(a.control === 'slow' ? { moveSpeedMult: 1 - a.slowPct } : { [{ root: 'root', stun: 'stun', fear: 'feared' }[a.control]!]: true }) }];
        case 'knockback': return [kb(a)];
        case 'dash_impact': return [{ kind: 'dash', mode: a.direction === 'aim' ? 'toPoint' : 'forward',
          maxDistance: a.distance, speed: a.speed, onEndOn: a.onBlocked === 'impact' ? 'always' : 'completed',
          onEndWhenDead: a.onDeath === 'impact', onEnd: [{ kind: 'damageArea', radius: a.hitRadius,
            damageType: dt(), amount: amount(), includeOrigin: true, falloff: 1,
            ...(a.push ? { onHitTargets: [{ kind: 'knockback', from: a.push.direction, distance: a.push.distance,
              speed: a.push.speed, subtractGap: a.push.subtractGap }] } : {}) }] }];
        case 'area_pulses': return [{ kind: 'delayed', shape: 'circle', radius: 1, radiusTier: a.radiusTier, side: 'enemies',
          anchor: a.anchor, delaySec: proposed(a, 'firstDelay', a.interval, loc), count: a.count, intervalSec: a.interval,
          targetMode: 'reresolve', hitOncePerTarget: false, effects: [hit()] }];
        case 'barrage': return [{ kind: 'randomArea', who: 'target', count: [a.count],
          intervalSec: proposed(a, 'interval', 0.2, loc), scatterRadius: proposed(a, 'scatterRadius', 0.5, loc), firstAtCast: true,
          effects: [{ kind: 'damageArea', radius: proposed(a, 'hitRadius', 2.75, loc), damageType: dt(), amount: amount(), includeOrigin: true }] }];
        case 'chain': return [{ kind: 'chainLightning', shape: 'single', jumps: a.totalTargets, damageType: dt(), amount: amount(),
          jumpRange: proposed(a, 'jumpRange', 4.5, loc), decay: a.decay, revisit: false }];
        case 'combo': {
          const strikes = proposed(a, 'strikes', 3, loc), interval = a.duration / (strikes + 1);
          return [
            ...(a.lock === 'none' ? [] : [{ kind: 'applyStatus', statusId, duration: a.duration, [a.lock]: true }]),
            ...(a.casterGuard === 'none' ? [] : [{ kind: 'invulnerable', applyTo: 'self', durationSec: a.duration,
              blocksDamage: a.casterGuard, blocksControl: false }]),
            { kind: 'delayed', shape: 'single', targetMode: 'frozen', delaySec: interval, intervalSec: interval,
              count: strikes, effects: [hit()], stopOnCasterDeath: true },
            { kind: 'delayed', shape: 'single', targetMode: 'frozen', delaySec: a.duration,
              effects: [{ kind: 'damage', damageType: dt(), amount: { damageTier: proposed(a, 'finisherTier', '小', loc) } }], stopOnCasterDeath: true },
          ];
        }
        case 'leap': return [{ kind: 'leap', applyTo: 'self', mode: 'toPoint', apexHeight: proposed(a, 'apexHeight', 0, loc),
          durationSec: proposed(a, 'duration', 0.3, loc), ...(a.distance === null ? {} : { throwDistance: a.distance }),
          landRadius: proposed(a, 'landRadius', 2.75, loc), onLand: [hit(), ...(a.pushOnLand ? [kb(a.pushOnLand)] : [])] }];
        case 'output_modifier': return [{ kind: 'applyBuff', sourceScope: 'caster', statusId: symbol(a.key), stackKey: symbol(a.key),
          maxStacks: 1, duration: a.duration, modifiers: ['ad', 'ap'].map(stat => ({ stat, op: 'pctAdd', value: a.percent })),
          polarity: a.percent < 0 ? 'debuff' : 'buff', dispellable: true }];
        case 'spend_health': return [{ kind: 'spendHealth', amount: { flat: 0 }, pctMaxHealth: a.maxHpPct, minimumHp: a.minimumHp }];
        case 'projectile': return [{ kind: 'spawnProjectile', projectileId: 'imported.bolt.void', onHit: effects(a.onHit, slot, loc + '.onHit') }];
        case 'status_branch': return [{ kind: 'consumeStatus', shape: 'single', statusId: symbol(a.key), count: 'all',
          ...(a.ownership === 'same_caster' ? { appliedBy: 'self' } : {}),
          onConsumed: effects(a.present, slot, loc + '.present'), onMissing: effects(a.missing, slot, loc + '.missing') }];
        case 'counter_window': return [{ kind: 'applyBuff', applyTo: 'self', duration: proposed(a, 'duration', 0.5, loc),
          modifiers: [], statusId, stackKey: statusId, maxStacks: 1, hooks: [{ on: 'onDamageTaken', victim: 'enemy', damageSource: 'basic',
            maxTriggers: 1, onConsumed: 'detachSource', condition: { all: [
              { kind: 'distance', op: '<=', value: proposed(a, 'radius', 2.5, loc) },
              ...(a.facingArc === null ? [] : [{ kind: 'facing', subject: 'self', arcDegrees: a.facingArc }]),
            ] }, effects: [{ ...hit(), incomingPct: { perRank: [0], negateOriginal: false, maxChainDepth: 0 } }] }] }];
        default: {
          if (!Object.hasOwn(NATIVE_ACTIONS, a.op)) throw new Error(`UNLOWERED_ACTION:${a.op}`);
          const { evidence, ...native } = a;
          const result = lowerNativeAction(native, ir.slots[slot].delivery, loc);
          proposals.push(...result.proposals);
          return result.effects;
        }
      }
    });
  }
  const slots = Object.fromEntries(SLOTS.map((slot: string) => {
    const s = ir.slots[slot], products: any[] = [];
    const product = (ref: string, params: any) => products.push({ ref, params });
    if (slot === 'PASSIVE') for (const a of s.actions) {
      if (a.op === 'attack_proc') product('tpl-event-passive', { hooks: [{ on: 'onBasicAttack', target: 'event', victim: 'enemy',
        internalCooldown: a.cooldown, ...(a.targetHpBelow === null ? {} : { condition: { kind: 'stat', subject: 'target', stat: 'hp', mode: 'percent', op: '<', value: a.targetHpBelow } }),
        effects: [{ kind: 'damage', damageType: proposed(a, 'damageType', 'magic', slot), amount: { damageTier: proposed(a, 'tier', '極小', slot) } }] }] });
      else if (a.op === 'resource') {
        product('tpl-mark-stacks', { markId: symbol(a.key), initial: a.initial, max: a.max, durationSec: -1, resetOn: a.reset, lethalMode: 'none', perStackLost: [] });
        product('tpl-event-passive', { hooks: [{ on: 'onDamageDealt', target: 'self', victim: 'enemy', oncePerCast: true,
          effects: [{ kind: 'applyStatus', statusId: symbol(a.key), stacks: a.amount, duration: 1 }] }] });
      }
    } else if (s.actions.length) product('tpl-effect-sequence', { castType: s.delivery, castTimeSec: proposed(s, 'windup', 0, slot),
      radius: 2.75, side: 'enemies', effects: effects(s.actions, slot, slot) });
    return [slot, { products, abilityOverrides: { ...(s.rangeTier ? { rangeTier: s.rangeTier } : {}),
      ...(s.cost ? { statusCost: { statusId: symbol(s.cost.key), count: s.cost.count } } : {}) } }];
  }));
  return { ...checked, namespace, slots, proposals, automaticAccept: false };
}

export function compileIR6(input: unknown, source: any, catalog = currentCatalog()) {
  const lowered = lowerIR6(input, source), ir = lowered.ir6;
  assert.equal(lowered.gaps.length, 0, 'UNRESOLVED_MECHANISM_GAPS');
  const built = compileReviewedProducts({ source, recipe: {
    origin: ir.hero.origin, identitySummary: ir.hero.identitySummary, slots: lowered.slots,
  } }, catalog);
  return { ...built, lowered, ir6: ir,
    previewProposals: [...lowered.previewProposals, ...lowered.proposals],
    unresolvedSourceChoices: lowered.unresolvedSourceChoices,
    sourceEntailmentVerified: false, automaticAccept: false, releaseQualified: false };
}
