## 問題：成長蓄能的收益對象與來源相反

`tpl-growth-charge` 的來源是「每 N 次擊殺，擊殺者增加一種屬性」。但展開的 `onKill` hook 未填 `target: "self"`，實際會把 `grantAttribute` 的受詞與計數器放在受害者身上。

這不是文案措辭問題，也不是微調模型能修好的能力缺口。模板可展開且 schema 通過，仍會教出錯誤的能力推薦。

## 版本與去重

- 重現版本：`4793eaaaf2775b2081f5eca5881db32e0aab0ea8`。
- 開票前再次檢查 main `14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a`：以下五個相關檔案的 Git blob SHA 與重現版本全部相同。
- 搜尋 `growth-charge` 與 `成長 蓄能`，找到相關已關閉的 #916，但未找到同一受詞錯誤的現有票。本票不重開舊票。

## 同一條實際執行路徑

1. [模板來源](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/content/ability-templates/tpl-growth-charge.json)：`attr.origin` 引用 `GetKillingUnitBJ()`；預設每 8 次、敏捷 +1。
2. [模板展開](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/content/templates/expand.ts#L1121)：hook 為 `{ on: "onKill", effects: [grant], ... }`，無 `target: "self"`。
3. [死亡事件](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/sim/systems/DeathSystem.ts#L111)：呼叫 `fireHooks(world, killer, "onKill", id)`，第四參數為受害者。
4. [hook 受詞解析](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/sim/effects/hooks.ts#L516)：未指定 self 且有 event target 時使用 `[target]`。
5. [屬性授予](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/sim/effects/grantAttribute.ts#L211)：逐一讀取 `ctx.targets` 的 champion，並在該身體累計 `${ctx.origin}|${attr}`。

## 實測與控制組

在真實 `SimWorld` 生成 SELA 身體，將**真模板展開結果**的 hook 用 `attachSource` 掛給施法者，再用真 `fireHooks(world, killer, "onKill", victim)` 發送事件。未自製 grantAttribute 模擬器。

| 實驗 | 擊殺者敏捷增量 | 受害者結果 |
| --- | --- | --- |
| 原模板，合法參數 everyNth=1，一次事件 | 0 | 受害者 +1 |
| 原模板預設 everyNth=8，八個不同受害者各一次事件 | 0；擊殺者無計數器 | 每個受害者各有進度 1 |
| 控制組：只在記憶體 hook 加 target=self，同樣八個不同受害者 | +1；進度歸零 | 全部不變 |

範圍揭露：這是完整 hook 分派＋真 effect handler 的隔離重現，不是八次玩家操作擊殺 E2E；死亡系統第四參數則已逐行確認。沒有修改任何遊戲或正式內容。

## 建議修正與驗收

- 在模板來源／展開的正確住處明確指向擊殺者，不要改全域 hook 預設，避免傷害類 hook 的受詞一起改壞。
- 將此模板的測試從「有 onKill/grantAttribute」提升到收益受詞及計數器歸屬：第七次沒有增量、第八次只加擊殺者，不加受害者。
- 加入真實死亡事件入口的跨受害者測試，並驗證不同屬性、受害者篩選及上限不回歸。
- 成長模板完成修正前，分類／推薦訓練資料應隔離該能力，不將 schema 通過等同可支援。

本次僅開票與保存診斷；未修 main、未啟用模型。
