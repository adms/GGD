# R3 訓練前控制組：剩餘錯誤逐案複核

本次讀取 `baseline-error-report/report.json` 中 R2 全部6題錯誤的完整輸入、來源及輸出，重新核对既定答案。這是dev診斷，沒有改題目、改label或讀封存test結果；不是R3成績。

## 已觀察的差異

同一83題dev、相同base／runtime／seed／非推理／無grammar設定：base 69/83、R2 77/83，兩者錯誤放行均0。R2修正8題模板拒絕，英雄／Owner來源5題混淆完全未改善。R2原先訓練以模板分類為主，因此不能把這個結果誤寫成「專項來源微調無效」；R3才加入來源判讀訓練，效果需等待實测。

| ID | 複核後答案 | R2回答 | 原文判準 |
| --- | --- | --- | --- |
| hero-source-godie-h01n-unknown | not-stated | contradicted | 來源只說代理死神經歷與四種可學技能，未定義千年血戰篇全部能力；也未明文排除該版本。不能拿外部角色知識補結論。 |
| owner-mechanism-godie-h01n.ex-unknown | not-stated | contradicted | 來源寫卍解下吸血等加成，沒寫每秒固定10%最大生命回復；不能由「有吸血」推出「一定沒有其他回血」。 |
| owner-mechanism-godie-e00s.w-no | contradicted | not-stated | 30/40/50/60%四階擴散比例明確不同，與「所有等級固定相同」直接矛盾。 |
| owner-mechanism-godie-e00s.passive-unknown | not-stated | contradicted | 「防禦增加2倍」有增量／最終倍率措辭歧義；不能斷言「必定剛好2倍」，也不擅自定為必定3倍。 |
| hero-source-godie-hpal-unknown | not-stated | contradicted | 原文說可召喚魔獸並列四項技能，但沒有精確二十隻契約魔獸的數量。 |
| r3-vertical-landing-yes | accept tpl-leap-strike | refuse | 提供的版本目錄明列原地垂直跳、落地範圍傷害；本題不是水平移動或穿牆要求。 |

## 對下一輪迭代的含義

- 五題來源錯誤是「缺乏證據／語意歧義」與「明確反證」的區分，適合以完整來源的三態對比資料測試；不是靠增加特效樣本解決。
- 不將這六道dev原題直接搬進train；若R3仍有同型錯誤，應從原train來源家族產生並逐題核對的新正／反／未述對照，保留既定dev/test用途。
- 單卡垂直跳是已提供能力被拒絕，可能受措辭泛化或保守拒絕偏向影響；這是待驗假說，不是已確定根因。
- source判讀與runtime支援是兩個問題。歷史原文支持的技能不等於現有模板實現，反之現有模板能力不能替原文補設定。
- R3驗收要逐題看是否修正、是否新增錯誤放行與退步，不能只看83題總分或training loss。

`r3-error-report.mjs` 已實際生成配對報告；3項測試覆蓋跨任務退步不可被平均隱藏、schema錯誤分類、seed／請求／runtime漂移及未完成結果拒絕。它不挑checkpoint、不啟用模型，也不自動生訓練資料。
