## 問題

`tpl-pull-throw` 暴露 `throwDistance`，來源欄位說明引用多支技能不同的投擲距離；但模板實際展開為 ground cast。施法入口必定提供 `ctx.point`，`leap` 優先以此為落點，只有沒有 point 的分支才使用 throwDistance。因此這格在真實施法路徑中填了不生效。

同一個施法點，throwDistance=100 和 1000 產生完全相同的落點。不能拿「展開 JSON 中數字有變」或「直接呼叫 effect、刻意不給 point」當作玩家能取得不同投擲距離的證據。

## 版本／既有票範圍

重現：`4793eaaaf2775b2081f5eca5881db32e0aab0ea8`。開票前確認 main `14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a` 的模板、expand、abilitySystem、leap 四個檔案 blob 全相同。

搜尋 pull-throw／throwDistance 並完整閱讀 #959（已關閉，7技能位移驗收）及 #993（手寫技能模板化）；兩票未列出此模板欄位在真實 cast path 不生效的具體問題。本票只修模板能力／參數契約，不重開舊票、不要求逐支手拼技能。

## 因果鏈

- [模板 throwDistance](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/content/ability-templates/tpl-pull-throw.json) 對外可編輯。
- [expand](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/content/templates/expand.ts#L1248) 寫入 leap.throwDistance，並固定 castType=ground。
- [ground cast](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/sim/abilities/abilitySystem.ts#L669) 選取地面小圈的所有敵人，並傳入 point。
- [leap handler](https://github.com/adms/GGD/blob/14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a/packages/shared/src/sim/effects/leap.ts#L44) 在 point 已存在時直接使用 point；throwDistance 只在沒有 point 的目標拋投分支讀取。

## 真施法入口重現

真模板 expand → zAbilityDoc.parse → 記憶體 fixture champion／registry → spawnChampion → rank Q=1 → castAbility(Q, point)。施法者在(-40,0)，指定點(-38,0)，附近兩名敵人。

| 試驗 | castAbility結果 | 受影響身體 | leap終點 |
| --- | --- | --- | --- |
| throwDistance=100 | ok | 兩名敵人 | 都是(-38,0) |
| throwDistance=1000 | ok | 兩名敵人 | 都是(-38,0) |
| entity目標指令 | bad-target | 無 | 無 |
| 控制：直接runEffects、不給point，distance=100 | 非玩家施法控制組 | 一名敵人 | (-38.17,0) |
| 同控制，distance=1000 | 非玩家施法控制組 | 一名敵人 | (-21.67,0) |

控制組證明底層距離分支存在，但模板的施法入口進不去。另確認此模板目前是地面群體選取，不能僅按家族名稱宣稱指定單一敵人。範圍揭露：檢查到真cast入口及實際leap狀態，不宣稱已跑完整落地傷害／沿線碰撞E2E。

## 驗收建議

1. 明確決定這族的受詞／選取點／投擲終點契約，在模板層與runtime接線一致。不能偷偷把玩家選取點換成其他意思。
2. 要保留throwDistance就讓它在宣告的模式下實際影響落點；若該模式不使用它，明確標為不適用／移除，不能保留可調卻無效的欄位。
3. 測試必須從cast入口穿透到leap落點，包含兩個不同合法距離與相同施法點對照；另驗證多人／單人選取契約。
4. 不以單一effect測試或純展開deep-equal代替上面檢查。不要求新增專屬技能if或逐支修改技能。

本輪僅開票、保存證據與限制推薦資料；沒有修改正式遊戲內容。
