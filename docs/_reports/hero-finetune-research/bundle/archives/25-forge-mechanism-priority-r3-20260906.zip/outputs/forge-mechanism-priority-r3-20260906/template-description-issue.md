## 問題

在英雄／技能分類訓練的資料審核中，發現兩張目前 enabled 模板的說明仍混用了舊引擎限制。這會讓 Editor 作者或讀取卡片描述的 AI 誤判「能否完整套用」，不是畫面美觀問題。

本票只修正說明與可用能力契約的對齊；**不要求改遊戲平衡、移除穿牆限制，也不擅自把既有模板改成另一種機制**。

已對照遠端 main `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`（2026-09-06），不是只拿舊 Editor 工作分支開票。

## 1. tpl-teleport 未交代目前的牆體規則

- [卡片說明](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/content/ability-templates/tpl-teleport.json#L5) 說「飛行途中不吃地形也不吃碰撞」，容易被理解成可直接穿越牆體到達目標。
- [模板 expander](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/expand.ts#L1789) 仍輸出 `kind: leap`，不是 `blink`；它本身也没有授予 flight。
- [leap effect](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/sim/effects/leap.ts#L76) 在起跳前呼叫 `resolveLandingPoint(..., {mode: "leap", from: takeoff})`。
- [落點 resolver](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/sim/movement/leap.ts#L187) 會先執行 `resolveDisplacementEnd`，政策取自 `world.wallBlock`；[出貨預設](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/sim/movement/wallBlock.ts#L119) 為 enabled + leap clamp。
- 所以「空中每 tick 不做碰撞」和「最終能穿到牆另一邊」不是同一件事。普通非飛行角色預設會把落點截在牆前；`flightIgnoresObstacles` 與 `flightExempt` 同時成立才有飛行例外，邊界與落點合法性仍受限。

建議文案明確分開：短程 leap 耗時、一般牆體截斷／可設定政策、飛行豁免、邊界限制、友軍分支僅拉到施法者腳邊、可選落地傷害。不要把所有「移動」一律描述成無條件穿牆真瞬移。

## 2. tpl-mark-stacks 將未接線誤稱成引擎沒有排程

- [卡片說明](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/content/ability-templates/tpl-mark-stacks.json#L5) 說無敵／回復／擊退同格，括號理由是「sim 沒有延後排程」。
- main 已有真正使用 `kind: delayed` 的技能來源，例如 [初號機來源 berserk_smoke](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/tools/skill-remake/heroes/godie-e00r.py#L33)，建立 `delaySec/count/intervalSec/effects` 排程。
- [mark-stacks expander](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/expand.ts#L2123) 仍以同格 selfEffects／aoeEffects 產生免死鏈。因此正確界線應是「**此模板尚未接延後回復／擊退**」，不能把局部模板落差說成整個 sim 沒有排程能力。

此票不自行判定 delayed 能無縫接到所有免死情境；若要實作，需另外驗證死亡／重觸發／施法者狀態與排程取消等行為。

## 驗收

- [ ] 兩張模板文案與當前有效展開路徑對齊，分清「引擎有能力」與「此卡已接線」。
- [ ] 同步檢查會引用這兩份描述的 generated catalog／Editor 說明，避免重生後回到舊敘述。
- [ ] teleport 的對照至少涵蓋一般角色牆前截斷、合法飛行豁免及邊界限制；不把既有 runtime 修正回退成穿牆。
- [ ] mark-stacks 的同格限制仍明示；如果選擇實作延遲，須另有真實時序驗證，不能只改說明假裝完成。
- [ ] 分類資料不得因卡片名字或舊描述承諾同幀瞬移／延遲免死鏈。

## 查重與證據界線

已查 `tpl-teleport`、`tpl-mark-stacks` 及開啟中的模板瞬移相關票。#487 是牆體／飛行規則修正，#838 是工坊工作範圍；本票追蹤的是**仍存在的模板說明落差**，不重開已關閉的 runtime 票。

本次有遠端 main 靜態原始碼與本地 schema/expansion 對照證據；**沒有聲稱已在 main 重新跑遊戲端 E2E 或視覺驗收**。初號機舊 TSV 與 #644 的版本差異另記來源版本警告，沒有誤開為新遊戲缺陷。
