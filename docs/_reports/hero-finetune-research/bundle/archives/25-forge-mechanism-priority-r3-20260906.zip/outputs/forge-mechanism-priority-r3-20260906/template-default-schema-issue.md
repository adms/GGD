## 問題

主線兩張 enabled 卡片的預設參數能通過 paramsSchemaFor，也能呼叫 expand，但**展開出的完整 ability@1 無法通過 zAbilityDoc**。目前「defaults EXPAND」測試只確認 castType／非空 payload，漏掉 schema 的跨欄位約束。

版本：main `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`。本次盤點 46 張卡，35 enabled；35/35 預設參數與 expand 成功，只有 **33/35 完整技能 schema 成功**。

## 兩個重現

1. **tpl-beam-roll**：預設 `path:static, count:1, spacing:2`。expand 輸出 spacing；zEffectDef 和 zAbilityDoc 都拒絕：`只有 path:"static" 且 count≥2 讀得到 spacing`，錯誤路徑 `effects.0.spacing`。
2. **tpl-dragon-serpent**：預設輸出 `clipTimeScale:0.3`，但沒有 clip。兩個 schema 都拒絕：`沒有 clip 就沒有人讀 clipTimeScale`，錯誤路徑 `effects.0.clipTimeScale`。

## 原始碼

- [共同 expander](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/expand.ts#L591)：直接依已宣告參數輸出 spacing／clipTimeScale。
- [效果 schema](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/schema/effects/spawnModelFx.ts#L496)：跨欄位 refine。
- [現有 defaults EXPAND 測試](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/paramsSchema.test.ts#L121)：尚未將結果送進完整技能 schema。
- [實際載入檢查](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/registries.ts#L572)：展開結果會送入 zAbilityDoc／zAbilityDef。

重現方法：逐張 zTemplateDoc.parse → defaultParamsFor → paramsSchemaFor.safeParse → expand → 把結果與合法 skeleton（id/name/slot/maxRank/cooldown/manaCost/range）合併 → zAbilityDoc.safeParse。被動卡使用 PASSIVE，其餘使用 Q。另逐個頂層 effect 跑 zEffectDef.safeParse，確認失敗不是 skeleton 自造的錯誤。

## 驗收

- [ ] 兩張卡由來源／共用 expander 修正，不放寬現有 schema 來掩蓋無效欄位。
- [ ] 預設光束 count=1 不發出无意義 spacing；count≥2 的真實間距分支仍有覆蓋。
- [ ] 黑龍剪輯與速率有有效來源且成對，不能只刪掉有意義的播放需求來讓測試綠。
- [ ] 所有 enabled 模板預設都需過完整 ability schema，外加 optional／enum 代表分支；不是只檢查 effects 非空。
- [ ] 分清模板 expand 與 spawnModelFx.preset 載入兩條路；本票不宣稱所有既有使用 preset 的技能都已壞掉。

已查開啟中的 spacing／clipTimeScale 票（#838）與所有狀態的 dragon-serpent/clip；未找到同一個預設展開 schema 缺陷。證據是本地釘選主線的實際 schema 執行，未聲稱遊戲／視覺 E2E。
