# [重要][fix] summon-agent 的 maxAlive=0 宣稱不設上限，實際施法零召喚

## Objective

讓召喚模板的上限說明、預設展開與實際施法一致。現況預設 `maxAlive: 0` 的說明是「不設上限」，但實際 handler 把它視為零容量，施法回傳 `ok` 卻沒有任何召喚物。

## Evidence / reproduction

在 main 快照 `4793eaaaf2775b2081f5eca5881db32e0aab0ea8` 使用真實 `defaultParamsFor → expand → zAbilityDoc.parse → registerChampion → castAbility → SimWorld`；不是只檢查 JSON 裡有 `kind: summon`。

| 模板設定 | castAbility | 立即產生具數 |
| --- | --- | --- |
| 全部原始預設（count=1, maxAlive=0） | ok | 0 |
| 僅 count=2，仍使用預設上限 | ok | 0 |
| count=2, maxAlive=2 | ok | 2 |
| count=2，明確省略 maxAlive | ok | 2 |

正上限控制組兩具都具有正的 HP/maxHP。這證明召喚管線存在，問題是預設上限契約；不是「整個 summon 都未實作」。本次未宣稱完整驗證召喚 AI、到期、擊殺歸屬或所有出貨技能 E2E。

關鍵原文與程式：

- `content/ability-templates/tpl-summon-agent.json:76–82`：`maxAlive.default=0`，origin 卻說「0＝不設上限」。
- `packages/shared/src/content/templates/expand.ts` 的 summon-agent：有該參數便原樣發出 `maxAlive`，不把 0 轉成省略。
- `packages/shared/src/sim/effects/summon.ts:131,159–160`：`Math.max(0, Math.floor(e.maxAlive ?? DEFAULT_SUMMON_CAP))`，`live.length >= maxAlive` 時預設 `onCap=skip` 直接 break。初始 live=0，因此 0>=0，永遠不生成。

另以出貨 ability 的真實 template params 展開，以下三支皆繼承 `maxAlive: 0`：`godie-etyr.r`、`godie-huth.e`、`godie-n00b.w`。這部分是展開證據，並非三支實際遊戲完整驗收。

重現腳本已保留在研究工作區 `tools/forge-training/main-summon-cap-probe.ts`，證據 `outputs/forge-mechanism-priority-r3-20260906/main-summon-cap-probe-v1.json`（尚未 push）。脚本會驗四組 cast 回傳與產生數量，且拒絕覆寫證據。

## Scope / likely affected modules

召喚模板的 maxAlive 預設與說明、template 展開契約、召喚模板實際施法回歸測試；核對以上三個模板消費者是否應繼承預設。

## Non-goals

不更改英雄原始機制，不新增特殊英雄分支，不新增召喚 AI，不重新打開已結案 #423，也不因模型訓練方便改遊戲語意。

## Implementation constraints / risks

不要直接把全引擎 `maxAlive=0` 改成無限，因為其他 effect 呼叫者可能正確依賴零容量語意。先統一模板契約：若想表達省略上限，必須正確處理參數預設與缺席；而 handler 的缺席仍有 `DEFAULT_SUMMON_CAP` 安全上限，不能把有限預設再說成真正無限。保留有限 cap / onCap 的既有行為。

## Test / acceptance criteria

1. 預設模板透過完整 ability schema 和 castAbility 真的生成承諾具數，不能只驗 expand.effects 含 summon。
2. count=2 的預設使用者生成兩具，生命、擁有者及身體正確。
3. 有限 maxAlive、零容量（若契約保留）、省略參數三種情況都有符合說明的行為測試。
4. 針對出貨三支技能核對繼承預設；若需要改預設，更新來源而非只改生成輸出。
5. 突變測試：讓預設再次產生零容量時，真實施法守衛必須失敗。

**思考策略**：模板展開存在不等於實際產生召喚物；用只變一個欄位的正控制隔離原因。

**解決模板**：來源契約修正＋真實 cast-path 回歸守衛，禁止 per-hero 修補。

## Latest-main verification

開票前讀到 main `ddcb3c1b8de5b9467a9416999b3c305766369bca`；模板與 summon handler 的 Git blob 分別仍為 `24475545ba50f1b03f23fa8a25c2f7377dded25b`、`0e354b0f0f79f04095771130495297ffae30bdb1`，與重現快照相同。展開器整檔有其他變更，但另行讀取最新版本後，召喚分支第 807 行仍直接發出 `maxAlive: num(t,p,"maxAlive")`，沒有零值轉换。本次實跑版本仍是上述固定快照，不冒充最新 main 全套重跑。

來源：[模板預設](https://github.com/adms/GGD/blob/ddcb3c1b8de5b9467a9416999b3c305766369bca/content/ability-templates/tpl-summon-agent.json#L76)、[展開器](https://github.com/adms/GGD/blob/ddcb3c1b8de5b9467a9416999b3c305766369bca/packages/shared/src/content/templates/expand.ts#L807)、[零容量判定](https://github.com/adms/GGD/blob/ddcb3c1b8de5b9467a9416999b3c305766369bca/packages/shared/src/sim/effects/summon.ts#L131)。
