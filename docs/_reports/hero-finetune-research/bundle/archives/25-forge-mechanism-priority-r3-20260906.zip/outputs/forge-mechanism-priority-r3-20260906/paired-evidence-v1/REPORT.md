# R3 與接續診斷證據索引

狀態：complete-research-evidence；原訓練程序：complete-research-only；接續診斷：complete-research-only。

本報告只整理證據，不重新選模型、不啟用Editor、不宣告完整目標達成。

- [r3-dev](r3-dev/REPORT.md)：base / r2 / r3。
- [r3-test](r3-test/REPORT.md)：base / r2 / r3。
- [main-hero-diagnostic-v1](main-hero-diagnostic-v1/REPORT.md)：base / r2 / r3。
- [fidelity-diagnostic-v2](fidelity-diagnostic-v2/REPORT.md)：base / r2 / r3。
- [main-diagnostic-v3](main-diagnostic-v3/REPORT.md)：base / r2 / r3。

分數必須連同逐案退步、錯誤放行及來源限制閱讀。只有套用模板分類結果，不等於完整技能用途與英雄設定已能自動鑄造。
