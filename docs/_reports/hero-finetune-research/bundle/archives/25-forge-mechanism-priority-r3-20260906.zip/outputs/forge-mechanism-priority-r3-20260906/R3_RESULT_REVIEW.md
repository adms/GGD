# R3 原始實驗結果與逐案裁決

2026-09-06 16:42 Asia/Taipei。原始 R3 已完成，後續診斷另報；不是穩定可用／完整英雄鑄造通過。

## 真實量測

434 筆訓練、3 epochs、327 optimizer steps，BF16 Qwen3.5-4B + LoRA rank16／最後8層／lr5e-6。訓練108.63分鐘，Metal峰值21.88GiB，梯度有限。訓練 probe loss下降不能當作泛化證據。

| 固定資料 | base | R2 | R3 dev選定epoch2 |
|---|---:|---:|---:|
| dev 英雄來源 | 19/21 | 19/21 | 21/21 |
| dev Owner機制 | 35/38 | 35/38 | 36/38 |
| dev 模板 | 15/24 | 23/24 | 24/24 |
| test 英雄來源 | 43/48 | 43/48 | 47/48 |
| test Owner機制 | 37/40 | 37/40 | 36/40 |
| test 模板 | 16/20 | 19/20 | 19/20 |

epoch1/2/3 dev總分為80/83、81/83、79/83，依既定英雄優先與各層安全規則選epoch2，選模早於test。dev Owner94.74%未達95%；test Owner90%且仍有1題錯誤放行，不能四捨五入或用總分102/108掩蓋。相對R2，test英雄修正4題無退步；Owner修正1題、退步2題。

## 親自複核的剩餘錯誤

- `godie-h00l.passive`：原文寫3%最大生命，但未明確寫是哪一方；模型仍支持「明確以敵人最大生命計算」，屬錯誤放行。
- `godie-emns.r`：原文有現存生命30/40/50%及40%AP；否認現存生命的命題應為contradicted，三模型均答not-stated。
- `godie-emns.passive`：原文每點魔力抵3傷害，R3將正確同義描述判為contradicted；R2原本正確。
- `godie-e00r.q`：吞噬敵方英雄並依其剩餘生命回復，R3將正確描述判為contradicted；R2原本正確。不額外推定原文未精確定義的等號邊界。
- `godie-udea`：去死團原創角色被說成FF7角色，應contradicted，三模型均答not-stated。
- cosmetic-separation：外觀交美術、機制單人一次無狀態傷害，三模型均錯誤拒絕。

dev兩個剩餘錯誤都來自`godie-e00s.w`，「擴散」原文與「分裂」命題的同義性／各級比例閱讀是待查假說，不是已證實原因。原dev標籤與分數保持不變；若要改寫題目，必須另建前瞻性對照，不能回填提高分數。

## 下一輪決策

R3保留研究用途，不啟用。補強TRAIN來源的受詞、條件、數字、未知與矛盾區分，維持完整原文與雜湊，不複製dev/test原題到train。R3已揭露test在下一輪只能稱回歸集；另立預先凍結的新題，說明來源家族是否仍重疊。後續診斷不能回頭重選R3。

已核對保存adapter SHA256：`54ca2eb91c3c2313f1911ee4e7026571685776650f1505d2af67bc38bd436c06`；32,480,560 bytes，位置`selected-adapter/`，基底沿用R2保存的原始BF16。未做R3量化／16GB實機驗證，VFX保留測試尚待執行。

逐題證據見`heldout-error-report/`、`selection.json`、`comparison.json`、`training-run.json`。完整main診斷由`post-diagnostics-v3/`另行記錄。
