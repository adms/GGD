## 問題

`tpl-combo-finisher` 的主線卡片目前已是 `enabled`，但 description 仍以現在式宣稱「這張卡是 draft」及「FAMILIES 裡沒有展開路徑」。這會讓讀取模板說明的 Editor 作者／分類模型錯誤拒絕已接線的自動連段收尾家族。

核對版本：`adms/GGD` main `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`（2026-09-06）。

## 可重現證據

1. [模板原始檔](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/content/ability-templates/tpl-combo-finisher.json#L5)：description 最後一段說是 draft、沒有展開路徑；同一檔的 `status` 實際是 `enabled`。
2. [主線 expander](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/expand.ts#L1401)：已註冊 `combo-finisher`，輸出 targeted 的 `comboStrikes`，含 perStrike 與 finisher；上方註解明確將「未接線」限定為 2026-09-02 之前的歷史。
3. 本次在上述 commit 的獨立副本執行 `zTemplateDoc.parse` → `defaultParamsFor` → `expand`：成功，預設 `family: superff7`，每段有 damage／spawnVfx／floatingText，收尾另含 screenFlash／screenShake。沒有把 schema/default 展開成功冒充完整遊戲 E2E。

## 建議修正範圍

- 保留歷史原文，但把過期段落明確標為「2026-09-02 接線前的歷史」，在描述開頭寫清目前已 enabled／可展開。
- 區分「家族模板可用」與「任意英雄連段已完整接好」；不要因這次文案修正宣稱所有技能都已符合 Owner。
- 同步檢查引用描述的 generated catalog／Editor 卡片；應由來源生成，不只修生成物。
- 可加防回歸：目前 enabled 且可 expand 的卡片，不應在有效說明中仍以現在式宣告無展開路徑。歷史紀錄不刪除。

## 查重與界線

已查所有狀態的 `combo-finisher` 相關票（#672、#244、#940），並閱讀已關閉的 #916。它們追蹤家族／積木實作，本票是其落地後尚存的**目前狀態說明矛盾**，不重開既有功能票。本票也不更改技能數值、連段節奏、遊戲實作或特效參數。
