## 說明與機制不一致

`tpl-drain-leech` 的 `leechFlat.origin` 明確說回復施法者；expander 註解也說回施法者。但它輸出的 `heal` 沒有 `applyTo:"self"`，目前 handler 的省略語意是 target，因此回的是被點選的敵人。

核對 main commit：`4793eaaaf2775b2081f5eca5881db32e0aab0ea8`。

## 原始碼與實測證據

- [來源聲明](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/content/ability-templates/tpl-drain-leech.json#L45)：原作回的是施法者；每跳回復折算成一次是另一個已註明的近似。
- [展開器](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/content/templates/expand.ts#L1154)：targeted、targetsEnemies=true，輸出 damage → `heal{amount:{flat:50}}` → dot，heal 未寫 applyTo。
- [heal handler](https://github.com/adms/GGD/blob/4793eaaaf2775b2081f5eca5881db32e0aab0ea8/packages/shared/src/sim/effects/heal.ts#L21)：僅 `applyTo === "self"` 才選 caster，否則使用 ctx.targets。
- 在此 commit 的獨立副本，以真正的 SimWorld + spawnChampion + runEffects，兩名敵對角色都降至 421 HP。抽出**模板實際產出的 heal 節點**執行，結果 caster **421→421**，enemy **421→471**。
- 同場重置 HP，以僅補 `applyTo:"self"` 的測試用控制組執行：caster **421→471**，enemy **421→421**。沒有修改主線或出貨內容。

證據界線：這是實際 handler／受詞重現，**不是整招施放／DOT 時序／視覺 E2E**；但已足以證明回復方向與來源聲明相反。不能只用 schema 成功或 effects deep-equal 宣稱吸血正確。

## 建議驗收

- [ ] 模板回血的受詞與來源裁決一致；不要改全域 heal 的預設，否則會影響正常治療技能。
- [ ] 以敵我都缺血的行為測試驗證「施法者得到回復、受害者不被這個 heal 補血」，並有錯誤受詞突變控制。
- [ ] 檢查這份模板的採用者／產生器來源是否有同型漏寫；由來源修正並再生，不只修生成檔。
- [ ] 「逐跳吸血」與「一次回血」另列近似，沒有 Owner 新裁決前不擅改次數、數值或整招設計。
- [ ] 修正前，分類／訓練資料不可把目前卡片當成已能正確完成汲取的正例。

已查 `drain-leech` 及 drain/heal 相關票，並閱讀 #993 與 #916；#993 是批次採用／等價重構，不包含這個已重現的受詞錯誤。本票作其採用前需排除的資料品質缺陷，不重開舊票。
