# 資料校正與模型驗證狀態

更新：2026-09-06 15:04 Asia/Taipei。R3 正在訓練；此頁不是成效或發行通過報告。

## 已審資料與尚未證明的事

| 資料 | 實際狀態 | 不可外推的結論 |
|---|---|---|
| 舊1,872／188／260 | 已撤回正式核可，不再作為訓練配額 | 筆數或schema不等於品質 |
| R3 53份英雄來源、90份Owner技能 | 原文親自閱讀，指定正／反／未敘述命題已核對 | 不是全部設定／機制原子完整覆蓋 |
| R3 434／83／108 | 625題研究資料已凍結，來源家族分側，正在3 epoch訓練 | 不是人工Gold；未完成推論無成績 |
| R3歷史來源版本 | 2026-08-08 TSV及本地設定；每題提供鎖定來源 | 不代表目前main最新版英雄數值 |
| 最新main 46模板 | 35 enabled、11 draft，完整來源／預設／展開皆存證 | 不是35張遊戲E2E通過 |
| main預設schema | 35張參數與expand成功，33張完整ability schema成功 | expand非空不代表可載入 |
| main診斷候選 | 32候選、3隔離、11draft | 所有新main資料仍 trainingEligible=false |

## 三張隔離卡

| 卡片 | 原因 | 證據／追蹤 |
|---|---|---|
| tpl-drain-leech | heal回敵人而非施法者，受詞錯誤 | main-template-probes.json runtime；[#1046](https://github.com/adms/GGD/issues/1046) |
| tpl-beam-roll | 預設count=1帶spacing，完整schema拒絕 | main-template-probes.json schemas；[#1047](https://github.com/adms/GGD/issues/1047) |
| tpl-dragon-serpent | 預設clipTimeScale沒有clip，完整schema拒絕 | 同上[#1047](https://github.com/adms/GGD/issues/1047) |

main版本釘選 `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`。原始檔、完整參數、展開結果在 `main-template-inventory.json`；各卡審查及隔離狀態在 `main-catalog-review.json`。沒有修改遊戲或把錯誤行為教成正確答案。32張中尚有完整選取／時序／遊戲路徑待驗；例如 pull-throw 已明列選取路徑待查。

## 新增、但絕不當訓練答案的診斷

- `main-diagnostic-v1/`：40題，確認模型依新版目錄，而不是記住舊17張卡的答案。最多2292 prompt tokens，沒有截斷。
- `fidelity-diagnostic-v2/`：18組完整版／漏項／錯誤版提案、114次判讀。檢查完整提案支持度與反向條件涵蓋。保留全部來源原文，引用版號；舊／新初號機設定不混用。
- v1 fidelity草稿保留；v2將AT力場漏項改成「不疊加」，避免以物理傷害措辭間接推論真傷規則造成Gold歧義。未執行任何v1模型推論。
- 新診斷**不重選checkpoint、不替代R3 sealed test**，來源有重疊，因此不能称完全未見測試。
- `post-diagnostics-v1/`：一次性本機接續程序已啟動；先等待原R3流程成功完成，再用GPU鎖依序跑base、R2、R3。實際分數尚未產生。

## R3校正帳本索引

- `personal-source-review.json`：143份來源的指定命題審查，不是整招實作核可。
- `question-review.json`：625題逐題輸入、可接受答案及理由。
- `PRETRAIN_REVIEW.md`：修正、排除、source split與限制。
- `semantic-review.json`：研究訓練准入收據，綁定cases摘要。
- `SOURCE_VERSION_WARNING.md`：歷史來源與目前主線不可混淆。
- `source-snapshot.json` 的 pending欄位是**最初不可變快照**，最新審查看上述外部帳本；不回寫歷史資料假裝一開始就已核可。

## 尚未完成

R3結果與逐案退步稽核；最新主線全部英雄設定的全文權威審核；全必要技能用途／原子機制覆蓋；完整來源提案到模板建議的端到端驗證；量化後保真與16GB實機。任何一項未證明都不標完整目標達成。英雄設定與機制優先，VFX不抵銷這些問題。

## 15:12 英雄來源與出身優先權補查

主線 `main-hero-inventory-v2.json` 盤點71份英雄文件：63份有故事說明、8份缺少說明。R3的53份中49份故事原文與這版主線逐字相同，另外4位（安云、賈修貝爾、藤井八雲、麻倉葉）不在當前內容樹，且全部在主線roster下架名單中；不當成漏抓或擅自恢復。

新增的14份有說明文件已親自全文閱讀，但多數是同名變身態，**不是14個新獨立英雄**。全部71份共有20個變身身體，6份文件同時列入下架；隱藏英雄與下架英雄分開記錄。8份缺故事者不自動借用本體或同名角色設定。

目前49份有明確指定出身，**39份與忽略指定值後的三圍推導不同**。主線 `originOf()` 已改為「明確 origin 優先、沒有才推導」，所以不能沿用早期只從三圍算出身的答案。這不是替模型放寬要求，而是核對新版權威規則。現在的玩法標籤與pitch另行保留，不能把故事中的舊數值當成目前定位裁決。

`hero-source-client.mjs` 已实现版本鎖、同名／變身歧義、下架、隱藏手選／隨機差異、缺原文以及來源摘要校驗。它產生鎖定來源供小模型判讀，不替模型預填判斷答案，不自動啟用英雄。所有主線63份有故事者可解析、8份缺故事者阻擋；4個已下架且不在內容樹的舊ID回報 historical-only。另有4項單元測試與實際Saber／悟空變身／喪標麥可／藤井八雲／初號機案例檢查。

PASSIVE／EX 使用主線 `passiveAbility`／`exAbility` 引用欄位，136個引用全部找到正確slot；不是從runtime component的slot名稱猜。`main-hero-inventory.json` 初稿未收齊這兩類引用，已由v2替代，初稿保留但不作後續來源入口。

新增 `main-hero-diagnostic-v1/` 140題：98題明確出身優先權閱讀控制、42題新文件設定正／反／未敘述判讀。最多826 token，無截斷。**目前尚未執行模型推論，不進訓練**，也不能用閱讀控制分數冒充新英雄設計能力或完全未見泛化。後续排程須在既有R3與已排定診斷之後使用GPU鎖。

這份補查證明了來源／身分與規則對齊，不等於71位全部機制、玩法敘述与遊戲實作都已逐項對帳。原未完成項仍保留。

## 15:22 複合模板與成長受詞校正（優先於前述舊版帳本）

- `main-stack-audit-v1.json`：32張卡的1,024種有序雙卡預設組合中，180種無衝突且通過schema；**不是語意核可矩陣**。含直接真effect測試：拉回＋回復在起飛當格回血，不等抵達。
- `main-growth-receiver-probe.json`：真hook分派確認growth-charge將計數／增量給受害者，不是擊殺者。everyNth=1反例、8個不同受害者計數、只加target=self的控制組全部重現。未模擬八次玩家擊殺E2E，DeathSystem的事件受詞另已核對。
- `main-catalog-review-v2.json`：有效新版帳本為**31候選／4隔離／11draft**，growth-charge因[#1048](https://github.com/adms/GGD/issues/1048)新增隔離。舊32候選帳本保留不可覆寫，但不再當目前推薦能力。
- `main-data-corrections-v2.json`：撤銷main-diagnostic-v1的single-stat-growth正例；三圍effect-only測試不得上升為支援擊殺成長的證據。原R3正例目標中沒有growth-charge，訓練與原封存測試未更改。
- `main-diagnostic-v2/`：校正後40題，最多2251 prompt token，含256輸出reserve仍小於4096；未進訓練。校正器2項測試通過，包含來源版本／非重現證據拒絕與原始帳本不變。
- 舊post-diagnostics-v1因答案校正而在等待階段取消，0階段完成，未持有GPU鎖；不是GPU訓練失敗。新版post-diagnostics-v2已排入40＋114＋140題、base/R2/R3三組對照，等待原R3完成再取得同一GPU鎖。

新增議題#1048已確認OPEN。開票前main已到14098b7，但五個相關檔案blob與4793eaa完全相同；這不是把舊版已修復問題再開票。所有推論仍使用已釘選來源版本，不熱更新正在跑的實驗。

完整機制組合仍待端到端驗收；結構檢查與來源盤點不能替代英雄正確性／全部技能用途的實際改善證據。

## 拉扯投擲待驗項已完成；有效帳本升為v3

`main-pull-throw-probe.json` 已從真castAbility入口確認：ground選取小圈所有敵人，entity指令bad-target；throwDistance=100與1000實際落點相同。不給point的effect-only控制組則隨距離改變。此為實際施法入口／leap狀態證據，不宣稱完整落地傷害E2E。已開並確認[#1050](https://github.com/adms/GGD/issues/1050) OPEN。

有效帳本改為 `main-catalog-review-v3.json`：**30候選／5隔離／11draft**。第五張隔離卡為pull-throw。R3原始train/dev/test沒有它的正例，因此不修改、不重跑；舊診斷也沒有它的正例，但目錄資訊需校正，已另存 `main-diagnostic-v3/`（40題、最多2203 token）。舊版本全部保留為歷史，不再作最新推薦能力宣告。

post-diagnostics-v2在等待階段（0推論）取消；目前有效接續程序是 **post-diagnostics-v3**：英雄140題 → 完整提案114次 → 新版機制40題，各base/R2/R3三臂。新script自身、來源inventory、review及請求全部釘選；hero inventory／catalog與manifest的摘要亦交叉驗證。任何pin變更、取消、期限到或原R3失敗都停止，不自動啟用或偷偷重選checkpoint。

目前模型效果仍待R3實際dev/test與接續診斷；本輪增加的是資料正確性及錯誤能力阻擋的證據，不是新的模型改善百分比。

## 控制組逐案複核與結果自動彙整

`baseline-error-report/REPORT.md` 已由實際base／R2輸出生成：83題dev，69→77正確，錯誤放行均0；改善全在8題模板過度拒絕，5題來源「contradicted／not-stated」混淆未改善。剩餘6題完整來源與答案已再次親自複核，記錄於 `BASELINE_ERROR_REVIEW.md`；沒有更改label或把dev原題搬入train。

`r3-error-report.mjs` 的3項測試通過，會拒絕base／runtime／seed／請求漂移及未完成輸出，逐任務保留修正、退步、錯誤放行與完整模型值。它不挑checkpoint或批准模型。

CPU-only一次性 `r3-evidence-finish.mjs` 已啟動，輸出目錄 `paired-evidence-v1/`；以真PID確認原R3與post-diagnostics-v3存活後等待，受同一期限約束。完成後自動產生R3 dev、R3 test、英雄140題、完整提案114次與新版機制40題共五份配對報告；如果輸出不完整則明列缺失，不冒充完整成效。此程序不取得GPU、不改模型選擇或啟用狀態。

下一步以固定訓練與診斷的真實結果作決策；現階段無需再新增等待腳本、改已釘選資料，或為了有工作可做而盲目擴增訓練。

## 16:53結果更新：R3已完成，R4獨立迭代進行中

以上等待狀態是歷史。現在`run-state.json`及`post-diagnostics-v3/state.json`皆已完成，`paired-evidence-v1/`五份報告、缺失0。R3 epoch2：原test英雄47/48、Owner36/40（錯誤放行1）、模板19/20；尚未達標。補充英雄139/140、完整提案114/114、新main目錄33/40，三組無錯誤放行。詳細結論見`R3_RESULT_REVIEW.md`，不能用補充分數覆蓋原test失敗。

本輪逐案審查已支持進行下一個資料校準實驗，位於`../forge-source-calibration-r4-20260906/`，不改此R3凍結資料／模型。R4保留原434train並增加158個核對過的來源命題；另立54個前瞻性同來源題。原R3test從此只稱回歸。主線有30候選／5隔離／11draft的版本限制不變。

VFX接續評估另揭露24個舊情境家族與R3/R4train共享，屬不同問法的保留測試，不是未見家族Gold。R4接續程序會另報家族隔離部分與重疊部分；沒有把新測試加入train。報告器也補上`vfx-semantic`任務統計顯示，JSON分數算法未變，4項報告測試通過。歷史五份報告保留原樣。

## 18:36 召喚預設實測修正：最新帳本v4

`main-summon-cap-probe-v1.json`證實模板maxAlive預設0與「不設上限」說明相反：真施法ok但0具；正上限2與明確省略cap的控制組各有2具有生命的單位。三個出貨消費者展開皆繼承0，但未冒稱三支完整遊戲E2E。已開並確認[#1076](https://github.com/adms/GGD/issues/1076) OPEN。

`main-catalog-review-v4.json`為最新有效帳本：29候選／6隔離／11draft。召喚是預設契約失效，不是引擎完全不支援召喚；修正前不可無條件推薦。`main-diagnostic-v4/`40題有2個召喚正例因可用性修正改成refuse，新輸入需重新推論。校正器2測試通過；保留全部v3來源與raw，不以新答案重算舊輸出。

R4資料與正在跑的腳本不動。60題新main候選資料已HOLD且从未核准或訓練；下一輪先重新審查v4，再以R4結果決定是否值得訓練，不能以資料量代替正確性。
