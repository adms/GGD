# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| owner-mechanism / base | 113/114 | 1 | 114/114 |
| owner-mechanism / r2 | 113/114 | 1 | 114/114 |
| owner-mechanism / r3 | 114/114 | 0 | 114/114 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r2 / owner-mechanism | 0 | 0 | 113 | 1 |
| base → r3 / owner-mechanism | 1 | 0 | 113 | 0 |
| r2 → r3 / owner-mechanism | 1 | 0 | 113 | 0 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r2 | r3 |
| --- | --- | --- | --- | --- | --- |
| hercules-historical-wrong/forward | owner-mechanism | [{"verdict":"contradicted"}] | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"contradicted"} / pass |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
