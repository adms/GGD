import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
const read=n=>JSON.parse(fs.readFileSync(path.join(here,n),'utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const manifest=read('manifest.json');
const selection=fs.existsSync(path.join(here,'selection.json'))?read('selection.json'):null;
for(const pin of manifest.scorerPins)assert.equal(hash(fs.readFileSync(path.join(root,pin.path))),pin.sha256,'SCORER_CHANGED');
const {score}=await import(path.join(root,'GGD-hero-auto-forge/tools/forge-training/r6-score.mjs'));
const cases=read('cases.private.json'),arms={};
const lines=['# Qwen3.8 本機英雄／機制比較','','下載與推論狀態分開記錄；尚未完成的臂不計為完整測試。',
 '96 題固定分層樣本：英雄設定24、技能原文36、機制計畫36（接受／拒絕各18）。非獨立 Owner Gold，非上線驗收。',
 '27B 為8-bit，Flash-Next為4-bit；差異包含模型架構、參數量及量化，不能單獨歸因參數量。',
 '不推理上限512 tokens；推理為medium、上限4096 tokens；temperature=0。截斷／非JSON列為錯誤，不從推理中找答案。','',
 '| 模型／模式 | 完成題數 | 任務 | 正確 | 錯誤放行 |',
 '| --- | ---: | --- | ---: | ---: |'];
if(selection)lines.splice(2,0,'最新使用者選擇：僅 Qwen3.8-27B 8-bit；Flash-Next已取消下載／測試，部分檔案保留。以下只比較27B不推理與medium推理，不宣稱已完成雙模型比較。','');
for(const name of selection?.models??['27b','flash'])for(const mode of ['plain','thinking']){
 const key=`${name}-${mode}`,file=key+'-raw.json';
 const actual=fs.existsSync(path.join(here,file))?file:fs.existsSync(path.join(here,file+'.partial'))?file+'.partial':null;
 if(!actual)continue;
 const raw=read(actual),tasks={},rows=[],decisions={};
 for(let i=0;i<raw.results.length;i++){
  const r=raw.results[i],c=cases[i];assert.equal(c.id,r.id);assert.equal(c.requestDigest,r.requestDigest);
  const s=score(c,r.value);assert(!r.error||!s.pass);
  const t=tasks[c.comparisonCohort]??={count:0,passed:0,unsafe:0};t.count++;t.passed+=+s.pass;t.unsafe+=+s.unsafe;
  const expectedDecision=c.target.verdict??c.target.decision;
  const bucket=c.comparisonCohort+':'+expectedDecision;
  const b=decisions[bucket]??={count:0,passed:0,unsafe:0};b.count++;b.passed+=+s.pass;b.unsafe+=+s.unsafe;
  rows.push({id:c.id,task:c.task,cohort:c.comparisonCohort,expected:c.acceptedTargets,value:r.value,error:r.error,score:s});
 }
 arms[key]={complete:raw.complete,count:rows.length,tasks,decisions,rows,
  passed:rows.filter(r=>r.score.pass).length,unsafe:rows.filter(r=>r.score.unsafe).length,
  outputErrors:rows.filter(r=>r.error).length,
  generationSeconds:raw.results.reduce((n,r)=>n+r.seconds,0),loadSeconds:raw.metadata.loadSeconds,
  peakMetalGiB:Math.max(0,...raw.results.map(r=>r.peakMetalBytes))/1024**3};
 for(const [task,t] of Object.entries(tasks))lines.push(`| ${key} | ${rows.length}/96${raw.complete?'':'（部分）'} | ${task} | ${t.passed}/${t.count} | ${t.unsafe} |`);
}
if(!Object.keys(arms).length)lines.push('| 尚無推論結果 | 0 | — | — | — |');
const historical=fs.existsSync(path.join(here,'historical-reference.json'))?read('historical-reference.json'):null;
const comparisons={};
const goldFlags=fs.existsSync(path.join(here,'gold-review-flags.json'))?read('gold-review-flags.json'):{};
const sensitivity={};
function sensitivityOf(rows){
 const admitted=rows.filter(r=>!Object.hasOwn(goldFlags,r.id));
 return {count:admitted.length,passed:admitted.filter(r=>r.score.pass).length,unsafe:admitted.filter(r=>r.score.unsafe).length,excluded:rows.filter(r=>Object.hasOwn(goldFlags,r.id)).map(r=>r.id)};
}
function paired(before,after){
 assert.equal(before.length,after.length);
 const result={count:before.length,fixed:[],regressed:[],newUnsafe:[],removedUnsafe:[]};
 for(let i=0;i<before.length;i++){
  const a=before[i],b=after[i];assert.equal(a.id,b.id);
  if(!a.score.pass&&b.score.pass)result.fixed.push(a.id);
  if(a.score.pass&&!b.score.pass)result.regressed.push(a.id);
  if(!a.score.unsafe&&b.score.unsafe)result.newUnsafe.push(a.id);
  if(a.score.unsafe&&!b.score.unsafe)result.removedUnsafe.push(a.id);
 }
 return result;
}
if(historical){
 lines.push('','## 相同96題的4B歷史參考（不是同環境新測）','',
  '以下從既有raw輸出按ID與完整messages digest精確匹配，不重跑4B、不選最好的一次。兩代模型的量化／執行環境不同，不能作參數量的單因子因果比較。',
  '','| 歷史模型 | 正確 | 錯誤放行 |','| --- | ---: | ---: |');
 for(const [name,a] of Object.entries(historical.results)){
  lines.push(`| 4B ${name} | ${a.passed}/96 | ${a.unsafe} |`);
  for(const [key,current] of Object.entries(arms))if(current.complete&&current.count===96)comparisons[`historical-${name}-to-${key}`]=paired(a.rows,current.rows);
 }
}
for(const name of selection?.models??['27b','flash']){
 const a=arms[name+'-plain'],b=arms[name+'-thinking'];
 if(a?.complete&&b?.complete)comparisons[name+'-plain-to-thinking']=paired(a.rows,b.rows);
}
if(Object.keys(comparisons).length){
 lines.push('','## 逐題修正與退步','','| 比較 | 修正 | 退步 | 新增錯誤放行 | 消除錯誤放行 |','| --- | ---: | ---: | ---: | ---: |');
 for(const [k,p] of Object.entries(comparisons))lines.push(`| ${k} | ${p.fixed.length} | ${p.regressed.length} | ${p.newUnsafe.length} | ${p.removedUnsafe.length} |`);
}
if(Object.keys(goldFlags).length){
 lines.push('','## Gold疑義與敏感度（原分数不改）','',
  '以下是助理覆核提出的來源／觸發語意疑義，尚非Owner裁定。主表保留原Gold；敏感度對所有完整模型臂排除相同ID，不把模型答案當Gold。詳見gold-review-flags.json。',
  '','| 完整臂 | 排除疑義後正確 | 錯誤放行 |','| --- | ---: | ---: |');
 for(const [k,a] of Object.entries(arms))if(a.complete)sensitivity[k]=sensitivityOf(a.rows);
 if(historical)for(const [k,a] of Object.entries(historical.results))sensitivity['historical-'+k]=sensitivityOf(a.rows);
 for(const [k,a] of Object.entries(sensitivity))lines.push(`| ${k} | ${a.passed}/${a.count} | ${a.unsafe} |`);
}
if(fs.existsSync(path.join(here,'gold-audit.json'))){
 const audit=read('gold-audit.json');
 assert.equal(hash(fs.readFileSync(path.join(here,'cases.private.json'))),audit.sourceSha256,'AUDITED_CORPUS_CHANGED');
 assert.equal(hash(fs.readFileSync(path.join(here,'gold-audit-notes.json'))),audit.notesSha256,'AUDIT_NOTES_CHANGED');
 assert.equal(hash(fs.readFileSync(path.join(here,'gold-review-flags.json'))),audit.flagsSha256,'AUDIT_FLAGS_CHANGED');
 lines.push('','## 本批逐題來源／Gold覆核','',
  `已助理逐題覆核${audit.count}題（來源${audit.sourceCount}、機制${audit.stackCount}），逐ID依據見gold-audit.json與gold-audit-notes.json。${audit.flaggedIds.length}題保留政策疑義；未改原Gold、未改推論輸入、未投入訓練。`,
  `來源題涵蓋${audit.sourceUnits}個來源ID；${audit.stackCount}個機制輸入只有${audit.uniqueLiteralStackRequests}種不同需求文字，重複版本不可當成新的獨立需求。`,
  '覆核有先前模型輸出暴露，不是盲測或独立Owner認證；只檢查輸入所附歷史來源／目錄，不證明當前Main引擎能力或原作史實。');
}
lines.push('','## 機制計畫：接受／拒絕分開','','| 模式 | Gold | 正確 | 錯誤放行 |','| --- | --- | ---: | ---: |');
for(const [k,a] of Object.entries(arms))for(const decision of ['accept','refuse']){
 const b=a.decisions['mechanism-stack:'+decision];if(b)lines.push(`| ${k} | ${decision} | ${b.passed}/${b.count} | ${b.unsafe} |`);
}
lines.push('','## 執行狀態','');
for(const name of ['27b','flash']){
 const n=name+'-download.json';if(fs.existsSync(path.join(here,n))){const d=read(n);lines.push(`- ${d.repo}：${d.status}；revision ${d.revision}；下載位置 ${d.destination}`);}
}
if(fs.existsSync(path.join(here,'state.json')))lines.push('','```json',JSON.stringify(read('state.json'),null,2),'```');
lines.push('','## 時間與記憶體','');
for(const [k,a] of Object.entries(arms))lines.push(`- ${k}：共用模型載入 ${a.loadSeconds.toFixed(2)} 秒（兩臂只載入一次，不重複加總）；逐題生成合計 ${(a.generationSeconds/60).toFixed(2)} 分鐘；該階段截至當時的worker累積Metal峰值 ${a.peakMetalGiB.toFixed(2)} GiB（不等於整機記憶體）。`);
lines.push('','兩臂之間未reset Metal峰值計數，因此不能把thinking欄當成獨立重測的模式峰值，也不能據兩欄相同宣稱兩模式記憶體完全相等。');
lines.push('','安全限制：僅單一GPU worker；不調高系統 wired limit，不關閉別人的程式。可用記憶體不足、swap增加超過2 GiB、電源拔除或單題超時時停止。',
 '原始輸出與逐題判分見各臂 raw JSON 和 analysis.json；不更改既有微調成品、舊研究收尾狀態或 Editor。','');
fs.writeFileSync(path.join(here,'analysis.json'),JSON.stringify({arms,comparisons,goldFlags,sensitivity,releaseQualified:false},null,2)+'\n');
fs.writeFileSync(path.join(here,'REPORT.md'),lines.join('\n'));
console.log(JSON.stringify(Object.fromEntries(Object.entries(arms).map(([k,v])=>[k,{complete:v.complete,count:v.count,tasks:v.tasks}]))));
