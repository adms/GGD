import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const cases=read(path.join(here,'cases.private.json'));
const {score}=await import(path.join(root,'GGD-hero-auto-forge/tools/forge-training/r6-score.mjs'));
const dirs=['outputs/forge-final-three-hours-20260906/inference-review-run-v1',
 'outputs/forge-owner-remaining-inference-20260907-v1',
 'outputs/community37-inference-full-20260907-v1',
 'outputs/forge-stack-full-inference-20260907-v1'];
const cohortDirectory={'hero-source':dirs[0],'owner-historical':dirs[1],'owner-community37':dirs[2],'mechanism-stack':dirs[3]};
const arms={base:new Map(),r3:new Map(),r7:new Map()},pins=[],metadata=[];
for(const dir of dirs)for(const name of fs.readdirSync(path.join(root,dir))){
 const match=name.match(/(?:^|[-])(base|r3|r7)(?:-raw)?\.json$/);if(!match)continue;
 const file=path.join(root,dir,name),raw=read(file);if(raw.complete!==true||!raw.results)continue;
 const arm=match[1];let used=false;
 for(const c of cases){if(cohortDirectory[c.comparisonCohort]!==dir)continue;const row=raw.results.find(r=>r.id===c.id&&r.requestDigest===c.requestDigest);if(!row)continue;
  const prior=arms[arm].get(c.id);assert(!prior,'DUPLICATE_HISTORICAL_MATCH:'+arm+':'+c.id);
  arms[arm].set(c.id,{id:c.id,requestDigest:c.requestDigest,cohort:c.comparisonCohort,
   value:row.value,error:row.error,score:score(c,row.value),source:path.join(dir,name)});used=true;
 }
 if(used){pins.push({path:path.join(dir,name),sha256:hash(file)});metadata.push({arm,path:path.join(dir,name),metadata:raw.metadata});}
}
const results={};
for(const [arm,map] of Object.entries(arms)){
 assert.equal(map.size,96,'MISSING_HISTORICAL_REFERENCE:'+arm);
 const rows=cases.map(c=>map.get(c.id)),tasks={};
 for(const r of rows){const t=tasks[r.cohort]??={count:0,passed:0,unsafe:0};t.count++;t.passed+=+r.score.pass;t.unsafe+=+r.score.unsafe;}
 results[arm]={count:96,passed:rows.filter(r=>r.score.pass).length,unsafe:rows.filter(r=>r.score.unsafe).length,tasks,rows};
}
const output={createdAt:new Date().toISOString(),newInferenceCalls:0,
 scope:'Historical Qwen3.5-4B native BF16 base/R3/R7 outputs matched by exact ID and messages digest to these 96 cases. Historical runtime/decoding differ from Qwen3.8-27B MLX-VLM; this is contextual reference, not a controlled parameter-count comparison.',
 pins,metadata,results};
fs.writeFileSync(path.join(here,'historical-reference.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(Object.fromEntries(Object.entries(results).map(([k,v])=>[k,{count:v.count,passed:v.passed,unsafe:v.unsafe,tasks:v.tasks}]))));
