# Qwen3.8 本機英雄／機制比較

最新使用者選擇：僅 Qwen3.8-27B 8-bit；Flash-Next已取消下載／測試，部分檔案保留。以下只比較27B不推理與medium推理，不宣稱已完成雙模型比較。

下載與推論狀態分開記錄；尚未完成的臂不計為完整測試。
96 題固定分層樣本：英雄設定24、技能原文36、機制計畫36（接受／拒絕各18）。非獨立 Owner Gold，非上線驗收。
27B 為8-bit，Flash-Next為4-bit；差異包含模型架構、參數量及量化，不能單獨歸因參數量。
不推理上限512 tokens；推理為medium、上限4096 tokens；temperature=0。截斷／非JSON列為錯誤，不從推理中找答案。

| 模型／模式 | 完成題數 | 任務 | 正確 | 錯誤放行 |
| --- | ---: | --- | ---: | ---: |
| 27b-plain | 96/96 | hero-source | 22/24 | 0 |
| 27b-plain | 96/96 | owner-community37 | 18/18 | 0 |
| 27b-plain | 96/96 | owner-historical | 16/18 | 0 |
| 27b-plain | 96/96 | mechanism-stack | 35/36 | 0 |
| 27b-thinking | 96/96 | hero-source | 22/24 | 0 |
| 27b-thinking | 96/96 | owner-community37 | 16/18 | 0 |
| 27b-thinking | 96/96 | owner-historical | 18/18 | 0 |
| 27b-thinking | 96/96 | mechanism-stack | 35/36 | 0 |

## 相同96題的4B歷史參考（不是同環境新測）

以下從既有raw輸出按ID與完整messages digest精確匹配，不重跑4B、不選最好的一次。兩代模型的量化／執行環境不同，不能作參數量的單因子因果比較。

| 歷史模型 | 正確 | 錯誤放行 |
| --- | ---: | ---: |
| 4B base | 78/96 | 5 |
| 4B r3 | 78/96 | 13 |
| 4B r7 | 83/96 | 8 |

## 逐題修正與退步

| 比較 | 修正 | 退步 | 新增錯誤放行 | 消除錯誤放行 |
| --- | ---: | ---: | ---: | ---: |
| historical-base-to-27b-plain | 14 | 1 | 0 | 5 |
| historical-base-to-27b-thinking | 14 | 1 | 0 | 5 |
| historical-r3-to-27b-plain | 14 | 1 | 0 | 13 |
| historical-r3-to-27b-thinking | 14 | 1 | 0 | 13 |
| historical-r7-to-27b-plain | 10 | 2 | 0 | 8 |
| historical-r7-to-27b-thinking | 10 | 2 | 0 | 8 |
| 27b-plain-to-thinking | 2 | 2 | 0 | 0 |

## Gold疑義與敏感度（原分数不改）

以下是助理覆核提出的來源／觸發語意疑義，尚非Owner裁定。主表保留原Gold；敏感度對所有完整模型臂排除相同ID，不把模型答案當Gold。詳見gold-review-flags.json。

| 完整臂 | 排除疑義後正確 | 錯誤放行 |
| --- | ---: | ---: |
| 27b-plain | 90/93 | 0 |
| 27b-thinking | 91/93 | 0 |
| historical-base | 77/93 | 4 |
| historical-r3 | 77/93 | 12 |
| historical-r7 | 81/93 | 8 |

## 本批逐題來源／Gold覆核

已助理逐題覆核96題（來源60、機制36），逐ID依據見gold-audit.json與gold-audit-notes.json。3題保留政策疑義；未改原Gold、未改推論輸入、未投入訓練。
來源題涵蓋57個來源ID；36個機制輸入只有34種不同需求文字，重複版本不可當成新的獨立需求。
覆核有先前模型輸出暴露，不是盲測或独立Owner認證；只檢查輸入所附歷史來源／目錄，不證明當前Main引擎能力或原作史實。

## 機制計畫：接受／拒絕分開

| 模式 | Gold | 正確 | 錯誤放行 |
| --- | --- | ---: | ---: |
| 27b-plain | accept | 17/18 | 0 |
| 27b-plain | refuse | 18/18 | 0 |
| 27b-thinking | accept | 17/18 | 0 |
| 27b-thinking | refuse | 18/18 | 0 |

## 執行狀態

- mlx-community/Qwen3.8-27B-8bit：verified；revision 815b83c0df8ffd1d1b5244cf75fd6ef14fca9ef9；下載位置 /private/tmp/ggd-qwen38-models-20260907/Qwen3.8-27B-8bit
- mlx-community/Qwen3.8-Flash-Next-4bit：cancelled-by-user-model-selection；revision 07b5dc6c54600a359b87f1e53e7adf6351c72a2c；下載位置 /private/tmp/ggd-qwen38-models-20260907/Qwen3.8-Flash-Next-4bit

```json
{
  "status": "complete",
  "startedAt": 1788771017.558679,
  "selectedModels": [
    "27b"
  ],
  "pid": 19689,
  "models": {
    "27b": {
      "status": "complete",
      "availableGiB": 47.701263427734375,
      "existingSwapGiB": 18.77410888671875,
      "requiredAvailableGiB": 33.5033710077405,
      "acPower": true,
      "exitCode": 0,
      "safetyStop": null,
      "seconds": 2975.7240691184998,
      "minimumAvailableGiB": 21.265121459960938,
      "maximumSwapGiB": 19.5120849609375
    }
  },
  "workerPid": null,
  "policy": {
    "training": false,
    "cloud": false,
    "concurrentGpuWorkers": 1,
    "maxDownloadWaitHours": 4,
    "minAvailableGiB": 4,
    "maxSwapIncreaseGiB": 2,
    "maxCaseSeconds": 250,
    "maxWorkerMinutes": 100
  },
  "currentModel": "27b",
  "workerStartedAt": 1788771017.559675,
  "endedAt": 1788773993.641522
}
```

## 時間與記憶體

- 27b-plain：共用模型載入 7.16 秒（兩臂只載入一次，不重複加總）；逐題生成合計 5.33 分鐘；該階段截至當時的worker累積Metal峰值 28.39 GiB（不等於整機記憶體）。
- 27b-thinking：共用模型載入 7.16 秒（兩臂只載入一次，不重複加總）；逐題生成合計 43.95 分鐘；該階段截至當時的worker累積Metal峰值 28.39 GiB（不等於整機記憶體）。

兩臂之間未reset Metal峰值計數，因此不能把thinking欄當成獨立重測的模式峰值，也不能據兩欄相同宣稱兩模式記憶體完全相等。

安全限制：僅單一GPU worker；不調高系統 wired limit，不關閉別人的程式。可用記憶體不足、swap增加超過2 GiB、電源拔除或單題超時時停止。
原始輸出與逐題判分見各臂 raw JSON 和 analysis.json；不更改既有微調成品、舊研究收尾狀態或 Editor。
