import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(here,'../..');
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const put=(name,value)=>fs.writeFileSync(path.join(here,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const sourceNames={main:'outputs/forge-final-three-hours-20260906/inference-review-data-v1/cases.private.json',
 old:'outputs/forge-owner-remaining-inference-20260907-v1/cases.private.json',
 community:'outputs/community37-inference-full-20260907-v1/cases.private.json',
 stack:'outputs/forge-stack-full-inference-20260907-v1/cases.private.json'};
const pools=Object.fromEntries(Object.entries(sourceNames).map(([k,p])=>[k,read(p)]));
const selected=[];
function take(pool,n,cohort){
 assert(pool.length>=n);
 const ordered=pool.slice().sort((a,b)=>hash('qwen38-fixed-v1:'+a.requestDigest).localeCompare(hash('qwen38-fixed-v1:'+b.requestDigest)));
 selected.push(...ordered.slice(0,n).map(c=>({...c,comparisonCohort:cohort})));
}
for(const verdict of ['supported','contradicted','not-stated']){
 take(pools.main.filter(c=>c.task==='hero-source'&&c.target.verdict===verdict),8,'hero-source');
 take(pools.old.filter(c=>c.target.verdict===verdict),6,'owner-historical');
 take(pools.community.filter(c=>c.task==='owner-mechanism'&&c.target.verdict===verdict),6,'owner-community37');
}
for(const decision of ['accept','refuse'])take(pools.stack.filter(c=>c.id!=='inference-review-01536'&&c.target.decision===decision),18,'mechanism-stack');
selected.sort((a,b)=>hash('order:'+a.requestDigest).localeCompare(hash('order:'+b.requestDigest)));
assert.equal(selected.length,96);assert.equal(new Set(selected.map(c=>c.requestDigest)).size,96);
const {score}=await import(path.join(root,'GGD-hero-auto-forge/tools/forge-training/r6-score.mjs'));
for(const c of selected){assert.equal(hash(JSON.stringify(c.messages)),c.requestDigest);for(const t of c.acceptedTargets)assert(score(c,t).pass);}
put('cases.private.json',selected);
const requests=selected.map(({id,messages,requestDigest})=>({id,messages,requestDigest}));
put('requests.json',requests);
put('manifest.json',{
 authorizedBy:'User: 兩個都下載下來測試吧',createdAt:new Date().toISOString(),count:96,
 scope:'Local inference only; no training, cloud GPU, uploads, publication or editor activation.',
 selection:'Fixed salted SHA256 order, stratified by task, source cohort and target; not selected by prior model failure.',
 distribution:{heroSource:24,ownerHistorical:18,ownerCommunity37:18,stackAccept:18,stackRefuse:18},
 requestSha256:hash(fs.readFileSync(path.join(here,'requests.json'))),
 sourcePins:Object.values(sourceNames).map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(root,p)))})),
 scorerPins:['r6-score.mjs','r3-score.mjs','classification-score.mjs','composition-client.mjs'].map(n=>({path:'GGD-hero-auto-forge/tools/forge-training/'+n,sha256:hash(fs.readFileSync(path.join(root,'GGD-hero-auto-forge/tools/forge-training',n)))})),
 modes:[{thinking:false,maxTokens:512},{thinking:true,reasoningEffort:'medium',maxTokens:4096}],
 seed:20260907,temperature:0,limitations:['Small diagnostic sample, not release qualification.','Historical assistant-reviewed labels, not independent Owner Gold.','Different model sizes AND quantization precision; not an isolated parameter-count experiment.','Existing 4B results have different runtime/decoding and are historical reference only.'],
 releaseQualified:false
});
console.log('FROZEN 96 cases; expected targets validated; no GPU use.');
