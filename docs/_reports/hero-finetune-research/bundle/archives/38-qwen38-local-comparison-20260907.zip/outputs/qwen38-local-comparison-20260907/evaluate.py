"""Offline, text-only MLX-VLM evaluation. Requests do not contain answer keys."""
import argparse
import gc
import hashlib
import importlib.metadata as md
import json
import os
import time
from pathlib import Path

for key in ['HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'HF_HUB_DISABLE_TELEMETRY', 'HF_HUB_DISABLE_IMPLICIT_TOKEN']:
    os.environ[key] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['OMP_NUM_THREADS'] = '4'

HERE = Path(__file__).resolve().parent
def put(name, value):
    tmp = HERE / (name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(HERE / name)

def final_json(text, thinking):
    if thinking:
        if '</think>' not in text:
            raise ValueError('UNFINISHED_REASONING')
        text = text.split('</think>', 1)[1]
    elif text.lstrip().startswith('<think>'):
        raise ValueError('UNEXPECTED_REASONING')
    value = json.loads(text.strip())
    if not isinstance(value, dict):
        raise ValueError('NOT_JSON_OBJECT')
    return value

def main():
    p = argparse.ArgumentParser()
    p.add_argument('name', choices=['27b', 'flash'])
    p.add_argument('--doctor', action='store_true')
    args = p.parse_args()
    receipt = json.loads((HERE / (args.name + '-download.json')).read_text())
    manifest = json.loads((HERE / 'manifest.json').read_text())
    data = (HERE / 'requests.json').read_bytes()
    assert hashlib.sha256(data).hexdigest() == manifest['requestSha256']
    requests = json.loads(data)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(receipt['destination'], trust_remote_code=False, local_files_only=True)
    prompts = {}
    for thinking in [False, True]:
        prompts[thinking] = [tokenizer.apply_chat_template(r['messages'], tokenize=False,
            add_generation_prompt=True, enable_thinking=thinking, reasoning_effort='medium') for r in requests]
        counts = [len(tokenizer.encode(s, add_special_tokens=False)) for s in prompts[thinking]]
        assert max(counts) <= 8192, 'PROMPT_BUDGET'
        suffix = prompts[thinking][0][-120:]
        assert ('</think>' not in suffix) if thinking else ('</think>' in suffix), 'THINKING_TEMPLATE'
        put(args.name + ('-thinking' if thinking else '-plain') + '-prompt-check.json',
            {'count': len(counts), 'minTokens': min(counts), 'maxTokens': max(counts),
             'cpuOnly': True, 'thinking': thinking, 'suffix': suffix})
    if args.doctor:
        print('TOKENIZER_AND_BUDGET_PASS', flush=True)
        return
    assert receipt['status'] == 'verified', 'DOWNLOAD_NOT_VERIFIED'
    import mlx.core as mx
    import psutil
    from mlx_vlm import load, stream_generate
    device = mx.device_info()
    memory_limit = min((40 if args.name == '27b' else 108) * 1024**3,
                       device['max_recommended_working_set_size'])
    mx.set_memory_limit(memory_limit)
    mx.set_cache_limit(256 * 1024**2)
    if psutil.virtual_memory().available < receipt['expectedBytes'] + 6 * 1024**3:
        raise RuntimeError('INSUFFICIENT_AVAILABLE_MEMORY_BEFORE_LOAD')
    for mode in ['plain', 'thinking']:
        assert not (HERE / f'{args.name}-{mode}-raw.json').exists(), 'REFUSE_OVERWRITE'
    started = time.monotonic()
    model, processor = load(receipt['destination'], lazy=True, strict=True, trust_remote_code=False)
    mx.eval(model.parameters())
    metadata = {'model': receipt['repo'], 'revision': receipt['revision'], 'device': device,
                'loadSeconds': time.monotonic() - started, 'memoryLimitBytes': memory_limit,
                'versions': {k: md.version(k) for k in ['mlx', 'mlx-vlm', 'transformers', 'psutil']},
                'quantization': '8-bit' if args.name == '27b' else '4-bit',
                'temperature': 0, 'seed': 20260907, 'prefillStepSize': 256,
                'grammar': 'none', 'visualInputs': False, 'training': False}
    print(json.dumps({'event': 'loaded', **metadata}), flush=True)
    for thinking in [False, True]:
        mode = 'thinking' if thinking else 'plain'
        result = {'metadata': {**metadata, 'thinking': thinking,
                  'reasoningEffort': 'medium' if thinking else None}, 'results': [], 'complete': False}
        parse_failures = 0
        for i, request in enumerate(requests):
            if (HERE / 'STOP').exists():
                raise RuntimeError('USER_STOP')
            put('worker-progress.json', {'pid': os.getpid(), 'model': args.name,
                'mode': mode, 'index': i, 'count': len(requests), 'caseStartedAt': time.time()})
            mx.random.seed(20260907)
            start = time.monotonic()
            text = ''
            last = None
            first_token = None
            stream = stream_generate(model, processor, prompts[thinking][i],
                max_tokens=4096 if thinking else 512, temperature=0,
                top_p=1.0, top_k=0, prefill_step_size=256, enable_thinking=thinking,
                seed=20260907, verbose=False)
            try:
                for chunk in stream:
                    if first_token is None:
                        first_token = time.monotonic() - start
                    text += chunk.text
                    last = chunk
                    if time.monotonic() - start > 240:
                        raise TimeoutError('CASE_TIMEOUT')
            finally:
                stream.close()
            error, value = None, None
            try:
                if last is None or last.finish_reason != 'stop':
                    raise ValueError('TOKEN_BUDGET_EXHAUSTED')
                value = final_json(text, thinking)
            except (ValueError, TypeError) as exc:
                error = str(exc)
            row = {**{k: request[k] for k in ['id', 'requestDigest']}, 'text': text,
                   'value': value, 'error': error, 'seconds': time.monotonic() - start,
                   'firstTokenSeconds': first_token, 'peakMetalBytes': mx.get_peak_memory(),
                   'promptTokens': last.prompt_tokens if last else None,
                   'generationTokens': last.generation_tokens if last else None,
                   'generationTps': last.generation_tps if last else None,
                   'finishReason': last.finish_reason if last else None}
            result['results'].append(row)
            put(f'{args.name}-{mode}-raw.json.partial', result)
            print(json.dumps({'event': 'case', 'mode': mode, 'index': i + 1,
                              'seconds': row['seconds'], 'error': error}), flush=True)
            parse_failures = parse_failures + 1 if error else 0
            if parse_failures >= 3:
                raise RuntimeError('THREE_CONSECUTIVE_PROTOCOL_FAILURES')
            gc.collect()
            mx.clear_cache()
        result['complete'] = True
        result['metadata']['peakMetalBytes'] = mx.get_peak_memory()
        put(f'{args.name}-{mode}-raw.json', result)
    print('EVALUATION_COMPLETE', flush=True)

if __name__ == '__main__':
    main()
