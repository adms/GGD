"""Public, revision-pinned download; never sends project data or runs model code."""
import argparse
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN'] = '1'
os.environ['HF_HUB_DISABLE_XET'] = '1'
from huggingface_hub import HfApi, snapshot_download

p = argparse.ArgumentParser()
p.add_argument('name', choices=['27b', 'flash'])
args = p.parse_args()
repo = {'27b': 'mlx-community/Qwen3.8-27B-8bit',
        'flash': 'mlx-community/Qwen3.8-Flash-Next-4bit'}[args.name]
out = Path(__file__).resolve().parent
destination = Path('/private/tmp/ggd-qwen38-models-20260907') / repo.split('/')[1]
destination.mkdir(parents=True, exist_ok=True)
info = HfApi(token=False).model_info(repo, files_metadata=True)
files = [f for f in info.siblings if f.rfilename != '.gitattributes']
total = sum(f.size or 0 for f in files)
assert shutil.disk_usage(destination).free > total + 40 * 1024**3, 'DISK_RESERVE'
receipt = {'repo': repo, 'revision': info.sha, 'destination': str(destination),
           'expectedBytes': total, 'status': 'downloading', 'startedAt': time.time(),
           'files': [{'name': f.rfilename, 'bytes': f.size,
                      'sha256': getattr(f.lfs, 'sha256', None)} for f in files]}
def save():
    tmp = out / (args.name + '-download.json.tmp')
    tmp.write_text(json.dumps(receipt, indent=2) + '\n')
    tmp.replace(out / (args.name + '-download.json'))
save()
print(json.dumps({k: v for k, v in receipt.items() if k != 'files'}), flush=True)
try:
    snapshot_download(repo, revision=info.sha, local_dir=destination,
                      allow_patterns=[f.rfilename for f in files],
                      max_workers=2, token=False)
    for f in receipt['files']:
        path = destination / f['name']
        assert path.stat().st_size == f['bytes'], 'SIZE_MISMATCH:' + f['name']
        if f['sha256']:
            h = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(16 * 1024**2), b''):
                    h.update(block)
            assert h.hexdigest() == f['sha256'], 'HASH_MISMATCH:' + f['name']
        print('VERIFIED ' + f['name'], flush=True)
    receipt.update(status='verified', completedAt=time.time())
    save()
except Exception as exc:
    receipt.update(status='failed', error=repr(exc))
    save()
    raise
