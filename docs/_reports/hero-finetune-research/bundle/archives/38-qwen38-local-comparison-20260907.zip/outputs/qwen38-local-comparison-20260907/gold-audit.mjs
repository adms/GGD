import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const read=n=>JSON.parse(fs.readFileSync(path.join(here,n),'utf8'));
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const cases=read('cases.private.json'),notes=read('gold-audit-notes.json'),flags=read('gold-review-flags.json');
assert.equal(cases.length,96);assert.deepEqual(cases.map(c=>c.id).sort(),Object.keys(notes).sort());
const source=cases.filter(c=>c.task!=='mechanism-stack'),stack=cases.filter(c=>c.task==='mechanism-stack');
const groups=new Map();
for(const c of stack){const request=JSON.parse(c.messages[1].content).request;const ids=groups.get(request)??[];ids.push(c.id);groups.set(request,ids);}
const result={reviewedAt:new Date().toISOString(),reviewer:'assistant; not independent human Owner',
 count:96,sourceCount:source.length,stackCount:stack.length,
 sourceUnits:new Set(source.map(c=>JSON.parse(c.messages[1].content).source.id)).size,
 uniqueLiteralStackRequests:groups.size,stackRepeatedRequests:[...groups].filter(([,ids])=>ids.length>1).map(([request,ids])=>({request,ids})),
 method:'Read all 60 complete source texts and claims, all 36 mechanism requests and all 34 unique allowed-plan definitions. Review only entailment of the supplied historical source/catalog; no claims of current engine or canonical lore verification.',
 priorOutputExposure:true,independentGold:false,trainingAllowed:false,goldChanged:false,
 sourceSha256:hash(fs.readFileSync(path.join(here,'cases.private.json'))),
 notesSha256:hash(fs.readFileSync(path.join(here,'gold-audit-notes.json'))),
 flagsSha256:hash(fs.readFileSync(path.join(here,'gold-review-flags.json'))),
 flaggedIds:Object.keys(flags),
 rows:cases.map(c=>({id:c.id,requestDigest:c.requestDigest,task:c.task,status:flags[c.id]?'needs-policy-clarification':'consistent-under-stated-scope',note:notes[c.id]}))};
fs.writeFileSync(path.join(here,'gold-audit.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({count:result.count,sourceUnits:result.sourceUnits,uniqueLiteralStackRequests:result.uniqueLiteralStackRequests,flags:result.flaggedIds}));
