import json
import unittest
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import run as supervisor
from evaluate import final_json
from run import memory_gate, GiB

class SafetyTests(unittest.TestCase):
    def test_plain(self):
        self.assertEqual(final_json('{"verdict":"supported"}', False), {'verdict':'supported'})
    def test_reasoning_only_final_is_scored(self):
        self.assertEqual(final_json('{"verdict":"supported"}</think>\n{"verdict":"contradicted"}', True), {'verdict':'contradicted'})
    def test_unfinished_reasoning(self):
        with self.assertRaises(ValueError):
            final_json('{"verdict":"supported"}', True)
    def test_prose_not_repaired(self):
        for s in ['Here is JSON: {"verdict":"supported"}', '```json\n{"verdict":"supported"}\n```', '[]']:
            with self.assertRaises(ValueError):
                final_json(s, False)
    def test_gate(self):
        self.assertFalse(memory_gate(112 * GiB, 40 * GiB))
        self.assertFalse(memory_gate(30 * GiB, 35 * GiB))
        self.assertTrue(memory_gate(30 * GiB, 36 * GiB))
    def test_no_answer_key_in_requests(self):
        from pathlib import Path
        requests=json.loads((Path(__file__).parent/'requests.json').read_text())
        self.assertEqual(len(requests), 96)
        for r in requests:
            self.assertEqual(set(r), {'id','messages','requestDigest'})

    def test_supervisor_blocks_without_starting_worker(self):
        with tempfile.TemporaryDirectory(prefix='qwen38-test-') as d:
            folder=Path(d)
            for name in ['27b','flash']:
                (folder/(name+'-download.json')).write_text(json.dumps({'status':'verified','expectedBytes':112*GiB}))
            with patch.object(supervisor,'HERE',folder), patch.object(supervisor,'report'), \
                 patch.object(supervisor.psutil,'virtual_memory',return_value=SimpleNamespace(available=40*GiB)), \
                 patch.object(supervisor.psutil,'swap_memory',return_value=SimpleNamespace(used=0)), \
                 patch.object(supervisor.psutil,'sensors_battery',return_value=SimpleNamespace(power_plugged=True)), \
                 patch.object(supervisor.subprocess,'Popen') as spawn:
                supervisor.main()
                spawn.assert_not_called()
            state=json.loads((folder/'state.json').read_text())
            self.assertEqual(state['status'],'finished-with-incomplete-tests')
            self.assertTrue(all(v['status']=='downloaded-test-blocked-resource' for v in state['models'].values()))

    def test_supervisor_preserves_other_gpu_lock(self):
        with tempfile.TemporaryDirectory(prefix='qwen38-test-') as d:
            folder=Path(d)
            lock=folder/'gpu.lock'
            lock.write_text('{"pid":12345}')
            for name in ['27b','flash']:
                (folder/(name+'-download.json')).write_text(json.dumps({'status':'verified','expectedBytes':30*GiB}))
            with patch.object(supervisor,'HERE',folder), patch.object(supervisor,'LOCK',lock), patch.object(supervisor,'report'), \
                 patch.object(supervisor.psutil,'virtual_memory',return_value=SimpleNamespace(available=50*GiB)), \
                 patch.object(supervisor.psutil,'swap_memory',return_value=SimpleNamespace(used=0)), \
                 patch.object(supervisor.psutil,'sensors_battery',return_value=SimpleNamespace(power_plugged=True)), \
                 patch.object(supervisor.subprocess,'Popen') as spawn:
                supervisor.main()
                spawn.assert_not_called()
            self.assertEqual(lock.read_text(),'{"pid":12345}')
            state=json.loads((folder/'state.json').read_text())
            self.assertTrue(all(v['status']=='downloaded-test-blocked-gpu-lock' for v in state['models'].values()))

if __name__ == '__main__':
    unittest.main()
