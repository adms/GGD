import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {isDeepStrictEqual as equal} from 'node:util';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const read=n=>JSON.parse(fs.readFileSync(path.join(here,n),'utf8'));
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const completeRequired=process.argv.includes('--complete');
const cases=read('cases.private.json'),requests=read('requests.json'),manifest=read('manifest.json'),analysis=read('analysis.json');
assert.equal(cases.length,96);assert.equal(requests.length,96);
assert.equal(new Set(cases.map(c=>c.id)).size,96);
assert.equal(new Set(cases.map(c=>c.requestDigest)).size,96);
assert.equal(hash(fs.readFileSync(path.join(here,'requests.json'))),manifest.requestSha256);
assert.deepEqual(read('selection.json').models,['27b']);
const download=read('27b-download.json');assert.equal(download.status,'verified');
assert.equal(download.repo,'mlx-community/Qwen3.8-27B-8bit');
for(const f of download.files)assert.equal(fs.statSync(path.join(download.destination,f.name)).size,f.bytes);
assert.equal(read('flash-download.json').status,'cancelled-by-user-model-selection');
const audit=read('gold-audit.json');assert.equal(audit.count,96);assert.equal(audit.goldChanged,false);
assert.equal(hash(fs.readFileSync(path.join(here,'cases.private.json'))),audit.sourceSha256);
for(let i=0;i<96;i++){
 const c=cases[i],r=requests[i];assert.equal(c.id,r.id);assert.deepEqual(c.messages,r.messages);
 assert.equal(hash(JSON.stringify(c.messages)),r.requestDigest);
 assert.equal(c.requestDigest,r.requestDigest);
 assert.equal(audit.rows[i].requestDigest,r.requestDigest);assert.equal(audit.rows[i].id,r.id);
}
const verified=[];
for(const mode of ['plain','thinking']){
 const name='27b-'+mode,file=name+'-raw.json';
 if(!fs.existsSync(path.join(here,file))){assert(!completeRequired,'MISSING_COMPLETE_ARM:'+name);continue;}
 const raw=read(file);assert.equal(raw.complete,true);assert.equal(raw.results.length,96);
 assert.equal(raw.metadata.model,download.repo);assert.equal(raw.metadata.revision,download.revision);
 assert.equal(raw.metadata.thinking,mode==='thinking');assert.equal(raw.metadata.temperature,0);
 assert.equal(raw.metadata.training,false);assert.equal(raw.metadata.visualInputs,false);
 let correct=0,unsafe=0;
 for(let i=0;i<96;i++){
  const c=cases[i],r=raw.results[i];assert.equal(c.id,r.id);assert.equal(c.requestDigest,r.requestDigest);
  // Independent exact-target cross-check, not an invocation of the production scorer.
  const pass=c.acceptedTargets.some(t=>equal(t,r.value));
  assert(!r.error||!pass,'ERROR_WITH_ACCEPTED_ANSWER');
  const danger=c.task==='mechanism-stack'?r.value?.decision==='accept'&&!pass:r.value?.verdict==='supported'&&c.target.verdict!=='supported';
  assert.equal(analysis.arms[name].rows[i].score.pass,pass);
  assert.equal(analysis.arms[name].rows[i].score.unsafe,danger);
  correct+=+pass;unsafe+=+danger;
 }
 assert.equal(analysis.arms[name].passed,correct);assert.equal(analysis.arms[name].unsafe,unsafe);
 assert.equal(analysis.arms[name].complete,true);
 verified.push({name,correct,unsafe,count:96});
}
if(completeRequired){
 assert.equal(read('state.json').status,'complete');assert.equal(verified.length,2);
 const failureUnion=new Set(Object.values(analysis.arms).flatMap(a=>a.rows.filter(r=>!r.score.pass).map(r=>r.id)));
 assert.deepEqual([...failureUnion].sort(),Object.keys(read('review-notes.json').cases).sort(),'FAILURE_REVIEW_COVERAGE');
}
const result={verifiedAt:new Date().toISOString(),checksPassed:true,completeExperiment:verified.length===2,
 verifiedArms:verified,independentExactTargetCrossCheck:true,filesizeRecheck:true,sha256RehashedWeightsThisPass:false,
 sourceAuditCount:96,releaseQualified:false,scope:'Result arithmetic, input identity, model revision, selected scope, raw completeness and source-audit coverage. Not production quality certification.'};
fs.writeFileSync(path.join(here,'VERIFICATION.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
