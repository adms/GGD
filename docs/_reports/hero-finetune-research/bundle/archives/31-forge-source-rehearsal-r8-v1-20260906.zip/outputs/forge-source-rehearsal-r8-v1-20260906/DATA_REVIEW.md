# R8預備資料：原文保留、新角色、能力校正

550 train／179 dev／228 test；目前只是資料準備，沒有啟動訓練或選定超參數。

- R7原英雄／Owner來源資料逐筆不變。
- 兩個舊wave terminal-positive保留原文與原答案但退出train；不是直接改成refuse。
- 同數量補入明確不要求獨立任意節拍的line-blast行進＋獨立終點爆炸正例，單卡和多卡接口各一。
- traveling-wave保留無terminal模式；可合法省略terminalBurst，與既有SimWorld無terminal控制的完整ability逐欄相同。
- 所有受影響輸入的目錄同步改寫，新requestDigest逐筆記錄；舊R6/R7分數不重算或洗掉。
- 七角色84 train、21 dev、42 test保持原切分，額外effects不當模板原生能力。
- 所有舊來源／模板／多卡測試範圍保留；不以縮小用途來提高過關率。
- 下一輪若啟動，需要全新控制組評測、固定選模規則、token預算、GPU獨占及明確截止。
