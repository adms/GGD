# 英雄設定／機制優先驗收

英雄設定：**尚未驗證**。完整目標與正式啟用：**未通過**。

機制優先權重：epoch 2；僅以 dev 選擇，與原 macro 選擇相同。

| 機制指標 | 基底 | 微調 |
|---|---:|---:|
| 分類 | 50/68 | 61/68 |
| 決策 | 50/68 | 61/68 |
| 格式 | 18/68 | 68/68 |
| 錯誤接受 | 0 | 0 |

修正 11 題；退步 0 題；兩者皆錯 7 題。

機制研究門檻：未通過；不晉級。特效分數不抵銷機制錯誤。

未解決題目：mechanism-wave-3、mechanism-area-status-3、mechanism-charge-4、mechanism-combo-4、mechanism-sweep-approx-3、mechanism-vertical-jump-4、mechanism-lethal-3。逐題資料見 priority-review.json。

這是助手審查的目錄分類研究集，未驗證完整英雄設定、所有原始技能、任意組合或真實 16GB 裝置。原 A/B 與評分不改寫。
