# 經語意審查的微調結果

狀態：keep-base-do-not-promote。僅研究，未啟用 Editor。

同題 test A/B：主分類 106/132 → 120/132（80.30% → 90.91%）；修正 16、退步 2。Macro 80.51% → 90.95%。

| 任務 | 基底 A | 微調 B |
|---|---:|---:|
| vfx-semantic | 56/64 | 59/64 |
| mechanism-template | 50/68 | 61/68 |

格式 81 → 132，決策 112 → 123，不安全接受 0 → 2。選 epoch 2 只用 dev。

品質門檻 false；零退步門檻 false。任何退步均不自動升級。完整逐項資料：paired-review.json。

## 限制

這是 268/88/132 助手審查研究集，不是舊 1872/188/260 的直接可比分數，也不是 Owner Gold。17張 enabled 卡及85種標準/具名VFX候選；未審英雄分類、其餘VFX與任意多卡組合不在本輪品質承諾。機制意圖共享、VFX目錄可見，不代表未知遊戲或視覺美感泛化。16GB實機未測。

## 錯誤與變動案例

### mechanism-wave-3 — both-wrong

劍士站著不動，丟出會向前飛的劍氣，不是瞬間鋪滿整條路。

- 可接受：`[{"decision":"accept","templateId":"tpl-traveling-wave"},{"decision":"accept","templateId":"tpl-line-sweep"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### vfx-special-ki-cannon-4 — fixed

幫我挑鬥氣光束的既有特效，不是環形震波。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.ki.beam"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.lightning.beam"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.ki.beam"],"reasonCode":"matching-template"}`

### vfx-special-not-found-4 — regressed

目標是寫實角色肖像，不接受煙霧或任何粒子形態。

- 可接受：`[{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}]`
- A：`{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.wind.nova"],"reasonCode":"matching-template"}`

### mechanism-fixed-dot-3 — fixed

範圍彈幕可用固定目標群的連續傷害代替，不需獨立落點或躲彈判定。

- 可接受：`[{"decision":"accept","templateId":"tpl-random-barrage"},{"decision":"accept","templateId":"tpl-orbit-array"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-random-barrage"}`

### mechanism-area-status-3 — both-wrong

群體法術需要逐個作用到範圍敵人並附控制，不是友軍技能。

- 可接受：`[{"decision":"accept","templateId":"tpl-proxy-fanout"},{"decision":"accept","templateId":"tpl-proxy-cast"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### vfx-fx.prim.arcane.slash-0 — both-wrong

只挑特效：奧術風格的新月形斬擊弧。機制另外處理，參數由人工調。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.slash"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.nova"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.nova"],"reasonCode":"matching-template"}`

### vfx-fx.prim.fire.pulse-1 — fixed

美術需求是忽明忽暗的柔光氣場，主題用烈焰，不要幫我實作傷害或改參數。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.fire.pulse"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.fire.nova"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.fire.pulse"],"reasonCode":"matching-template"}`

### mechanism-self-nova-4 — fixed

我已把技能射程限制為0，接著要推薦能對腳邊敵人爆發一次的卡。

- 可接受：`[{"decision":"accept","templateId":"tpl-ground-nova"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-fanout"},{"decision":"accept","templateId":"tpl-orbit-array"},{"decision":"accept","templateId":"tpl-random-barrage"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-instant-blast"}`

### mechanism-charge-4 — both-wrong

地面突進到終點，敵人到落點結算時才被擊退；不是原地發波。

- 可接受：`[{"decision":"accept","templateId":"tpl-charge-push"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### mechanism-combo-4 — both-wrong

一個人吃完固定節奏多連擊，允許原地演出，不要每一下換位置。

- 可接受：`[{"decision":"accept","templateId":"tpl-lock-combo"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### vfx-special-not-damage-4 — regressed

不使用技能機制，光靠套用粒子模板讓敵人死亡。

- 可接受：`[{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.sound.explosion"],"reasonCode":"matching-template"}`

### vfx-special-ki-bolt-3 — fixed

先選氣勁球形飛彈特效，發射機制不用你實作。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.ki.bolt"],"reasonCode":"matching-template"}]`
- A：`{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.ki.bolt"],"reasonCode":"matching-template"}`

### mechanism-combo-3 — fixed

英雄留在演出位置打完整段，目標被鎖住，尾刀才接終結。

- 可接受：`[{"decision":"accept","templateId":"tpl-lock-combo"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-lock-combo"}`

### mechanism-sweep-approx-3 — both-wrong

長條刀氣可以逐漸飛出去，無需一瞬间整條帶子同時扣血。

- 可接受：`[{"decision":"accept","templateId":"tpl-line-sweep"},{"decision":"accept","templateId":"tpl-traveling-wave"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### mechanism-react-3 — fixed

敵人打傷我以後我才回敬他一次；不要求施法前攔截。

- 可接受：`[{"decision":"accept","templateId":"tpl-on-hit-react"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-on-hit-react"}`

### mechanism-jump-3 — fixed

落點碰到障礙就接受改用最近合法位置；拋物線跳躍並落地傷害。

- 可接受：`[{"decision":"accept","templateId":"tpl-leap-strike"},{"decision":"accept","templateId":"tpl-charge-push"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-leap-strike"}`

### mechanism-sweep-approx-4 — fixed

原本想沿線分段打擊；已授權取消分段判定，使用單枚直線波。

- 可接受：`[{"decision":"accept","templateId":"tpl-line-sweep"},{"decision":"accept","templateId":"tpl-traveling-wave"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-line-sweep"}`

### vfx-fx.prim.physical.shockwave-1 — both-wrong

美術需求是滾動擴散的震盪波，主題用武器物理打擊，不要幫我實作傷害或改參數。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.physical.shockwave"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.physical.nova"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.physical.nova"],"reasonCode":"matching-template"}`

### mechanism-charge-3 — fixed

不掃過沿路敵人，只在抵達後用傷害與推撞收尾。

- 可接受：`[{"decision":"accept","templateId":"tpl-charge-push"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-charge-push"}`

### mechanism-point-burst-4 — fixed

一個落點、一個傷害圓、一輪結算，不要彈道。

- 可接受：`[{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-ground-nova"},{"decision":"accept","templateId":"tpl-proxy-cast"},{"decision":"accept","templateId":"tpl-proxy-fanout"},{"decision":"accept","templateId":"tpl-orbit-array"},{"decision":"accept","templateId":"tpl-random-barrage"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-instant-blast"}`

### vfx-fx.prim.holy.explosion-1 — fixed

美術需求是激烈炸開的一團光，主題用聖光，不要幫我實作傷害或改參數。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.holy.explosion"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.holy.nova"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.holy.explosion"],"reasonCode":"matching-template"}`

### vfx-fx.prim.arcane.slash-1 — both-wrong

美術需求是彎月狀刀光，主題用魔力，不要幫我實作傷害或改參數。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.slash"],"reasonCode":"matching-template"}]`
- A：`{"decision":"accept","suggestedTemplateIds":["fx.prim.holy.slash"],"reasonCode":"matching-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.holy.slash"],"reasonCode":"matching-template"}`

### mechanism-mark-4 — fixed

具名標記要有層數，並能對已消耗層數給永久數值加成。

- 可接受：`[{"decision":"accept","templateId":"tpl-mark-stacks"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-mark-stacks"}`

### mechanism-vertical-jump-4 — both-wrong

像原地重踩：先向上跳，回到腳下時傷害四周。

- 可接受：`[{"decision":"accept","templateId":"tpl-leap-strike"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### mechanism-vertical-jump-3 — fixed

起跳和落地的平面座標相同，落地才結算範圍傷害。

- 可接受：`[{"decision":"accept","templateId":"tpl-leap-strike"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-leap-strike"}`

### mechanism-lethal-3 — both-wrong

保命牌消耗後即刻回血、即刻推開敵人；不必先無敵一段時間才治療。

- 可接受：`[{"decision":"accept","templateId":"tpl-mark-stacks"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"refuse","templateId":null}`

### vfx-fx.prim.physical.beam-1 — fixed

美術需求是連成一條長線的能量束，主題用武器物理打擊，不要幫我實作傷害或改參數。

- 可接受：`[{"decision":"accept","suggestedTemplateIds":["fx.prim.physical.beam"],"reasonCode":"matching-template"}]`
- A：`{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","suggestedTemplateIds":["fx.prim.physical.beam"],"reasonCode":"matching-template"}`

### mechanism-self-nova-3 — fixed

range=0 的技能需要一次環形傷害，只打周圍敵人不打自己。

- 可接受：`[{"decision":"accept","templateId":"tpl-ground-nova"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-fanout"},{"decision":"accept","templateId":"tpl-orbit-array"},{"decision":"accept","templateId":"tpl-random-barrage"}]`
- A：`{"decision":"refuse","templateId":null,"suggestedTemplateIds":[],"reasonCode":"no-supported-template"}`
- B：`{"decision":"accept","templateId":"tpl-orbit-array"}`

