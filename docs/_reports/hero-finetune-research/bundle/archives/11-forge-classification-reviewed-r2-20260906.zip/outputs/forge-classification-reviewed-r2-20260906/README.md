# 已審查資料的正式對照執行 R2

## 最新結果

兩轮訓練與固定 A/B、4-bit／8-bit 診斷已完成。優先閱讀 [EXPERIMENT_REPORT.md](EXPERIMENT_REPORT.md) 與 [PRIORITY_RESULTS.md](PRIORITY_RESULTS.md)。機制 test 50/68 → 61/68（修正 11、退步 0），但仍未達採用門檻；英雄設定未驗證。4-bit 明顯退步，8-bit 另新增一題錯誤接受，兩者均不作合格部署版。保持 research-only，不自動啟用。

以下保留原執行背景與約束。

目標恢復後於 2026-09-06 12:35 左右啟動。截止仍為同日15:36:10 Asia/Taipei；Mac-only、Qwen3.5-4B non-thinking，沒有雲端 GPU。

資料以 `relaunch-receipt.json` 逐檔確認與已審版本一致：268訓練／88驗證／132測試。這不是單純把舊2320筆依程式過濾成488筆，而是隔離不可靠產生器後，依核對過的模板能力與特效語意重新出題、逐題審查。審查範圍、實際案例與限制在 `QUALITY_REVIEW.md`；全部問答在 `QUESTION_REVIEW.md`。

原始資料、已取消執行均保留；不沿用任何取消的 adapter。R2 執行順序為 doctor → 基底dev → 最多2個完整epoch → dev選模 → 固定test A/B。先選達到驗證安全／格式門檻的 checkpoint，再比較分類準度。Test不參與選epoch或修改標籤。

真實狀態以 `run-state.json` 與受管理程序為準，不能用本文件代替完成收據。`comparison.json` 尚未出現前不能宣稱微調提升。出現分類退步、決策／格式／安全惡化或未過品質門檻，不替換基底，不自動接入Editor。

本輪已審資料涵蓋34張機制候選（17可用）與85個標準／具名VFX。未審舊英雄定位、任意多卡組合與其餘VFX尚不在品質承諾內；本輪結果不能據此宣稱完整英雄鑄造目標完成。
