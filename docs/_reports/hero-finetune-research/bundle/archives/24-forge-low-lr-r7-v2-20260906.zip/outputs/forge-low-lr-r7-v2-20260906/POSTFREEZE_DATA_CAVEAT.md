# R7凍結後發現的機制能力證據缺陷

2026-09-06 23:41，獨立CPU SimWorld探針重現traveling-wave終點爆炸漏打最後一段新命中者。這不改寫已凍結資料、policy、scorer或原始分數；**本輪只繼續作受控低學習率研究，不允許因原評分表通過而升為可部署模型。** 所有自動報告本來即固定releaseQualified=false、activation=false。

原始證據：`../forge-additional-four-hours-20260906/wave-equivalence-probe-v1.json`；完整根因、主線核對與開票內容：`../forge-additional-four-hours-20260906/WAVE_TERMINAL_ISSUE.md`。

## 逐筆裁定

| 訓練ID | 原答案 | 本次裁定 |
| --- | --- | --- |
| r6-stack-main-candidate-traveling-wave-supported | accept [tpl-traveling-wave] | 撤回「完整能力已驗證」認定；下一版資料須隔離或依新能力證據重建，不再原樣加入新訓練 |
| main-candidate-traveling-wave-supported | accept tpl-traveling-wave | 同上；需求明說終點另有一次爆炸 |
| main-candidate-line-sweep-supported | line-sweep；可接受traveling-wave | 沒要求終點爆炸，本探針未證明其答案錯誤；不得為好看一併扣除 |
| r6-stack-main-candidate-line-sweep-supported | [line-sweep]；可接受[traveling-wave] | 同上；需在後續修正版能力目錄區分無terminal模式 |

R7共810 cases，其中train466/dev158/test186；cases SHA256 `066e0251fb36898e3ffb985dbcd77b1f1cd3135997e7bec74063ae3308746df2`。上列4筆都在train；核心dev/test沒有acceptedTargets包含此模板的題目。但能力目錄出現在148筆train、48筆dev、44筆test的输入，因此不是「只有兩個字串改掉就完成所有資料校正」。

後續post的`main-diagnostic-v4-wave-terminal`及公開入口`manual-wave`也受到oracle能力假設影響。既有40題/10次入口分數仍按凍結標準報告，另附此缺陷，不當成完整runtime-backed準確率。line-blast在探針有相近行進＋終點能力，但尚未證明可滿足所有任意節拍與步距需求，不能直接把所有wave答案改成line-blast。

## 為何不原地修改R7

R7正在驗證和R6完全相同資料／權重／順序下的learning-rate單因素差異。原地刪改資料會破壞釘選與A/B解釋；本次新證據不會消失，而是附加這份永久caveat，後續資料修正必須使用新目錄及新版本，所有臂都重新取得匹配輸入。

23:40:07實際metrics已處理82筆／完整更新80筆，兩個terminal-positive訓練ID尚未出現在此前綴；此事不表示往後不會讀到，也不撤销完整資料已含此風險的判定。

## 尚待工作

建立下一版逐卡能力／答案校正，維持英雄與Owner文字不變；只隔離沒有足夠runtime根據的正例，不能把整個目標縮成永遠refuse或只回答英雄設定。新資料與新模型仍須用原本的完整分類／組合需求驗收。沒有在本次缺陷票內修production或宣告模型合格。
