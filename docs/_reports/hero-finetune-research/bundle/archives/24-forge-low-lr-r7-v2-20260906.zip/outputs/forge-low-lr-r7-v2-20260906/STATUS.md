# R7-v2 低學習率對照：實際執行（2026-09-06 23:26）

**23:25:28已正式進入train，worker PID50111。** base-dev於23:23:43完成、R3-dev於23:25:26完成、doctor成功；兩組各158題的ID／request digest／原始文字／解析值／error與R6完全相同。23:25:55已有前2筆有限loss紀錄，尚未形成第一個累積4的完整更新，不以此宣稱任何品質改善。下方base-dev階段為歷史。

**已啟動，尚在base/R3 dev對照，不是已完成訓練。** R6全部GPU階段結束後，獨立CPU報告恢復完成，才啟動本輪；無GPU重疊。

## 真實程序

- core：exec **18089**／PID **46738**，23:21:51開始；23:23狀態base-dev。程式r7-run-v2.mjs，run-state.json。
- post：exec **3316**／PID **46868**，等待core真正完成並退出，post-v1/state.json。
- entry：exec **97048**／PID **47378**，等待core及post真正完成並退出，manual-entry-v1/state.json。
- finish：exec **85509**／PID **47476**，零GPU，等待上述三程序真正完成並退出，finish-v1/state.json。程式r7-finish-v2.mjs、collector r7-final-report-v2.mjs。

四個接續皆真實啟動，不是文字排程。不重啟本目錄，不修改被釘選的腳本／資料／政策。取消時終止已核實的自有程序及其worker，不刪他人的GPU鎖。

## 凍結對照

R3相同權重warm-start，fresh Adam，單輪466筆、累積4，last8／rank16／scale16／dropout0。只將R6 lr1e-5降為2.5e-6；資料、答案、seed／順序、解碼presence penalty0、scorer與逐題守衛不變。23份資料／證據檔逐位元組核對一致；10份入口17個請求與R6完全相同。92項forge-training CPU測試通過，不等於品質驗收。

仍只評48、96與最後完整checkpoint，平手保留R3。任何原文答對變错、新增錯誤放行或主要任務退步不得採用；post不選模。僅同一步數的R6/R7可作LR比較。63來源題已在R6用過，這輪明稱source-63-regression；其餘也是已曝光回歸，不是獨立Gold。

最晚23:30啟訓、00:45軟停止、00:48硬停止。GPU截至9/7 01:21:10、全部報告截至01:36:10，未再延長；若只完成部分輪次必須按實際筆數報告。無雲端、teacher、參數生成、Editor啟用或push。

## 為何有v2

先前`forge-low-lr-r7-20260906`只CPU準備，沒有任何訓練。R6原finish-v1在比對報告的undefined reason欄位時誤報；JSON存檔會省略該欄位。原failed狀態與腳本保持，獨立finish-v2零GPU重播成功，正式R6報告在`../forge-joint-source-stack-r6-v2-20260906/final-evidence-v2/`。本v2只改接續路徑與JSON正規化比對，非改訓練、標籤、評分或時限。

## 待實際完成

core → post八組三臂 → 公開入口10次 → final-evidence-v1；之後可執行r7-result-audit-v2.mjs本目錄，產生逐題複核包（腳本不冒充已親自審查）。目前沒有R7品質分數、未選定R7新權重、未量化或16GB實機驗證。所有候選仍research-only。
