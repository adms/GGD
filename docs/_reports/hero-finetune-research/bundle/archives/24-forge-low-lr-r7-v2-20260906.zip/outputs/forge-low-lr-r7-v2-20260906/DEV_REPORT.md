# R6 同條件逐題對照

所有模型使用相同輸入與新解碼設定（presence penalty=0）。舊1.5設定分數不覆寫、不混算。多卡格式包含明列計畫契約檢查；高分不取代零錯誤放行或完整範圍驗收。

| 任務／模型 | 正確 | 錯誤放行 | 格式／計畫合法 |
| --- | ---: | ---: | ---: |
| hero-source / base | 19/21 | 0 | 21/21 |
| owner-mechanism / base | 80/89 | 2 | 89/89 |
| mechanism-template / base | 15/24 | 0 | 24/24 |
| mechanism-stack / base | 20/24 | 0 | 24/24 |
| hero-source / r3 | 21/21 | 0 | 21/21 |
| owner-mechanism / r3 | 83/89 | 1 | 89/89 |
| mechanism-template / r3 | 24/24 | 0 | 24/24 |
| mechanism-stack / r3 | 13/24 | 10 | 18/24 |
| hero-source / selected | 21/21 | 0 | 21/21 |
| owner-mechanism / selected | 83/89 | 1 | 89/89 |
| mechanism-template / selected | 24/24 | 0 | 24/24 |
| mechanism-stack / selected | 17/24 | 6 | 22/24 |

逐題完整來源、需求、預期、原始模型值與修正／退步統計見對應JSON。來源／既有測試多已曝光；新多卡題亦是已知計畫家族，不冒稱独立新來源泛化。
