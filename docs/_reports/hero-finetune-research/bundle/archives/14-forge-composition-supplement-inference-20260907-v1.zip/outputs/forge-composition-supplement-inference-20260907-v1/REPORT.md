# 20 題機制組合分類：停止後補測

本輪補齊原先已準備、但未完成基底／R3／R7 配對的組合診斷。只推薦輸入已列出的單卡或多卡計畫，不生成參數、不創造任意組合；缺少任一必要条件就應拒絕。

| 模型 | 正確／20 | 正確率 | 錯誤放行 | 契約合法 | 程序耗時 | Metal 峰值 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| base | 17/20 | 85.00% | 1 | 20/20 | 24.92 秒 | 9.35 GiB |
| r3 | 12/20 | 60.00% | 8 | 17/20 | 28.32 秒 | 9.72 GiB |
| r7 | 12/20 | 60.00% | 8 | 19/20 | 29.34 秒 | 9.72 GiB |

| 預期決策 | 基底正確 | R3 正確 | R7 正確 |
| --- | ---: | ---: | ---: |
| accept | 7/10 | 8/10 | 8/10 |
| refuse | 10/10 | 4/10 | 4/10 |

## 配對差異

- base → r3：修正 1、退步 6、共同正確 11、共同錯誤 2。
- base → r7：修正 1、退步 6、共同正確 11、共同錯誤 2。
- r3 → r7：修正 0、退步 0、共同正確 12、共同錯誤 8。

## 工程守衛不能取代機制正確性

純契約檢查能攔下不在清單的組合與把計畫 ID 當模板 ID，但攔不下合法計畫被用錯需求。以下是離線計數，不是已部署的新保護層：

| 模型 | 非法推薦可被契約擋下 | 契約合法但仍錯誤放行 |
| --- | ---: | ---: |
| base | 0 | 1 |
| r3 | 3 | 5 |
| r7 | 1 | 7 |

R7 較 R3 少了非法組合輸出，但完整需求正確率沒有因此提升。共享冷卻、對象、護盾／回血、取消原傷害、反擊範圍、延遲時序都不能當成稍後調參就能補上的非必要細節；這正是模板推薦仍需完整語意驗證的原因。

## 逐題完整需求與輸出

以下保留全部 20 題，不只挑成功或失敗案例。答案與原始模型輸出未更改。錯誤放行包含「做錯卻說 accept」與推薦非法計畫，不能只看輸出是 JSON。

### composition-buff-restore-train-pattern-a

同一次主動施法，立刻回復我自己的一部分最大生命，並暫時增加我自己的攻擊力；不要等增益到期才回血。

可接受答案：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-life-manipulate","tpl-buff-self"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過

既有理由：兩條self效果同次施法，來源為真實cast測試。
三者均符合固定答案。

### composition-buff-restore-train-pattern-b

我需要一個自用的恢復加強化技能：數值增益有期限，生命回復在施法時直接增加自己目前生命且不超上限。

可接受答案：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-life-manipulate","tpl-buff-self"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；通過

既有理由：同一已測語意的另一措辭，不是獨立機制家族。
三者均符合固定答案。

### composition-buff-restore-ally-instead

同一次施法把增益給我自己，生命回復給我選中的另一位隊友。兩者缺一不可。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；失敗，錯誤放行
- r7：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：已核對组合是self/self，不提供self/target跨瞄準模式合併。
本輪原文／計畫覆核：已列組合限制為 self/self，題目需要 self/另一友軍；不得因 life-manipulate 單卡可以選友軍，就推斷已核對的組合也支援跨對象。兩個微調版本都忽略對象不相容。

### composition-buff-restore-wait-for-expiry

先對自己上數值增益，必須等這個增益自然結束之後才回復自己的生命，不能提前回血。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r7：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過

既有理由：並列效果沒有等待buff到期的相依排程。
三者均符合固定答案。

### composition-buff-restore-shield-not-hp

我自己暫時增加攻擊力，同時取得一面可吸收傷害的護盾；不要把護盾換成生命回復。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-buff-self","tpl-on-hit-react"],"onConflict":"reject"}；失敗，錯誤放行，契約不合法
- r7：{"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：restore是生命加法，不是吸收護盾；沒有已核對的增益加護盾計畫。
本輪原文／計畫覆核：題目必須同時有增益與護盾，清楚禁止以回血取代。候選沒有符合計畫；R3 拼出未列組合且反擊不等於護盾，R7 只選增益卡而漏掉护盾。拒絕表示此列表沒有方案，不是證明引擎永遠不可能。

### composition-buff-restore-replace-kit

同時回復自己生命並把我的整套技能替換成另一套，只有數值提升不算完成。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r7：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過

既有理由：buff-self不更換技能組。
三者均符合固定答案。

### composition-independent-hooks-train-pattern-a

常駐被動：普攻命中追加一段傷害給該目標；我受傷之後回擊當次攻擊者。這兩條機率與冷卻各自獨立，不免除原本受的傷。

可接受答案：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-on-hit-react","tpl-on-attack"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過

既有理由：真實普攻與受傷管線、分離ICD及單一攻擊者都有實測。
三者均符合固定答案。

### composition-independent-hooks-train-pattern-b

一個不需按鍵的被動，同時保有普攻附傷與受擊後只反擊來源敵人的能力；兩種事件分開處理即可。

可接受答案：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-on-hit-react","tpl-on-attack"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；通過

既有理由：允許同一被動內的兩條獨立hook，不要求共享條件。
三者均符合固定答案。

### composition-independent-hooks-shared-cooldown

普攻附傷與受傷反擊必須共用同一個內部冷卻：任一觸發後，另一個也必須一起進入冷卻。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；失敗，錯誤放行
- r7：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：每條hook各自記帳，不是共享冷卻。
本輪原文／計畫覆核：候選明示兩條 hook 各自独立記帳，需求則必須共用同一冷卻。兩個微調版本都選獨立事件組合，是把核心共用條件省略；人工改參數的提示不能補成共享狀態。

### composition-independent-hooks-temporary-button

按下按鍵後，才在接下來八秒內同時獲得普攻附傷和受傷反擊；八秒後兩種效果都消失。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r7：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過

既有理由：核對的是常駐被動，不是有hook的短時主動狀態；buff-self不載入這兩條hook。
三者均符合固定答案。

### composition-independent-hooks-cancel-damage

普攻附傷之外，我受到攻擊時還必須取消那一發原傷害，並把它反彈給來源；事後追加傷害不算。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-hit-react","tpl-single-strike"],"onConflict":"reject"}；失敗，錯誤放行，契約不合法
- r7：{"decision":"accept","templateIds":["tpl-on-hit-react"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：on-hit-react是原傷害後追加傷害，不具有取消原傷害語意。
本輪原文／計畫覆核：題目要求取消原傷害並反彈，on-hit-react 明說在受傷後追加傷害，不會取消。R3 額外拼出未列組合，R7 留下單卡仍缺取消傷害與普攻附傷需求；兩者都不應 accept。

### composition-independent-hooks-area-counter

我普攻時追加傷害；我受傷時反擊周圍所有敵人，不只是打我的那個人。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"}；失敗，錯誤放行
- r7：{"decision":"accept","templateIds":["tpl-on-attack"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：反擊範圍欄位不改變只打事件來源的語意。
本輪原文／計畫覆核：題目明確要求受傷後反擊周圍所有敵人，候選的 on-hit-react 只打施害者。R3 選錯反擊範圍；R7 更只保留普攻卡，漏掉整個受傷反擊。都違反完整涵蓋要求。

### composition-two-immediate-strikes-train-pattern-a

一次對單一敵人施法，立刻分別結算兩筆單體傷害；需要兩次命中結算，不要求中間有間隔。

可接受答案：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}；通過

既有理由：實測重複卡產生兩個damage事件及控制組兩倍掉血。
三者均符合固定答案。

### composition-two-immediate-strikes-train-pattern-b

對我選的敵人連續給兩筆同次施法的傷害，不等第二次按鍵，也不延遲第二筆。

可接受答案：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；失敗
- r3：{"decision":"accept","templateIds":["composition-two-immediate-strikes"],"onConflict":"reject"}；失敗，錯誤放行，契約不合法
- r7：{"decision":"accept","templateIds":["composition-two-immediate-strikes"],"onConflict":"reject"}；失敗，錯誤放行，契約不合法

既有理由：同次施法兩筆的另一措辭，不當作新機制家族。
本輪原文／計畫覆核：需求是同次施法兩筆即時傷害，已列 composition-two-immediate-strikes 並指定兩個重複的 tpl-single-strike。基底的 refuse 是漏推薦；R3/R7 把計畫 ID 填入 templateIds，不是合法模板 ID，不能在評分時偷偷替換修正。

### composition-two-immediate-strikes-delay-second

指定敵人施法的當下立即打第一下，整整一秒後才打第二下；期間施法者仍能自由移動，不進入原地演出。不能在同次結算中立刻打兩筆。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}；失敗，錯誤放行
- r7：{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：重複single-strike没有延時；lock-combo首筆等一個間隔且施法者有原地演出，不符合第一筆即時與自由移動。本集合未列出精確計畫。
本輪原文／計畫覆核：題目要求第一下立即、第二下整整一秒後且可自由移動，已列雙 single-strike 是同次即時兩筆，不具延遲排程。兩個微調版本都用立即兩擊取代必要時序，不能因有兩次傷害就接受。

### composition-two-immediate-strikes-second-key

第一次按鍵只打第一下，玩家再按第二次按鍵才打第二下；不能自動打完。

可接受答案：{"decision":"refuse","templateIds":[],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r3：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過
- r7：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；通過

既有理由：重複卡與預定時間表都不是玩家按鍵確認第二擊。
三者均符合固定答案。

### composition-single-card-controls-single-hit

我只要指定一名敵人造成一次即時傷害，不能無故多打第二次，也不需要其他效果。

可接受答案：{"decision":"accept","templateIds":["tpl-single-strike"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-instant-blast"],"onConflict":"reject"} 或 {"decision":"accept","templateIds":["tpl-proxy-cast"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-single-strike"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-single-strike"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-single-strike"],"onConflict":"reject"}；通過

既有理由：多卡不是愈多愈好；保留已核對單卡等價選項。
三者均符合固定答案。

### composition-single-card-controls-single-buff

只暫時提高我自己的攻擊力，不要額外治療、反擊或改技能組。

可接受答案：{"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"}

- base：{"decision":"refuse","templateIds":[],"onConflict":"reject"}；失敗
- r3：{"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"}；通過

既有理由：單卡已完整涵蓋，不加第二張卡引入副作用。
本輪原文／計畫覆核：只要自身短期攻擊力增益，tpl-buff-self 已完整符合且沒有要求第二張卡。基底拒絕是不必要拒絕，兩個微調版本在此題修正它。

### composition-single-card-controls-single-restore

立即按我自身最大生命的一部分回復我自己的生命，受上限封頂；沒有額外增益。

可接受答案：{"decision":"accept","templateIds":["tpl-life-manipulate"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；失敗，錯誤放行
- r3：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；失敗，錯誤放行
- r7：{"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"}；失敗，錯誤放行

既有理由：單卡restore可設為self，沒有數值增益要求。
本輪原文／計畫覆核：需求明確說沒有額外增益，單張 tpl-life-manipulate 即可；三者都多塞 tpl-buff-self。組合雖在允許列表內，仍違反這個需求，是共同的合法格式／錯誤語意放行。

### composition-single-card-controls-single-react

受到傷害之後，只回擊造成該次傷害的敵人；不免傷，不需要普攻附傷。

可接受答案：{"decision":"accept","templateIds":["tpl-on-hit-react"],"onConflict":"reject"}

- base：{"decision":"accept","templateIds":["tpl-on-hit-react"],"onConflict":"reject"}；通過
- r3：{"decision":"accept","templateIds":["tpl-on-hit-react"],"onConflict":"reject"}；通過
- r7：{"decision":"accept","templateIds":["tpl-on-hit-react"],"onConflict":"reject"}；通過

既有理由：不要為反擊單一用途多塞on-attack。
三者均符合固定答案。

## 使用界線與執行證據

- 原 composition-diagnostic-v2 的 20 題：10 接受、10 拒絕；32 個候選計畫（29 單卡＋3 多卡），包含單卡控制，不是只有多卡題。
- 三個多卡家族是自身增益＋同時回血、兩條獨立事件被動、同次施法兩筆即時單體傷害。已知家族與 train-pattern 不是獨立未見來源，不重選 checkpoint。
- 所有原始 messages／答案／來源 pins 驗證一致，推論前驗證全部 acceptedTargets 的契約；輸入 2915–2939 tokens，輸出預留 256，未截斷。
- temperature=0、presence penalty=0、thinking=false；三者相同輸入與逐題種子，不修補生成結果、不施加 grammar。
- 原系統只要求選輸入既有計畫，拒絕表示此列表無完整方案，不是證明現行遊戲引擎永遠做不到。sourceVersion 與計畫保留原凍結版本，沒有重新執行現行 main 的 runtime 驗收。
- 60 次推論程序合計 82.58 秒；Metal 峰值不是整機 RAM 或耗電量。單次一模型，12 GiB 上限，5 分鐘 GPU 截止。worker 已終止、GPU lock 已釋放，執行前後權重雜湊一致。
- 訓練呼叫 0，未改舊 CANCEL、權重、正式資料、原分數或舊 2695 題隊列。與新 37 名英雄的 555 題分開報告，不合併分母。
- 至少一模型失敗的 9 題全數由助理回讀需求與可選計畫覆核；非獨立 Owner Gold。全範圍模型資格仍未達成，不啟用 Editor。

## 證據檔案

- comparison.json、analysis.json、case-review.json、review-notes.json：逐題配對、覆核與統計。
- base-raw.json、r3-raw.json、r7-raw.json：完整 60 次原始模型輸出。
- PREPARATION.json、token-budget.json、models-before.json、models-after.json、summary.json：凍結、模型與停止證據。
- report.mjs：僅 CPU 重播既有 scorer 並重建報告，不會啟動模型。
