import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {compare} from '../../GGD-hero-auto-forge/tools/forge-training/r6-score.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const cases=read('cases.private.json'),summary=read('summary.json'),names=['base','r3','r7'];
assert.equal(summary.status,'complete');assert.equal(summary.completedCalls,60);assert.equal(summary.trainingCalls,0);assert.equal(summary.workerPid,null);assert(summary.lockReleased);
const arms=names.map(name=>({name,raw:read(name+'-raw.json')})),r=compare(cases,arms);
assert.deepEqual(r,read('comparison.json'));
const stats={};
for(const {name,raw} of arms){
 const s=r.scores[name],group={accept:{total:0,passed:0},refuse:{total:0,passed:0}};
 cases.forEach((c,i)=>{assert.equal(raw.results[i].error,null);assert.equal(raw.results[i].finish,'stop');const g=group[c.target.decision];g.total++;g.passed+=Number(s.rows[i].pass);});
 stats[name]={passed:s.passed,total:s.total,pct:100*s.passed/s.total,unsafe:s.unsafe,schema:s.tasks['mechanism-stack'].schema,illegalAccepts:s.rows.filter(v=>v.unsafe&&!v.schema).length,legalButWrongAccepts:s.rows.filter(v=>v.unsafe&&v.schema).length,group,...summary.arms.find(a=>a.name===name)};
}
const errors=r.rows.filter(e=>names.some(n=>!e.outputs[n].score.pass));
const review=read('review-notes.json');
for(const e of errors){assert(typeof review[e.id]==='string'&&review[e.id].length>10,'UNREVIEWED_ERROR:'+e.id);}
for(const id of Object.keys(review))assert(errors.some(e=>e.id===id),'NOTE_FOR_NON_ERROR');
const rows=r.rows.map(e=>({id:e.id,request:e.input.request,expected:e.expected,originalReviewReason:e.reason,outputs:e.outputs,postInferenceReview:review[e.id]??null,goldChanged:false}));
const analysis={createdAt:new Date().toISOString(),stats,comparisons:r.comparisons,errorUnionCount:errors.length,reviewedErrorCount:Object.keys(review).length,workerSeconds:summary.arms.reduce((n,a)=>n+a.seconds,0),releaseQualified:false,trainingExecuted:false,scope:'20 known-family closed-plan classification regression questions; no current engine or whole-hero certification'};
const lines=['# 20 題機制組合分類：停止後補測','',
 '本輪補齊原先已準備、但未完成基底／R3／R7 配對的組合診斷。只推薦輸入已列出的單卡或多卡計畫，不生成參數、不創造任意組合；缺少任一必要条件就應拒絕。',
 '', '| 模型 | 正確／20 | 正確率 | 錯誤放行 | 契約合法 | 程序耗時 | Metal 峰值 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |'];
for(const n of names){const s=stats[n];lines.push(`| ${n} | ${s.passed}/20 | ${s.pct.toFixed(2)}% | ${s.unsafe} | ${s.schema}/20 | ${s.seconds.toFixed(2)} 秒 | ${s.peakGiB.toFixed(2)} GiB |`);}
lines.push('', '| 預期決策 | 基底正確 | R3 正確 | R7 正確 |','| --- | ---: | ---: | ---: |');
for(const d of ['accept','refuse'])lines.push(`| ${d} | ${names.map(n=>`${stats[n].group[d].passed}/${stats[n].group[d].total}`).join(' | ')} |`);
lines.push('', '## 配對差異','');
for(const c of r.comparisons){const p=c.byTask['mechanism-stack'];lines.push(`- ${c.before} → ${c.after}：修正 ${p.fixed}、退步 ${p.regressed}、共同正確 ${p.bothCorrect}、共同錯誤 ${p.bothWrong}。`);}
lines.push('', '## 工程守衛不能取代機制正確性','',
 '純契約檢查能攔下不在清單的組合與把計畫 ID 當模板 ID，但攔不下合法計畫被用錯需求。以下是離線計數，不是已部署的新保護層：',
 '', '| 模型 | 非法推薦可被契約擋下 | 契約合法但仍錯誤放行 |','| --- | ---: | ---: |');
for(const n of names)lines.push(`| ${n} | ${stats[n].illegalAccepts} | ${stats[n].legalButWrongAccepts} |`);
lines.push('', 'R7 較 R3 少了非法組合輸出，但完整需求正確率沒有因此提升。共享冷卻、對象、護盾／回血、取消原傷害、反擊範圍、延遲時序都不能當成稍後調參就能補上的非必要細節；這正是模板推薦仍需完整語意驗證的原因。');
lines.push('', '## 逐題完整需求與輸出','', '以下保留全部 20 題，不只挑成功或失敗案例。答案與原始模型輸出未更改。錯誤放行包含「做錯卻說 accept」與推薦非法計畫，不能只看輸出是 JSON。','');
for(const row of rows){lines.push(`### ${row.id}`,'',row.request,'',`可接受答案：${row.expected.map(v=>JSON.stringify(v)).join(' 或 ')}`,'');for(const n of names){const o=row.outputs[n];lines.push(`- ${n}：${JSON.stringify(o.value)}；${o.score.pass?'通過':'失敗'}${o.score.unsafe?'，錯誤放行':''}${!o.score.schema?'，契約不合法':''}`);}lines.push('',`既有理由：${row.originalReviewReason}`,row.postInferenceReview?`本輪原文／計畫覆核：${row.postInferenceReview}`:'三者均符合固定答案。','');}
lines.push('## 使用界線與執行證據','',
 '- 原 composition-diagnostic-v2 的 20 題：10 接受、10 拒絕；32 個候選計畫（29 單卡＋3 多卡），包含單卡控制，不是只有多卡題。',
 '- 三個多卡家族是自身增益＋同時回血、兩條獨立事件被動、同次施法兩筆即時單體傷害。已知家族與 train-pattern 不是獨立未見來源，不重選 checkpoint。',
 '- 所有原始 messages／答案／來源 pins 驗證一致，推論前驗證全部 acceptedTargets 的契約；輸入 2915–2939 tokens，輸出預留 256，未截斷。',
 '- temperature=0、presence penalty=0、thinking=false；三者相同輸入與逐題種子，不修補生成結果、不施加 grammar。',
 '- 原系統只要求選輸入既有計畫，拒絕表示此列表無完整方案，不是證明現行遊戲引擎永遠做不到。sourceVersion 與計畫保留原凍結版本，沒有重新執行現行 main 的 runtime 驗收。',
 `- 60 次推論程序合計 ${analysis.workerSeconds.toFixed(2)} 秒；Metal 峰值不是整機 RAM 或耗電量。單次一模型，12 GiB 上限，5 分鐘 GPU 截止。worker 已終止、GPU lock 已釋放，執行前後權重雜湊一致。`,
 '- 訓練呼叫 0，未改舊 CANCEL、權重、正式資料、原分數或舊 2695 題隊列。與新 37 名英雄的 555 題分開報告，不合併分母。',
 `- 至少一模型失敗的 ${errors.length} 題全數由助理回讀需求與可選計畫覆核；非獨立 Owner Gold。全範圍模型資格仍未達成，不啟用 Editor。`,
 '', '## 證據檔案','',
 '- comparison.json、analysis.json、case-review.json、review-notes.json：逐題配對、覆核與統計。',
 '- base-raw.json、r3-raw.json、r7-raw.json：完整 60 次原始模型輸出。',
 '- PREPARATION.json、token-budget.json、models-before.json、models-after.json、summary.json：凍結、模型與停止證據。',
 '- report.mjs：僅 CPU 重播既有 scorer 並重建報告，不會啟動模型。','');
for(const [file,data] of Object.entries({'analysis.json':analysis,'case-review.json':rows}))fs.writeFileSync(path.join(dir,file),JSON.stringify(data,null,2)+'\n');
fs.writeFileSync(path.join(dir,'REPORT.md'),lines.join('\n'));
const pins=['run.mjs','report.mjs','review-notes.json','REPORT.md','analysis.json','case-review.json','comparison.json'].map(name=>({name,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,name))).digest('hex')}));
fs.writeFileSync(path.join(dir,'REPORT_VALIDATION.json'),JSON.stringify({createdAt:new Date().toISOString(),comparisonRecomputed:true,all60Aligned:true,allErrorCasesReviewed:true,releaseQualified:false,pins},null,2)+'\n');
console.log(JSON.stringify(analysis,null,2));
