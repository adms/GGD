# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| vfx-semantic / base | 50/54 | 2 | 54/54 |
| vfx-semantic / r3 | 52/54 | 2 | 54/54 |
| vfx-semantic / r5 | 52/54 | 2 | 54/54 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / vfx-semantic | 3 | 1 | 49 | 1 |
| base → r5 / vfx-semantic | 3 | 1 | 49 | 1 |
| r3 → r5 / vfx-semantic | 0 | 0 | 52 | 2 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r5 |
| --- | --- | --- | --- | --- | --- |
| vfx-fx.prim.ice.shockwave-1 | vfx-semantic | [{"decision":"accept","suggestedTemplateIds":["fx.prim.ice.shockwave"],"reasonCode":"matching-template"}] | {"decision":"accept","suggestedTemplateIds":["fx.prim.ice.nova"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted | {"decision":"accept","suggestedTemplateIds":["fx.prim.ice.shockwave"],"reasonCode":"matching-template"} / pass | {"decision":"accept","suggestedTemplateIds":["fx.prim.ice.shockwave"],"reasonCode":"matching-template"} / pass |
| vfx-fx.cinder-ward-1 | vfx-semantic | [{"decision":"accept","suggestedTemplateIds":["fx.cinder-ward"],"reasonCode":"matching-template"}] | {"decision":"accept","suggestedTemplateIds":["fx.prim.void.nova"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted | {"decision":"accept","suggestedTemplateIds":["fx.cinder-ward"],"reasonCode":"matching-template"} / pass | {"decision":"accept","suggestedTemplateIds":["fx.cinder-ward"],"reasonCode":"matching-template"} / pass |
| vfx-special-not-found-2 | vfx-semantic | [{"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"}] | {"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"} / pass | {"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.nova"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted | {"decision":"accept","suggestedTemplateIds":["fx.prim.arcane.nova"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted |
| vfx-fx.prim.ice.beam-1 | vfx-semantic | [{"decision":"accept","suggestedTemplateIds":["fx.prim.ice.beam"],"reasonCode":"matching-template"}] | {"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"} / supported-template-refused | {"decision":"accept","suggestedTemplateIds":["fx.prim.ice.beam"],"reasonCode":"matching-template"} / pass | {"decision":"accept","suggestedTemplateIds":["fx.prim.ice.beam"],"reasonCode":"matching-template"} / pass |
| vfx-fx.prim.lightning.beam-1 | vfx-semantic | [{"decision":"accept","suggestedTemplateIds":["fx.prim.lightning.beam"],"reasonCode":"matching-template"}] | {"decision":"refuse","suggestedTemplateIds":[],"reasonCode":"no-supported-template"} / supported-template-refused | {"decision":"accept","suggestedTemplateIds":["fx.prim.lightning.dash"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted | {"decision":"accept","suggestedTemplateIds":["fx.prim.lightning.dash"],"reasonCode":"matching-template"} / wrong-or-unsupported-template-accepted |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
