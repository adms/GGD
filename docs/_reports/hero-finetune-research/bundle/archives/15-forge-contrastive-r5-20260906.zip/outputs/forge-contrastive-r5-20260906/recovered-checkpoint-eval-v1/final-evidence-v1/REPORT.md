# R5 本機微調結果與模型卡

產生時間：2026-09-06T13:05:34.266Z。僅整理實測，未自動啟用。

## 選模與訓練狀態

原83題dev選定step 80；後續測試沒有重選。
**本輪訓練未完成。** 只評估既定截止前完整保存的checkpoint；可驗證更新前綴320例。完整原始失敗紀錄保留。

準備資料628train／83dev／162已揭露回歸；受控虛構來源與目錄排序呈現不當成独立Owner新稿。

## 同題核心比較

| 任務 | 未微調 | R3 | 本輪選定 | 本輪錯誤放行 |
| --- | ---: | ---: | ---: | ---: |
| hero-source | 43/48 | 47/48 | 47/48 | 0 |
| owner-mechanism | 82/94 | 87/94 | 88/94 | 2 |
| mechanism-template | 16/20 | 19/20 | 18/20 | 1 |

| 相對R3／任務 | 修正 | 退步 | 仍錯 |
| --- | ---: | ---: | ---: |
| owner-mechanism | 2 | 1 | 5 |
| mechanism-template | 0 | 1 | 1 |
| hero-source | 0 | 0 | 1 |

## 分開報告新來源與回歸

新來源是24份釘選專案說明的72個命題，不冒充最新Owner權威；其他題組多屬已知診斷。

| 題組 | 未微調 | R3 | 本輪選定 | 本輪錯誤放行 |
| --- | ---: | ---: | ---: | ---: |
| fresh-source | 67/72 | 70/72 | 69/72 | 1 |
| current-main-v4 | 19/40 | 31/40 | 36/40 | 3 |
| main-hero-diagnostic-v1 | 137/140 | 139/140 | 140/140 | 0 |
| fidelity-diagnostic-v2 | 113/114 | 114/114 | 114/114 | 0 |
| vfx-test | 55/64 | 60/64 | 60/64 | 4 |
| vfx-family-disjoint | 84/94 | 91/94 | 91/94 | 3 |
| vfx-seen-family-retention | 21/24 | 21/24 | 21/24 | 3 |
| r3-exposed-regression | 96/108 | 102/108 | 103/108 | 2 |
| r4-prospective-same-source-diagnostic | 45/54 | 51/54 | 50/54 | 1 |

完整來源、預期值、模型原值及逐題修正／退步保留在`../post-diagnostics-v1/`的各份REPORT與JSON。只看總正確率不能代替英雄／機制優先審查。

## 必要測量門檻（非完整目標核可）

- originalDev：通過。
- originalTest：未通過。
- freshRepositorySource：未通過。
- currentMain：未通過。
- representativeEntry：通過。

## 真實入口與本機資源

| 入口 | 契約通過 | 對照答案相符 | 推論秒數 | Metal峰值GiB |
| --- | --- | --- | ---: | ---: |
| manual-retaliation | true | true | 0.931 | 9.72 |
| manual-wave | true | true | 0.952 | 9.72 |
| manual-clone | true | true | 0.890 | 9.72 |
| manual-ki-vfx | true | true | 0.948 | 9.13 |

四個代表例只證明入口，不是新泛化分數；12GiB分配限制不是16GB實機。
完整提案入口的modelChecklistPass=true，仍只涵蓋呼叫者提供的必要條件。

## 使用與限制

- 基底revision：851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a；13個檔案已逐bytes摘要核對。
- 基底：/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-classification-reviewed-r2-20260906/native-reference/base。
- adapter：/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/selected-adapter。
- adapter SHA256：4d26b5a23febd38155503d3a2c5c9409c1a199e6b225677cfe2ea32d2e2c6437。
- 目前釘選目錄：29候選／6隔離／11draft，不宣稱與線上自動同步。
- 不推理、不生成參數、不作視覺驗證；未push、未修改遊戲、未自動啟用模型。

- Reliable coverage of all original hero/skill requirements and multi-card composition remains unproven.
- New repository descriptions are not promoted to latest Owner authority; all labels are assistant reviewed.
- Original test and current-main diagnostics are exposed regression, not independent fresh Gold.
- Fresh 72 cases cover 24 new skill texts, not entirely unseen franchises, semantic patterns or pretraining data.
- Whole-proposal checking covers only explicitly supplied requirements.
- Current R5 quantization fidelity and physical 16GB Mac behavior are untested.
- Schema-valid enabled recommendations can still be semantically wrong; no automatic game activation.

任何未通過項或未驗證範圍仍然存在時，不將「流程完成」宣告成「穩定模型／整個目標完成」。
