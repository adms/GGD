# R5 進度與接手（2026-09-06 19:40 Asia/Taipei）

> **21:10 最終狀態**：下方 live／等待均為歷史。原訓練因 TRAINING_STOP_RESERVE 於20:56:10停止，最後metrics為example595，但完整已保存checkpoint只有step80／320筆；原failed不覆寫。獨立 `recovered-checkpoint-eval-v1/` 的 core、post、四題入口及最終報告均完成；額外15題澄清、20題多卡和3個多卡CLI亦完成於 `../forge-additional-four-hours-20260906/recovered-r5-follow-on-v1/`。所有相關程序已正常結束或明示失敗，不重啟舊命令。

> **不採用R5**：dev82/83對R3的81/83，但Owner錯誤放行增加、新來源退步。多卡R3/R5都12/20、8次錯誤放行，低於base17/20、1次；3個多卡入口僅1個語意正確。原4個單卡／VFX入口4/4不能取代這些失敗。詳見 `recovered-checkpoint-eval-v1/final-evidence-v1/REPORT.md` 及額外follow-on報告。仍未量化、未16GB實機、未Editor啟用。

> **20:50自動接續更新**：新exec session6977／PID95931等待本R5 core/post真正結束。其後會自動執行原四題手動入口與最終報告，再跑額外兩組三臂與三個多卡入口；**不要依下方歷史命令另外重複啟動**。狀態見`../forge-additional-four-hours-20260906/follow-on-evaluation-v1/state.json`。若原R5因凍結截止真正失敗，接續也會停止，才按獨立recovery流程處理。step80已另存`checkpoint-archive/step-80/`並驗證位元組，不改選模。

> **20:38更新**：原訓練session41291與等待post的94685仍live；最新log約513／628、step128，尚無R5評分。step80已完整保存並實讀hash核對。新增資料工作與三臂／多卡入口準備在`../forge-additional-four-hours-20260906/EXTENSION.md`；包括完整Owner120題及英雄90題複核候選，均HOLD未訓練。下方19:40／19:49內容是保留的歷史進度，不是最新筆數。R5凍結pins此次重新核對未變。

> **19:55新增授權：總目標截止已延至9/7 01:36:10台灣時間**，GPU總截止01:21:10；見`../forge-additional-four-hours-20260906/`。下方R5自身20:56訓練停止／21:21評估停止是凍結實驗時間，仍保留不改，不能與新的全目標截止混淆。原handle41291在19:55再次確認live，log約173/628。

模型尚未達到穩定可用門檻。R3仍是來源優先的研究對照；R4 Owner由87/94降成86/94，拒絕採用。一般system規則短測也失敗，不延伸到test或R5。

## 正在執行

- 核心：exec session **41291**，父PID32768，19:30:49開始；本次已用原始handle確認live。19:40最近log例65／628、step16／157，尚無R5模型評分。後續讀實際handle和新metrics，勿因觀測timeout重新啟動。
- 接續：exec session **94685**，父PID52127，19:39:29開始；目前等待核心，尚無GPU子階段。會再次確認原父PID活著、核心完成且共用鎖釋放後才推論。
- 核心最晚20:56:10停止訓練；全部GPU最晚21:21:10停止；最終21:36:10。Mac-only，無雲端、無push、無Editor啟用。
- 原train、dev、test、policy、訓練／評分腳本全部釘選，**正在執行時不可改**。新來源與post腳本現在亦已釘選。

## 已完成的新工作

1. `fresh-source-diagnostic-v1/`：親自審查24份新技能專案說明，72題，三種verdict各24；原文／檔案hash／答案理由／來源層級皆保留。對已稽核R2–R5及命名診斷無同技能ID或完整原文曝光。五個作品家族原屬test；不是對預訓練和所有歷史實驗的保證。
2. 來源為釘選main中的w3x-import標記description，不冒充新版Owner或遊戲機制正確。未解placeholder保持未知。新題只作診斷，不入train或dev，不影響選模。
3. 單一資料保全測試通過；CPU tokenizer72題全部適合4096限制（393–538prompt＋256輸出保留）。這些是資料／基礎設施檢查，不是模型通過。
4. `r5-post.mjs`已排隊：base/R3/R5新來源對照，及目前v4目錄40、英雄140、fidelity114、VFX118、原108與54回歸分列，最後真source-predict入口12GiB限制。

## 下一步

核心完成後檢查`selection.json`、`DEV_REPORT.md`、`TEST_REPORT.md`。step0代表沒有選用新微調權重，不能冒稱R5提升。step80／157也必須檢查逐題修正與退步、Owner錯誤放行、當前模板錯誤接受，再判斷收益。

post的`partial-summary.json`隨完成題組更新，全部結束才有`summary.json`。新來源獨立報分，不能與已揭露回歸湊一個總平均掩蓋退步。若只看到loss下降或流程complete，仍不能宣告模型合格。

若訓練在20:56截止被停止，先檢查其真實終止原因與已完成checkpoint；不要改凍結policy或重跑訓練。只可在剩餘授權時間內另記錄可驗證checkpoint的評估，並清楚標示未完成整輪。

完整穩定分類／多卡用途覆蓋與量化保真仍未驗證；12GiB分配cap不是16GB實機。現有七張來源／遊戲差異票保持獨立，不能拿隔離或開票數當fine-tune收益。

## 19:49追加：新版分類入口已準備，GPU尚未跑

`current-template-client.mjs`綁定review v4摘要，拒絕目錄或需求漂移、隔離卡及多餘參數；`classification-predict.py`補上實際輸入摘要／catalog驗證。JS→Python真preflight測試通過，原VFX氣功測試通過，py_compile及syntax check通過。這些是工程保全，不是模型準確率。

`manual-entry-check-v1/`四題已凍結，`preparation.json`釘選新版入口腳本與請求。`manual-entry-preflight-superseded-v1/`是尚未GPU執行的舊準備，僅保存欄位順序比較修正前的歷史，不應執行或當結果。訓練仍在原session41291、post仍在94685，兩者19:46已再次確認live；當時log到example113／step28。

核心及post完成後，先看真實模型結果，再從GGD-hero-auto-forge執行（同一GPU截止21:21:10）：

```sh
node tools/forge-training/current-template-entry-check.mjs run \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-contrastive-r5-20260906' \
  /private/tmp/ggd-forge-mlx-20260906-venv/bin/python \
  /private/tmp/ggd-forge-training-runtime
```

`run`在目前核心未完成時拒絕、未啟动GPU的守衛已實測。真正結果要讀`manual-entry-check-v1/summary.json`；不能把四個代表案例誇成新泛化或穩定模型證明。若核心因時間停止而沒有選模，先处理已保存checkpoint的明示部分訓練評估，勿硬改原run-state讓入口通過。

## 19:55追加：截止備援與最終報告器

- `r5-checkpoint-recovery.mjs ORIGINAL_R5_ROOT PYTHON RUNTIME`僅接受因TRAINING_STOP_RESERVE真正終止的核心、已終止post、已釋放GPU鎖及完整已保存checkpoint。輸出新`recovered-checkpoint-eval-v1/`，原失敗run不改。仍活著／前綴metrics不完整時拒絕的CPU測試通過；沒有實際啟用備援或再訓練。
- 恢復評估如有必要且成功，後續`r5-post.mjs`與manual-entry準備／執行改指向該新根目錄；不可把原R5failed寫成complete。這條分支會明示部分訓練，仍使用原dev排序與原test。
- `r5-final-report.mjs COMPLETED_RUN_ROOT`重播原始分數、dev排序、各補充題組，核對base／adapter和入口證據。必須core、post、manual-entry皆真正完成；目前INCOMPLETE_CORE拒絕已驗證，未產生最終報告。正常與部分checkpoint路徑都不自動啟用模型。
- 若後續新版本使用額外四小時，必須另建政策與資料版本，引用明確新授權；R5所有凍結pins保持不變。
