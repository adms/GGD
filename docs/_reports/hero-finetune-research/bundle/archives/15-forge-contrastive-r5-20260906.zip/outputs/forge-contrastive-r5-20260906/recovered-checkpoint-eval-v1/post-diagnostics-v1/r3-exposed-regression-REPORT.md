# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| hero-source / base | 43/48 | 0 | 48/48 |
| hero-source / r3 | 47/48 | 0 | 48/48 |
| hero-source / r5 | 47/48 | 0 | 48/48 |
| owner-mechanism / base | 37/40 | 1 | 40/40 |
| owner-mechanism / r3 | 36/40 | 1 | 40/40 |
| owner-mechanism / r5 | 38/40 | 1 | 40/40 |
| mechanism-template / base | 16/20 | 0 | 20/20 |
| mechanism-template / r3 | 19/20 | 0 | 20/20 |
| mechanism-template / r5 | 18/20 | 1 | 20/20 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / owner-mechanism | 1 | 2 | 35 | 2 |
| base → r3 / mechanism-template | 3 | 0 | 16 | 1 |
| base → r3 / hero-source | 4 | 0 | 43 | 1 |
| base → r5 / owner-mechanism | 1 | 0 | 37 | 2 |
| base → r5 / mechanism-template | 3 | 1 | 15 | 1 |
| base → r5 / hero-source | 4 | 0 | 43 | 1 |
| r3 → r5 / owner-mechanism | 2 | 0 | 36 | 2 |
| r3 → r5 / mechanism-template | 0 | 1 | 18 | 1 |
| r3 → r5 / hero-source | 0 | 0 | 47 | 1 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r5 |
| --- | --- | --- | --- | --- | --- |
| owner-mechanism-godie-emns.r-no | owner-mechanism | [{"verdict":"contradicted"}] | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion |
| owner-mechanism-godie-h00l.passive-unknown | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"supported"} / unsupported-source-claim-accepted |
| hero-source-godie-h00l-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| r3-cosmetic-separation-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-single-strike"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-cast"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| owner-mechanism-godie-emns.passive-yes | owner-mechanism | [{"verdict":"supported"}] | {"verdict":"supported"} / pass | {"verdict":"contradicted"} / supported-source-claim-rejected | {"verdict":"supported"} / pass |
| hero-source-godie-emns-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| owner-mechanism-godie-e00r.q-yes | owner-mechanism | [{"verdict":"supported"}] | {"verdict":"supported"} / pass | {"verdict":"contradicted"} / supported-source-claim-rejected | {"verdict":"supported"} / pass |
| r3-rescue-shift-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-teleport"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-teleport"} / pass | {"decision":"accept","templateId":"tpl-teleport"} / pass |
| r3-ground-curse-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-proxy-cast"},{"decision":"accept","templateId":"tpl-proxy-fanout"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-proxy-cast"} / pass | {"decision":"accept","templateId":"tpl-proxy-cast"} / pass |
| hero-source-godie-udea-no | hero-source | [{"verdict":"contradicted"}] | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion |
| r3-blink-consent-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-teleport"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-teleport"} / pass | {"decision":"accept","templateId":"tpl-teleport"} / pass |
| hero-source-godie-osam-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| owner-mechanism-godie-emns.ex-unknown | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| r3-mark-no-delay-no | mechanism-template | [{"decision":"refuse","templateId":null}] | {"decision":"refuse","templateId":null} / pass | {"decision":"refuse","templateId":null} / pass | {"decision":"accept","templateId":"tpl-mark-stacks"} / wrong-or-unsupported-template-accepted |
| hero-source-godie-u00n-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
