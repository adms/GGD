# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| mechanism-template / base | 19/40 | 0 | 40/40 |
| mechanism-template / r3 | 31/40 | 3 | 40/40 |
| mechanism-template / r4 | 36/40 | 3 | 40/40 |
| mechanism-template / r5 | 36/40 | 3 | 40/40 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / mechanism-template | 13 | 1 | 18 | 8 |
| base → r4 / mechanism-template | 18 | 1 | 18 | 3 |
| base → r5 / mechanism-template | 18 | 1 | 18 | 3 |
| r3 → r4 / mechanism-template | 5 | 0 | 31 | 4 |
| r3 → r5 / mechanism-template | 5 | 0 | 31 | 4 |
| r4 → r5 / mechanism-template | 0 | 0 | 36 | 4 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r4 | r5 |
| --- | --- | --- | --- | --- | --- | --- |
| main-diagnostic-v4-blink-attack | mechanism-template | [{"decision":"accept","templateId":"tpl-blink-strike"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-blink-strike"} / pass | {"decision":"accept","templateId":"tpl-blink-strike"} / pass |
| main-diagnostic-v4-point-periodic | mechanism-template | [{"decision":"accept","templateId":"tpl-periodic-field"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass |
| main-diagnostic-v4-caster-periodic | mechanism-template | [{"decision":"accept","templateId":"tpl-periodic-field"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass |
| main-diagnostic-v4-self-restore-add | mechanism-template | [{"decision":"accept","templateId":"tpl-life-manipulate"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v4-friend-restore | mechanism-template | [{"decision":"accept","templateId":"tpl-life-manipulate"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-life-manipulate"} / pass | {"decision":"accept","templateId":"tpl-life-manipulate"} / pass |
| main-diagnostic-v4-segmented-sweep | mechanism-template | [{"decision":"accept","templateId":"tpl-line-sweep"},{"decision":"accept","templateId":"tpl-traveling-wave"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass |
| main-diagnostic-v4-wave-terminal | mechanism-template | [{"decision":"accept","templateId":"tpl-traveling-wave"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-line-blast"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-line-blast"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-line-blast"} / wrong-or-unsupported-template-accepted |
| main-diagnostic-v4-sweep-repeat | mechanism-template | [{"decision":"refuse","templateId":null}] | {"decision":"refuse","templateId":null} / pass | {"decision":"accept","templateId":"tpl-line-sweep"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-line-sweep"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-line-sweep"} / wrong-or-unsupported-template-accepted |
| main-diagnostic-v4-moving-model-burst | mechanism-template | [{"decision":"accept","templateId":"tpl-line-blast"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-line-blast"} / pass | {"decision":"accept","templateId":"tpl-line-blast"} / pass | {"decision":"accept","templateId":"tpl-line-blast"} / pass |
| main-diagnostic-v4-radial-damage | mechanism-template | [{"decision":"accept","templateId":"tpl-radial-burst"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-radial-burst"} / pass | {"decision":"accept","templateId":"tpl-radial-burst"} / pass | {"decision":"accept","templateId":"tpl-radial-burst"} / pass |
| main-diagnostic-v4-combo-family | mechanism-template | [{"decision":"accept","templateId":"tpl-combo-finisher"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-combo-finisher"} / pass | {"decision":"accept","templateId":"tpl-combo-finisher"} / pass | {"decision":"accept","templateId":"tpl-combo-finisher"} / pass |
| main-diagnostic-v4-combo-finisher-ref | mechanism-template | [{"decision":"accept","templateId":"tpl-lock-combo"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-lock-combo"} / pass | {"decision":"accept","templateId":"tpl-lock-combo"} / pass | {"decision":"accept","templateId":"tpl-lock-combo"} / pass |
| main-diagnostic-v4-mark-immediate | mechanism-template | [{"decision":"accept","templateId":"tpl-mark-stacks"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-mark-stacks"} / pass | {"decision":"accept","templateId":"tpl-mark-stacks"} / pass |
| main-diagnostic-v4-rally-only | mechanism-template | [{"decision":"accept","templateId":"tpl-teleport"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-teleport"} / pass | {"decision":"accept","templateId":"tpl-teleport"} / pass | {"decision":"accept","templateId":"tpl-teleport"} / pass |
| main-diagnostic-v4-attack-direction | mechanism-template | [{"decision":"accept","templateId":"tpl-on-attack"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-attack"} / pass | {"decision":"accept","templateId":"tpl-on-attack"} / pass | {"decision":"accept","templateId":"tpl-on-attack"} / pass |
| main-diagnostic-v4-react-direction | mechanism-template | [{"decision":"accept","templateId":"tpl-on-hit-react"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass |
| main-diagnostic-v4-plain-hit | mechanism-template | [{"decision":"accept","templateId":"tpl-single-strike"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-cast"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-single-strike"} / pass | {"decision":"accept","templateId":"tpl-single-strike"} / pass | {"decision":"accept","templateId":"tpl-single-strike"} / pass |
| main-diagnostic-v4-root-circle | mechanism-template | [{"decision":"accept","templateId":"tpl-proxy-cast"},{"decision":"accept","templateId":"tpl-proxy-fanout"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-proxy-fanout"} / pass | {"decision":"accept","templateId":"tpl-proxy-fanout"} / pass | {"decision":"accept","templateId":"tpl-proxy-cast"} / pass |
| main-diagnostic-v4-charge-end | mechanism-template | [{"decision":"accept","templateId":"tpl-charge-push"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-charge-push"} / pass | {"decision":"accept","templateId":"tpl-charge-push"} / pass |
| main-diagnostic-v4-vertical-jump | mechanism-template | [{"decision":"accept","templateId":"tpl-leap-strike"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-leap-strike"} / pass | {"decision":"accept","templateId":"tpl-leap-strike"} / pass |
| main-diagnostic-v4-self-stat-only | mechanism-template | [{"decision":"accept","templateId":"tpl-buff-self"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-buff-self"} / pass | {"decision":"accept","templateId":"tpl-buff-self"} / pass | {"decision":"accept","templateId":"tpl-buff-self"} / pass |
| main-diagnostic-v4-roster-approved | mechanism-template | [{"decision":"accept","templateId":"tpl-random-barrage"},{"decision":"accept","templateId":"tpl-orbit-array"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-periodic-field"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateId":"tpl-periodic-field"} / wrong-or-unsupported-template-accepted |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
