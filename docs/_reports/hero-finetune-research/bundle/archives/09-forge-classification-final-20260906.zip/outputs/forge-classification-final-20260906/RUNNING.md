# 四小時：分類與模板推薦模型

最新使用者目標：分類／模板推薦準度優先；参数建議不影響分類分數；特效只推薦現成模板，其他參數留給人工。

時間盒：2026-09-06 11:36:10–15:36:10 Asia/Taipei。原八小時實驗不覆寫；本輪 Mac-only、Qwen3.5-4B、不推理、無雲端 GPU。最後15分鐘保留報告；不自行延長。

資料已固定：1872 train、188 dev、260 test，涵蓋7個任務（機制模板、模板組合、既有特效綁定沿用、自然語言特效推薦、能力狀態、行為分類、英雄分類）。完整來源盤點34模板、632特效、461技能、498行為分類、53英雄分類；其中17模板 enabled，17 draft 只作不支援該模板的判斷資料。85筆隔離記錄含不合法模板組合与一筆缺行為證據的歷史分類；详見 validation.json。

本輪不是單模板擴增，也不是將舊 Owner 原文與不一致 JSON 強行配成正解。全部題目為程式依現有註冊表／分類紀錄構造，並保留來源及限制。catalog-aware、綁定沿用與跨措辭任務各自報分，不能混称未知需求或美感已驗證。

## 執行入口與狀態

`GGD-hero-auto-forge/tools/forge-training/classification-run.mjs` 已啟動。run-state.json 是最新階段；worker-lease.json 記錄受管理子程序，但是否仍活著必須查實際程序／執行 session，不能只信 lease。

流程：doctor → 未微調 dev → 乾淨 BF16 基底、全資料1 epoch LoRA → 候選 dev → 選定候選封存 → test A/B。rank16、最後8層、learning rate5e-6、accumulation4。所有抽樣與前處理 A/B 一致。模型與資料未更換、輸出不帶參數，依任務 macro 計分；分類錯誤不能用參數分數補償。另計格式／不安全接受守衛。

doctor 已驗證1872筆完整載入，max sequence1558 tokens、沒有截斷、completion-only loss、MLX Metal 可用。第一個預備版本於正式訓練前取消，以修正標準／大型 VFX 模板的名稱歧義；原記錄留在 forge-classification-v2-20260906，不作新結果使用。

完成時會產出 comparison.json、selection.json、selected-adapter/；沒有這些實際檔案就不能聲稱訓練／測試完成。主要研究門檻：macro≥95%、各任務≥90%、不安全接受0、格式全通過；仍須另外驗證實際推薦入口與量化／重載，才可稱可穩定使用。

## 推薦入口

classification-catalog.mjs 匯出公開模板資訊，不帶題目答案；classification-client.mjs 依使用者需求準備模型請求，VFX 大目錄先做關鍵字候選檢索，再由模型選擇。它不是模型準度評分或已完成推論。

ki-beam-request.json 是使用者氣功砲範例。選出的模板可交給人工套用／微調；輸出不得含 alpha、scale、delay 等特效欄位，不得引用候選外或不可用模板，且不自動啟用 Editor。

未 commit／push，未修改遊戲內容、現有 Editor 或發布旗標。
