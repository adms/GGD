# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| owner-mechanism / base | 12/15 | 2 | 15/15 |
| owner-mechanism / r3 | 13/15 | 1 | 15/15 |
| owner-mechanism / selected | 12/15 | 2 | 15/15 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / owner-mechanism | 2 | 1 | 11 | 1 |
| base → selected / owner-mechanism | 1 | 1 | 11 | 2 |
| r3 → selected / owner-mechanism | 0 | 1 | 12 | 2 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | selected |
| --- | --- | --- | --- | --- | --- |
| source-clarification-e00r.q-2 | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| source-clarification-h00l.passive-2 | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"supported"} / unsupported-source-claim-accepted |
| source-clarification-emns.passive-1 | owner-mechanism | [{"verdict":"contradicted"}] | {"verdict":"contradicted"} / pass | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion |
| source-clarification-h00l.r-2 | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"supported"} / unsupported-source-claim-accepted | {"verdict":"not-stated"} / pass | {"verdict":"supported"} / unsupported-source-claim-accepted |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。

## 診斷限制

Same-input post-selection diagnostic only. Keep the original benchmark scores and denominators; clarified claims are not necessarily equivalent and are not independent new-source generalization.
