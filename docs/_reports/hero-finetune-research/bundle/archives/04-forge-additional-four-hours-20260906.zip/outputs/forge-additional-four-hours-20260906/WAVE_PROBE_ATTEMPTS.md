# 波浪分類邊界探針紀錄

2026-09-06 23:31，首次執行session97945 exit1：`TypeError: Cannot read properties of undefined (reading 'x')`，位於vec2.sub → abilitySystem.ts:664 → probe run:37。探針誤傳`{type:"point",x,z}`，實際介面使用`{type:"point",point:{x,z}}`。

首次沒有產生正式結果檔，未進入傷害比較；這是測試輸入錯誤，不能列為遊戲或模型缺陷。只修探針，原production、模板及R7資料均不變。後续结果须另以真实SimWorld与控制组判断。

第二次session91868 exit1，`FIXTURE_TARGET_MOVED`：目標從x=-29.073333333333334移到-29.66。關閉autoEngage與繳械不足以固定靶子位置，沒有輸出正式結果；改用既有root狀態固定測量目標，不修改sim。此失敗仍是夾具控制不足，不是波浪機制結論。
