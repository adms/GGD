# [bug] traveling-wave 終點爆發漏打最後一段新命中的目標

## 已重現的問題

`tpl-traveling-wave` 宣告可帶終點爆發，expander 註解亦明說最後一段「追加」。但是同樣位於終點爆炸範圍內的目標，若先前段已命中，會收到沿途與終點共兩次傷害；若最後一段才首次命中，反而只收到一次。結果依命中歷史而異。

這是技能機制／模板能力缺陷，不是模型訓練或特效視覺品質問題。未修改 production，未部署，未要求修改個別英雄技能。

## 可重現條件與結果

已完整重現於 `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`：真正 template params/schema → expand/merge → ability schema → damage/aoe tier resolvers → `castAbility` → `SimWorld.step()`。兩個 seed：20260906、20260907，結果一致。

模板覆寫（其餘由 `defaultParamsFor` 取得）：

```json
{"stepSize":200,"stepCount":4,"stepIntervalSec":0.1,"aoePerStep":50,"terminalBurst":200,"damage":{"perRank":[200],"ratios":[]},"damageType":"true","castTimeSec":0}
```

`stepSize`／範圍為模板 wc3u，經真實解析後每段前進約3.67U；四段中心約0、3.67、7.33、11U。固定施法者朝+x，cast point在11U；施法者及敵人用既有root/disarm固定位置，目標未死亡；以帶此ability origin的damage事件計數，不以含自然回血的HP差判定。

| 敵人相對位置 | 原模板事件 | 只移除terminal的記憶體控制 | 只加includeOrigin:true的記憶體控制 |
| --- | --- | --- | --- |
| x=8.4，較早段已命中 | tick10、13，共2次 | tick10，共1次 | 共2次 |
| x=11，最後一段才首次命中 | tick13，共1次 | tick13，共1次 | tick13兩次 |
| x=4與x=11同時存在 | 近端1次、終點1次 | 近端1次、終點1次 | 近端1次、終點2次 |

每次事件在該夾具實際造成304傷害；此數字不是固定遊戲需求，重點是額外傷害是否發生。另以未修改的`tpl-line-blast`作對照，終點x=11可得到沿途＋終點兩次傷害；兩模板半徑/時刻不同，不因此宣稱所有配置等價。

## 根因證據與主線核對

2026-09-06核對GitHub主線 `1de2bd31fb6266ecb7738f110f2245e393c78071`：

- [expand.ts L1066-L1077](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/content/templates/expand.ts#L1066-L1077)：終點`damageArea`沒有`includeOrigin:true`。
- [delayed.ts L426-L483](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/sim/effects/delayed.ts#L426-L483)：先按hitOnce歷史過濾本段targets，最後一段的本體與finalEffects使用同一ctx。
- [damageArea.ts L29-L57](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/sim/effects/damageArea.ts#L29-L57)：預設排除`ctx.targets`；因此最後一段的新目標被排除，先前已命中的目標反而不在排除集合。

主線`delayed.ts`、`spawnModelFx.ts`與template JSON和重現版本逐bytes相同。主線damageArea新增了slot-rank scaling參數，但上述中心／排除邏輯仍在。**沒有在完整最新主線checkout重跑，因此不冒充最新主線E2E收據。**

另一個待確認風險：damageArea圓心優先採第一個ctx.targets的座標，而非wave終點；只加includeOrigin可能沒有修復圓心漂移。本票不把這個尚未獨立重現的風險寫成已確認第二缺陷，也不指定全域修改damageArea語意。

## 建議驗收

- 在真正模板展開→cast→SimWorld路徑，終點範圍內的「以前命中过」「最後段才命中」兩類敵人都收到正確終點追加；沿途hitOnce仍成立。
- 驗證終點爆炸中心與wave落點一致，涵蓋偏離中心的敵人；不能只修計數而讓中心依第一個目標改變。
- 以一套參數化治具涵蓋上述幾何與移除terminal的負控制，不逐英雄增加腳本。
- 不改掉近戰擴散原本排除起始受害者的語意；不順手修改Owner設計或全域damageArea預設。

## 訓練資料影響與範圍

本機R6/R7各有兩個train標準答案，把「終點另有一次爆炸」無條件映射到此模板；應隔離後重新校正能力證據。沒有終點爆炸要求的兩筆line-sweep替代答案不應一併算錯。正式凍結實驗保留歷史，不回頭換標籤美化分數；模型維持research-only。

本機原始收據：`outputs/forge-additional-four-hours-20260906/wave-equivalence-probe-v1.json`，SHA256 `74a65d448a096e4b051bd21fdcea993a771f220e013ea47a82ff91609fb33f9d`。探針`tools/forge-training/main-wave-equivalence-probe.ts` SHA256 `c9730a09b0ed8f606b9f7ce4ff34d9e4986d1606c377221c5915d04a739ee24f`，尚未push；上方參數、路徑與事件表是可獨立重建的重現說明。

已搜尋traveling-wave、terminal、終點爆發與includeOrigin並讀過#960、#311；兩者不是這個命中歷史／終點排除缺陷的專票。不重開舊票。
