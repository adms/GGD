# 額外四小時：英雄設定與機制精度迭代

> **21:54 接續修正**：core68938與post24285不变，R6訓練持續中。原入口54071尚未跑GPU即因CPU序列化比對誤報被明確停止，failed紀錄保留；新入口接續14467／PID10926等待core和post，結果改寫至`manual-entry-v3/`。十份輸入及預期答案位元組完全不變，未改模型輸出、資料、選模或公開推論程式。唯讀最終報告接續80178／PID19497已於21:53啟動，等全部真實結果完成才產生報告。後續以R6-v2的STATUS索引為準。

> **21:40 最新執行索引**：R6-v2已啟動，見`../forge-joint-source-stack-r6-v2-20260906/STATUS.md`。core68938／PID7974、worker8839正在單輪訓練；post24285／PID9307與公開入口54071／PID10294等待前置完成。466train／158dev／186test，另63新來源post題；636筆準備草案因舊170機制目錄問題淘汰，從未訓練。R6結果尚未出爐，舊R5結論不變。

> **21:10 結果更新（優先於下方歷史狀態）**：原 R5 於 20:56:10 因凍結訓練截止停止，原 core／post／follow-on 的 failed 紀錄均保留。獨立 `../forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/` 已完成 step80（320筆、不是628筆整輪）的選模、回歸、post 與原四題入口；`recovered-r5-follow-on-v1/follow-on-evaluation-v1/` 亦已全部完成，沒有待執行的舊 GPU 工作。**R5 不採用，所有模型維持 research-only。** 原 dev 81→82/83 的一題改善涉及既有措辭爭議；Owner 回歸雖87→88/94，錯誤放行1→2，新來源70→69/72、錯誤放行0→1。多卡20題更暴露退步：base17/20、錯誤放行1，R3與R5均12/20、錯誤放行8；真實多卡入口只1/3語意正確。R3僅是較好的來源研究對照，不是全用途合格模型。

下一輪採新的資料、政策與程式版本；不改舊分數、截止或測試。原英雄90題與Owner120題的24個措辭候選已完成全來源複核；另備17個原dev專屬來源／51題的未知資訊平衡候選（`r6-source-dev-candidate-v1/`），只在新一輪預先登錄後用於dev，不入train、不冒充新來源泛化。訓練前仍需完成多卡訓練與獨立需求切分及完整資料核對。

> **20:50執行索引：後續檢查現已由一次性程序接手。** `follow-on-evaluation-v1/state.json`，exec session6977／PID95931，已用真handle確認live，當下waiting-for-core-and-post。原R5核心41291、post94685不變。下方早期「尚未排隊」是歷史進度；現在不要另外啟動原四題入口、兩組paired或三個多卡入口，避免重複。若原core/post真失敗，本接續也會明確停止，不自動改舊policy或偽造完成。

使用者於2026-09-06 19:55台灣時間明確再延長四小時。總截止從當晚21:36:10延到 **2026-09-07 01:36:10 Asia/Taipei**，GPU最晚01:21:10停止，最後至少十五分鐘保留報告。

這是協調／授權紀錄，不是已訓練模型目錄。沒有新雲端預算、push、遊戲修正或自動啟用授權；仍採4B不推理、本機M5 Max、分類及既有模板推薦，不訓練特效調參或視覺驗證。

## 不修改正在執行的實驗

R5原trainingStopAt=20:56:10、原評估截止21:21:10與所有釘選資料／腳本不動。改時間檔會破壞既有釘選程序，不能默默改。若R5完整結束，照原流程取得dev選模、test及新來源對照；若真因舊訓練停止點終止，只在確認核心和post均已終止後，用完整保存的checkpoint進行明示的部分訓練評估。不得因速度估算就中斷或重跑。

## 新增時間優先用途

1. 先讀R5逐題結果，評估英雄設定／Owner原文機制是否改善、是否新增錯誤放行；保留與R3及基底的同題比較。R4無收益與一般system規則失敗仍是已知反例，不盲加epoch。
2. 根據實際錯誤重新核對原文與標籤，補充有明確受詞、條件、數值基準及用途對照的高品質訓練例；對曖昧題先標出語意爭議，不能事後改舊分數掩蓋退步。
3. 若有可驗證的資料或配方改善方向，開新版本、本機有界迭代。既有測試保持回歸用途；新測試先凍結、說明來源重疊，不直接把錯題答案倒回train。
4. 保留模型評估與本機重載時間；足夠好的BF16＋LoRA優先。只有來源／機制品質值得保留時，才投入融合／量化保真檢查。體積或載入成功不等於能在16GB實機穩定達到同品質。

不保證多四小時一定達標，也不為用滿時間增加無效訓練。完成條件保持完整英雄／機制用途、支援／近似／拒絕正確性、對照收益及可用模型證據；不能用特效高分或少數入口測試替代。

## 20:01已完成的資料工作

已重新完整複核五份反覆出錯的Owner來源與舊命題，將術語差異／未明示門檻與真正的錯誤放行分開；見`SOURCE_LABEL_AUDIT.md`。15題澄清診斷已事先凍結在`source-label-clarification-v1/`，來源摘要與逐題重建檢查通過。原R5資料／分數不改，新題不入訓練或選模；它們不全是舊題的等價改寫，不能聲稱較高新分数就是修好舊錯題。

下一步等R5選模後，對這15題作base／R3／選定模型的同輸入對照，再決定後續乾淨標籤與來源詞彙處理。不要提前把原本有爭議的舊題從R5門檻移除，也不要把澄清題當成独立新來源Gold。

## 20:12原Owner訓練題重讀完成

精確盤點54份完整訓練來源、120題，已全部再次親自閱讀核對。14題提出消除主體／觸發條件／普通攻擊範圍等歧義的改寫候選，106題逐物件保留；未將14题直接宣稱為14個錯標。逐題來源、舊問句、舊答案、理由與候選見 `owner-training-wording-review-v1/REVIEW.md` 與 `review.json`。來源文字、答案標籤、system及train切分均保持，沒有搬入dev/test。CPU重建檢查通過；120題prompt為380–536 tokens，加256輸出保留均適合4096，沒有截斷。此為候選資料，狀態HOLD_PENDING_R5_RESULTS，尚未開訓。

15題另已準備同條件三臂腳本 `paired-diagnostic-run.mjs`，資料凍結在 `source-label-paired-v1/preparation.json`，使用本次延長授權的新policy。等R5核心及post均完成後才執行；目前沒有自動排隊程序，也沒有GPU結果。兩個防護測試及真實live-core拒絕檢查已通過，未改動R5任何釘選檔案。

後續命令（GPU空閒且R5核心/post完成時；如採checkpoint recovery，需用新root重新prepare，不改這份準備紀錄）：

```sh
node tools/forge-training/paired-diagnostic-run.mjs run \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-additional-four-hours-20260906/source-label-paired-v1' \
  /private/tmp/ggd-forge-mlx-20260906-venv/bin/python \
  /private/tmp/ggd-forge-training-runtime
```

此命令只跑base／R3／已選checkpoint的診斷，不訓練、不重選、不啟用。舊分數及分母必須保留。

## 20:13第一個R5 checkpoint已保存

step80／已訓練320筆的checkpoint已寫入原runtime，CPU實讀驗證32,480,560 bytes的adapter摘要為 `4d26b5a23febd38155503d3a2c5c9409c1a199e6b225677cfe2ea32d2e2c6437`；設定檔一致，前320筆metrics完整有序且loss／時間有限值，第320筆對應step80。原訓練handle仍live，正在往628筆一輪前進。這只是完整checkpoint保存證據，尚未評估或選定，不表示品質提升。

本次精簡資料／評分／配對防護測試共11項通過；不是整個repo全測試或模型品質驗收。

## 20:24多卡行為證據與20題診斷

新增 `COMPOSITION_REVIEW.md`：兩個實用多卡組合的雙seed／双順序實際施法或普攻／傷害管線驗證，加三個衝突／不可施放／重複命中控制，共11項通過。前三個前置fixture版本失敗紀錄全留，已證實是目標標記、木樁自動普攻、實際傷害倍率及硬控時間上限等測量問題，不當遊戲缺陷開票。

`composition-diagnostic-v2/`已凍結20題與32個已審查計畫（29單卡＋3組合），CPU token預算通過；`composition-paired-v1/`已準備沿用同一有界三臂執行器。原R5核心/post結束後才跑，沒有自動排隊。它使用新多卡task契約，不與舊單卡分母混算，也不改R5訓練或選模。此刻R5實際handle仍live，約401／628筆。

## 20:38新增：英雄設定全量重讀與多卡公開入口

`hero-training-wording-review-v1/`完成30份完整英雄來源／90題親自複核，80題保留、10題提出措辭候選；不是10個已證實錯標，部分待判命題也改變。保留巴恩「才有機會」而非必定使用的可能性、避免把一位授予者／一種流派當排他事實、直接判斷未知屬性而非來源已說明的後設句。原文、答案標籤、system與train切分均不變，沒有引入dev/test；HOLD、尚未訓練。重建與漂移拒絕檢查通過，90題442–651 prompt tokens加256全部fits4096。verification.json綁定7個程式／原資料／新資料證據摘要。

公開 `composition-client.mjs`／`composition-predict.mjs` 已接上32個明列計畫，公開builder與20題診斷messages完全一致。四個CPU測試及真GPU_BUSY preflight通過，沒有搶GPU或產生模型結果。用法見 `tools/forge-training/COMPOSITION_INFERENCE.md`；三個已知模式的真入口案例已在 `manual-composition-inputs-v1/preparation.json` 凍結11個pins，預期答案獨立，不送入模型。

這三個入口檢查尚未執行，也沒有排隊daemon。R5核心與post完成後才使用選定的native-reference；逐一呼叫公開入口並按EXPECTED.private.json核對語意。不得把契約合法當語意正確，不宣稱16GB實機或Editor可啟用。原四題單卡／VFX入口仍需先在R5舊截止內執行；兩組追加三臂診斷再沿用本次新截止。

## 20:50後續檢查正式自動串接

`follow-on-evaluation.mjs`已啟動並釘選程式／準備檔。先核對原core/post狀態、實際PID均已終止及GPU鎖不存在，才依序執行：原四題CLI入口→R5原最終報告→15題澄清三臂→20題多卡三臂→三個公開多卡入口。原入口保留舊13:21 UTC截止，追加診斷保留新17:21 UTC截止，沒有偷偷改policy；不訓練、不重選、不啟用。失敗／取消不重跑或刪鎖，原程序死亡但未完成也會拒絕。

兩個等待／停止判定測試與三個最終報告renderer／未完成守衛測試通過。此刻接續尚未啟動GPU階段，不把等待程序成立當模型結果。資料與原core/post pins未修改；實際階段、逐階段log和結果將寫在 `follow-on-evaluation-v1/`。

step80完整checkpoint另保存到R5的 `checkpoint-archive/step-80/`：adapter、config及320筆完整metrics前綴均實讀驗證，ARCHIVE.json記錄原位置及檔案摘要。沒有更改原runtime或選模，不宣稱該checkpoint已選定或已達品質。

另見 `PRECISION_CAUSAL_AUDIT.md`：目前舊R2沒有完整同題fused-BF16 test，部署退步不能全部歸因於量化。後續只有native品質值得保留，才分開檢查融合與量化保真。
