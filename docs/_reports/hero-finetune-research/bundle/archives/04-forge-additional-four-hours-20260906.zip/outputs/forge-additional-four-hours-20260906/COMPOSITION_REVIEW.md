# 多卡機制：實際行為證據與分類診斷

## 已完成的證據

`composition-runtime-probe-v4.json`：11項檢查通過。測的是釘選main `4793eaaaf2775b2081f5eca5881db32e0aab0ea8` 的真模板展開、衝突拒絕、完整ability schema、castAbility、SimWorld普攻與傷害管線。沒有修改遊戲程式、review-v4目錄或R5訓練。

| 組合／反例 | 證據與邊界 |
| --- | --- |
| buff-self＋life-manipulate（self） | 兩個seed、兩種順序：同一次對自己施法立即增加自己HP並暫時加攻擊力，其他友敵沒有收到回復；增益到期後攻擊力恢復。不是增益到期才回血，不是治療另一名友軍。 |
| on-attack＋on-hit-react | 兩個seed、兩種順序：真普攻引發附傷；實際受傷後只反擊該次來源敵人。兩條hook的ICD分開，同一ICD期間可各觸發一次。第二次受傷被自己的反擊ICD擋住，冷卻後換另一個攻擊者會只反擊新來源。原傷害仍造成HP損失。 |
| single-strike重複兩張 | 單seed控制：一張一個damage事件、兩張兩個事件，實際HP損失34.96→69.92。兩者共用同一live stat scaling；重複不是無害去重，也不是一筆傷害。 |
| targeted＋ground形狀衝突 | reject policy真實拒絕，不用lastWins偷偷抹掉其中一個瞄準方式。 |
| 天生被動＋主動增益 | 即使schema可解析，PASSIVE施放仍回passive，主動增益不生效。不能把這種合併說成可按鍵的暫時強化。 |

這些測試使用明確fixture參數，不證明每一個可填數字、每個模板組合或最新main全部正確。機率1的測試也不是隨機機率分布驗證；獨立抽籤語意另依實際hook dispatcher逐hook處理的程式來源。數值由人工調整後仍要重新做契約／行為檢查；不讓小模型生成調參值。

## 保留失敗的測試前置版本

v1、v2、v3結果保留，不能當作已證實的遊戲回歸，也沒有據此開票：

- v1目標使用了錯誤的`unit`標記，實際API需要`entity`。
- v1/v2本來想隔離一次普攻，但其他角色也會自動普攻，結果真的同時觸發了受傷反擊。事件清單已保存。`autoEngage`不是禁止普攻的總開關；v4改用通過schema的真實繳械效果製作不攻擊的木樁。
- v1/v2直接把模板原始傷害23當成最終掉血，忽略實際角色的傷害倍率。最終檢查是同條件控制的一次／兩次事件與兩倍HP損失，沒有假裝實際值是23。
- v3繳械fixture填30秒，正確被硬控最多20秒的schema拒絕；v4使用涵蓋測試窗口的5秒。
- 普攻所在的world.step結束後tick會加一，因此兩條hook的記帳可為9、10而非同個tick。驗證的是兩次觸發落在同一個1秒ICD窗口，且互不消耗對方冷卻，沒有改動遊戲時鐘。

## 已凍結、尚未跑模型的20題

正式待評估目錄是 **`composition-diagnostic-v2/`**。包含29個已啟用單卡家族與上述3個明確組合，共32個可推薦計畫。20題中10題接受、10題拒絕；加上合法單卡等價選項及兩種已驗順序，共26個答案變體。所有答案都通過契約及既有逐題評分器檢查，隔離卡選擇會被拒絕並計為錯誤放行。

任務輸出為 `{decision,templateIds,onConflict:"reject"}`，單卡也用一元素陣列。只允許列出的計畫，不自由拼裝；有意的雙斬擊保留重複ID。無法完整覆蓋時拒絕，不刪掉不支援的要求。未列出的有效組合是「尚未核對」，**不等於引擎絕不可能實現**。

v1目錄保留但沒有跑過模型；v2把延時第二擊的問句明確化為「第一筆施法當下立即發生、之後自由移動」，避免將可能接受原地連段的需求誤標為拒絕。也將每張單卡重複的人工調參提醒提升至共同system，減少重複token。CPU tokenizer實測20題prompt為2915–2939，加256輸出保留均小於4096，沒有截斷。

同條件base／R3／R5選定checkpoint的準備在`composition-paired-v1/`。執行前必須確認原R5核心及post完成且GPU空閒，再呼叫：

```sh
node tools/forge-training/paired-diagnostic-run.mjs run \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-additional-four-hours-20260906/composition-paired-v1' \
  /private/tmp/ggd-forge-mlx-20260906-venv/bin/python \
  /private/tmp/ggd-forge-training-runtime
```

目前沒有排隊daemon或模型結果。此診斷不參與訓練及checkpoint選擇；是已知模板語意的新task輸入契約，不能與舊單卡benchmark直接合併分數，也不能將輸入／目錄改善全部算作fine-tune收益。全英雄設定、來源全部用途與任意多卡覆蓋仍未完成，這20題不能替代它們。
