# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| mechanism-stack / base | 17/20 | 1 | 20/20 |
| mechanism-stack / r3 | 12/20 | 8 | 20/20 |
| mechanism-stack / selected | 12/20 | 8 | 20/20 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / mechanism-stack | 1 | 6 | 11 | 2 |
| base → selected / mechanism-stack | 1 | 6 | 11 | 2 |
| r3 → selected / mechanism-stack | 0 | 0 | 12 | 8 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | selected |
| --- | --- | --- | --- | --- | --- |
| composition-buff-restore-ally-instead | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-buff-restore-shield-not-hp | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-buff-self","tpl-on-hit-react"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-buff-self","tpl-instant-blast"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-independent-hooks-shared-cooldown | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-independent-hooks-cancel-damage | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-on-hit-react","tpl-single-strike"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-on-hit-react","tpl-instant-blast"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-independent-hooks-area-counter | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-on-attack","tpl-on-hit-react"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-two-immediate-strikes-train-pattern-b | mechanism-stack | [{"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / supported-template-refused | {"decision":"accept","templateIds":["composition-two-immediate-strikes"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["composition-two-immediate-strikes"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-two-immediate-strikes-delay-second | mechanism-stack | [{"decision":"refuse","templateIds":[],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-single-strike","tpl-single-strike"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |
| composition-single-card-controls-single-buff | mechanism-stack | [{"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"}] | {"decision":"refuse","templateIds":[],"onConflict":"reject"} / supported-template-refused | {"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"} / pass | {"decision":"accept","templateIds":["tpl-buff-self"],"onConflict":"reject"} / pass |
| composition-single-card-controls-single-restore | mechanism-stack | [{"decision":"accept","templateIds":["tpl-life-manipulate"],"onConflict":"reject"}] | {"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted | {"decision":"accept","templateIds":["tpl-buff-self","tpl-life-manipulate"],"onConflict":"reject"} / wrong-or-unsupported-template-accepted |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。

## 診斷限制

Same-input post-selection diagnostic only. Keep the original benchmark scores and denominators; clarified claims are not necessarily equivalent and are not independent new-source generalization.
