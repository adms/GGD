# 英雄設定訓練題全量複核

30份完整來源／90題已再次親自閱讀；80題保留，10題提出措辭候選。原文、標籤、system與train切分不變，沒有改R3/R5、回填舊分數或搬入dev/test。

這不是10個已證實錯標；部分候選改了待判命題，不能當舊題等價改寫。未知生日／性別／身高僅表示給定來源沒提供，不能用外部作品知識判真偽。所有候選HOLD，未訓練、未證明收益。

| 原題 | 疑慮 | 候選 |
| --- | --- | --- |
| hero-source-godie-hapm-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本海克力斯的確切年齡是三十歲。 |
| hero-source-godie-orkn-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本臭作的年齡是六十歲。 |
| hero-source-godie-ubal-yes | preserve-possibility-not-guaranteed-action | 巴恩封印年輕肉體，精神轉移到老頭身體；只有重要戰役才有機會再使用年輕肉體。 |
| hero-source-godie-emfr-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本涅吉的身高是一百四十公分。 |
| hero-source-godie-umal-no | explicit-denial-not-assumed-exclusive-style | 拳四郎不是北斗神拳的傳人，也不會使用秘穴拳法。 |
| hero-source-godie-ucrl-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本的傑永遠維持成年強制成長狀態。 |
| hero-source-godie-nbbc-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本小呆的生日在十二月。 |
| hero-source-godie-ofar-unknown | direct-unknown-attribute-not-meta-source-claim | 此版本皮卡丘的性別為雄性。 |
| hero-source-godie-nplh-no | explicit-denial-not-assumed-exclusive-grantor | 麻倉葉沒有得到安娜授予的超占事略決。 |
| hero-source-godie-ubal-unknown | replace-temporally-ambiguous-unknown | 此版本巴恩的年輕肉體身高是兩公尺。 |

逐題完整來源、原問句、舊答案與個別審查理由見review.json。先看R5固定結果及追加診斷，才決定是否另建R6訓練。
