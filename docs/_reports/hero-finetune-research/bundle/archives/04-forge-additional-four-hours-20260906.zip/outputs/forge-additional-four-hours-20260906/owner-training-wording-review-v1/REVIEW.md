# Owner 訓練題完整複核與措辭校正候選

已逐份讀完原 R3 Owner 訓練來源的完整原文及全部120題。這不是固定原始總筆數的背書，也不是Owner Gold。

- 54份訓練來源／120題：106題未發現新的措辭疑慮，14題提出改寫。
- 原標籤沒有直接更改；14題也不代表14個已證實錯標。
- 來源原文、R3/R5既有資料及分數完全保留；候選尚未進行訓練。
- 僅限原本train切分，沒有將dev/test或新15題澄清診斷搬入訓練。

| 原題 | 疑慮 | 下一版候選問句 |
| --- | --- | --- |
| owner-mechanism-godie-h02k.passive-yes | basic-attack-scope | 普通攻擊有3%機率造成999點真實傷害，並對敵人附帶燃燒狀態。 |
| owner-mechanism-godie-e002.q-no | implicit-rank-convention | 原文只給出6%這一個物理迴避機率，沒有列出12%、18%或24%。 |
| owner-mechanism-godie-e002.q-yes | implicit-rank-convention | 原文列出的物理迴避機率依序為6%、12%、18%、24%。 |
| owner-mechanism-godie-h02k.q-yes | basic-attack-scope | 普通攻擊有機率觸發十倍暴擊與一秒暈眩；敵方處於燃燒狀態時額外追加致盲。 |
| owner-mechanism-godie-h01u.q-yes | basic-attack-scope | 每次普通攻擊可疊加攻速；沒有繼續攻擊時，攻速增益會歸零。 |
| owner-mechanism-godie-emfr.r-yes | basic-attack-scope | 十二秒形態使移速加倍，施放技能後的下一次普通攻擊附加雷屬性傷害。 |
| owner-mechanism-godie-hapm.r-yes | percentage-owner-pronoun | 吟唱兩秒，施法者向前衝刺後造成周圍範圍傷害；若敵人具有恐懼狀態，額外傷害以施法者自身最大生命的25%計算。 |
| owner-mechanism-godie-e00w.w-yes | basic-attack-scope | 普通攻擊有10%機率使出1.5倍暴擊傷害，並附加範圍落雷傷害。 |
| owner-mechanism-godie-hapm.q-yes | percentage-owner-omission | 狂怒提升攻速與吸血；期間每承受施法者自身最大生命5%的傷害，狂怒持續時間延長兩秒。 |
| owner-mechanism-godie-emfr.e-yes | basic-attack-and-skill-scope | 形態持續十二秒，移速減半；普通攻擊附加火焰傷害，每次技能命中還會引發爆炎標記及周圍範圍傷害。 |
| owner-mechanism-godie-efur.passive-yes | basic-attack-scope | 每次普通攻擊依照順序循環取得不同屬性加成，每個加成各自持續一秒。 |
| owner-mechanism-godie-h01u.r-yes | basic-attack-scope | 八秒內，普通攻擊與受到傷害兩種事件都有20%機率觸發弒鬼神反擊。 |
| owner-mechanism-godie-h02v.w-yes | threshold-versus-permanent-unlock | 當自身生命降低到30%時，普通攻擊可吞噬生命低於原文所列比例的敵方單位，並永久增加1點AP。 |
| owner-mechanism-godie-edem.r-no | sufficient-versus-necessary-condition | 前置技能命中帶有燃燒標記的敵人時，也完全不會引發目標周圍的雷電爆炸傷害。 |

完整逐題原文、舊問句、舊答案、來源審查理由與候選問句見 review.json。候選摘要綁定於 manifest.json。

## 使用條件

先看R5原本固定評估及新來源診斷結果，再決定是否建立R6；不得用此改寫回填或美化R5成績。若採用，需重新鎖定資料與訓練暴露紀錄，保留原R3作控制。尚未證明這14項改寫能提升模型。
