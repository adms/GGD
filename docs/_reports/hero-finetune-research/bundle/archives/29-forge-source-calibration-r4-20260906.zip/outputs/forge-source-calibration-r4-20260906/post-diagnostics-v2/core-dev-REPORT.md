# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| hero-source / base | 19/21 | 0 | 21/21 |
| hero-source / r3 | 21/21 | 0 | 21/21 |
| hero-source / r4 | 21/21 | 0 | 21/21 |
| owner-mechanism / base | 35/38 | 0 | 38/38 |
| owner-mechanism / r3 | 36/38 | 0 | 38/38 |
| owner-mechanism / r4 | 36/38 | 0 | 38/38 |
| mechanism-template / base | 15/24 | 0 | 24/24 |
| mechanism-template / r3 | 24/24 | 0 | 24/24 |
| mechanism-template / r4 | 24/24 | 0 | 24/24 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / hero-source | 2 | 0 | 19 | 0 |
| base → r3 / owner-mechanism | 2 | 1 | 34 | 1 |
| base → r3 / mechanism-template | 9 | 0 | 15 | 0 |
| base → r4 / hero-source | 2 | 0 | 19 | 0 |
| base → r4 / owner-mechanism | 2 | 1 | 34 | 1 |
| base → r4 / mechanism-template | 9 | 0 | 15 | 0 |
| r3 → r4 / hero-source | 0 | 0 | 21 | 0 |
| r3 → r4 / owner-mechanism | 0 | 0 | 36 | 2 |
| r3 → r4 / mechanism-template | 0 | 0 | 24 | 0 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r4 |
| --- | --- | --- | --- | --- | --- |
| hero-source-godie-h01n-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| r3-shield-rush-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-charge-push"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-charge-push"} / pass | {"decision":"accept","templateId":"tpl-charge-push"} / pass |
| r3-gong-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-ground-nova"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-fanout"},{"decision":"accept","templateId":"tpl-orbit-array"},{"decision":"accept","templateId":"tpl-random-barrage"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-instant-blast"} / pass | {"decision":"accept","templateId":"tpl-instant-blast"} / pass |
| r3-vertical-landing-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-leap-strike"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-leap-strike"} / pass | {"decision":"accept","templateId":"tpl-leap-strike"} / pass |
| owner-mechanism-godie-h01n.ex-unknown | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| r3-ancestral-counter-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-mark-stacks"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-mark-stacks"} / pass | {"decision":"accept","templateId":"tpl-mark-stacks"} / pass |
| owner-mechanism-godie-e00s.w-no | owner-mechanism | [{"verdict":"contradicted"}] | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / contradicted-versus-not-stated-confusion |
| r3-wall-hit-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-leap-strike"},{"decision":"accept","templateId":"tpl-charge-push"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-leap-strike"} / pass | {"decision":"accept","templateId":"tpl-leap-strike"} / pass |
| r3-counter-attacker-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-on-hit-react"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass |
| r3-chorus-self-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-buff-self"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-buff-self"} / pass | {"decision":"accept","templateId":"tpl-buff-self"} / pass |
| r3-revenge-react-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-on-hit-react"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass |
| owner-mechanism-godie-e00s.passive-unknown | owner-mechanism | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| owner-mechanism-godie-e00s.w-yes | owner-mechanism | [{"verdict":"supported"}] | {"verdict":"supported"} / pass | {"verdict":"not-stated"} / supported-source-claim-rejected | {"verdict":"contradicted"} / supported-source-claim-rejected |
| r3-no-swap-buff-yes | mechanism-template | [{"decision":"accept","templateId":"tpl-buff-self"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-buff-self"} / pass | {"decision":"accept","templateId":"tpl-buff-self"} / pass |
| hero-source-godie-hpal-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
