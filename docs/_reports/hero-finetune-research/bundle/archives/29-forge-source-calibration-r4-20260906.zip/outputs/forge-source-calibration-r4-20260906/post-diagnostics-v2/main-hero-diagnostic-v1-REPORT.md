# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| hero-source / base | 137/140 | 0 | 140/140 |
| hero-source / r3 | 139/140 | 0 | 140/140 |
| hero-source / r4 | 139/140 | 0 | 140/140 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / hero-source | 3 | 1 | 136 | 0 |
| base → r4 / hero-source | 3 | 1 | 136 | 0 |
| r3 → r4 / hero-source | 0 | 0 | 139 | 1 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r4 |
| --- | --- | --- | --- | --- | --- |
| main-hero-godie-e007-setting-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| main-hero-godie-h02u-setting-yes | hero-source | [{"verdict":"supported"}] | {"verdict":"supported"} / pass | {"verdict":"contradicted"} / supported-source-claim-rejected | {"verdict":"contradicted"} / supported-source-claim-rejected |
| main-hero-godie-n01g-setting-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |
| main-hero-godie-o030-setting-unknown | hero-source | [{"verdict":"not-stated"}] | {"verdict":"contradicted"} / contradicted-versus-not-stated-confusion | {"verdict":"not-stated"} / pass | {"verdict":"not-stated"} / pass |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
