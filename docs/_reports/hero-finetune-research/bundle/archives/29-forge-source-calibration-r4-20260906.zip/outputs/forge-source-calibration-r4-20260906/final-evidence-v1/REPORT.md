# R4 本機微調實測報告

產生時間：2026-09-06T11:19:17.980Z。僅整理完成的實測，不自動啟用模型。

## 核心結論

dev選定epoch 3；dev既定門檻未通過。是否足夠穩定仍須逐任務、逐題檢查以下回歸，不能以loss或總平均宣告。

## 資料與训练

- train/dev/test：592/83/162。
- 實際訓練：3 epochs，444 optimizer steps，131.53分鐘，Metal峰值21.88GiB。
- Qwen3.5-4B非推理、乾淨BF16基底＋LoRA；選模只使用dev，未用test重選。

## 相同題目的核心test對照

| 任務 | base | R3 | R4 | R4錯誤放行 |
| --- | ---: | ---: | ---: | ---: |
| hero-source | 43/48 | 47/48 | 47/48 | 0 |
| owner-mechanism | 82/94 | 87/94 | 86/94 | 1 |
| mechanism-template | 16/20 | 19/20 | 19/20 | 0 |

原108題與新54題必須分開看，不能讓新增容易題掩蓋原題退步。

| 題組／任務 | R4正確 | R4錯誤放行 | 相對R3修正 | 相對R3退步 |
| --- | ---: | ---: | ---: | ---: |
| r3-exposed-regression / owner-mechanism | 36/40 | 1 | 0 | 0 |
| r3-exposed-regression / mechanism-template | 19/20 | 0 | 0 | 0 |
| r3-exposed-regression / hero-source | 47/48 | 0 | 0 | 0 |
| r4-prospective-same-source-diagnostic / owner-mechanism | 50/54 | 0 | 0 | 1 |

## 新版能力目錄

目前29候選／6隔離／11draft。召喚預設零容量問題另開#1076；v4使用新請求重測，沒有重套v3輸出。

| 同一v4輸入 | 正確 | 錯誤放行 |
| --- | ---: | ---: |
| base | 19/40 | 0 |
| r3 | 31/40 | 3 |
| r4 | 36/40 | 3 |

完整錯題與模型原值：[v4逐題報告](../supplement-v1/main-v4-REPORT.md)。舊v3分數只作歷史能力目錄對照，不代表当前可用性。

## 補充診斷與特效保留

| 題組 | 模型 | 正確 | 錯誤放行 |
| --- | --- | ---: | ---: |
| main-hero-diagnostic-v1 | base | 137/140 | 0 |
| main-hero-diagnostic-v1 | r3 | 139/140 | 0 |
| main-hero-diagnostic-v1 | r4 | 139/140 | 0 |
| fidelity-diagnostic-v2 | base | 113/114 | 1 |
| fidelity-diagnostic-v2 | r3 | 114/114 | 0 |
| fidelity-diagnostic-v2 | r4 | 114/114 | 0 |
| main-diagnostic-v3 | base | 17/40 | 0 |
| main-diagnostic-v3 | r3 | 33/40 | 0 |
| main-diagnostic-v3 | r4 | 34/40 | 1 |
| vfx-all | base | 105/118 | 8 |
| vfx-all | r2 | 111/118 | 7 |
| vfx-all | r3 | 112/118 | 6 |
| vfx-all | r4 | 112/118 | 6 |
| vfx-dev | base | 50/54 | 2 |
| vfx-dev | r2 | 52/54 | 2 |
| vfx-dev | r3 | 52/54 | 2 |
| vfx-dev | r4 | 52/54 | 2 |
| vfx-test | base | 55/64 | 6 |
| vfx-test | r2 | 59/64 | 5 |
| vfx-test | r3 | 60/64 | 4 |
| vfx-test | r4 | 60/64 | 4 |
| vfx-family-disjoint | base | 84/94 | 7 |
| vfx-family-disjoint | r2 | 90/94 | 4 |
| vfx-family-disjoint | r3 | 91/94 | 3 |
| vfx-family-disjoint | r4 | 91/94 | 3 |
| vfx-seen-family-retention | base | 21/24 | 1 |
| vfx-seen-family-retention | r2 | 21/24 | 3 |
| vfx-seen-family-retention | r3 | 21/24 | 3 |
| vfx-seen-family-retention | r4 | 21/24 | 3 |

VFX只建議既有模板；已見家族保留與家族隔離已分列，不作視覺驗證、不輸出調參。

## 真實來源推論入口

| 入口 | 請求 | 格式通過 | 記憶體限制 | Metal峰值 |
| --- | ---: | --- | ---: | ---: |
| hero | 1 | true | 12GiB | 8.88GiB |
| fidelity | 8 | true | 12GiB | 8.92GiB |

完整提案煙霧測試modelChecklistPass=true；未涵蓋項目：[]。這不是額外泛化分數，也不參與選模。

## 模型與限制

- adapter SHA256：1409ccaabe3ff83157b595cba7c933a2755c4c9af8912817a16a86b60935ae3e。
- 基底：/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-classification-reviewed-r2-20260906/native-reference/base。
- adapter：/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-source-calibration-r4-20260906/selected-adapter。
- 未push、未啟用Editor、未更改遊戲機制；雲端GPU使用0。

- Assistant-authored reviewed labels, not independent Owner Gold.
- Original R3 test is exposed regression; added R4 claims use held-out sources but are same-source diagnostics.
- Main-v4 changes both availability inputs and two oracles; never compare its aggregate directly to v3 as model improvement.
- Whole-proposal coverage checks only caller-supplied requirements, not unlisted source facts.
- 12 GiB MLX allocation-limit smoke tests are not measurements on a physical 16GB Mac.
- All game-contract issues remain separate from model quality; quarantining a card is not a fine-tuning gain.

工具測試通過不能替代以上實測；尚有錯誤或未驗收範圍時，不宣告整體目標完成。
