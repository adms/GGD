# 逐題模型對照與錯誤清單

本報告只整理實際輸出，不挑選checkpoint、不批准模型、不自動建立訓練資料。英雄設定與技能機制分開看，特效分數不得抵銷它們。

| 任務／模型 | 正確 | 錯誤放行 | 格式通過 |
| --- | ---: | ---: | ---: |
| mechanism-template / base | 17/40 | 0 | 40/40 |
| mechanism-template / r3 | 33/40 | 0 | 40/40 |
| mechanism-template / r4 | 34/40 | 1 | 40/40 |

## 配對修正與退步

同一題、同一請求摘要、相同base／runtime／seed／非推理設定；只比較已提供模型臂，不把尚未跑的R3寫成結果。

| 對照／任務 | 修正 | 退步 | 兩者正確 | 兩者錯誤 |
| --- | ---: | ---: | ---: | ---: |
| base → r3 / mechanism-template | 16 | 0 | 17 | 7 |
| base → r4 / mechanism-template | 17 | 0 | 17 | 6 |
| r3 → r4 / mechanism-template | 1 | 0 | 33 | 6 |

## 需要逐案審查

下表包含任一模型出錯的全部題目。完整來源、預期答案、原始模型值及摘要見同目錄 `report.json`；分類只是輸出錯誤類型，不代表已確定訓練缺陷根因。

| ID | 任務 | 預期 | base | r3 | r4 |
| --- | --- | --- | --- | --- | --- |
| main-diagnostic-v3-blink-attack | mechanism-template | [{"decision":"accept","templateId":"tpl-blink-strike"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-blink-strike"} / pass | {"decision":"accept","templateId":"tpl-blink-strike"} / pass |
| main-diagnostic-v3-real-clones | mechanism-template | [{"decision":"accept","templateId":"tpl-summon-agent"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v3-point-periodic | mechanism-template | [{"decision":"accept","templateId":"tpl-periodic-field"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass |
| main-diagnostic-v3-caster-periodic | mechanism-template | [{"decision":"accept","templateId":"tpl-periodic-field"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / pass | {"decision":"accept","templateId":"tpl-periodic-field"} / pass |
| main-diagnostic-v3-self-restore-add | mechanism-template | [{"decision":"accept","templateId":"tpl-life-manipulate"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v3-friend-restore | mechanism-template | [{"decision":"accept","templateId":"tpl-life-manipulate"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v3-segmented-sweep | mechanism-template | [{"decision":"accept","templateId":"tpl-line-sweep"},{"decision":"accept","templateId":"tpl-traveling-wave"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass | {"decision":"accept","templateId":"tpl-line-sweep"} / pass |
| main-diagnostic-v3-wave-terminal | mechanism-template | [{"decision":"accept","templateId":"tpl-traveling-wave"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass | {"decision":"accept","templateId":"tpl-traveling-wave"} / pass |
| main-diagnostic-v3-moving-model-burst | mechanism-template | [{"decision":"accept","templateId":"tpl-line-blast"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-line-blast"} / pass | {"decision":"accept","templateId":"tpl-line-blast"} / pass |
| main-diagnostic-v3-radial-damage | mechanism-template | [{"decision":"accept","templateId":"tpl-radial-burst"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-radial-burst"} / pass | {"decision":"accept","templateId":"tpl-radial-burst"} / pass |
| main-diagnostic-v3-summon-vs-model | mechanism-template | [{"decision":"accept","templateId":"tpl-summon-agent"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v3-combo-family | mechanism-template | [{"decision":"accept","templateId":"tpl-combo-finisher"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-combo-finisher"} / pass | {"decision":"accept","templateId":"tpl-combo-finisher"} / pass |
| main-diagnostic-v3-combo-finisher-ref | mechanism-template | [{"decision":"accept","templateId":"tpl-lock-combo"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-lock-combo"} / pass | {"decision":"accept","templateId":"tpl-lock-combo"} / pass |
| main-diagnostic-v3-mark-immediate | mechanism-template | [{"decision":"accept","templateId":"tpl-mark-stacks"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused |
| main-diagnostic-v3-rally-only | mechanism-template | [{"decision":"accept","templateId":"tpl-teleport"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-teleport"} / pass | {"decision":"accept","templateId":"tpl-teleport"} / pass |
| main-diagnostic-v3-attack-direction | mechanism-template | [{"decision":"accept","templateId":"tpl-on-attack"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-attack"} / pass | {"decision":"accept","templateId":"tpl-on-attack"} / pass |
| main-diagnostic-v3-react-direction | mechanism-template | [{"decision":"accept","templateId":"tpl-on-hit-react"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass | {"decision":"accept","templateId":"tpl-on-hit-react"} / pass |
| main-diagnostic-v3-plain-hit | mechanism-template | [{"decision":"accept","templateId":"tpl-single-strike"},{"decision":"accept","templateId":"tpl-instant-blast"},{"decision":"accept","templateId":"tpl-proxy-cast"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-instant-blast"} / pass | {"decision":"accept","templateId":"tpl-instant-blast"} / pass |
| main-diagnostic-v3-root-circle | mechanism-template | [{"decision":"accept","templateId":"tpl-proxy-cast"},{"decision":"accept","templateId":"tpl-proxy-fanout"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-proxy-fanout"} / pass | {"decision":"accept","templateId":"tpl-proxy-fanout"} / pass |
| main-diagnostic-v3-charge-end | mechanism-template | [{"decision":"accept","templateId":"tpl-charge-push"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-charge-push"} / pass |
| main-diagnostic-v3-vertical-jump | mechanism-template | [{"decision":"accept","templateId":"tpl-leap-strike"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-leap-strike"} / pass | {"decision":"accept","templateId":"tpl-leap-strike"} / pass |
| main-diagnostic-v3-self-stat-only | mechanism-template | [{"decision":"accept","templateId":"tpl-buff-self"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-buff-self"} / pass | {"decision":"accept","templateId":"tpl-buff-self"} / pass |
| main-diagnostic-v3-roster-approved | mechanism-template | [{"decision":"accept","templateId":"tpl-random-barrage"},{"decision":"accept","templateId":"tpl-orbit-array"}] | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"refuse","templateId":null} / supported-template-refused | {"decision":"accept","templateId":"tpl-periodic-field"} / wrong-or-unsupported-template-accepted |

以上不是Owner Gold、不是完整英雄技能生成驗收，也不是16GB實機證明。保留所有錯誤，不以總平均分或loss掩蓋英雄設定／技能用途的退步。
