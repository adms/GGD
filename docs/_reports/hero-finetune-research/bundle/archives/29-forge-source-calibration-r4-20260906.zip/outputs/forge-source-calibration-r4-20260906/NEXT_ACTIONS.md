# R4 接續操作（2026-09-06 18:46 Asia/Taipei）

> **19:40最新狀態取代以下歷史操作順序：** R4核心6032、post18850、supplement8681及source-policy dev37453皆已終止exit0。完整報告已產生於`final-evidence-v1/REPORT.md`。R4未改善Owner，不採用；source-policy dev退步且gate=false，禁止再跑其regression。不要重跑下方任何已完成程序。現在工作已移至`../forge-contrastive-r5-20260906/STATUS.md`：R5訓練session41291，接續评估session94685。請先以真實handle確認，不用舊狀態檔推論存活。

## 目前真實程序

本次兩個原始exec handle都再次確認存活：6032（R4）／18850（post）。R4第三epoch最新讀取example377／592、step390／444；無R4評測結果。只讀監看functions cell819已停止，**沒有停止訓練**，不能因監看結束重新跑R4。

下一次只需續查相同handle和實際新輸出，勿以狀態檔或舊log當存活證據。最終deadline仍21:36:10，GPU cutoff21:21:10。

## 完成後的固定順序

1. 讀R4的selection/comparison及post-diagnostics-v2結果，逐任務檢查英雄、Owner、模板；原108回歸和新54同來源題分開，不用總分掩蓋退步。
2. 兩程序均完成且GPU鎖釋放後執行`r4-supplement.mjs`。它不等待、不訓練、不重選：v4新40題base/R3/R4三臂 → 真source-predict英雄入口 → 真fidelity入口及validate。兩個公開入口都限制12GiB MLX分配，並非16GB實機證明。
3. 補測完成後執行`r4-final-report.mjs`重算並核對原始分數／adapter／pins，生成final-evidence-v1；人工再讀所有錯誤才作結論。腳本不自動批准模型。
4. 若高優先度仍未達標，再根據實際錯誤與剩餘時間決定下一輪；不能為了時間未用完便盲目訓練。原始來源、dev/test、R4腳本均保持凍結。

從`GGD-hero-auto-forge`工作目錄執行（Metal需本機GPU權限）：

```sh
node tools/forge-training/r4-supplement.mjs \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-source-calibration-r4-20260906' \
  /private/tmp/ggd-forge-mlx-20260906-venv/bin/python \
  /private/tmp/ggd-forge-training-runtime

node tools/forge-training/r4-final-report.mjs \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-source-calibration-r4-20260906'
```

尚未執行GPU supplement，也尚未生成final report；只有syntax check、source_predict CPU測試、以及對真實未完成R4的INCOMPLETE_CORE拒絕檢查通過。所有`*.test.mjs`共41項已通過，不必只為有進度而重跑同一批。

## 版本與資料注意

最新main目錄為R3根目錄main-catalog-review-v4.json：29候選／6隔離／11draft。新票#1076為召喚零上限預設；兩個v4召喚題改refuse，**新請求必須重新推論**，不能重算v3舊raw。R4既有post仍固定v3，保留為歷史對照。

60題current-main-candidate資料尚未核准或訓練，已HOLD；不要直接轉train。R4訓練未使用這批。所有遊戲差異票只開票與隔離，未修改main、未push、未啟用模型。

## 19:12更新（取代上方「訓練中」快照）

6032已完成exit0，不再poll/restart它。R4核心test結果已證實沒有改善，詳見R4_RESULT_REVIEW.md：Owner86/94低於R3的87/94，原錯誤放行仍在；不採用R4。18850仍存活跑VFX，之前三組診斷已完成；v3目錄R4新增一次錯誤放行（把初始名單DOT選成periodic-field）。仍須等它完成後執行上述supplement和final-report。

下一個有界實驗不是新訓練：source-policy-probe-data.mjs已建立`../forge-source-policy-probe-20260906/`，245題原來源／claim／label／split完全不變，只有system一般判讀規則介入。來源、標籤保全檢查PASS；兩腳本syntax check PASS，尚未跑GPU。原文兩類訓練／泛化優先級不變，規則改善不可算成純fine-tune收益。

在post與supplement均完成後，從GGD-hero-auto-forge執行：

```sh
node tools/forge-training/source-policy-probe-run.mjs \
  '/Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/forge-source-policy-probe-20260906' \
  /private/tmp/ggd-forge-mlx-20260906-venv/bin/python \
  /private/tmp/ggd-forge-training-runtime dev
```

只有dev/summary.json的devGate=true才執行同命令最後參數regression。先看一般規則澄清是否有效，再決定針對性資料／續訓，**尚未實作或啟動R5權重訓練**。不要把60題HOLD候選或任何已揭露dev/test原题倒入train。最終期限仍21:36:10，模型未達標不能mark goal complete。
