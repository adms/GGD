# R4 資料校準狀態

2026-09-06 16:53 Asia/Taipei：本機訓練中，不是完成報告。

- 主程序PID78640，`run-state.json`是即時狀態。已完成doctor、base dev、R3 dev，正在乾淨基底的LoRA訓練；參數有限性由每步守衛檢查。
- 有效接續程序PID79720，`post-diagnostics-v2/state.json`，等待R4完成。第一次post preflight無GPU工作即停止，原因保存在`post-diagnostics/PREFLIGHT_FAILURE.md`。
- 592train／83dev／162test；新增逐題審查212列，train增158、前瞻性同來源test增54。舊108test是回歸，不是新Gold。
- 同一非推理BF16基底、相同LoRA配方；本輪是資料介入，非warm restart。最多3epochs，留足評估時間，dev選模後才評測test。
- 接續重測R3的英雄140題、雙向完整提案114次、新main目錄40題，及四模型VFX回歸。VFX的24個已見家族變體另列，不混充未見家族。
- Mac-only、雲端花費0；最終21:36:10截止，最後15分鐘報告reserve。不push、不修改遊戲、不啟用模型。

尚未有R4成效結論。R3已證明部分提升，但其Owner錯誤放行與退步未解決；未驗證完整英雄自動鑄造、16GB實機或量化部署。不得將資料增加、loss下降或訓練成功當作正確率提升。

## 16:57 獨立來源推論入口

新增`source-predict.py`，接受真`hero-source-client`請求或整份fidelity plan，離線非推理／12GiB預設／共用GPU鎖／摘要與完整輸出守衛。CPU測試以真JS資料驗證跨語言digest、未知來源／重複ID／輸入變動拒絕，1項整合測試通過。不是已完成GPU測試。

已準備`standalone-hero-request.json`（Saber来源1題）和`standalone-fidelity-plan.json`（十二道試煉完整版8次判讀），待R4及`post-diagnostics-v2`均完成並釋放GPU鎖後，用選定adapter跑真入口，再執行fidelity validate。這是公開入口／記憶體／可恢復性煙霧測試，不算新增泛化分數，也不使用它重選checkpoint。

本輪已開票並再次核對OPEN：[#1044](https://github.com/adms/GGD/issues/1044)、[#1045](https://github.com/adms/GGD/issues/1045)、[#1046](https://github.com/adms/GGD/issues/1046)、[#1047](https://github.com/adms/GGD/issues/1047)、[#1048](https://github.com/adms/GGD/issues/1048)、[#1050](https://github.com/adms/GGD/issues/1050)。涉及過期說明、汲取回血方向、預設schema、擊殺成長受詞與拉扯投擲距離；先隔離錯誤能力，不擅自改遊戲。

## 18:36 新增召喚預設差異票；R4仍正常訓練

兩個原始session6032／18850均再次回傳存活；訓練已到epoch3（最新讀取example241、step356），接續評估仍等待，沒有R4結果可宣告。

真castAbility正控制證明召喚模板預設maxAlive=0會產生零具；改為2或明確省略後同一流程生出兩具有生命的單位。已開並確認[#1076](https://github.com/adms/GGD/issues/1076) OPEN；開票前對照最新main相關原文，未修改遊戲。細節和四組證據見R3目錄的`SUMMON_CAP_ISSUE.md`與`main-summon-cap-probe-v1.json`。

最新能力帳本為R3目錄`main-catalog-review-v4.json`：**29候選／6隔離／11draft**。`main-diagnostic-v4/`另存40題，其中兩題因召喚卡隔離改為拒絕。這是有證據的可用性修正，不是模型成效。v4需新推論，禁止拿v3原輸出重套答案。

R4與post-diagnostics-v2既有pins不修改、不重啟，仍會產出歷史v3對照。完成後須另外補跑v4目錄，並在報告明確區分。新準備的60題下一輪候選資料尚未核准或訓練，已加HOLD，不帶入錯誤召喚預設；先看R4實測再決定是否有必要做下一輪。

## 19:12 核心完成但沒有改善

exec6032已exit0；epoch3選定，dev英雄21/21、Owner36/38、模板24/24，未達Owner95%門檻。test英雄47/48、Owner86/94（錯誤放行1）、模板19/20；R3 Owner為87/94。原108回歸逐題未改善，新54題退步1。R4不採用，詳見`R4_RESULT_REVIEW.md`。

post的英雄139/140、完整提案114/114與R3相同；v3模板34/40但新增一次錯誤放行，不能以總分改善宣告成功。VFX仍跑中，原handle18850確認存活。等post完成跑r4-supplement及final-report，不重啟訓練。

另備妥不改權重的source-policy-probe：同一來源／claim／label，只補一般判讀規則，先比較base/R3的83dev，達原門檻才准跑162已揭露回歸。它是prompt介入，不是純微調收益；尚未執行GPU短測。新的有界小測用來決定下一個資料／訓練方向，而不是盲目再加epochs。
