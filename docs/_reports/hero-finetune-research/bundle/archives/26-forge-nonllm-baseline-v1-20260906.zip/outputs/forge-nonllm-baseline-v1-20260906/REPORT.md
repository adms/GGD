# 非LLM規則／檢索基準：事後研究比較

最近訓練例基準使用R3＋R6實際train聯集；不是純關鍵詞規則。目錄基準只用當次公開目錄與需求，不讀訓練答案。兩者不使用LLM。來源任務未實作目錄查表，不以空答案假裝比較。

去重後660筆（原始900）；TF-IDF建立0.294秒；觀測RSS最大193.3MiB（非整機或真正峰值）。

同題、同scorer；不偽裝成相同推論backend。accuracy與safety分別用158 dev選參數，再凍結測試與post。這是事後比較，不是獨立未見Gold，也未證明最佳規則方案。R3沒有接受R6新增train，但本基準有；與R7完整訓練後的比較才能更接近相同資料暴露。

| 題組 | 任務 | 方法 | 正確 | 錯誤放行 |
| --- | --- | --- | ---: | ---: |
| core-dev | hero-source | nearest-accuracy | 17/21 | 0 |
| core-dev | owner-mechanism | nearest-accuracy | 64/89 | 6 |
| core-dev | mechanism-template | nearest-accuracy | 20/24 | 3 |
| core-dev | mechanism-stack | nearest-accuracy | 16/24 | 4 |
| core-dev | hero-source | nearest-safety | 17/21 | 0 |
| core-dev | owner-mechanism | nearest-safety | 63/89 | 5 |
| core-dev | mechanism-template | nearest-safety | 20/24 | 3 |
| core-dev | mechanism-stack | nearest-safety | 16/24 | 4 |
| core-dev | mechanism-template | catalog-accuracy | 15/24 | 1 |
| core-dev | mechanism-stack | catalog-accuracy | 12/24 | 0 |
| core-dev | mechanism-template | catalog-safety | 15/24 | 1 |
| core-dev | mechanism-stack | catalog-safety | 12/24 | 0 |
| core-dev | hero-source | base | 19/21 | 0 |
| core-dev | owner-mechanism | base | 80/89 | 2 |
| core-dev | mechanism-template | base | 15/24 | 0 |
| core-dev | mechanism-stack | base | 20/24 | 0 |
| core-dev | hero-source | r3 | 21/21 | 0 |
| core-dev | owner-mechanism | r3 | 83/89 | 1 |
| core-dev | mechanism-template | r3 | 24/24 | 0 |
| core-dev | mechanism-stack | r3 | 13/24 | 10 |
| core-test | owner-mechanism | nearest-accuracy | 63/94 | 6 |
| core-test | mechanism-template | nearest-accuracy | 15/20 | 3 |
| core-test | hero-source | nearest-accuracy | 38/48 | 0 |
| core-test | mechanism-stack | nearest-accuracy | 15/24 | 4 |
| core-test | owner-mechanism | nearest-safety | 63/94 | 6 |
| core-test | mechanism-template | nearest-safety | 15/20 | 3 |
| core-test | hero-source | nearest-safety | 38/48 | 0 |
| core-test | mechanism-stack | nearest-safety | 15/24 | 4 |
| core-test | mechanism-template | catalog-accuracy | 12/20 | 0 |
| core-test | mechanism-stack | catalog-accuracy | 11/24 | 1 |
| core-test | mechanism-template | catalog-safety | 12/20 | 0 |
| core-test | mechanism-stack | catalog-safety | 11/24 | 1 |
| core-test | owner-mechanism | base | 82/94 | 3 |
| core-test | mechanism-template | base | 16/20 | 0 |
| core-test | hero-source | base | 43/48 | 0 |
| core-test | mechanism-stack | base | 16/24 | 4 |
| core-test | owner-mechanism | r3 | 87/94 | 1 |
| core-test | mechanism-template | r3 | 19/20 | 0 |
| core-test | hero-source | r3 | 47/48 | 0 |
| core-test | mechanism-stack | r3 | 9/24 | 15 |
| new-source-63 | owner-mechanism | nearest-accuracy | 45/63 | 5 |
| new-source-63 | owner-mechanism | nearest-safety | 45/63 | 4 |
| new-source-63 | owner-mechanism | base | 57/63 | 3 |
| new-source-63 | owner-mechanism | r3 | 58/63 | 2 |
| previous-source-72 | owner-mechanism | nearest-accuracy | 44/72 | 9 |
| previous-source-72 | owner-mechanism | nearest-safety | 45/72 | 8 |
| previous-source-72 | owner-mechanism | base | 67/72 | 2 |
| previous-source-72 | owner-mechanism | r3 | 70/72 | 0 |
| hero-140 | hero-source | nearest-accuracy | 77/140 | 6 |
| hero-140 | hero-source | nearest-safety | 77/140 | 6 |
| hero-140 | hero-source | base | 137/140 | 0 |
| hero-140 | hero-source | r3 | 139/140 | 0 |
| fidelity-114 | owner-mechanism | nearest-accuracy | 49/114 | 9 |
| fidelity-114 | owner-mechanism | nearest-safety | 47/114 | 9 |
| fidelity-114 | owner-mechanism | base | 113/114 | 1 |
| fidelity-114 | owner-mechanism | r3 | 114/114 | 0 |
| current-main-v4 | mechanism-template | nearest-accuracy | 33/40 | 3 |
| current-main-v4 | mechanism-template | nearest-safety | 33/40 | 3 |
| current-main-v4 | mechanism-template | catalog-accuracy | 26/40 | 4 |
| current-main-v4 | mechanism-template | catalog-safety | 26/40 | 4 |
| current-main-v4 | mechanism-template | base | 19/40 | 0 |
| current-main-v4 | mechanism-template | r3 | 31/40 | 3 |

## 限制

- 字面相似不等於完整語意涵蓋；最近例、關鍵詞命中都可能忽略否定、對象或時間。
- 未在此流程編写每個英雄ID的規則；source ID/name/snapshot、case ID與測試答案不進入特徵。
- 所有模型題集仍沿用原凍結oracle；traveling-wave已另證實能力／標籤問題，相關題分數不能當runtime支持。
- 不以這兩個有限基準落後來證明fine-tune不可替代，也不以過度refuse換取合格結論。
- 未變更R6/R7模型、資料、解碼、選模、截止或啟用狀態。R7仍待實際完成比較。
