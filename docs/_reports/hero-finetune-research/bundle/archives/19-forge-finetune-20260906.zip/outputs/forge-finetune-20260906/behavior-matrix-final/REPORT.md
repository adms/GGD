# 範圍傷害目標反例

57 組全部通過：24 組 frozen test 參考配置，A 組語意已通過的 10 組，以及 B 組語意已通過的 23 組。**不是 A/B 全部輸出都正確**，未通過語意的提案仍保留原本錯誤判決。

每組均從實際模板參數經 heroForge generator／compiler，建立相同 seed 的施放與未施放對照世界。實際送 IntentFrame 給 world.step，讀 HP 與 damage events：

- 圈內敵人恰好多一個命中，且有額外掉血。
- 施法者、友方、範圍外敵人沒有額外命中或掉血。
- 距離依原始 spec 的 WC3 半徑換算，而非依輸出 ability 半徑反推期望。
- 故意把編譯後半徑縮成 0.001 的錯誤夾具，確實被「圈內敵人須受傷／恰好一次命中」攔截；沒有修改出貨引擎。

保留每個世界的 before／after、事件、digest trail、編譯後能力 hash、引擎快照與 verifier source hash，見 [results.json](results.json)。

這是補充的機制／目標驗證，不更動原 A/B 比較。未驗證狀態開始／到期、onHit／onMiss、特效渲染／掛點／美感，也沒有增加自然語言 Gold 或讓研究模型晉級。
