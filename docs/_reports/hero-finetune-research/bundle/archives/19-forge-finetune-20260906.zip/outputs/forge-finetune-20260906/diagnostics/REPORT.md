# 補充診斷：規則、成本與證據邊界

本報告在 A/B 完成後補算；不修改原 scorer、test、候選或配方。

| 指標 | A | B |
| --- | ---: | ---: |
| jsonParsed | 48/48 | 48/48 |
| engineContractAndScenario | 44/48 | 48/48 |
| unsupportedBlocked | 12/12 | 12/12 |
| correctClarification | 11/12 | 12/12 |
| overRefusal | 8/24 | 1/24 |

總生成 token：A 2092；B 2391。每個首次成功結果攤提生成秒數：A 1.704；B 1.380。不是人工修正／整機電費。
新 process 模型載入秒數 A 0.5579492499819025，B 0.6693555830279365；檔案快取可能已暖，不稱為 cold-disk。

## 規則比較

後設 literal grammar parser：train 144/144、dev 24/24、test 48/48。只讀與模型相同的公開輸入，不讀 spec／target；通過另需相同 scorer 與引擎檢查。
這個 parser 是看過已編寫的 grammar 後才建的，不是預先登錄的第三組，也不是自然語言泛化測試。若規則已能完成這批固定模板需求，合成 A/B 增益本身並不足以證明值得投入微調。

## 不確定性

Only four eligible compositional families from one authored grammar; no independent human-confirmed source families. A population/generalization interval would be misleading.
每組僅一個 seed，依序 A→B，沒有次序交錯。家族成績、逐案規則結果與原始引擎檢查均保留。尚未覆蓋的目標／持續時間／觸發時序不能由正向傷害 scenario 推論為通過。

[機器可讀指標](metrics.json) · [規則逐案](rule-comparison.json) · [引擎逐案](engine-results.json)
