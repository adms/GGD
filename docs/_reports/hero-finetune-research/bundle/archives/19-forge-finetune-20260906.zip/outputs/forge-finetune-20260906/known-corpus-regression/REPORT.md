# 已知題庫：微調前後回歸

同一 BF16 MLX、同一提示與抽樣、non-thinking、沒有 grammar；輸出 schema 額外放入提示。不可直接比舊 GGUF 百分比。

A 19/23；B 19/23。配對 {"bothCorrect":17,"fixed":2,"regressed":2,"bothWrong":2}。

沿用原本 vfx-01 排除協議；全部 24 題輸出保留。這是已知開發題庫的跨接口保留測試，不是新未見品質，也不是現行引擎驗證（例如舊 alpha=0 規格與實際 schema 不同）。不依此重新選候選或調參。

[逐案結果](comparison.json)
