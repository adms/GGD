# 微調缺點是否可修：訓練分布與原始輸出核對

2026-09-06，報告保留時段的 CPU 分析；沒有新訓練、推論、選模或改分。本次不能據此聲稱下一配方一定有效。

## 新核對的分布

直接計數 train.jsonl 的 144 筆 target：proposed 72、refused 36、advice 18、degraded 18。90 筆可生成答案全部使用 tpl-ground-nova，且全為單層 VFX；另 54 筆沒有模板／VFX。

90 筆有 VFX 的答案中，18 筆只有 vfxKey 與 attachTo，沒有可選 override。alpha 僅出現 0.1（6 次）、0.5（12 次）；delayMs 僅出現 100／200／300（各 8 次）、400／500（各 6 次）。**沒有 delayMs=0、alpha=1 或兩層 VFX 的訓練答案**。

## 錯誤與可以成立的推論

| 舊回歸案例 | 原始微調輸出缺點 | 本次證據支持／不支持什麼 |
| --- | --- | --- |
| vfx-03 | 比正確基底多加 delayMs=0 | 不是直接複製訓練答案中同一預設值；可能是跨接口遵循不足，但單 seed 不能建立原因 |
| vfx-06 | 多加 delayMs=0、alpha=1，及另一層 nova | 顯示未要求內容新增問題；不能只以「格式更簡潔」說模型變好 |
| policy-05 | A/B 都選 accept、blink、self-to-ally，舊 scorer 均判錯 | 單一 ground-nova 的拒絕例沒有證明可遷移至其他能力／方向判斷 |
| coverage-03 | A/B 都沒有通過用途涵蓋；B 更換 EX 模板仍錯 | 槽位齊全與用途涵蓋是不同指標；單技能訓練不構成全英雄覆蓋訓練 |

其中 vfx-03 的 delayMs=0 被原 scorer 按精確 override 契約判 critical，不應改述成已證明造成危險遊戲行為。vfx-06 多層則確實是與原答案不同的 VFX 組合；仍未實際渲染。

## 下一次實驗應驗證的假說，不是本輪已完成能力

1. 微調可能改善「只輸出要求欄位」，但資料要加入有／無 override、要求移除／保留的成對規格，並跨不同措辭、層數及接口測試。已有 18 筆無 override 仍出錯，不能只宣稱補零值樣本就會修好。
2. 為支援／降級／拒絕做不同能力、方向、明確授權與未授權 fallback 的反事實對照；不能把 profile 未支援混成引擎一律不支援。
3. 用可執行覆蓋約束評估整個英雄的用途集合，而不只檢查 PASSIVE/Q/W/E/R/EX 名称齊全。訓練與測試都必須真的涵蓋此任務。
4. 下一候選須在新 dev 決策，舊回歸只作保留指標；新的未見 test 先封存，至少比較多個抽樣 seed。若加入修正器，另外報原始首答和修正後，不能把修正器成效算成純微調。

目前無法區分抽樣變異、窄域微調造成的能力干擾、提示接口差異或其他因素。需要受控新實驗，不應直接上更大 LoRA rank／更多 epochs。

原始證據：train.jsonl、known-corpus-regression/requests.json、known-corpus-regression/comparison.json。原評分與候選身份未變。作業系統程序清單另已確認没有 forge-training 訓練／評測程序，只有當次 ps/rg 檢查命令；不是等待中的訓練。
