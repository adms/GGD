# 本輪實作與前置失敗紀錄

本輪 2026-09-06 03:24:15 Asia/Taipei 開始，原截止 11:24:15 不變。首次正式訓練於 03:46:34 開始；之前都是環境／資料／train-only 學習診斷。没有執行雲端 GPU 或外部教師。

## 已保留的調整

1. `preflight-rejected-alpha-zero/`：第一批合成資料的 alpha=0 被真實 schema（下限 0.05）拒絕。保留全部原案例和失敗收據，再把新合成資料改成合法的 alpha=0.1／0.5；沒有改引擎或 scorer。先前文字 benchmark 未經此完整編譯驗證，其範圍不能外推。
2. `setup-esbuild-architecture-failure/`：原生 arm64 Node 與 checkout 已安裝的 x64 esbuild 不相容。CPU 協調器改用既有 Node；MLX Python worker 仍強制原生 arm64 與真實 Metal，並已量到 Apple M5 Max。
3. `learning-probe-v1/`：首八題同源且第一題答案出現在檢索範例中，初始 probe loss 0.0008055 幾乎為零；16 次單筆更新（lr=1e-4）後升為 0.5830，停止於學習閘，沒有正式訓練。
4. `learning-probe-v2/`：改為八個訓練類別平均，lr=5e-5、仍單筆更新；平均 loss 0.0127899 → 0.1456052，仍未通過。這是更新擾動的實測，不僅是原探針偏差；沒有忽略警報。
5. 現行探針：lr=1e-6、累積八題後更新一次，共兩次 optimizer updates。平均 loss 0.0127899 → 0.0116015，七類下降；梯度有限且 adapter bytes 改變。重載通過後，才從乾淨底座用 lr=5e-6、accumulation=4 啟動一個正式研究配方。

前置調整只使用 train／dev，當時尚未產生 holdout 模型輸出。記憶測試 adapter 從未作為正式訓練起點。舊收據中的絕對路徑保留當時值；封存後的實際檔案在各 archive 的 `stages/` 下面，勿把舊絕對路徑誤當現行 run。v1 程式在 `learning-probe-v1/source/`；v2 及現行程式在各自 preflight artifact 的 `source/`。

## 程式驗證

### 台詞前處理修正（20:23 UTC 取消舊協定）

原先只在提示要求忽略角色台詞，未符合專案「先由程式剝除完整 `「…」`」規則。發現後在 epoch 3 尚未完成時取消，當時未做任何 candidate dev、freeze 或 holdout 推論。舊資料、階段收據與取消紀錄保存於 `raw-dialogue-protocol-v3/`；大型 checkpoint 仍在原 runtime 目錄。封存收據的絕對路徑是當時值，應透過 archive 相對位置讀取，不得當作現行結果。

新協定保留原文 request／ownerTextSha256，另產生 mechanicsText；主輸入與 train-only retrieval 均經深度解析器剝除完整台詞，支援行內、多行、巢狀引號，未配對引號拒絕處理。數值、分組、target、scorer 與穩定訓練 recipe 不變。A baseline 和 B 都以新輸入從頭重跑，避免把前處理效益歸給微調；八小時截止不延後。

- `node --test tools/forge-training/test.mjs`：基本 local-only 政策、未知欄位／超時預算拒絕、家族隔離、train-only retrieval、獨立語意反例通過。
- 加上 `FORGE_CANCEL_TEST=<本次 run 絕對路徑>`：2 tests / 2 passed；真實 CLI 在 preflight 收到取消後回到 cancelled，沒有啟動 doctor／GPU worker，lease 清理成功。此項使用 `/usr/bin/false` 作 worker executable，即使取消失效也不會誤開 GPU。
- 合成 target 檢查：216 題中 126 題可生成配置跑過既有 schema／compiler／SimWorld；90 題拒絕或澄清走無提案契約。不能說 216 題都執行了遊戲技能。
- Scorer：216 個正例與 21 個故意錯誤輸出檢查通過；這是程式守衛，不是人工確認的自然語言 Gold。

## 交付界線

## 實測錯誤與後續假說

- 合成 holdout B 唯一未過 `test-14-5`：560 WC3、190 true damage、point、delayMs=100 是合法組合，卻回 refused。這是過度拒絕；本輪不依此題再訓練。
- 選定 BF16 dev 的 `dev-10-5` 將明示骨頭跟隨需求錯誤接受；不能把 test 只剩過度拒絕誤讀成所有拒絕安全已完全解決。
- 4-bit dev 雖同為 23/24，修好 `dev-10-5`，但 `dev-8-0` 變成過度拒絕。量化／融合造成行為改變，不是 bit-exact 相同模型。
- 已知舊題 B 新退步：`vfx-03` 擅自加 `delayMs=0`；`vfx-06` 擅自加 alpha、delayMs 與額外圖層。它們不是 alpha=0 舊 oracle 的排除爭議，而是真正的該題契約不符合。單一專用資料分布不足以保證跨接口保留。
- 後續可驗的假說：用真實核可資料增加「只覆寫明示欄位／不能加圖層」的對照例、同機制多措辭、授權替代及不支援邊界，並混合原能力保留資料；但必須另立獨立來源評測，不能拿這輪已看過的錯題當新 test 宣稱泛化。此輪沒有執行追加訓練。

原子 JSON 階段收據取代此輪不必要的 SQLite 實作；有取消、deadline、資源鎖、輸入 hash 和阶段續跑。沒有 optimizer／RNG 精確續訓。融合／4-bit 工作流是可選本機部署診斷，沒有結果收據前保持 not-tested。

此輪沒有修改遊戲機制、正式內容、Editor 發布設定或舊 benchmark；沒有 commit／push。主計畫只加上本輪選型、開始時間與證據限制的覆蓋說明。正式結果請以 `experiment-report.md` 與 `comparison.json` 為準，本文不預告有效性。
