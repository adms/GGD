# 計畫對齊稽核（2026-09-06）

上一個目標回合分類為 **progress**：實際完成 LoRA、A/B、量化與回歸證據。本回合追加規則比較、分項成本與合法快取續跑驗證。沒有新增訓練、修改凍結測試或提升候選等級。

不能把 `pipeline-complete-unqualified` 解讀成完整產品完成。計畫 §23 明確區分完整產品與 §26 八小時實驗；下面只證明已核對的實驗交付，完整產品仍有未完成項，目標暫不標 complete。

## §26 逐項核對

| 條款 | 現況與證據 | 判定 |
| --- | --- | --- |
| 26.1 問題與成效界線 | comparison.json 固定為 evidence-insufficient；只有 synthetic 訊號 | 已記錄，不構成真實需求有效性證明 |
| 26.2 任務、平台與排除項 | experiment-policy.json；engine-snapshot.json；實測官方 4B non-thinking / MLX；模型選型依計畫頂部覆蓋 | Mac-only 單招切片已跑；附加狀態／多目標／方向／持續時間仍未涵蓋 |
| 26.3 A/B 公平性 1–4 | freeze stage、48 組相同 request digest/seed、96 scorer replay、同 BF16 runtime、first output、無修正器 | integrity-audit.json 證明本次配對；可選 C／修正器未跑 |
| 26.3 公平性 5–7 | worker metadata、單 runtime-root lease；A 後 B，沒有同時 GPU job | 有 fresh-process 載入值；非 cold-disk，未做 AB/BA 交错；C 不適用 |
| 26.3 規則覆蓋 | diagnostics/rule-comparison.json：144/144、24/24、48/48，另過相同引擎 | 後設字面 grammar comparator；不是預先登錄的 C，也不能外推自然語言 |
| 26.4 數量、來源、split、台詞 | dataset-manifest.json、split-report.json、cases.private.json；144/24/48，先按組合家族切分；原文 hash 保留 | 列數符合；獨立人工 Gold 為 0，品質證據不足；不假造 Silver |
| 26.4 必要三類 | holdout proposed 24、refused 12、advice 12 | 已覆蓋；不表示各種真實難例均已覆蓋 |
| 26.5 學習與乾淨正式起點 | learning-sanity stage、sanity-reload stage、train stage；loss 下降、權重改變、finite gradients；正式 108 updates | 已實測；失敗試跑與台詞協定修正保留於 archives |
| 26.5 dev 選模 | candidate-dev-1/2/3 與 freeze；按固定排序選 epoch 2 | 已實測；不依 test 再調參 |
| 26.6 oracle 與反例 | scorer-checks.json：216 positives、21 mutations；test.mjs 手寫 anchor | 程式規格守衛已驗；anchor 非人工核可，不能宣稱 Gold oracle |
| 26.6 遊戲行為 | preflight targets-engine、engine-validation、diagnostics/engine-results.json；後補 behavior-matrix-final/results.json | 57 組 paired cast/no-cast 檢查圈內敵人一次傷害、施法者／友方／範圍外無額外命中或掉血，半徑錯誤夾具被攔。狀態到期／onHit-onMiss 尚未驗 |
| 26.7 主指標、配對與分母 | comparison.json：eligible 10/24→23/24，全題 33/48→47/48，fixed 14/regressed 0 | 已核對；無刪除解析失敗或超時個案 |
| 26.7 分項、token、成本、載入 | diagnostics/metrics.json、diagnostics/REPORT.md | 已補；修改工時／電費未測，不能拿推論秒數充當全部成本 |
| 26.7 家族不確定性 | diagnostics/metrics.json 保存每家族成績與不能估可靠區間的原因 | 4 個可完成組合家族共用單一 grammar，單 seed，不提供虛假泛化 CI |
| 26.8 政策、停止晉級 | experiment-policy.json、freeze、comparison、package qualified=false | 保留 A 與所有錯誤；研究用轉換不等於候選晉級 |
| 26.9 時間與取消 | 原 deadline 不變；原 CANCEL 成功終止舊 managed worker；当前 worker lease=null、lock 不存在 | 無雲端、無延長、無追加配方；沒有把前置失敗時間扣掉 |
| 26.10 必交產物 | 下表 | 已有收據；缺口仍列 not-tested / evidence-insufficient |

## 必交產物索引

| 計畫接口 | 實際路徑 |
| --- | --- |
| experiment-policy | experiment-policy.json |
| dataset-manifest / split-report | 同名 JSON |
| scorer-checks | scorer-checks.json；薄守衛 tools/forge-training/test.mjs |
| baseline-dev | stages/baseline-dev/attempt-1/result.json |
| learning-sanity | stages/learning-sanity/attempt-1/result.json |
| training-run | stages/train/attempt-1/result.json；內含原 runtime 引用與檔案 hash |
| comparison JSON / Markdown | comparison.json；experiment-report.md；diagnostics/REPORT.md |
| experiment-report | experiment-report.md；FINAL_REPORT.md；IMPLEMENTATION_NOTES.md |
| adapter、base、tokenizer、license | research-adapter/；package-manifest.json；model-download.json |
| mac-deployment-report | mac-deployment-report.json；deployment-roundtrip.json；quantized-dev.json |
| 原始／逐題輸出 | stages/test-A、stages/test-B、known-corpus-regression/A.json、B.json |
| 合法快取重用 | 本回合命令 `cli.mjs resume --python /usr/bin/false` exit 0，所有 stages 重用；未啟動 GPU worker |

量化前的部署報告另保存在 mac-deployment-report.pre-deployment.json；目前主報告指向實際 roundtrip 與 dev 結果。16GB 實機依然 not-tested。

## 尚未完成的目標面向

- 已新增獨立 `intake.mjs` 入口與 INTAKE.md：來源／外部核可摘要、授權清單、跨 split 隔離、待審佇列、實際引擎閘與 MLX JSONL 匯出。`outputs/forge-intake-smoke-20260906/` 4 筆夾具得到 Gold 0／Pending 1／Rejected 3。這只證明隔離接線；沒有新的真實核可資料，未串進凍結 run 或提供人工審查 UI，不能稱完整資料產線已完成。
- 真實來源盤點已由 `inventory.mjs` 執行：`outputs/forge-owner-inventory-20260906/` 包含 90 個唯一技能 ID，90 個同 ID JSON，全文相同 10、僅括號／空白差異 13、其他全文差異 67；全部 Pending，沒有輸出訓練資料。未取得外部核可 registry，不能以相同 ID 或 provenance 宣告補足 Gold。差異不是自動的機制錯誤判定；完整 source／target 對照均保留。
- ground-nova 目標負例已補 57 組；狀態與命中時序矩陣仍未覆蓋，不能把一次範圍傷害的證據外推。
- 已新增 `workflow.mjs` 單一入口，串連核心實驗、稽核、診斷、行為矩陣、可選量化／已知題回歸與總報告。`workflow-attempts/1788644209784-2134/receipt.json` 證明 finalize-existing 分支成功，以 allowNewGpuDiagnostics=false 驗證並重用真實結果，不啟動 GPU。新 run 分支已接線但尚未重做第二次完整訓練，不能把歷史子階段成果冒充新版端到端實測。
- 完整產品的任務契約、資料產線、Editor 接入、release gate／回滾、全套 heroForge 提案與視覺校準，不是目前工具的完成範圍。
- 合法快取重用已實測。後續發現並修正資料匯出檔位於 stage 目錄外的缺口，現已驗 train／test request／cases／policy／artifact／source 改動的拒絕路徑；新版也將資料摘要放進執行中 ensure。尚未實作完整依賴失效圖／自動局部重建，採明確拒絕並要求新 run。
- 這次快取修正變更核心程式版本，原實驗 source snapshot 保留；不得用新版 CLI 重跑原 run 並冒充同一版本。原始研究模型／A/B 結果不變。
- 最終快取整合證據：`outputs/forge-cache-check-final-20260906/results.json`，7/7；每項保留具體 expected error、stdout／stderr 與時長。有效快取 probe 耗時 24.66 秒，說明原 20 秒測試時限不足；原 run state hash 未變。執行中資料 pin 的變更檢查另由薄單元守衛驗證，未把它誇大為真實訓練中故障注入。
- 缺可靠自然語言資料時，下一步應建立可核可的來源匯入與評測契約，不是繼續追求相同 grammar 合成題滿分。

因此本文件不把完整目標標為已達成，也不因已有合成增益自動繼續訓練。後續須在原 Mac-only、八小時與候選不晉級限制內，補具體缺口並更新此矩陣。
