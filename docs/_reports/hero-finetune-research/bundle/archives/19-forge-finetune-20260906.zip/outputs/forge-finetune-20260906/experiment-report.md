# Mac 本機微調實驗報告

執行狀態：pipeline-complete-unqualified。結論：evidence-insufficient。
開始：2026-09-05T19:24:15Z；截止：2026-09-06T03:24:15Z；更新：2026-09-05T21:16:46.311Z。

Qwen3.5-4B non-thinking；本機 MLX，沒有雲端 GPU／外部教師／Editor 啟用。

## 資料與結論邊界

本輪資料為新編寫的 synthetic-research 診斷案例，沒有已核可的 Owner Gold。家族先切分再擴增，但仍共用一種語言模板與引擎模板。不能以此宣稱真實英雄需求泛化或正式發布合格。原先四組 benchmark 沒有作為訓練集或此次未見評測。

## 階段

| 階段 | 狀態 | 證據 |
| --- | --- | --- |
| preflight | succeeded | [artifact](stages/preflight/attempt-1/result.json) |
| doctor | succeeded | [artifact](stages/doctor/attempt-1/result.json) |
| baseline-dev | succeeded | [artifact](stages/baseline-dev/attempt-1/result.json) |
| learning-sanity | succeeded | [artifact](stages/learning-sanity/attempt-1/result.json) |
| sanity-reload | succeeded | [artifact](stages/sanity-reload/attempt-1/result.json) |
| train | succeeded | [artifact](stages/train/attempt-1/result.json) |
| candidate-dev-1 | succeeded | [artifact](stages/candidate-dev-1/attempt-1/result.json) |
| candidate-dev-2 | succeeded | [artifact](stages/candidate-dev-2/attempt-1/result.json) |
| candidate-dev-3 | succeeded | [artifact](stages/candidate-dev-3/attempt-1/result.json) |
| freeze | succeeded | [artifact](stages/freeze/attempt-1/result.json) |
| test-A | succeeded | [artifact](stages/test-A/attempt-1/result.json) |
| test-B | succeeded | [artifact](stages/test-B/attempt-1/result.json) |
| engine-validation | succeeded | [artifact](stages/engine-validation/attempt-1/result.json) |
| package | succeeded | [artifact](stages/package/attempt-1/result.json) |

## A/B 合成診斷結果

| 組別 | 全題通過 | 可完成題通過 | 重大錯誤 | 平均秒 |
| --- | ---: | ---: | ---: | ---: |
| A | 33/48 | 10/24 | 11 | 1.17 |
| B | 47/48 | 23/24 | 1 | 1.35 |

配對：{"bothCorrect":33,"fixedByFinetune":14,"regressedByFinetune":0,"bothWrong":1}；主指標提升 54.17 個百分點。
這是合成診斷，不是先前 GGUF benchmark 的直接延續；本次 A/B 使用相同 BF16 MLX、相同請求／抽樣與無 grammar 的原始輸出。

[逐案比較](comparison.json)

## 未驗證與操作

16GB MacBook 實機、視覺、美感、全英雄創意／平衡、完整 Editor 接入及跨平台發布均未驗證。現有 release manifests 保持不變。
協調器使用原子 JSON 階段收據與 process-group lease；未實作 SQLite。可續跑完成階段，但非 optimizer/RNG 精確續訓。訓練中斷後以新 attempt 從乾淨底座重跑，保留舊 checkpoint。

研究 adapter 與大型檔案放在設定的 runtime-root，不在 Dropbox；請依 package-manifest.json 備份，/private/tmp 不是永久儲存。

[資料清單](dataset-manifest.json) · [split 報告](split-report.json) · [scorer 守衛](scorer-checks.json) · [執行政策](experiment-policy.json)

技術依據：[Qwen 官方模型卡](https://huggingface.co/Qwen/Qwen3.5-4B)、[MLX-LM LoRA](https://github.com/ml-explore/mlx-lm/blob/main/mlx_lm/LORA.md)。實際版本與權重 hash 以本次收據為準。
