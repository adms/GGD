# 本機微調交付報告

## 結論

已實作並實際跑完 Qwen3.5-4B non-thinking / MLX LoRA 研究流程。有效性判定仍為 **evidence-insufficient**：沒有人工核可的獨立 Owner Gold，不是可正式發布的英雄鑄造模型。
合成診斷訊號：positive-synthetic-signal；新增重大錯誤 0。

## 固定 A/B 合成 holdout

A 為未微調基底，B 為 dev 選出的 epoch 2。同一資料、前處理、檢索、BF16 runtime 與抽樣，沒有 grammar。

| 指標 | A | B |
| --- | ---: | ---: |
| 全題 | 33/48 | 47/48 |
| 可完成題 | 10/24 | 23/24 |
| 重大錯誤 | 11 | 1 |
| 平均秒/題 | 1.17 | 1.35 |

配對：{"bothCorrect":33,"fixedByFinetune":14,"regressedByFinetune":0,"bothWrong":1}。重大錯誤分類是保守的：合法題遭過度拒絕時缺少必填機制欄位也可能列入，不能把全部 critical 當作危險技能真的被執行。

| 預期決策 | A | B |
| --- | ---: | ---: |
| proposed | 10/24 | 23/24 |
| refused | 12/12 | 12/12 |
| advice | 11/12 | 12/12 |

## 本機資源與部署

正式訓練 35.01 分鐘，峰值 Metal 17.79 GiB；全任務到本報告 2.22 小時，包含建置、下載、失敗試跑與前處理修正。沒有租用雲端 GPU（GPU 費用 USD 0；不代表 Codex 帳單為零）。
固定 4-bit/group64 dev：23/24；選定 BF16 adapter dev：23/24。逐題配對 {"bothCorrect":22,"fixed":1,"regressed":1,"bothWrong":0}；同分不代表完全相同。4-bit 獨立 worker 峰值 Metal 3.38 GiB、平均 0.55 秒/題、模型檔案 2.22 GiB。
融合與序列化收據：[deployment-roundtrip.json](deployment-roundtrip.json)。融合最大 logit 差 0.1875，BF16/4-bit 保存重載最大差 0/0。兩個 dev next-token probe 只驗證數值接線，不代表品質。
16GB MacBook 未實測；Metal 峰值不等於整機 RAM，仍需納入系統、Editor、上下文與 KV cache。

## 已知題庫回歸

BF16 同協定 A 19/23，B 19/23；{"bothCorrect":17,"fixed":2,"regressed":2,"bothWrong":2}。[完整回歸](known-corpus-regression/REPORT.md)。這是已知舊題跨接口保留檢查，不是未見泛化，亦不可直接和舊 GGUF + grammar 分數比較。

## 交付與限制

研究 adapter 已另存並校驗於 [research-adapter](research-adapter)，約 31 MiB。大型 BF16/4-bit 在 /private/tmp，可能被系統清理，並非永久部署。量化模型位置：/private/tmp/ggd-forge-qwen35-4b-finetuned-20260906/mlx-4bit。
原文 request 與 hash 保留；模型只讀經程式去除完整台詞的 mechanicsText。216 個合成案例：144 train／24 dev／48 holdout；只有一種語言 grammar 與一種引擎模板。不是完整英雄技能用途、VFX 美感、平衡或全機制能力的證明。
接下來必須以人工核可的真實原文／配置建立獨立 source-family holdout，才可決定擴充或停止投入。沒有改動 Editor、發布旗標、既有引擎，也沒有 commit／push。

[完整階段報告](experiment-report.md) · [完整性稽核](integrity-audit.json) · [逐題 A/B](comparison.json) · [失敗與修正紀錄](IMPLEMENTATION_NOTES.md) · [機器可讀摘要](FINAL_SUMMARY.json)

## 後補的規則／成本比較

固定字面語法規則 train 144/144、dev 24/24、test 48/48，含相同 scorer 與引擎檢查。這是看過已編寫 grammar 後建立的比較，不是預先登錄的第三組。
目前合成題可由規則完成，因此不足以證明實際需要 fine-tune。下一輪資料必須含真實、多措辭且人工核可的需求，不能只擴增相同模板。
[分項指標、成本、家族與不確定性](diagnostics/REPORT.md)
