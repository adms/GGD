# 組合診斷補充隊列

原composition-diagnostic-v2的20題：10接受、10拒絕，皆曾審查，皆不在2695題主隊列的完全相同輸入中。保留原始messages／答案；不訓練、不重選checkpoint、不重啟截止後的R7舊程序。已知組合家族，不是獨立Owner Gold。

此處只是準備，須完成token長度檢查並取得三模型實際輸出才能宣稱已測。與主隊列分開報告，未增加語意家族數。

## 2026-09-07 補测完成（原資料與上述準備快照保留）

使用者另行授權推論後，已在獨立 `outputs/forge-composition-supplement-inference-20260907-v1/` 完成相同 20 題 × 基底／R3／R7，原始 messages／答案／來源 pins 均保持。輸入 2915–2939 tokens，加 256 輸出預留皆通過；60 次原始輸出完成。

基底 17/20、錯誤放行 1；R3 與 R7 各 12/20、錯誤放行 8。9 題失敗聯集已回讀需求與候選計畫覆核。[完整報告](../../forge-composition-supplement-inference-20260907-v1/REPORT.md)。這仍是已知計畫家族回歸；不改主隊列分母、不訓練、不啟用模型，worker 已結束。
