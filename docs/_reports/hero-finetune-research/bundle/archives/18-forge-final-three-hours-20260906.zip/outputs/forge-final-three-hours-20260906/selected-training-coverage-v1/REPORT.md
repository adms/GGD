# 所選權重的實際教師答案覆蓋

R3 epoch2使用434個獨特訓練例、2輪。R7所選step48只新增192例；不是準備466或worker完整更新380例。下表數例，不把梯度步數、重複epoch或評分用acceptedTargets選項假裝成新的獨特教師例。

| 任務 | R3獨特train | R7選中新增前綴 |
| --- | ---: | ---: |
| hero-source | 90 | 41 |
| owner-mechanism | 120 | 71 |
| mechanism-template | 170 | 22 |
| mechanism-stack | 0 | 39 |
| vfx-semantic | 54 | 19 |

## 真正多卡正例

R3沒有mechanism-stack例。R7的39個stack例中21個accept；僅6個正例的templateIds長度大於1，其中4個是重複卡，涵蓋3種實際卡片序列。

| 教師卡片序列 | 正例數 | 來源case |
| --- | ---: | --- |
| tpl-single-strike → tpl-single-strike | 4 | r6-stack-train-double-no-merge, r6-stack-train-double-same-target, r6-stack-train-double-events, r6-stack-train-double-automatic |
| tpl-buff-self → tpl-life-manipulate | 1 | r6-stack-train-recovery-duration |
| tpl-on-attack → tpl-on-hit-react | 1 | r6-stack-train-hooks-no-area |

## 公開組合能力的研究範圍

目前保存的研究目錄只有32個明列計畫：29個單卡、3個多卡。多卡為：
- composition-self-buff-restore：tpl-buff-self + tpl-life-manipulate
- composition-independent-hooks：tpl-on-attack + tpl-on-hit-react
- composition-two-immediate-strikes：tpl-single-strike + tpl-single-strike

因此不能把它称为所有英雄機制或任意技能組合的完整訓練／評測。整個引擎能做什麼與這個受限研究目錄放行什麼，是不同範圍。三個計畫的語意條件與必要人工選項仍須核對，不因同卡片序列就推論所有需求等價。

輸出契約要求templateIds，不要求另加planId；缺少planId不是資料缺陷。把計畫ID填進templateIds才是ID種類混淆。上述覆蓋稀疏與組合退步相符，但沒有單因果實驗，不能斷言補例一定改善。依最新指示不再訓練。

## 單模板教師正例分布

| 模板 | R3正例 | R7選中新增正例 |
| --- | ---: | ---: |
| tpl-buff-self | 4 | 0 |
| tpl-charge-push | 6 | 0 |
| tpl-ground-nova | 2 | 0 |
| tpl-instant-blast | 6 | 1 |
| tpl-leap-strike | 6 | 0 |
| tpl-life-manipulate | 0 | 1 |
| tpl-line-sweep | 8 | 0 |
| tpl-lock-combo | 10 | 1 |
| tpl-locust-orb | 0 | 1 |
| tpl-mark-stacks | 10 | 1 |
| tpl-on-attack | 6 | 0 |
| tpl-on-hit-react | 4 | 0 |
| tpl-orbit-array | 2 | 0 |
| tpl-proxy-cast | 2 | 1 |
| tpl-proxy-fanout | 4 | 0 |
| tpl-radial-burst | 0 | 1 |
| tpl-random-barrage | 4 | 1 |
| tpl-single-strike | 4 | 1 |
| tpl-teleport | 2 | 0 |
| tpl-traveling-wave | 8 | 0 |
