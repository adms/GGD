# 全資料推論對照與錯誤分析

分析時間：2026-09-06T17:45:39.447Z；推論程序：running。計畫2695題，完整三模型配對570題，可信評分分母570題；未配對2125題。

沒有新增訓練，R8未訓練；不由這份分析重選checkpoint。版本盤點見資料目錄INVENTORY.md。

## 按任務／模型

| 任務 | 模型 | 正確 | 誤放行 |
| --- | --- | ---: | ---: |
| hero-source | base | 322/348 | 4 |
| owner-mechanism | base | 203/222 | 3 |
| hero-source | r3 | 338/348 | 0 |
| owner-mechanism | r3 | 206/222 | 0 |
| hero-source | r7 | 339/348 | 0 |
| owner-mechanism | r7 | 206/222 | 0 |

## 七個新角色來源，未訓練

這147題原本的train/dev/test標籤只代表預先固定的資料切分；任何一題都未用於本次新訓練。沒有獨立Owner Gold，仍屬經審查的GGD改編來源研究。

| 原切分 | 模型 | 正確 | 誤放行 |
| --- | --- | ---: | ---: |
| train | base | 79/84 | 0 |
| train | r3 | 76/84 | 0 |
| train | r7 | 76/84 | 0 |
| dev | base | 20/21 | 0 |
| dev | r3 | 18/21 | 0 |
| dev | r7 | 18/21 | 0 |
| test | base | 40/42 | 0 |
| test | r3 | 40/42 | 0 |
| test | r7 | 41/42 | 0 |

七角色再按7份英雄設定＋42份技能來源分組，只有該份來源的所有已提供命題均答對才算整組通過；這仍不證明未列出的所有原文要求也被涵蓋。

| 模型 | 來源組內已提供命題全對 | 有誤放行的來源組 |
| --- | ---: | ---: |
| base | 41/49 | 0 |
| r3 | 36/49 | 0 |
| r7 | 37/49 | 0 |

## 實際訓練暴露分層

| 以誰的訓練紀錄分層 | 題型 | 模型 | 正確 | 誤放行 |
| --- | --- | --- | ---: | ---: |
| r3 | exact-training-input | base | 109/122 | 2 |
| r3 | exact-training-input | r3 | 116/122 | 0 |
| r3 | exact-training-input | r7 | 116/122 | 0 |
| r3 | new-input-seen-source | base | 35/43 | 5 |
| r3 | new-input-seen-source | r3 | 42/43 | 0 |
| r3 | new-input-seen-source | r7 | 42/43 | 0 |
| r3 | new-input-new-source | base | 381/405 | 0 |
| r3 | new-input-new-source | r3 | 386/405 | 0 |
| r3 | new-input-new-source | r7 | 387/405 | 0 |
| r3 | new-nonsource-input | base | 0/0 | 0 |
| r3 | new-nonsource-input | r3 | 0/0 | 0 |
| r3 | new-nonsource-input | r7 | 0/0 | 0 |
| r7 | exact-training-input | base | 119/132 | 2 |
| r7 | exact-training-input | r3 | 126/132 | 0 |
| r7 | exact-training-input | r7 | 126/132 | 0 |
| r7 | new-input-seen-source | base | 25/33 | 5 |
| r7 | new-input-seen-source | r3 | 32/33 | 0 |
| r7 | new-input-seen-source | r7 | 32/33 | 0 |
| r7 | new-input-new-source | base | 381/405 | 0 |
| r7 | new-input-new-source | r3 | 386/405 | 0 |
| r7 | new-input-new-source | r7 | 387/405 | 0 |
| r7 | new-nonsource-input | base | 0/0 | 0 |
| r7 | new-nonsource-input | r3 | 0/0 | 0 |
| r7 | new-nonsource-input | r7 | 0/0 | 0 |

## 版本覆蓋

同一請求可能屬於多版，下面不能相加為獨特資料量。

| 資料版 | 原始列 | 計畫獨特請求 | 已配對 | 有效評分 |
| --- | ---: | ---: | ---: | ---: |
| forge-source-rehearsal-r8-v1-20260906 | 957 | 957 | 402 | 402 |
| forge-final-three-hours-20260906/final-broader-data-v1 | 582 | 582 | 140 | 140 |
| forge-low-lr-r7-v2-20260906 | 810 | 810 | 255 | 255 |
| forge-joint-source-stack-r6-v2-20260906 | 810 | 810 | 255 | 255 |
| forge-contrastive-r5-20260906 | 873 | 873 | 227 | 227 |
| forge-source-calibration-r4-20260906 | 837 | 837 | 245 | 245 |
| forge-mechanism-priority-r3-20260906 | 625 | 625 | 207 | 207 |
| forge-classification-reviewed-r2-20260906 | 488 | 488 | 0 | 0 |

## 目錄排列重複與穩定性

2695個完全訊息去重請求，若僅忽略catalog／allowedPlans／unavailable的列表排列，剩2579個；116個額外排列不是同樣數目的新語意需求。0/58組已完整配對，可在summary.json查看排列不同時答案／正確性是否改變。計畫內卡片順序、重複數、描述、原文與system完全保留，不為去重刪掉語意。

## 判讀限制

- 不是所有歷史隔離／舊proposal資料都納入此次新推論，未匹配項目逐份列於INVENTORY.md；不能把已排隊當完成。
- 新錯誤放行、過度拒絕、錯誤模板／計畫、來源contradicted與not-stated混淆分開計數，詳見summary.json。
- all-failures.private.json保留所有配對失敗的完整输入、預期、原始值與理由；review-priority.private.json優先列新七角色與來源退步供人工分析。自動錯誤分類不代表已逐題人工裁定。
- 12GiB配置只測這台M5 Max，非16GB MacBook實機證明。生成耗時不含全部檔案校驗或入口冷啟動。
- 全部維持research-only；平均分、格式合法或訓練題命中不等於完整英雄技能鑄造合格。
