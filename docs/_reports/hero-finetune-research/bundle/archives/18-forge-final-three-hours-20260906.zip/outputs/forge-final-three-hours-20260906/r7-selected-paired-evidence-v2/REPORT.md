# 所選R7實際訓練暴露：script與模型對照

狀態：partial-research-evidence。原post：failed；缺少6組原始輸出，不補零、不冒稱通過。
R3的434個獨特train＋所選R7前192例；原始626、去重523。TF-IDF演算法與dev選參數不變，不按test換政策。

| 題組 | 任務 | 方法 | 正確 | 誤放行 |
| --- | --- | --- | ---: | ---: |
| core-dev | hero-source | nearest-accuracy | 17/21 | 0 |
| core-dev | owner-mechanism | nearest-accuracy | 70/89 | 7 |
| core-dev | mechanism-template | nearest-accuracy | 19/24 | 4 |
| core-dev | mechanism-stack | nearest-accuracy | 14/24 | 9 |
| core-dev | hero-source | nearest-safety | 17/21 | 0 |
| core-dev | owner-mechanism | nearest-safety | 70/89 | 7 |
| core-dev | mechanism-template | nearest-safety | 19/24 | 4 |
| core-dev | mechanism-stack | nearest-safety | 14/24 | 9 |
| core-dev | mechanism-template | catalog-accuracy | 15/24 | 1 |
| core-dev | mechanism-stack | catalog-accuracy | 12/24 | 0 |
| core-dev | mechanism-template | catalog-safety | 15/24 | 1 |
| core-dev | mechanism-stack | catalog-safety | 12/24 | 0 |
| core-dev | hero-source | base | 19/21 | 0 |
| core-dev | owner-mechanism | base | 80/89 | 2 |
| core-dev | mechanism-template | base | 15/24 | 0 |
| core-dev | mechanism-stack | base | 20/24 | 0 |
| core-dev | hero-source | r3 | 21/21 | 0 |
| core-dev | owner-mechanism | r3 | 83/89 | 1 |
| core-dev | mechanism-template | r3 | 24/24 | 0 |
| core-dev | mechanism-stack | r3 | 13/24 | 10 |
| core-dev | hero-source | selected | 21/21 | 0 |
| core-dev | owner-mechanism | selected | 83/89 | 1 |
| core-dev | mechanism-template | selected | 24/24 | 0 |
| core-dev | mechanism-stack | selected | 17/24 | 6 |
| core-test | owner-mechanism | nearest-accuracy | 68/94 | 12 |
| core-test | mechanism-template | nearest-accuracy | 12/20 | 5 |
| core-test | hero-source | nearest-accuracy | 38/48 | 0 |
| core-test | mechanism-stack | nearest-accuracy | 12/24 | 8 |
| core-test | owner-mechanism | nearest-safety | 68/94 | 12 |
| core-test | mechanism-template | nearest-safety | 12/20 | 5 |
| core-test | hero-source | nearest-safety | 38/48 | 0 |
| core-test | mechanism-stack | nearest-safety | 12/24 | 8 |
| core-test | mechanism-template | catalog-accuracy | 12/20 | 0 |
| core-test | mechanism-stack | catalog-accuracy | 11/24 | 1 |
| core-test | mechanism-template | catalog-safety | 12/20 | 0 |
| core-test | mechanism-stack | catalog-safety | 11/24 | 1 |
| core-test | owner-mechanism | base | 82/94 | 3 |
| core-test | mechanism-template | base | 16/20 | 0 |
| core-test | hero-source | base | 43/48 | 0 |
| core-test | mechanism-stack | base | 16/24 | 4 |
| core-test | owner-mechanism | r3 | 87/94 | 1 |
| core-test | mechanism-template | r3 | 19/20 | 0 |
| core-test | hero-source | r3 | 47/48 | 0 |
| core-test | mechanism-stack | r3 | 9/24 | 15 |
| core-test | owner-mechanism | selected | 85/94 | 1 |
| core-test | mechanism-template | selected | 18/20 | 1 |
| core-test | hero-source | selected | 47/48 | 0 |
| core-test | mechanism-stack | selected | 11/24 | 13 |
| source-63-regression | owner-mechanism | nearest-accuracy | 41/63 | 12 |
| source-63-regression | owner-mechanism | nearest-safety | 41/63 | 12 |
| source-63-regression | owner-mechanism | base | 57/63 | 3 |
| source-63-regression | owner-mechanism | r3 | 58/63 | 2 |
| source-63-regression | owner-mechanism | selected | 59/63 | 2 |
| previous-source-72 | owner-mechanism | nearest-accuracy | 41/72 | 14 |
| previous-source-72 | owner-mechanism | nearest-safety | 41/72 | 14 |
| previous-source-72 | owner-mechanism | base | 67/72 | 2 |
| previous-source-72 | owner-mechanism | r3 | 70/72 | 0 |
| previous-source-72 | owner-mechanism | selected | 70/72 | 0 |
| current-main-v4 | mechanism-template | nearest-accuracy | 27/40 | 8 |
| current-main-v4 | mechanism-template | nearest-safety | 27/40 | 8 |
| current-main-v4 | mechanism-template | catalog-accuracy | 26/40 | 4 |
| current-main-v4 | mechanism-template | catalog-safety | 26/40 | 4 |
| current-main-v4 | mechanism-template | base | 19/40 | 0 |
| current-main-v4 | mechanism-template | r3 | 31/40 | 3 |
| current-main-v4 | mechanism-template | selected | 37/40 | 3 |
| hero-140 | hero-source | nearest-accuracy | 77/140 | 6 |
| hero-140 | hero-source | nearest-safety | 77/140 | 6 |
| hero-140 | hero-source | base | 137/140 | 0 |
| hero-140 | hero-source | r3 | 139/140 | 0 |
| hero-140 | hero-source | selected | 140/140 | 0 |
| fidelity-114 | owner-mechanism | nearest-accuracy | 79/114 | 13 |
| fidelity-114 | owner-mechanism | nearest-safety | 79/114 | 13 |
| fidelity-114 | owner-mechanism | base | 113/114 | 1 |
| fidelity-114 | owner-mechanism | r3 | 114/114 | 0 |
| fidelity-114 | owner-mechanism | selected | 114/114 | 0 |
| composition-regression-20 | mechanism-stack | nearest-accuracy | 8/20 | 10 |
| composition-regression-20 | mechanism-stack | nearest-safety | 8/20 | 10 |
| composition-regression-20 | mechanism-stack | catalog-accuracy | 11/20 | 1 |
| composition-regression-20 | mechanism-stack | catalog-safety | 11/20 | 1 |
| source-clarification-15 | owner-mechanism | nearest-accuracy | 8/15 | 4 |
| source-clarification-15 | owner-mechanism | nearest-safety | 8/15 | 4 |

相同監督例可用不等於相同預訓練、梯度權重或計算量。此處沿用原R7輸入／wave標籤，不用校正後答案重算舊輸出。沒有VFX非LLM dev，因此不虛構該基線；模型VFX與未完成回歸仍須另外報告。

## 缺失原始輸出

- composition-regression-20/base：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
- composition-regression-20/r3：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
- composition-regression-20/selected：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
- source-clarification-15/base：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
- source-clarification-15/r3：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
- source-clarification-15/selected：AssertionError [ERR_ASSERTION]: AssertionError [ERR_ASSERTION]: GPU_CUTOFF
