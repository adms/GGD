# 英雄技能鑄造研究：資料與推論報告索引

## 最終收尾入口（2026-09-07）

使用者要求收尾，最後已啟動的 373 題原文推論完成後，停止新增實驗與 GPU 工作。請先讀[最終研究報告](../../Finetune_英雄技能模型_最終研究報告_20260907.md)：整合 R1–R7、所有近期補測、資料校正、模型保存、時間／記憶體、main 回饋與未完成界線。原目標的穩定全自動模型未達成，不啟用、不再訓練或續跑。

最後 373 題：基底 342/373（91.69%）、R3／R7 均 355/373（95.17%），錯誤放行 14／8／8。相對基底 R3 修正 15、退步 2；R7 修正 14、退步 1。33 題失敗聯集全部助理覆核，1 題冷卻語意 Gold 歧義另列，原標籤不改。[本批報告](../forge-owner-remaining-inference-20260907-v1/REPORT.md)。

主隊列最終覆蓋 **1623/2695 個輸入完整三模型配對、1622 題准予計分**：英雄 348/348、Owner 機制 979/979、機制計畫 296/296（其中撤回 1 題）。**剩餘單模板 700、VFX 372，共 1072 題明列未測，不再接續**；[缺測清單](../forge-owner-remaining-inference-20260907-v1/main-coverage.json)。新37名555題及補充20題保持獨立。

最後程序 1119 次推論合計 535.02 秒，Metal 峰值 8.53–8.94 GiB；程序正常結束、GPU lock 釋放、模型前後摘要一致。CPU 3 項對齊／序列化守衛通過，重播未更改任何分數。原始 JSON 不保存 undefined reviewReason，報告器僅以 JSON roundtrip 比對修正誤報，沒有重新推論。收尾狀態：[CLOSURE.json](../forge-owner-remaining-inference-20260907-v1/CLOSURE.json)。下方各段是歷史快照，缺測數以本節為準。

最新決策：停止訓練，只整理資料、既有模型推論和洞察。R8未訓練。以下全部為本機研究產物，沒有發布或啟用Editor。

**01:55 歷史停止快照：因使用者回報充電問題，GPU推論也已停止。954/2695題有完整三模型配對；其餘及補充20題未接續啟動。** 停止證據及電池讀值見[GPU_PAUSED_FOR_POWER.md](GPU_PAUSED_FOR_POWER.md)。下方舊快照的「進行中」不是重新啟動授權。

## 2026-09-07 新 37 名英雄：僅恢復推論後的完整結果

使用者另行授權「可以推論了」後，新校正資料的 555 題 × 基底／R3／R7 共 1,665 次推論已完成：[全量報告](../community37-inference-full-20260907-v1/REPORT.md)。基底 **529/555（95.32%）**、R7 **511/555（92.07%）**、R3 **500/555（90.09%）**，各有 1 題錯誤放行；微調相對基底修正 0 題、退步 18／29 題。55 題失敗聯集已逐題回讀原文覆核。

新資料是 [37 名英雄來源判讀增補](../community37-corrected-dataset-20260907-v1/README.md)，不含獲准的原意→模板正向映射，不是完整鑄造／遊戲驗收。沒有使用它訓練新模型，仍是 train-candidate，不能稱獨立未見 release test。先前 43 題小批包含在這 555 題內，不重複計數。舊 954/2695 隊列、CANCEL 與停止紀錄均未修改或重啟，這 555 題不混進舊分母。

全量推論程序合計 707.92 秒，Metal 峰值 8.61–9.03 GiB，worker 已結束並釋放 GPU lock。訓練仍停止、不啟用／發布模型；不自動接續舊隊列。

## 2026-09-07 機制組合 20 題補測

原本未完成三模型配對的 20 題單卡／多卡補充已另開獨立 run 完成：[完整需求、逐題輸出與覆核](../forge-composition-supplement-inference-20260907-v1/REPORT.md)。基底 **17/20（85%）、錯誤放行 1**；R3 與 R7 均 **12/20（60%）、錯誤放行 8**。兩個微調版本相對基底各修正 1 題、退步 6 題。9 題失敗聯集全數重新覆核，原標籤／模型輸出不變。

契約合法是基底 20/20、R3 17/20、R7 19/20；若僅以契約守衛拒絕非法推薦，仍分別剩 1、5、7 題合法格式但選錯機制。共享冷卻、跨對象、護盾、取消原傷害、反擊範圍與第二擊時序不是可忽略的調參細節。這是凍結候選計畫的分類回歸，不是現行 main 能力或完整英雄驗收。

60 次程序合計 82.58 秒，Metal 峰值 9.35–9.72 GiB；worker 已結束並釋放 GPU lock，未訓練。此補充不屬於原 2695 題，不混入其 954 題完成分母；主隊列仍有 1741 題未完整三模型配對。

## 2026-09-07 主隊列機制計畫全量補測：最新完成範圍

主隊列 mechanism-stack 的 296 個輸入已完成三模型配對（888 次推論）；一題在推論前已撤回標籤，正式計分 **295 題**：[完整報告](../forge-stack-full-inference-20260907-v1/REPORT.md)。基底 **212/295（71.86%）、錯誤放行 22**；R3 **180/295（61.02%）、錯誤放行 110**；R7 **212/295（71.86%）、錯誤放行 76**。

R7 相對基底修正 52、退步 52。可接受需求正確推薦由 65/147 提高到 116/147，但应拒絕需求正確數由 147/148 降到 96/148；總分持平掩蓋了能力邊界退步。R7 契約合法仍錯誤放行 58 題，不是只修 JSON／ID 即可解決。失敗聯集 152 個輸入、89 種需求文字已全數助理覆核，不是獨立 Owner Gold；未改標籤。

296 輸入含兩版候選目錄，計分後只有 158 種需求文字；39 個完整輸入匹配 R7 訓練資料，不能混稱未見測試。執行合計 1231.84 秒（20.53 分鐘），Metal 峰值 9.35–9.72 GiB；模型前後摘要一致，程序成功退出並釋放 GPU lock。沒有訓練、部署或新 main 缺陷宣告。

主隊列最新合併**覆蓋**為 **1250/2695 個輸入已完整三模型配對、其中 1249 題准予計分，剩 1445 題未完整配對**（Owner 機制 373、單模板 700、VFX 372）。這是獨立 run 的覆蓋帳本，不合併不同任務為單一品質分數；[逐 ID 缺測清單](../forge-stack-full-inference-20260907-v1/main-coverage.json) 驗證與舊 954 題不重疊。上方補充20題段落及下方舊總報告的 1741 題為當時快照，現由此節更新；原 failed／CANCEL 與報告不改寫。新37名555題與補充20題仍不混入主隊列分母。

## 先讀這三份

1. [總報告：停止算力版](FINAL_REPORT.md)：已整合R1–R7、954題配對、資料品質、67題失敗複查、時間／記憶體、非LLM比較、main回饋與模型保存。1,741題主隊列未完成，明列缺測，不代表模型目標達成。舊[草稿](RESULTS_REPORT_DRAFT.md)保留快照。
2. [七個新角色完整結果](SEVEN_HEROES_INFERENCE_FINDINGS.md)：147題三模型實測；微調沒有勝過基底，14題失敗聯集逐題複查。
3. [英雄設定348題完整結果](HERO_SOURCE_INFERENCE_FINDINGS.md)：微調在這批研究資料有進步，但五筆原標註政策疑義另列，未更改凍結答案。

## 資料及實驗可追溯性

| 需要查什麼 | 檔案 |
| --- | --- |
| 全部45份資料版本、哪些未新測 | [INVENTORY.md](inference-review-data-v1/INVENTORY.md) |
| 2695個請求對應的歷史ID／split／訓練暴露／撤回狀態 | [mapping.private.json](inference-review-data-v1/mapping.private.json) |
| 凍結輸入、原答案 | [cases.private.json](inference-review-data-v1/cases.private.json) |
| 輸入長度，是否截斷 | [token-budget.json](inference-review-data-v1/token-budget.json) |
| 最後完成階段／CANCEL，不能用排隊當完成 | [state.json](inference-review-run-v1/state.json) |
| 停機後三模型配對954題分析 | [分析報告](inference-review-analysis-power-stop-v1/REPORT.md) |
| 停機後全部104題失敗原文／答案／輸出 | [all-failures.private.json](inference-review-analysis-power-stop-v1/all-failures.private.json) |
| 每轮實際訓練與所選checkpoint | [LEDGER.md](experiment-ledger-inference-only-v1/LEDGER.md) |
| 所選權重究竟學過哪些任務／卡片 | [教師答案覆蓋](selected-training-coverage-v1/REPORT.md) |
| R7同題非LLM比較，含缺測項目 | [配對證據目錄](r7-selected-paired-evidence-v2/) |
| 資料與執行成本洞察 | [SOURCE_DATA_FINDINGS.md](SOURCE_DATA_FINDINGS.md) |
| 已回饋main的缺陷、證據及票號 | [MAIN_FEEDBACK_STATUS.md](MAIN_FEEDBACK_STATUS.md) |
| 主隊列未包含的20題組合補充，2026-09-07已補測 | [補充全結果](../forge-composition-supplement-inference-20260907-v1/REPORT.md)／[原資料清單](inference-review-composition-data-v1/INVENTORY.md) |
| 主隊列機制計畫296輸入／295計分，最新補測 | [完整報告](../forge-stack-full-inference-20260907-v1/REPORT.md)／[主隊列覆蓋](../forge-stack-full-inference-20260907-v1/main-coverage.json) |

`private`代表研究答案／來源材料，不是可公開發布包。本索引及本機保存不增加任何上傳授權；仍遵循使用者既有Dropbox同步設定。

## 模型保存與限制

[R3 native研究包](ggd-mac-r3-native-research-v1/)已逐檔驗證並實際重載；[公開入口測試](ggd-mac-r3-native-research-v1-portable-check/)為語意7/10、契約9/10。可載入不等於品質合格。沒有R8模型，沒有本次R3融合／8bit對照，16GB MacBook未實機測試。

所有原始實驗和已撤回題保留；不覆寫舊結果、不把研究模型標成正式成品、不再新增訓練。
