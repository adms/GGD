# 七角色：非LLM檢索對照

原訓練資料與原訓練+84題新來源分開建TF-IDF最近例。K僅用179 dev挑選，42題新角色測試不參與選擇。兩個policy均保留，不能看test挑好看的那個。這不證明任何finetune收益，也不是完整引擎能力測試。

| 訓練暴露 | K政策 | 任務 | 正確 | 錯誤放行 |
| --- | --- | --- | ---: | ---: |
| old-training-only | accuracy | owner-mechanism | 24/36 | 6 |
| old-training-only | accuracy | hero-source | 3/6 | 0 |
| old-training-only | safety | owner-mechanism | 22/36 | 6 |
| old-training-only | safety | hero-source | 3/6 | 0 |
| old-plus-community84 | accuracy | owner-mechanism | 23/36 | 7 |
| old-plus-community84 | accuracy | hero-source | 3/6 | 0 |
| old-plus-community84 | safety | owner-mechanism | 23/36 | 7 |
| old-plus-community84 | safety | hero-source | 2/6 | 0 |
