// Generated public-export facade; no training data or answer tables.
import crypto from "node:crypto";
export const digest = value => crypto.createHash('sha256').update(typeof value === 'string' ? value : JSON.stringify(value)).digest('hex');
export function mechanicsText(original) {
 let depth=0, result='';
 for(const ch of original){
  if(ch==='「'){depth++;continue;}
  if(ch==='」'){if(!depth)throw Error('UNMATCHED_DIALOGUE_CLOSE');depth--;continue;}
  if(!depth)result+=ch;
 }
 if(depth)throw Error('UNMATCHED_DIALOGUE_OPEN');
 return result;
}
