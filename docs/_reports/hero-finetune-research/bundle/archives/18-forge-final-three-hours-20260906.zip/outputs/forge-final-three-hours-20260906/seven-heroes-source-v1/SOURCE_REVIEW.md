# 七位GGD改編角色：完整來源快照

逐角色切分在出題／模型評估前由固定seed決定；相同角色六槽不跨split。來源是支線改編稿，不以LoL記憶或網頁補完設定。compile成功不是每句機制已被runtime驗證。

## 沃維克 (warwick) — test

角色：沃維克
出身：狂戰
循血追擊的近戰獵手，以短程撲擊、持續汲取與壓制連段作戰。
GGD改編設定：
低血量獵物改為普攻追加傷害，追獵加速需主動施放；不提供全圖追蹤。
減傷改為短效護盾，恐懼為指定目標；大招可被反擊，沒有無敵。
PASSIVE 嗅血：普攻生命低於 35% 的目標時追加極小級魔法傷害，內置冷卻 2 秒。
Q 噬痕：對指定敵人施加持續傷害，3 秒內每秒造成傷害；施放時立即回復自身生命。
W 循血疾行：主動獲得 3 秒極小級移速加成與 20% 攻速加成。
E 驚獵嚎聲：指定近處敵人，造成傷害並使其恐懼 0.8 秒。
R 獵衛封喉：鎖足敵人 0.9 秒，連續汲傷後收尾；施法者不獲得無敵。
EX 血性護甲：獲得持續 3 秒的全傷害護盾；同一護盾保留較大值。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"stat","subject":"target","stat":"hp","mode":"percent","op":"<","value":0.35},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"magic","internalCooldown":2}; authorEffects=[]
- Q: tpl-drain-leech; params={"damageTier":"極小","damageType":"magic","leechFlat":50,"intervalSec":1,"durationSec":3,"stacking":"refresh","castTimeSec":0.1}; authorEffects=[]
- W: tpl-buff-self; params={"duration":3,"modifiers":[{"stat":"ms","op":"pctAdd","msBonusTier":"極小"},{"stat":"as","op":"pctAdd","value":0.2}],"castTimeSec":0.1}; authorEffects=[]
- E: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.1}; authorEffects=[{"kind":"applyStatus","statusId":"fear","duration":0.8,"applyTo":"target","feared":true}]
- R: tpl-lock-combo; params={"hitCount":3,"hitIntervalSec":0.3,"perHitDamage":{"damageTier":"極小","ratios":[]},"finisherDamage":{"damageTier":"小","ratios":[]},"finisherRadius":400,"damageType":"magic","lockTarget":"root","casterGuard":"none","trigger":"onCast"}; authorEffects=[]
- EX: tpl-buff-self; params={"duration":3,"modifiers":[],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"all","stackKey":"concept-warwick-guard","onExisting":"keepLarger"}]

## 卡爾瑟斯 (karthus) — train

角色：卡爾瑟斯
出身：法師
在陣地間敲響暮鐘，使用延遲爆破、持續領域與有預警的遠端轟擊。
GGD改編設定：
死亡後施法改為每場一次的免死續命，仍須存活才能施法。
安魂曲改成極大級施放距離內的落點轟擊，沒有全圖命中；領域有固定期限。
PASSIVE 未竟尾聲：每場持有一層續命標記；致命傷時消耗標記並恢復部分生命。死亡後不能施法。
Q 暮點：短暫吟唱後，在指定區域引爆小級魔法傷害。
W 亡途繫縛：以單體咒縛取代牆體，命中敵人後減速 35%，持續 2 秒。
E 荒蕪迴音：以自身為中心維持 3 秒傷害領域，每秒傷害一次。
R 暮鐘終曲：經極大級吟唱，在極大級施放距離內引爆指定區域；不是全圖技能。
EX 靜默幕衣：獲得只吸收魔法傷害的 3 秒護盾，提供一段施法準備時間。

模板與作者額外效果：
- PASSIVE: tpl-mark-stacks; params={"markId":"$hero.last-song","initial":1,"max":1,"durationSec":-1,"resetOn":"match","perStackLost":[],"lethalMode":"save","lethalConsume":1,"surviveHpPct":0.01,"internalCooldown":1,"invulnerableSec":0.5,"restoreHealthPct":0.15,"aoeRadius":0,"knockbackDistance":0,"stunSec":0}; authorEffects=[]
- Q: tpl-ground-nova; params={"radius":300,"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- W: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.1}; authorEffects=[{"kind":"applyStatus","statusId":"slow35","duration":2,"applyTo":"target","moveSpeedMult":0.65}]
- E: tpl-periodic-field; params={"intervalSec":1,"durationSec":3,"radiusTier":"小","anchor":"caster","applyTo":"enemies","damageTier":"極小","damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- R: tpl-ground-nova; params={"radius":300,"damage":{"damageTier":"大","ratios":[]},"damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- EX: tpl-buff-self; params={"duration":3,"modifiers":[],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"magic","stackKey":"concept-karthus-guard","onExisting":"keepLarger"}]

## 拉克絲 (lux) — test

角色：拉克絲
出身：軟輔
結合光束、短效束縛與護盾，以清楚的施法提示協助隊伍創造進攻空間。
GGD改編設定：
照明標記改為有內置冷卻的普攻魔法追加，不保留標記引爆條件。
護盾改為自身護盾，束縛只命中指定一人；光束依本遊戲距離與傷害級距結算。
PASSIVE 餘光：普攻追加極小級魔法傷害，內置冷卻 2 秒。
Q 稜光束縛：命中指定敵人並鎖足 0.8 秒，不會同時束縛第二個目標。
W 折光護衣：獲得持續 3 秒的全傷害護盾，同名護盾保留較大值。
E 流光之域：在落點留下 3 秒光域，每秒造成極小級魔法傷害。
R 破曉光路：向前依序展開四段光束判定；敵人可受到相交段落的傷害。
EX 引路星芒：獲得 3 秒極小級移速加成，並恢復自身少量生命。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"chance","p":1},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"magic","internalCooldown":2}; authorEffects=[]
- Q: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.1}; authorEffects=[{"kind":"applyStatus","statusId":"root","duration":0.8,"applyTo":"target","root":true}]
- W: tpl-buff-self; params={"duration":3,"modifiers":[],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"all","stackKey":"concept-lux-guard","onExisting":"keepLarger"}]
- E: tpl-periodic-field; params={"intervalSec":1,"durationSec":3,"radiusTier":"小","anchor":"point","applyTo":"enemies","damageTier":"極小","damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- R: tpl-line-sweep; params={"segmentCount":4,"stepSize":100,"segmentAoe":150,"damage":{"damageTier":"極小","ratios":[]},"damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- EX: tpl-buff-self; params={"duration":3,"modifiers":[{"stat":"ms","op":"pctAdd","msBonusTier":"極小"}],"castTimeSec":0.1}; authorEffects=[{"kind":"heal","amount":{"flat":80,"ratios":[]},"applyTo":"self"}]

## 犽宿 (yasuo) — train

角色：犽宿
出身：鬥士
以短程穿行與風刃連擊掌握距離，使用防護姿態承受反擊。
GGD改編設定：
第三次斬擊旋風改為獨立 EX；大招不要求擊飛，但有固定鎖足與冷卻。
風牆改為限時物理護盾，不摧毀投射物；不提供雙倍暴擊或無限突進。
PASSIVE 風行刃：普攻追加極小級物理傷害，內置冷卻 2 秒。
Q 斬風：朝前方斬出四段窄風刃，以本遊戲線段判定命中。
W 迎風架勢：獲得只吸收物理傷害的護盾，持續 3 秒；不會消除投射物。
E 踏風進擊：朝指定方向短距突進，打擊接觸範圍的敵人；推移量會扣除雙方距離。
R 天際斷章：鎖足指定敵人後連擊三次，再以收尾斬結束；沒有無敵。
EX 旋風縛步：將蓄風招式獨立為 EX，對指定敵人造成物理傷害並鎖足 0.8 秒。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"chance","p":1},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"physical","internalCooldown":2}; authorEffects=[]
- Q: tpl-line-sweep; params={"segmentCount":4,"stepSize":100,"segmentAoe":150,"damage":{"damageTier":"極小","ratios":[]},"damageType":"physical","castTimeSec":0.3}; authorEffects=[]
- W: tpl-buff-self; params={"duration":3,"modifiers":[],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"physical","stackKey":"concept-yasuo-guard","onExisting":"keepLarger"}]
- E: tpl-charge-push; params={"dashDistance":300,"dashDurationSec":0.25,"apexHeight":0,"radius":150,"damage":{"damageTier":"極小","ratios":[]},"damageType":"physical","pushDistance":300,"pushSpeed":872,"pushFrom":"facing","pushLaunchHeight":0,"castTimeSec":0.1}; authorEffects=[]
- R: tpl-lock-combo; params={"hitCount":3,"hitIntervalSec":0.3,"perHitDamage":{"damageTier":"極小","ratios":[]},"finisherDamage":{"damageTier":"小","ratios":[]},"finisherRadius":400,"damageType":"physical","lockTarget":"root","casterGuard":"none","trigger":"onCast"}; authorEffects=[]
- EX: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","castTimeSec":0.1}; authorEffects=[{"kind":"applyStatus","statusId":"root","duration":0.8,"applyTo":"target","root":true}]

## 好運姐 (missfortune) — train

角色：好運姐
出身：射手
以雙重射擊、機動增益與持續彈雨控制交戰區域。
GGD改編設定：
換目標額外傷害改為固定內置冷卻，不因切換目標重置。
彈射使用最多兩人的連鎖判定；大招改為有界落點彈幕，非自由轉向的錐形掃射。
PASSIVE 先聲奪人：普攻追加極小級物理傷害，內置冷卻 2 秒。
Q 回聲雙響：先命中指定敵人，再發出最多兩人的物理連鎖；起點會承受追加一擊。
W 揚帆快步：獲得 3 秒極小級移速加成與 20% 攻速加成。
E 緋帆彈雨：在指定區域維持 3 秒彈雨，每秒造成極小級魔法傷害。
R 扇港齊射：向指定區域連續投下六發物理彈幕，散布及命中區域均有界。
EX 藏帆備彈：短暫以全傷害護盾掩護換位，持續 3 秒。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"chance","p":1},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"physical","internalCooldown":2}; authorEffects=[]
- Q: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","castTimeSec":0.1}; authorEffects=[{"kind":"chainLightning","shape":"single","amount":{"damageTier":"極小","ratios":[]},"damageType":"physical","jumps":2,"jumpRange":3,"decay":0.8,"revisit":false,"maxTotalJumps":2,"jumpIntervalSec":0.1}]
- W: tpl-buff-self; params={"duration":3,"modifiers":[{"stat":"ms","op":"pctAdd","msBonusTier":"極小"},{"stat":"as","op":"pctAdd","value":0.2}],"castTimeSec":0.1}; authorEffects=[]
- E: tpl-periodic-field; params={"intervalSec":1,"durationSec":3,"radiusTier":"小","anchor":"point","applyTo":"enemies","damageTier":"極小","damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- R: tpl-random-barrage; params={"count":6,"intervalSec":0.2,"impactDamage":{"damageTier":"極小","ratios":[]},"damageType":"physical","impactRadius":150,"scatterRadius":150,"payout":"perImpact","castTimeSec":0.5}; authorEffects=[]
- EX: tpl-buff-self; params={"duration":3,"modifiers":[{"stat":"ms","op":"pctAdd","msBonusTier":"極小"}],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"all","stackKey":"concept-missfortune-guard","onExisting":"keepLarger"}]

## 李星 (leesin) — dev

角色：李星
出身：鬥士
以聲波探擊、短程進身、護身與踢離敵人的連續節奏作戰。
GGD改編設定：
能量改用共通魔力，技能後兩次普攻改為有冷卻的普攻追加。
聲波與追擊分為 Q／EX，無二段重施放；護盾只給自身，踢擊使用共通推移機制。
PASSIVE 回響拳：普攻追加極小級物理傷害，內置冷卻 2 秒。
Q 聽雷探手：以中級距射程攻擊指定敵人；不會自動開啟第二段位移。
W 定心護體：獲得 3 秒護盾與 20% 攻速加成。
E 震地迴響：在指定近處引爆小級物理傷害，保留可瞄準的落點。
R 斷陣踢：短距進身後打擊並向前推開敵人，不附帶無敵或全場追蹤。
EX 逐響躍步：朝落點跳躍並在著地時打擊附近敵人，作為獨立追擊技能。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"chance","p":1},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"physical","internalCooldown":2}; authorEffects=[]
- Q: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","castTimeSec":0.1}; authorEffects=[]
- W: tpl-buff-self; params={"duration":3,"modifiers":[{"stat":"as","op":"pctAdd","value":0.2}],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"all","stackKey":"concept-leesin-guard","onExisting":"keepLarger"}]
- E: tpl-ground-nova; params={"radius":300,"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","castTimeSec":0.3}; authorEffects=[]
- R: tpl-charge-push; params={"dashDistance":200,"dashDurationSec":0.2,"apexHeight":0,"radius":150,"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","pushDistance":400,"pushSpeed":872,"pushFrom":"facing","pushLaunchHeight":100,"castTimeSec":0.3}; authorEffects=[]
- EX: tpl-leap-strike; params={"mode":"toPoint","applyTo":"self","apexHeight":300,"durationSec":0.5,"landRadius":150,"damage":{"damageTier":"小","ratios":[]},"damageType":"physical","castTimeSec":0.1}; authorEffects=[]

## 齊勒斯 (xerath) — train

角色：齊勒斯
出身：法師
以蓄能光路、落點爆破與定身咒彈控制距離，施放有限次數的奧術轟擊。
GGD改編設定：
普攻回魔改為 EX 主動回復固定比例魔力，受冷卻限制。
蓄力及大招重瞄準改為一次施放的固定時序；最遠射程使用極大級距。
PASSIVE 逸散奧能：普攻追加極小級魔法傷害，內置冷卻 2 秒。
Q 星牢光路：吟唱後向前產生四段奧術打擊，使用大級距施放距離。
W 星核墜落：在指定區域引爆小級魔法傷害。
E 奧能拘束：對指定敵人造成傷害並暈眩 0.8 秒，不按飛行距離延長。
R 星牢轟擊：在極大級距內選定落點，依序降下三發奧術砲擊，無法中途重新瞄準。
EX 回收奧能：獲得短效魔法護盾並回復自身 15% 最大魔力；受到 EX 冷卻限制。

模板與作者額外效果：
- PASSIVE: tpl-on-attack; params={"event":"onBasicAttack","condition":{"kind":"chance","p":1},"bonusDamage":{"damageTier":"極小","ratios":[]},"damageType":"magic","internalCooldown":2}; authorEffects=[]
- Q: tpl-line-sweep; params={"segmentCount":4,"stepSize":100,"segmentAoe":150,"damage":{"damageTier":"極小","ratios":[]},"damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- W: tpl-ground-nova; params={"radius":300,"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.3}; authorEffects=[]
- E: tpl-single-strike; params={"damage":{"damageTier":"小","ratios":[]},"damageType":"magic","castTimeSec":0.1}; authorEffects=[{"kind":"applyStatus","statusId":"stun","duration":0.8,"applyTo":"target","stun":true}]
- R: tpl-random-barrage; params={"count":3,"intervalSec":0.5,"impactDamage":{"damageTier":"小","ratios":[]},"damageType":"magic","impactRadius":200,"scatterRadius":100,"payout":"perImpact","castTimeSec":1}; authorEffects=[]
- EX: tpl-buff-self; params={"duration":3,"modifiers":[],"castTimeSec":0.1}; authorEffects=[{"kind":"shield","amount":{"flat":120,"ratios":[]},"duration":3,"absorbs":"magic","stackKey":"concept-xerath-guard","onExisting":"keepLarger"},{"kind":"restore","manaPct":0.15,"applyTo":"self"}]
