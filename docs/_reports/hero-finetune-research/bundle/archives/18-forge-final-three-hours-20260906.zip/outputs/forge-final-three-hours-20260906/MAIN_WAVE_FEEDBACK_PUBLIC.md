# traveling-wave 終點追加傷害會漏掉最後一段首次命中的敵人

## 問題與影響

`tpl-traveling-wave` 的 `terminalBurst` 不能穩定代表「沿途命中之外，終點再追加一次傷害」：終點範圍內先前已命中的敵人會收到追加，最後一段才首次命中的敵人反而不會。

因此模板能力說明與實際機制存在差距，會誤導技能作者及模板推薦系統。本票只回饋共用模板／機制，不要求逐英雄寫特殊腳本，不改Owner設計或特效參數。

## 重現證據與版本邊界

實際重現於 `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`，走模板參數schema → expand/merge → ability schema → damage/aoe tier解析 → `castAbility` → `SimWorld.step()`。兩個seed（20260906、20260907）結果一致。

2026-09-06再次讀取遠端main，HEAD仍是 `1de2bd31fb6266ecb7738f110f2245e393c78071`；下列相關程式路徑與先前主線核對一致。**尚未在完整最新main checkout重新執行，所以不宣稱最新main端到端重現已完成。**

模板覆寫，其餘取 `defaultParamsFor`：

```json
{"stepSize":200,"stepCount":4,"stepIntervalSec":0.1,"aoePerStep":50,"terminalBurst":200,"damage":{"perRank":[200],"ratios":[]},"damageType":"true","castTimeSec":0}
```

模板wc3u經解析後，每段前進約3.67U，四段中心相對施法者約0、3.67、7.33、11U。朝+x施法，固定雙方位置，目標不死亡；以此技能origin的damage事件計數，避免自然回血干擾HP差。

| 敵人位置 | 原模板 | 只移除terminal的記憶體負控制 | 只加includeOrigin:true的記憶體診斷 |
| --- | --- | --- | --- |
| x=8.4，早段已命中 | tick10、13，共2次 | tick10，共1次 | 共2次 |
| x=11，最後段首次命中 | tick13，共1次 | tick13，共1次 | tick13兩次 |
| x=4及x=11同時存在 | 各1次 | 各1次 | 近端1次、終點2次 |

上述記憶體修改只是診斷控制，未改動正式內容。另以未修改的 `tpl-line-blast` 對照，終點可收到沿途＋終點兩次事件；兩模板半徑／時刻不同，不宣稱任意配置等價。

## 根因路徑

- [expand.ts L1066-L1077](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/content/templates/expand.ts#L1066-L1077)：終點 `damageArea` 未設定 `includeOrigin:true`。
- [delayed.ts L426-L483](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/sim/effects/delayed.ts#L426-L483)：先依hitOnce歷史過濾本段targets，本段及finalEffects共用ctx。
- [damageArea.ts L29-L57](https://github.com/adms/GGD/blob/1de2bd31fb6266ecb7738f110f2245e393c78071/packages/shared/src/sim/effects/damageArea.ts#L29-L57)：預設排除ctx.targets，導致最後段新目標被排除；先前已命中的敵人則不在排除集合。

另有待核對風險：圓心可能優先採第一個ctx.targets的位置，而非wave落點。尚未獨立重現此第二問題，所以**不把只加includeOrigin當已完整驗收的修法**，也不建議全域改掉damageArea的預設排除語意。

## 建議main處置與驗收

1. 先在main以一套參數化治具重現：終點範圍內的「先前命中／最後段首次命中」皆應收到獨立終點追加，沿途hitOnce維持原意。
2. 包含偏離終點中心的敵人，確認爆炸圓心不隨第一個命中者漂移；保留移除terminal的負控制。
3. 修復共用模板／finalEffects上下文，不能破壞其他用途原本排除起始受害者的機制；不逐英雄加if。
4. 同步模板說明、能力推薦邊界與對应行為守衛。修復前，不能將「必須有獨立終點追加」無條件判為此模板完整支援；無terminal需求的沿途波不應一併封禁。

已搜尋 `traveling-wave`、`terminalBurst`、`includeOrigin`、終點，並閱讀 #960／#311；未找到此命中歷史／終點排除缺陷的專票。未附加任何訓練資料、權重、私人來源原文或本機路徑。
