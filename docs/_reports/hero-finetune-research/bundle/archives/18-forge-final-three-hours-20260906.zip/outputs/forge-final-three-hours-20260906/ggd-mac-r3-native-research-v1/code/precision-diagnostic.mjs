// Generated public-export facade; no training data or answer tables.
import fs from "node:fs";import crypto from "node:crypto";
export function fileHash(file){
 const h=crypto.createHash('sha256'),fd=fs.openSync(file,'r'),buffer=Buffer.alloc(1024*1024);let count;
 try{while((count=fs.readSync(fd,buffer,0,buffer.length,null))>0)h.update(buffer.subarray(0,count));}finally{fs.closeSync(fd);}return h.digest('hex');
}
