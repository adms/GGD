# 新七角色來源／資料狀態

更新：2026-09-07 00:04 Asia/Taipei。這是新增來源處理進度，不代表新權重已訓練或整體模型合格。

- 使用者指定七人全部找到：沃維克、卡爾瑟斯、拉克絲、犽宿、好運姐、李星、齊勒斯；每人PASSIVE/Q/W/E/R/EX，共42槽。
- 來源支線：`GGD-community-hero-forge` / `codex/community-hero-forge-integration`，HEAD `2afcf5989161fde58c953f43039397fb90306a8f`。工作目錄另有未提交名稱改動，已在snapshot保存diff與bytes。
- `communityExamples.ts` SHA256 `dbb0ee6696f99bab67fd891884d490f3d38063b63e234376cc3adaae8a14e09c`。
- `seven-heroes-source-v1/`：原始配方、完整文字、42槽編譯檢查、模板及附加effects分欄保存。未新跑42槽runtime，不把既有舊名proof當成當前逐句機制驗證。
- `seven-heroes-data-v1/PERSONAL_REVIEW.md`：147題的原文、敘述、答案及逐題理由。每個來源單元3題，沒有宣稱每項命題全部覆蓋。
- `seven-heroes-data-v1/ADMISSION.json`：84題train准入，21題dev，42題test；hash、重建、角色／全文分割、輸入長度全部通過。1項資料管線測試及1項排程安全測試通過，非語意品質獨立證明。

## 固定切分

| 用途 | 角色 | 題數 |
| --- | --- | ---: |
| train | 齊勒斯、好運姐、犽宿、卡爾瑟斯 | 84 |
| dev | 李星 | 21 |
| test | 拉克絲、沃維克 | 42 |

split在出題前用固定seed決定，之後未重分。同模板與機制模式仍跨角色共享，因此只是角色不交叉，不能宣稱全新機制家族泛化。答案由本assistant親自依來源撰寫核對，並非獨立人工Owner Gold。

## 非LLM實測與後續模型測試

`seven-heroes-nonllm-v1/REPORT.md`已完成CPU最近訓練例比較。K分別由舊158+新21 dev挑選，accuracy／safety兩政策均保留：

| 訓練暴露 | 政策 | 42 test正確 | 錯誤放行 |
| --- | --- | ---: | ---: |
| 舊660筆去重資料 | accuracy | 27 | 6 |
| 舊660 + 新84 | accuracy | 26 | 7 |
| 舊660筆去重資料 | safety | 25 | 6 |
| 舊660 + 新84 | safety | 25 | 7 |

不能把增加資料視為必然增益，也不能據有限字面檢索的失敗推論fine-tune必要。此42題已曝光於script診斷，禁止由其結果回頭改答案或選神經模型；神經模型尚未測42題。

新增dev神經模型流程已實際啟動：exec **16508** / PID **68224**，state `seven-heroes-dev-model-v1/state.json`。依次等R7 core/post/public-entry/final-report程序都成功且退出，才串行執行base、R3、R7-selected的21題李星dev。沒有訓練呼叫，不改R7選模；輸出仍為research-only。00:04快照為`waiting-for-r7-all-stages`，不等於已跑GPU。

R7在00:04仍訓練中：196/466例、49次完整更新、Metal峰值59.0GiB（metrics實讀）。新資料未改其凍結資料、script、政策、選模或截止。

## 不允許混淆的能力

1. 來源為GGD改編稿；不可把LoL原版背景／技能當答案。
2. 文本entailment不等於模板／引擎已能完整實現。
3. 独立authorEffects承擔的控制、盾、回復、連鎖不算template-alone原生能力。
4. 好運姐／齊勒斯R使用新支線perImpact，不與舊版random-barrage能力表混訓。
5. 沃維克R汲傷未寫治療公式、拉克絲R未清楚允許同人重複命中、犽宿E未清楚說沿路傷害、好運姐EX用途不等於瞬移。先標不確定／限制，不能產生錯誤正例。
