# 最後模型交付：已實作流程與尚未執行部分

更新：2026-09-07 00:38 Asia/Taipei。此為**執行前流程**，不是轉換／模型驗證已成功的報告。

## 當前實際進度

R7四個既有handle在00:25～00:26逐一核對仍live：core18089、post3316、entry97048、finish85509。core PID46738仍在train；最新實讀296/466例、step74，Metal峰值59.0GiB。post／entry／finish仍依序等待，沒有重啟或原地更改凍結實驗。

00:34 core18089／post3316與00:37 entry97048／finish85509／community16508均再次讀到live handle。00:37磁碟狀態仍為R7 train，其餘依序等待；本段最後實讀358 processed／356 committed／466 planned，59.0GiB。沒有把等待狀態當作完成或重啟工作。

## 已完成的程式與CPU驗證

程式皆在`GGD-hero-auto-forge/tools/forge-training/`：

1. `final-model-roundtrip-v1.mjs`：要求選定權重來自已完成core、沒有使用test選模，並等待已存在的post／entry／finish成功；GPU忙碌直接拒絕。以原`deploy.py`完成base+adapter→融合BF16→固定affine8bit/group64，核對adapter實際載入、數值序列化及tokenizer。然後用相同12GiB配置、相同seed／輸入／解碼，重跑完整dev與test的三臂對照。
2. `final-precision-score-v1.mjs`：依任務、逐題、錯誤放行及schema分开呈現；不能只看aggregate。8bit只有在native→fused→8bit每一步都保住所有dev正確題且沒有新unsafe時才成為預設；否則保留fused或native。選擇在任何test推論前寫入，test不能回頭挑精度。固定8bit，沒有4／6／8bit搜尋。
3. `final-bundle-v1.mjs`：只在上述真實測量完成後才複製完整native、fused、8bit變體，所有檔案逐一SHA核對。保留LICENSE、tokenizer/config、相對路徑、模型卡與Mac操作說明；不帶訓練資料、Owner審查答案、test oracle或prepared私有檔。
4. `portable-final-check-v1.mjs`：由**搬移後的code/run.mjs和模型檔**各跑10次native／fused／8bit公開入口（每種14個模型請求），答案只供輸出後比對。計算語意符合、格式、峰值；object欄位順序不影響語意相等，但重複卡片數量與卡片順序仍有意義。不能依此重選權重或精度。
5. `final-regression-data-v1.mjs`／`final-broader-check-v1.mjs`：較廣8組582題已實際準備在`final-broader-data-v1/`，60題目錄輸入校正、僅1題terminal標籤校正；其餘答案及所有英雄／Owner原題逐欄不變。新目錄／標籤不覆寫R7或舊成績。最長3051 prompt tokens＋256輸出預算，全部符合4096。後續fresh base／R3／native／fused／8bit共5臂重跑，保留8組任務分數與18整段提案反向檢查。合併題序的index seed與舊分組不同，因此不重用舊輸出；所有5臂使用同一新題序。禁止用較廣測試重選checkpoint或精度。

最新版工具包：`portable-contract-kit-v2/`。`portable-contract-kit-v1/`保留macOS路徑別名檢查失敗的準備歷史，不能作交付版。v2的五種公開契約提示／digest／驗證與原程式完全一致，沒有重新發明語意規則或把訓練答案放進推論。

最新操作範例：`portable-assets-v2/`。有single／stack／vfx三份固定目錄及10個範例、14個請求，覆蓋：來源正確／未知／明確矛盾、即時單體傷害、獨立終點爆炸、兩筆重複卡片、常駐雙hook、拒絕暫時hook被換成永久、氣功砲VFX、完整人造提案+四項requirement。10題答案由來源或既有能力證據先寫定；不是獨立Owner Gold。VFX只依公开目錄element=ki、shape=beam、usable=true核對模板分類，不做圖片驗證。

00:24最新相關測試：7/7 CPU通過（程式／hash／schema／選精度規則），**不表示7個模型測試成功**。模型轉換、搬移推論均尚未啟動。

00:37另7/7 CPU測試通過：R8資料重建／warm-start來源保留、前序成功且PID消失、582題範圍保留／單一證據校正，以及5臂scorer對digest、seed、完整性異常的拒絕。較廣scorer測試的輸出是明標CPU fixture，不是模型結果。初版test程式缺一個括號造成syntax failure，已在任何GPU執行前修正並重跑；未影響資料或正在訓練的R7。

## 時間與記憶體

- 新工作GPU总截止維持2026-09-06T20:06:10Z；portable末段採20:06:00Z，留終止緩衝。
- 總交付截止2026-09-06T20:36:10Z／9/7 04:36:10台北。
- 轉換可用64GiB配置；正式同題推論與portable入口限12GiB。轉換峰值與推論峰值分开，皆不當成16GB MacBook實機證明。
- 新訓練仍須19:00Z停止更新；有沒有執行R8要看R7與新21題dev結果，不因資料已準備就假稱R8已訓練。

## 尚待完成

- R7訓練／選模／完整post／真入口／結果重播；目前尚未有其最終分數。
- 新七角色21題dev的base/R3/R7實測（已排隊），以及最後訓練決策／實測。
- 上述轉換、全dev/test對照、實際成品模型複製和30次portable真入口。
- 更廣source／hero／VFX／完整機制補測的精度保留檢查；core與有限操作範例不能替代所有回歸族。
- 所有輪次總報告與需求清單，逐項說明完成、退步、失敗、缺證及未完成；目前沒有全用途合格模型，不能用交付腳本或模型可載入宣告目標完成。
