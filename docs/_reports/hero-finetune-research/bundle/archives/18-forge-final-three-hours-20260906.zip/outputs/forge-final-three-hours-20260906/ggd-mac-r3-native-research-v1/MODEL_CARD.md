# GGD來源／技能分類：native研究保存包

這是可搬移的研究權重保存包，**不是穩定全用途模型或正式產品**。只做來源分類與既有模板推薦，不調VFX參數、不作視覺驗證，不自動改寫技能或啟用Editor。

- Base：Qwen/Qwen3.5-4B，revision `851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a`。
- 原選模：{"kind":"r3-epoch-dev-only","epoch":2}；原選定權重未更換。
- 本包只有native BF16 base＋LoRA，沒有做融合或量化。
- 公開入口固定non-thinking、presence penalty=0；原始歷史1.5分數不混算。
- 三種精度互相比較尚未在本包執行；缺少8bit不是8bit合格或不合格的證據。

## 同協定既有核心回歸

| 任務 | 正確 | 錯誤放行 |
| --- | ---: | ---: |
| owner-mechanism | 87/94 | 1 |
| mechanism-template | 19/20 | 0 |
| hero-source | 47/48 | 0 |
| mechanism-stack | 9/24 | 15 |

這些是已曝光的研究回歸、非獨立Owner Gold；不是所有英雄設定／技能需求都已涵蓋。多模板與原文仍有實際錯誤，格式合法不能取代語意審查。目錄範例另採修正過的能力版本；上述核心數字不等於新目錄整體品質。

## 使用限制

本包建立時尚未從搬移後入口做GPU推論；須另看同名portable-check證據。入口配置12GiB上限不代表16GB MacBook實機已測；整機還需OS、Editor和其他程式記憶體。原測量只在本機M5 Max 128GB。

保留原始LICENSE。權重經本專案分類資料微調。本包不附訓練／測試資料或私人答案檔案；不代表模型權重完全不記憶訓練內容。
