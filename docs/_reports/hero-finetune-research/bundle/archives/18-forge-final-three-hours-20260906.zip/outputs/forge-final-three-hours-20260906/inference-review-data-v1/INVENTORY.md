# 全部資料版本盤點／推論隊列

發現45份corpus，歷史列數22386（大量重複，不能當独特資料量）。8份經審查主版本與最新較廣題組合併成2695個完全相同訊息去重後請求；不重寫prompt或答案。
標註衝突0題、已撤回標註2題：可保留推論作分析，但排除合格準度分母。
未匹配的隔離／舊proposal題保留為歷史／未新測，不宣稱全部歷史列都已重新推論。以下僅是隊列，完成需看run-state與各chunk原始輸出。

| 資料集 | 歷史列 | 本次完全相同請求涵蓋 | 其他／未新測 | 狀態 |
| --- | ---: | ---: | ---: | --- |
| forge-additional-four-hours-20260906/composition-diagnostic-v1/cases.private.json | 20 | 0 | 20 | historical-or-quarantined-not-silently-admitted |
| forge-additional-four-hours-20260906/composition-diagnostic-v2/cases.private.json | 20 | 0 | 20 | historical-or-quarantined-not-silently-admitted |
| forge-additional-four-hours-20260906/r6-source-dev-candidate-v1/cases.private.json | 51 | 51 | 0 | duplicate-requests-covered |
| forge-additional-four-hours-20260906/source-label-clarification-v1/cases.private.json | 15 | 15 | 0 | duplicate-requests-covered |
| forge-broad-20260906/cases.private.json | 1596 | 0 | 1596 | historical-or-quarantined-not-silently-admitted |
| forge-classification-20260906/cases.private.json | 1909 | 0 | 1909 | historical-or-quarantined-not-silently-admitted |
| forge-classification-final-20260906/cases.private.json | 2320 | 0 | 2320 | historical-or-quarantined-not-silently-admitted |
| forge-classification-reviewed-20260906/cases.private.json | 488 | 488 | 0 | duplicate-requests-covered |
| forge-classification-reviewed-r2-20260906/cases.private.json | 488 | 488 | 0 | reviewed-version-included |
| forge-classification-v2-20260906/cases.private.json | 2320 | 0 | 2320 | historical-or-quarantined-not-silently-admitted |
| forge-classification-v3-20260906/cases.private.json | 2320 | 0 | 2320 | historical-or-quarantined-not-silently-admitted |
| forge-contrastive-r5-20260906/cases.private.json | 873 | 873 | 0 | reviewed-version-included |
| forge-contrastive-r5-20260906/fresh-source-diagnostic-v1/cases.private.json | 72 | 72 | 0 | duplicate-requests-covered |
| forge-contrastive-r5-20260906/manual-entry-check-v1/cases.private.json | 4 | 0 | 4 | historical-or-quarantined-not-silently-admitted |
| forge-contrastive-r5-20260906/manual-entry-preflight-superseded-v1/cases.private.json | 4 | 0 | 4 | historical-or-quarantined-not-silently-admitted |
| forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/cases.private.json | 873 | 873 | 0 | duplicate-requests-covered |
| forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/fresh-source-diagnostic-v1/cases.private.json | 72 | 72 | 0 | duplicate-requests-covered |
| forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/manual-entry-check-v1/cases.private.json | 4 | 0 | 4 | historical-or-quarantined-not-silently-admitted |
| forge-current-main-candidate-20260906/cases.private.json | 60 | 0 | 60 | historical-or-quarantined-not-silently-admitted |
| forge-current-main-candidate-v4-20260906/cases.private.json | 58 | 58 | 0 | duplicate-requests-covered |
| forge-final-three-hours-20260906/final-broader-data-v1/cases.private.json | 582 | 582 | 0 | reviewed-version-included |
| forge-final-three-hours-20260906/seven-heroes-data-v1/cases.private.json | 147 | 147 | 0 | duplicate-requests-covered |
| forge-finetune-20260906/cases.private.json | 216 | 0 | 216 | historical-or-quarantined-not-silently-admitted |
| forge-finetune-20260906/preflight-rejected-alpha-zero/cases.private.json | 216 | 0 | 216 | historical-or-quarantined-not-silently-admitted |
| forge-finetune-20260906/raw-dialogue-protocol-v3/cases.private.json | 216 | 0 | 216 | historical-or-quarantined-not-silently-admitted |
| forge-joint-source-stack-r6-20260906/cases.private.json | 980 | 980 | 0 | duplicate-requests-covered |
| forge-joint-source-stack-r6-v2-20260906/cases.private.json | 810 | 810 | 0 | reviewed-version-included |
| forge-joint-source-stack-r6-v2-20260906/fresh-source-v1/cases.private.json | 63 | 63 | 0 | duplicate-requests-covered |
| forge-low-lr-r7-20260906/cases.private.json | 810 | 810 | 0 | duplicate-requests-covered |
| forge-low-lr-r7-20260906/fresh-source-v1/cases.private.json | 63 | 63 | 0 | duplicate-requests-covered |
| forge-low-lr-r7-v2-20260906/cases.private.json | 810 | 810 | 0 | reviewed-version-included |
| forge-low-lr-r7-v2-20260906/fresh-source-v1/cases.private.json | 63 | 63 | 0 | duplicate-requests-covered |
| forge-mechanism-priority-r3-20260906/cases.private.json | 625 | 625 | 0 | reviewed-version-included |
| forge-mechanism-priority-r3-20260906/fidelity-diagnostic-v1/cases.private.json | 114 | 107 | 7 | historical-or-quarantined-not-silently-admitted |
| forge-mechanism-priority-r3-20260906/fidelity-diagnostic-v2/cases.private.json | 114 | 114 | 0 | duplicate-requests-covered |
| forge-mechanism-priority-r3-20260906/main-diagnostic-v1/cases.private.json | 40 | 0 | 40 | historical-or-quarantined-not-silently-admitted |
| forge-mechanism-priority-r3-20260906/main-diagnostic-v2/cases.private.json | 40 | 0 | 40 | historical-or-quarantined-not-silently-admitted |
| forge-mechanism-priority-r3-20260906/main-diagnostic-v3/cases.private.json | 40 | 0 | 40 | historical-or-quarantined-not-silently-admitted |
| forge-mechanism-priority-r3-20260906/main-diagnostic-v4/cases.private.json | 40 | 0 | 40 | historical-or-quarantined-not-silently-admitted |
| forge-mechanism-priority-r3-20260906/main-hero-diagnostic-v1/cases.private.json | 140 | 140 | 0 | duplicate-requests-covered |
| forge-mechanism-priority-r3-20260906/pre-review-draft-1/cases.private.json | 627 | 401 | 226 | historical-or-quarantined-not-silently-admitted |
| forge-source-calibration-r4-20260906/cases.private.json | 837 | 837 | 0 | reviewed-version-included |
| forge-source-policy-probe-20260906/cases.private.json | 245 | 44 | 201 | historical-or-quarantined-not-silently-admitted |
| forge-source-rehearsal-r8-v1-20260906/cases.private.json | 957 | 957 | 0 | reviewed-version-included |
| forge-thinking-benchmark-20260906/corpus.private.json | 24 | 0 | 24 | historical-or-quarantined-not-silently-admitted |

所有模型使用同一chunk與seed。訓練題與未見来源分開；同一原文不同命題仍標為來源已見。新七角色沒有做神經訓練，原train/dev/test標籤只代表資料切分歷史。
