# Mac研究模型使用

先讀MODEL_CARD.md。需要Apple Silicon、arm64 Python 3.11及Node（此研究測25.9.0）。安裝會下載依賴；推論強制離線。

在本資料夾：

```sh
python3.11 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.lock.txt
mkdir -p runtime
node code/run.mjs examples/source-supported.json .venv/bin/python runtime run-001 native RESEARCH_ONLY
```

輸出目錄必須不存在。GPU鎖存在即拒絕，不終止其他工作；每次最多300秒、4096總token、256輸出token。來源過長報錯，不截斷。

examples有source、fidelity、single、stack、vfx五種既有契約。fidelity只檢查呼叫者明列的requirement，不保證未列出的原文條件也完整涵蓋。VFX僅推薦模板，人工微調。

source文字修改後，source.sha256必須同步更新。使用本包相同digest算法，例如：

```sh
node --input-type=module -e 'import {digest} from "./code/dataset.mjs"; console.log(digest("新的完整原文"));'
```

只檢查hash與schema不等於語意正确。保留raw.json與checked.json，所有輸出均需人工核對來源與能力；不可自動執行或直接寫入遊戲。

模型、tokenizer、config、adapter及程式均在MODEL_BUNDLE.json逐檔SHA256清單內。可搬移整個資料夾，不能只搬權重檔。
