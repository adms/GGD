# 纯推論分析執行狀態

**最終執行狀態：01:55:38因充電問題CANCEL，exec92729已終止，PID73219不存在，worker已退出。2958次完整模型呼叫，954題完整配對，1741題主隊列未完整配對；補充20題未執行。不得自動重啟。** 停機後CPU分析在`inference-review-analysis-power-stop-v1/`，整合報告為`FINAL_REPORT.md`。以下01:30內容保留歷史，不是現行執行指令。

2026-09-07 01:30 Taipei快照。最新指示已停止新增訓練；本檔不是完成宣告。

- R8：`TRAINING_DISABLED.json`，實際prepare入口已驗證會在寫入前拒絕啟動。沒有RUN_PREPARATION、run-state或訓練權重。
- 45份corpus／22,386歷史列完整盤點；經審查主版本與補充集去重2695個請求，全部通過4096總長度／256輸出預留檢查，最長prompt3065 tokens。
- 本次39個chunk、base/R3/R7三模型，共計畫8085次推論。每個chunk三模型都完成才列入配對統計，程序只呼叫worker eval。
- 執行目錄：`inference-review-run-v1`；exec session92729，PID73219。01:30已完成21題第一個base chunk，R3 chunk正實際執行。後續以state.json、worker-lease及原始輸出為準。
- 截止：GPU 04:06:10，報告04:36:10；沒有自行延長。若有未完成題，報告列出缺少分母，不冒稱全部完成。
- R3約9.38GB保存包：10次搬移後公開入口完成，語意7/10、格式9/10，Metal峰值約9.72GiB。收據：`ggd-mac-r3-native-research-v1-portable-check/summary.json`。只證明可載入且有已知缺點，不是合格成品。
- R7舊post/entry/finish與舊七角色dev等待程序均已退出；原截止失敗保留。非LLM對照已按可取得的原始輸出重播，見`r7-selected-paired-evidence-v2/REPORT.md`；缺6組輸出明列，不補造。
- 各輪成本／資料帳本：`experiment-ledger-inference-only-v1/LEDGER.md`，R8明列取消。

之後可用`inference-review-analysis-v1.mjs RUN NEW_OUTPUT`重播已完成配對chunk，產出錯誤全集、來源暴露分層與逐版本覆蓋。分析不調參、不重選checkpoint、不更新權重。
