# R7訓練截止實讀：不是選模結果

2026-09-07 00:46 Asia/Taipei讀取R7真實`training-run.json`及`run-state.json`：

- 原軟截止16:45Z沒有延長；當前example結束後16:45:35Z完成保存並轉入dev-step-48。
- status=`partial-checkpoints`，stopReason=`TRAINING_STOP_RESERVE`，trainingComplete=false。
- prepared466、processed383、committed380、discardedPartialGradientExamples3、optimizerSteps95。
- worker總時計80.07743492083391分鐘、Metal峰值63357910846 bytes（59.00665265135467GiB）。
- 完整保存checkpoint：16、32、48、64、80、95；最後step95只含380例完整更新。
- 原選模政策只測48、96若存在及最後完整保存點，因此本次預期評估48、95；不是把未滿epoch補成466例。
- R6保存並評過相同step48，可做同更新次數LR比較；R7沒有step96，不能把R7step95直接當成R6step96的單因素同暴露比較。
- core exec18089仍live，進入dev評估；post、公開入口、finish及新角色dev仍由既有依序程序處理。不重啟、不改R7資料或截止。

這份紀錄只證明訓練停止與checkpoint保存，不含尚未產生的選定權重、test分數或成品模型證據。R8與融合／量化／portable仍未執行。

本段其他完成：582題校正版較廣回歸資料、5臂回歸程式、成本帳本工具與共16項CPU驗證通過。這16項不是神經模型題目的通過數。

## 00:50選模更新（test仍在跑）

- 原158dev-only規則選定step48（192例完整更新）而非最後step95；沒有讀test作選擇。
- 選定adapter SHA256：`e8c7fdcbc9ed61fb1cc3ebedc9e0d7022fc6b87ebcfc1bded66136bcf3a76893`。
- R3→step48：英雄21/21→21/21、Owner83/89→83/89、單卡24/24→24/24、多卡13/24→17/24；多卡錯誤放行10→6。逐題來源退步0、新unsafe0、任務計數退步0，符合保留檢查但未達95%／zero-unsafe品質門檻。
- step95：Owner81/89；有3個原本正確來源題退步，並新增1個多卡unsafe，故淘汰。總unsafe同樣7不代表沒有「新的」unsafe。
- 同step48的R6→R7：單卡19/24→24/24、多卡16/24→17/24；來源計數相同。這是一個seed的同暴露對照，不是獨立重複實驗或統計確證。
- 此刻core在base-test；不能把上述dev數字當test／較廣回歸成績。R7 post／真入口／結果收據／新21題dev仍未完成。
