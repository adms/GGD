# 最終較廣回歸資料校正

固定 8 組、582 題，所有原始題組與舊成績不改。這是已曝光的回歸測試，不是新的獨立泛化證據。

- 全部受影響目錄同步更新 traveling-wave 無 terminal 限制及 line-blast 獨立抵達傷害能力。
- 僅修正 `main-diagnostic-v4-wave-terminal` 一題答案；原題没有要求任意獨立節拍，line-blast 的兩段獨立傷害有實際 SimWorld 控制組證據。
- 原完整題、原答案、校正理由留在 corrected-labels.json；其他答案逐欄不變。
- 不以這些結果選訓練 checkpoint 或量化精度，不回填訓練。
- native、融合 BF16、固定 8bit 須全部同題重跑，另保留 18 組整段提案／逐項回查檢查。
- 12GiB 推論上限不代表 16GB Mac 實機已驗證。
