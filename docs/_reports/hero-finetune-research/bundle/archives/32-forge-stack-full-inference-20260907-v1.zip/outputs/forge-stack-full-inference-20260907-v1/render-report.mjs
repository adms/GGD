import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const a=read('analysis.json'),rows=read('case-review.json'),names=['base','r3','r7'];
assert.equal(a.scoredQuestions,295);assert.deepEqual(a.withdrawn,['inference-review-01536']);assert.equal(a.reviewedErrorRequests,a.uniqueErrorRequests);
const table=stats=>['| 模型 | 正確 | 正確率 | 錯誤放行 | 契約合法 |','| --- | ---: | ---: | ---: | ---: |',...names.map(n=>{const s=stats[n];return `| ${n} | ${s.passed}/${s.total} | ${s.pct.toFixed(2)}% | ${s.unsafe} | ${s.schema}/${s.total} |`;})];
const lines=['# 主隊列機制計畫全量推論：296 個輸入／295 題計分','',
 '只測既有 4B 基底與 R3／R7 adapter，不重新訓練、量化、重選或部署。範圍是舊主隊列 mechanism-stack 的全部 296 個輸入；其中一題標籤在本輪開始前就已撤回，僅留原始輸出稽核，正式分母固定 295。',
 '', '## 結論與洞察','',
 'R7 確實更會給出可用計畫：可接受需求的完整正確數由基底 65/147 提升至 116/147；但應拒絕需求的正確數由 147/148 降至 96/148。總分恰好同為 212/295，掩蓋了能力邊界判斷退步。這不是「完全學不動」，而是目前的收益沒有同時保住拒絕能力，不符合高準確、避免錯配機制的用途。',
 '', 'R7 在 39 個完整訓練輸入上為 34/39，基底 23/39；其餘 256 題卻是 R7 178/256、基底 189/256。這支持將訓練暴露分層看待，不能單靠這次結果證明過擬合成因，也不能將非完整匹配題當全新語意。沒有執行重新平衡資料或再訓練實驗，無法保證修資料後必然改善。',
 '', '基底雖較少錯誤放行，仍只正確推薦 65/147 個可接受需求，亦不具備全自動上線資格。應將「完整符合／拒絕邊界」和模板 ID 契約分開驗收，不能用平均準確率或通過編譯代替。',
 '', '## 正式配對結果（排除撤回題）','',...table(a.stats),
 '', '錯誤放行是模型宣告 accept，但推薦不符合完整必要需求或不屬合法計畫。格式合法不代表符合需求；不必要拒絕另計為不正確，而不是錯誤放行。',
 '', '## 配對收益／退步',''];
for(const c of a.comparisons){const d=c.byTask['mechanism-stack'];lines.push(`- ${c.before} → ${c.after}：修正 ${d.fixed}、退步 ${d.regressed}、共同正確 ${d.bothCorrect}、共同錯誤 ${d.bothWrong}。`);}
lines.push('', '## 原本可接受與應拒絕的需求','');
for(const g of a.decisionGroups)lines.push('',`### 原答案 ${g.expectedDecision}`,'',...table(g.stats));
lines.push('', '## 候選目錄版本分開看','',
 '兩個版本各 32 計畫，差在 line-blast／traveling-wave 的沿途與終點傷害說明及 requiredChoices。runtime-clarified 是當時的澄清版本；legacy-description 保留舊描述。這些名稱不是目前 main 驗收狀態。候選順序也不同，不能把同一句需求的分差純粹歸因於排序、目錄澄清或模型訓練其中單一因素。');
for(const g of a.catalogGroups)lines.push('',`### ${g.label}（原始 ${g.rawRows} 個輸入）`,'',`目錄摘要：${g.catalogSha256}`,'',...table(g.stats));
lines.push('', '## 訓練暴露分層','',
 'R7 在這批資料中有 39 個完整訓練輸入匹配，不能與其他題混稱未見泛化。以下三個模型使用相同題組對照；未匹配完整輸入仍可能看過相同需求、單卡任務或機制家族。R3 無完整輸入匹配也不能推導完全未見語意。');
for(const g of a.exposureGroups)lines.push('',`### R7 完整訓練輸入${g.r7ExactTrainingInputSeen?'已匹配':'未匹配'}`,'',...table(g.stats));
lines.push('', '## 重複需求與較嚴格的完整通過','',
 `原始 296 輸入只有 ${a.rawUniqueRequestTexts} 種需求文字；排除撤回題後是 ${a.groupMetrics.base.uniqueRequests} 種。並非每個輸入都代表獨立機制，不能藉候選目錄版本重複增加獨立樣本數。以下以相同文字分組，但仍不是按語意改寫或機制家族去重。`,
 '', '| 模型 | 所有目錄版本都答對的需求 | 每需求等權平均正確率 | 至少一次錯誤放行的需求 |','| --- | ---: | ---: | ---: |');
for(const n of names){const g=a.groupMetrics[n];lines.push(`| ${n} | ${g.allCatalogVariantsCorrect}/${g.uniqueRequests} | ${g.requestMacroAccuracyPct.toFixed(2)}% | ${g.requestsWithAnyUnsafe} |`);}
lines.push('', '## 契約守衛後仍剩的語意錯誤','',
 '| 模型 | 非法推薦 | 契約合法但仍錯誤放行 |','| --- | ---: | ---: |');
for(const n of names)lines.push(`| ${n} | ${a.stats[n].illegalAccepts} | ${a.stats[n].legalButWrongAccepts} |`);
lines.push('', '這只是離線分類，不是已部署的新防護層。只修正 ID／JSON 或擋住未列計畫不能補回漏掉的對象、時序、事件或額外副作用。也不把模型的錯誤推薦直接當作 main 產品缺陷。',
 '', '## 逐需求錯誤覆核','',
 `至少一模型答錯的聯集為 ${a.errorCases} 個輸入、${a.uniqueErrorRequests} 種需求文字。所有這些需求均由助理回讀原文及對應計畫並記錄理由；同需求不同版本的原始輸出仍逐個保留。不是獨立人類／Owner Gold，也未修改本輪原標籤。`,
 '', '完整逐題資料為 case-review.json（295 題）和 error-review.json。review-notes.json 以一個代表 ID 記錄各需求的覆核，腳本會對應全部相同文字，不將一份理由宣稱多份獨立審查。',
 '', '### 已撤回題','',
 'inference-review-01536：帶可調取樣节拍且有終點爆炸的 traveling-wave 舊正例。原先就因終點行為證據撤回，沒有因這次某個模型答對／答錯才排除。其輸出只在 withdrawn-audit-only.json，不進 295 題、兩目錄或訓練暴露分層的分母。',
 '', '## 執行與可重現性','',
 `- 296 × 3 = 888 次實際推論；程序合計 ${a.workerSeconds.toFixed(2)} 秒（${(a.workerSeconds/60).toFixed(2)} 分鐘），另有模型完整性檢查開銷。`,
 ...names.map(n=>`- ${n}：${a.stats[n].seconds.toFixed(2)} 秒，Metal 峰值 ${a.stats[n].peakGiB.toFixed(2)} GiB。不是整機 RAM 或電池耗電量。`),
 '- 全題 tokenizer 2910–3065 tokens，加 256 輸出預留，符合 4096 上限；不截斷輸入、不修補輸出。',
 '- thinking=false、temperature=0、presence penalty=0，相同題序、逐題種子與版本；單次只載入一模型、12 GiB 上限、24 分鐘 GPU 硬截止。',
 '- 原 14 個來源 pins 與八個 requests chunk 摘要皆驗證；新 run 保留原 messages／target，未修改舊隊列或 CANCEL。',
 '- 基底和兩 adapter 在執行前後雜湊一致；本次 worker 終止、GPU lock 釋放，訓練呼叫 0，無雲端／下載／發布。',
 '- comparison.json 是全 296 輸入的原始重播（含撤回題），只供稽核；正式統計只用 comparison-qualified.json。兩者不得混用。',
 '- analyze.mjs 重新從原始輸出評分、檢查逐題 ID／摘要／種子與版本，依凍結 mapping 排除撤回題；不修改原始評分器。',
 '- sourceVersion 是原凍結版本，沒有重新編譯／驗收現行 main；原模板支援能力若變動，應另凍結新資料，而不是覆寫此次分數。',
 '', '## 完成界線','',
 '這只是补完主隊列的一個任務，不能標記「全範圍優質模型」完成。也不能把來源判讀、單多卡推薦或 VFX 分數互相抵銷。既有 20 題補充與新 37 名英雄 555 題保持獨立，不加进本 295 題分母。未宣稱模型已穩定可用，不恢復訓練。','');
fs.writeFileSync(path.join(dir,'REPORT.md'),lines.join('\n'));
fs.writeFileSync(path.join(dir,'RAW_SCORE_WARNING.md'),'# 原始重播與正式分母\n\ncomparison.json 包含 1 題事前已撤回標籤，只供重播稽核。正式比較請讀 comparison-qualified.json、analysis.json 或 REPORT.md，分母固定 295。不得將 296 題原始分數當正式品質證據。\n');
const files=['run.mjs','analyze.mjs','render-report.mjs','review-notes.json','analysis.json','main-coverage.json','case-review.json','error-review.json','catalog-variants.json','withdrawn-audit-only.json','comparison-qualified.json','RAW_SCORE_WARNING.md','REPORT.md'];
const pins=files.map(name=>({name,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,name))).digest('hex')}));
fs.writeFileSync(path.join(dir,'REPORT_VALIDATION.json'),JSON.stringify({createdAt:new Date().toISOString(),scoredQuestions:295,withdrawnExcludedBeforeScoring:true,allErrorRequestsReviewed:true,releaseQualified:false,pins},null,2)+'\n');
console.log(JSON.stringify({report:path.join(dir,'REPORT.md'),stats:a.stats}));
