import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {score} from '../../GGD-hero-auto-forge/tools/forge-training/r6-score.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const cases=read('cases.private.json'),admit=new Map(read('mapping.private.json').map(m=>[m.id,m.scoringQualified]));
const errors=new Map(),notes=fs.existsSync(path.join(dir,'review-notes.json'))?read('review-notes.json'):{};
const reviewed=Object.fromEntries(Object.entries(notes).map(([id,note])=>[JSON.parse(cases.find(c=>c.id===id).messages[1].content).request,note]));
for(const name of ['base','r3','r7']){
 const file=[name+'-raw.json',name+'-raw.json.partial'].find(n=>fs.existsSync(path.join(dir,n)));if(!file)continue;
 const raw=read(file);let passed=0,unsafe=0,scored=0;
 raw.results.forEach((r,i)=>{
  const c=cases[i],input=JSON.parse(c.messages[1].content);assert.equal(r.id,c.id);assert.equal(r.requestDigest,c.requestDigest);
  if(!admit.get(c.id))return;const s=score(c,r.value);scored++;passed+=Number(s.pass);unsafe+=Number(s.unsafe);
  if(!s.pass){const key=input.request,e=errors.get(key)??{request:key,expected:c.acceptedTargets,caseIds:[],outputs:{}};if(!e.caseIds.includes(c.id))e.caseIds.push(c.id);e.outputs[c.id+'-'+name]={value:r.value,pass:s.pass,unsafe:s.unsafe,schema:s.schema};errors.set(key,e);}
 });
 console.log(JSON.stringify({model:name,complete:raw.complete??false,generated:raw.results.length,scored,passed,unsafe}));
}
for(const e of errors.values())if(!process.argv.includes('--new-only')||!reviewed[e.request])console.log(JSON.stringify(e));
