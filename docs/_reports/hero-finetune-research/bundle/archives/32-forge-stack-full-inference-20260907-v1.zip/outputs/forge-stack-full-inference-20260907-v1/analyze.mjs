import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {compare} from '../../GGD-hero-auto-forge/tools/forge-training/r6-score.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8')),put=(n,v)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(v,null,2)+'\n');
const digest=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const cases=read('cases.private.json'),mapping=read('mapping.private.json'),summary=read('summary.json'),names=['base','r3','r7'];
assert.equal(summary.status,'complete');assert.equal(summary.completedCalls,888);assert.equal(summary.trainingCalls,0);assert.equal(summary.workerPid,null);assert(summary.lockReleased);
const arms=names.map(name=>({name,raw:read(name+'-raw.json')}));
assert.deepEqual(compare(cases,arms),read('comparison.json'));
const qualified=cases.map((c,i)=>({c,i,m:mapping[i]})).filter(({m})=>m.scoringQualified);assert.equal(qualified.length,295);
function compareRows(rows){return compare(rows.map(x=>x.c),arms.map(({name,raw})=>({name,raw:{...raw,results:rows.map(x=>raw.results[x.i])}})));}
const r=compareRows(qualified);put('comparison-qualified.json',r);
const variants=new Map(),groupKey=c=>{
 const input=JSON.parse(c.messages[1].content);return digest(input.allowedPlans.slice().sort((a,b)=>a.id.localeCompare(b.id)));
};
for(const c of cases){const key=groupKey(c);const input=JSON.parse(c.messages[1].content);const v=variants.get(key)??{id:key,plans:input.allowedPlans.slice().sort((a,b)=>a.id.localeCompare(b.id)),rows:0};v.rows++;variants.set(key,v);}
assert.equal(variants.size,2);
const compact=r=>Object.fromEntries(names.map(n=>{const s=r.scores[n],rows=s.rows;return[n,{passed:s.passed,total:s.total,pct:100*s.passed/s.total,unsafe:s.unsafe,schema:rows.filter(r=>r.schema).length,illegalAccepts:rows.filter(r=>r.unsafe&&!r.schema).length,legalButWrongAccepts:rows.filter(r=>r.unsafe&&r.schema).length}];}));
const catalogGroups=[...variants.values()].map(v=>({catalogSha256:v.id,label:v.plans.find(p=>p.id==='tpl-traveling-wave').requiredChoices.length?'runtime-clarified':'legacy-description',rawRows:v.rows,stats:compact(compareRows(qualified.filter(({c})=>groupKey(c)===v.id)))}));
const exposureGroups=[true,false].map(seen=>({r7ExactTrainingInputSeen:seen,warning:'No exact input match does not mean unseen requirement, template family, or semantic source',stats:compact(compareRows(qualified.filter(({m})=>m.exposure.r7.exactTrainingInputSeen===seen)))}));
const textGroups=new Map();for(const q of qualified){const input=JSON.parse(q.c.messages[1].content),g=textGroups.get(input.request)??[];g.push(q);textGroups.set(input.request,g);}
const groupMetrics=Object.fromEntries(names.map(n=>{const raw=arms.find(a=>a.name===n).raw;const indexed=new Map(r.scores[n].rows.map(x=>[x.id,x]));return[n,{uniqueRequests:textGroups.size,allCatalogVariantsCorrect:[...textGroups.values()].filter(qs=>qs.every(q=>indexed.get(q.c.id).pass)).length,requestMacroAccuracyPct:100*[...textGroups.values()].map(qs=>qs.filter(q=>indexed.get(q.c.id).pass).length/qs.length).reduce((a,b)=>a+b,0)/textGroups.size,requestsWithAnyUnsafe:[...textGroups.values()].filter(qs=>qs.some(q=>indexed.get(q.c.id).unsafe)).length}];}));
const notes=fs.existsSync(path.join(dir,'review-notes.json'))?read('review-notes.json'):{};
const review=Object.fromEntries(Object.entries(notes).map(([id,note])=>[JSON.parse(cases.find(c=>c.id===id).messages[1].content).request,note]));
assert.equal(Object.keys(review).length,Object.keys(notes).length,'DUPLICATE_REVIEW_REQUEST');
const errors=r.rows.filter(e=>names.some(n=>!e.outputs[n].score.pass));
const uniqueErrors=new Set(errors.map(e=>e.input.request));
for(const request of Object.keys(review))assert(uniqueErrors.has(request),'NOTE_FOR_NON_ERROR');
const rows=r.rows.map(e=>({...e,catalogSha256:groupKey(cases.find(c=>c.id===e.id)),postInferenceReview:review[e.input.request]??null,goldChanged:false,reviewQuality:'assistant review, not independent Owner Gold'}));
put('case-review.json',rows);put('error-review.json',rows.filter(e=>names.some(n=>!e.outputs[n].score.pass)));
put('catalog-variants.json',[...variants.values()]);
const unqualified=cases.map((c,i)=>({c,i,m:mapping[i]})).filter(({m})=>!m.scoringQualified);
put('withdrawn-audit-only.json',unqualified.map(({c,i,m})=>({id:c.id,request:JSON.parse(c.messages[1].content).request,oldTarget:c.target,admission:m,outputs:Object.fromEntries(arms.map(a=>[a.name,a.raw.results[i]])),scored:false})));
const stats=compact(r);for(const n of names)Object.assign(stats[n],summary.arms.find(a=>a.name===n));
const decisionGroups=['accept','refuse'].map(decision=>({expectedDecision:decision,stats:compact(compareRows(qualified.filter(({c})=>c.target.decision===decision)))}));
const analysis={createdAt:new Date().toISOString(),rawQuestions:296,scoredQuestions:295,withdrawn:unqualified.map(q=>q.c.id),stats,catalogGroups,exposureGroups,decisionGroups,groupMetrics,comparisons:r.comparisons,
 errorCases:errors.length,uniqueErrorRequests:uniqueErrors.size,reviewedErrorRequests:Object.keys(review).length,
 rawUniqueRequestTexts:new Set(cases.map(c=>JSON.parse(c.messages[1].content).request)).size,
 workerSeconds:summary.arms.reduce((n,a)=>n+a.seconds,0),trainingExecuted:false,releaseQualified:false,
 scope:'Historical closed-catalog classification, two catalog versions; not independent unseen or current-main runtime qualification'};
put('analysis.json',analysis);console.log(JSON.stringify(analysis,null,2));
const oldPath=path.resolve(dir,'../forge-final-three-hours-20260906/inference-review-analysis-power-stop-v1/summary.json');
const oldBytes=fs.readFileSync(oldPath),old=JSON.parse(oldBytes);
const previouslyMissing=new Set(old.notPaired.map(x=>x.id));
assert.equal(old.pairedRequests,954);assert.equal(previouslyMissing.size,1741);
assert(cases.every(c=>previouslyMissing.has(c.id)),'OVERLAP_WITH_PREVIOUSLY_PAIRED');
const completed=new Set(cases.map(c=>c.id));
const remaining=old.notPaired.filter(x=>!completed.has(x.id));
assert.equal(remaining.length,1445);
put('main-coverage.json',{createdAt:new Date().toISOString(),oldSummarySha256:crypto.createHash('sha256').update(oldBytes).digest('hex'),planned:2695,previouslyPaired:954,newRawPaired:296,newQualified:295,totalRawPaired:1250,totalScoreAdmitted:1249,remainingRaw:1445,remainingByTask:Object.fromEntries([...new Set(remaining.map(x=>x.task))].map(t=>[t,remaining.filter(x=>x.task===t).length])),remaining,oldRunUnchanged:true,otherRunsExcluded:['community37 full555','composition supplement20'],releaseQualified:false});
