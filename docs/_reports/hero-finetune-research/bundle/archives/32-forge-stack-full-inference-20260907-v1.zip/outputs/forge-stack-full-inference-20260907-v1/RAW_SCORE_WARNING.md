# 原始重播與正式分母

comparison.json 包含 1 題事前已撤回標籤，只供重播稽核。正式比較請讀 comparison-qualified.json、analysis.json 或 REPORT.md，分母固定 295。不得將 296 題原始分數當正式品質證據。
