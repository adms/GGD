# R7 低學習率單因素對照（23:10，已準備、未啟動）

R6完整一輪但三個候選均退步而未採用。R7重新從同一原R3權重開始，只將學習率1e-5降為2.5e-6，並按剩餘授權設定新時間窗；不是接續R6權重，也不添加輪數、prompt、標籤或資料。

23份資料／證據檔逐位元組複製並核對，466train／158dev／186test、來源、切分、seed、順序、LoRA設定、解碼與選模門檻不變。10份公開入口準備重新JSON正規化核對，17個模型請求與R6完全相同。82項forge-training CPU測試全部通過；不是模型品質結果。

凍結程式為r7-prepare/run/post/entry/finish/final-report；訓練器仍使用未修改的r6-train.py。ablation-preparation.json釘選R6比較證據與新配方，PRETRAIN_REVIEW.md列出假說與限制。相同步數48／96／117才做R6/R7學習率比較；最後不足完整輪次要明示。post63題已在R6用過，本輪標為source-63-regression，不能再當新來源測試。

啟動前必須確認R6 core、post、manual-entry-v3及finish皆成功且實際PID終止，GPU鎖空閒。此刻沒有R7 run-state或實際handle，不宣稱已在訓練。

時間：最晚23:30啟訓、9/7 00:45軟停止、00:48硬停止；整體GPU01:21:10、最終報告01:36:10。Mac-only，無雲端、外部teacher、推送或Editor啟用。量化與16GB實機仍未驗證；所有模型維持research-only。
