# CPU-only draft, not an inference run

This draft inherited unrelated metadata from the four-hero IR protocol. No GPU or training was started. It is retained unchanged for traceability; `semantic-facts-base-v2` uses an explicit execution-field allow-list and a pinned fact evaluator. The claims/targets themselves were unchanged.
