# 完整英雄資料初次盤點（CPU-only）

已收錄 44 名英雄／264 槽，分屬 33 個暫定作品家族。這是 37＋7 兩批完整來源的結構盤點，不是全部工作區資料，也不是本輪語意審查完成。

正向訓練映射核准 0；222 槽保留隔離、42 槽待重新驗證。44 名皆已有歷史評估曝光，不當作新盲測。

上游來源 hash：166 項，162 相符、4 改變、0 缺失。詳見 upstream-drift.json；舊快照保留，不以新 hash 偷換來源。

完全相同／去空白相同的技能文字組：2。家族與重複組必須在切分前處理；作品分組不等於機制家族已獨立。

| 英雄 | 暫定來源家族 | 槽數 | 模板映射 | 完整語意審查 | 新盲測 |
| --- | --- | ---: | --- | --- | --- |
| 武藤遊戲 | franchise:yugioh | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 八神庵 | franchise:kof | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 不知火舞 | franchise:kof | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 空條承太郎 | franchise:jojo | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 洛克人 | franchise:megaman | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 卡比 | franchise:kirby | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 西索 | franchise:hunter | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 米卡莎 | franchise:attack-on-titan | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 赫蘿 | franchise:spice-wolf | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 魯路修 | franchise:code-geass | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 利姆路 | franchise:slime | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 衛宮士郎 | franchise:fate | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 朝田詩乃 | franchise:sao | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 殺老師 | franchise:assassination | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 比利海靈頓 | franchise:wrestling-meme | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 魔法少女☆伊莉雅 | franchise:fate | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 安茲·烏爾·恭 | franchise:overlord | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 吉爾伽美什 | franchise:fate | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 桐谷和人 | franchise:sao | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 御坂美琴 | franchise:railgun | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 鹿目圓 | franchise:madoka | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 菜月昴 | franchise:rezero | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 坂田銀時 | franchise:gintama | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 奇犽 | franchise:hunter | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 一拳超人 | franchise:one-punch | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 名偵探柯南 | franchise:conan | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 庫洛魔法使 | franchise:cardcaptor | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 艾莉絲·伯雷亞斯·格雷拉特 | franchise:mushoku | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 芙莉蓮 | franchise:frieren | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 尼古貓貓 | franchise:yanineko | 6 | quarantined | 待重新逐槽審查 | 不可 |
| SUN樂 | franchise:shangrila | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 阿薩謝爾 | franchise:azazel | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 近衛刀太 | franchise:negima-uq | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 高速婆婆 | franchise:dandadan | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 炭治郎 | franchise:kimetsu | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 鬼畜王蘭斯 | franchise:rance | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 吉伊卡哇 | franchise:chiikawa | 6 | quarantined | 待重新逐槽審查 | 不可 |
| 沃維克 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 卡爾瑟斯 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 拉克絲 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 犽宿 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 好運姐 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 李星 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |
| 齊勒斯 | franchise:league-of-legends-ggd-adaptation | 6 | pending-revalidation | 待重新逐槽審查 | 不可 |

source-inputs.json 只包含原文與來源摘要；review-queue.private.json 另存舊模板和待審說明，不能把後者直接送進基線模型提示。

下一步：核對來源差異、逐槽拆必要要求與跨槽依賴、建立當前能力契約與行為證據，再决定哪些資料能進訓練或完整英雄基線。
