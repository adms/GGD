# 前次測試時限紀錄

最終版首次 probe 使用 20 秒整體時限，得到 `CHILD_EXIT:null:SIGTERM`，不是預期的 `/usr/bin/false` exit 1；測試器因此失敗，未把它當作產品守衛通過。

更精確的時序：權重校驗已完成，doctor sentinel 在 2026-09-05T21:30:03.529Z 開始，21:30:03.562Z 以 SIGTERM 結束；當時 lease 已清成 null。先前對話「權重校驗尚未完成」不精確，應以這份 stage 收據為準。測試包含大型權重 hash，20 秒上限不足以穩定涵蓋整個 probe。

原隔離狀態：`/var/folders/nh/0xwcm79d52v3qyr1ntzqvwnc0000gq/T/forge-cache-probe-Armdpo/state.json`。沒有執行 MLX，沒有修改原研究 run。

後續測試器改為每 probe 60 秒，並保存每個 probe 的 elapsed seconds、spawn error、signal、stdout／stderr，再依具體 expected error 判定。這不改變原實驗的八小時 deadline。
