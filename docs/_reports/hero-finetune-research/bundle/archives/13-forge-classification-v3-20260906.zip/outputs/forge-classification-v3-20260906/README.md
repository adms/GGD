# 四小時分類／模板推薦實驗（已取消，禁止晉級）

**2026-09-06 11:48:16 已依使用者品質要求取消。** 下方是取消前的歷史設定，不代表仍在執行。1,872／188／260 僅為產出筆數，不是語意品質通過證明。本版短暫訓練的權重不會沿用。後續品質稽核與重新挑選資料見 `../forge-classification-reviewed-20260906/QUALITY_REVIEW.md`。

時間：2026-09-06 11:36:10–15:36:10 Asia/Taipei，重跑沒有延長截止。4B non-thinking、Mac MLX、無雲端 GPU。

資料：1872 train／188 dev／260 test。七類任務涵蓋機制模板、模板順序組合、VFX 綁定沿用、自然語言 VFX 推薦、能力狀態、既有行為分類與英雄分類。來源盤點包括34模板（17 enabled／17 draft）、632 VFX、461技能、498行為分類（497進資料，1筆缺行為證據）、53英雄分類；不合法組合有明確隔離紀錄。

只訓練分類和建議套用模板；參數完全不進本輪 target。特效大小版本以模板名稱區分，但模型不產生 scale、alpha、delay 等參數。模型不改 Editor 或遊戲內容。

## 真正執行狀態

看 run-state.json、各階段 log 和 worker-lease.json；lease 不是程序仍活著的證明。訓練與評測由 `GGD-hero-auto-forge/tools/forge-training/classification-run.mjs` 自動銜接：doctor→baseline dev→最多2個完整 epoch→dev選擇→封存 test A/B。如果第二個 epoch 的預估時間侵蝕30分鐘評測保留，完整存完第一個 epoch 後停止。最後另留15分鐘報告。

比較使用相同 MLX BF16、greedy 解碼、去台詞規則、檢索上下文與請求。沒有 grammar。分類／模板主分數與 decision／schema 分開；不能把格式學習偽裝成選模板能力。將來 comparison.json 出現且實際完整，才能報微調成效。

## 明確限制

題目和答案是程式依既有資料產生，不是人工 Gold。VFX 的自然語言題是元素／形態分類，沒有視覺驗證；綁定沿用與英雄分類查錄是較容易的檢索任務，分開列分母。機制模板見過的種類共享目錄，不能宣稱所有測試都是未知模板泛化。Schema／compiler／SimWorld 證據詳見 validation.json，沒有把 scenario 通過外推成每一種行為的完整證明。

## 預備版本保留

- forge-classification-v2-20260906：在正式訓練前取消，修正大小版本名稱歧義。
- forge-classification-final-20260906：在 dev 發現契約未充分說明 decision/reasonCode 且評分混入格式；停止短暫訓練，未讀 test。氣功題實際選對 fx.prim.ki.beam，却因 decision 欄位放了 ID 而被舊評分列錯，因此不能拿那份低分當語意基準。
- 本 v3 從乾淨基底重來，明確輸出 enums、能力狀態直接用 supported/partial/unsupported，兩組統一 greedy；舊結果不重評成新成績。

## 交付接線（尚待訓練完成後驗證）

catalog.json 是公開模板候選資訊，不含訓練答案。classification-client.mjs 準備請求，classification-predict.py 做本機非推理推論，classification-client.mjs validate 檢查未知／不可用模板和禁止的特效參數。氣功砲關鍵字檢索只是候選召回，不算模型預測；實際模型端到端結果尚待完成後另測。

selected-adapter/、selection.json、comparison.json 目前若不存在，代表階段尚未完成，不能把本 README 當成完成收據。量化、重載、實際推薦入口與穩定性仍待後續執行；未 commit、未 push、未啟用 Editor。
