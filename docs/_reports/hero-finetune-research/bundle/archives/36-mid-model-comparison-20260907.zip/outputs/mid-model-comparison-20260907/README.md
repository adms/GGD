# 9B／12B 推論測試

**已於2026-09-08完成四組各96題，共384次推論，所有GPU作業已退出。** 結論入口：[FINAL_RESULT.md](FINAL_RESULT.md)；逐題與自動報告：[REPORT.md](REPORT.md)；證據檢查：[VERIFICATION.json](VERIFICATION.json)。原始嚴格分數與只去Markdown的離線診斷分開，沒有部署格式修復或重啟訓練。

授權：使用者「測試 9/12B」。僅下載並推論，不訓練、不部署、不更新舊目標成功狀態。

候選固定為 Qwen3.5-9B-8bit 與 Gemma 4 12B IT 8bit；revision 見 download.py 與各下載收據。優先使用MLX-VLM維護的Qwen 9B轉換（無MLX字尾），不是較早的實驗分支轉換。

沿用 ../qwen38-local-comparison-20260907 的全部96題，不挑失敗題、不修改Gold或提示詞。每模型依序測plain與native thinking，上限512／4096 tokens。兩家原生推理設定不宣稱是等價medium。

報告入口：REPORT.md。狀態：state.json。原始證據：*-raw.json（.partial不是完整結果）。下載檔驗證size及LFS SHA256；不允許trust_remote_code。

啟動：既有獨立venv的python執行 download.py 9b / 12b，再執行 run.py。監督器只允許一個GPU worker，並檢查接電、記憶體、swap及超時。再次執行會拒絕覆寫已存在state.json；不自動重試已完成實驗。建立本目錄STOP檔可要求停止評估。

本輪不是16GB實機測試，不承諾部署適用；下載約23.2GB，暫存在/private/tmp/ggd-mid-models-20260907，不刪除原27B或舊訓練成果。

初次停止後的接續：initial-attempt/保存原程式及部分結果，state.json保存首次終止狀態。9B推理因連續三題4096token截斷、12B不推理因連續三題Markdown包裝而停止。已確認是可評分模型缺點，非載入或解析器故障；resume-run.py依序補完12B、9B尚未測的題目，不重試／刪除失敗、不改提示或預算、不修復主成績。上述已知缺點只計錯，不再觸發基礎設施停止；其他保護不變。最新狀態為resume-state.json。
