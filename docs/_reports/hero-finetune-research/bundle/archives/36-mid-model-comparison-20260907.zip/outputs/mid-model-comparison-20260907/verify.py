"""Independent CPU-only evidence checks; no model imports or inference."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from evaluate import final_json

HERE = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    subprocess.run(['/usr/local/bin/node', str(HERE/'report.mjs')],check=True)
    manifest = read(HERE/'manifest.json')
    requests = read(HERE/'requests.json')
    private = read(HERE/'cases.private.json')
    assert len(requests) == len(private) == 96
    assert len({r['id'] for r in requests}) == 96
    request_hash = digest(HERE/'requests.json')
    assert request_hash == manifest['requestSha256']
    for r, c in zip(requests,private):
        assert set(r) == {'id','requestDigest','messages'}
        assert r['id'] == c['id'] and r['requestDigest'] == c['requestDigest']
        assert r['messages'] == c['messages']
    evidence = {}
    analysis = read(HERE/'analysis.json')
    for name in ['9b','12b']:
        receipt = read(HERE/f'{name}-download.json')
        assert receipt['status'] == 'verified'
        from transformers import AutoTokenizer
        tokenizer=AutoTokenizer.from_pretrained(receipt['destination'],local_files_only=True,trust_remote_code=False)
        for f in receipt['files']:
            assert (Path(receipt['destination'])/f['name']).stat().st_size == f['bytes']
        for mode in ['plain','thinking']:
            key = f'{name}-{mode}'
            raw = read(HERE/f'{key}-raw.json')
            meta = raw['metadata']
            assert raw['complete'] and len(raw['results']) == 96
            assert meta['model'] == receipt['repo'] and meta['revision'] == receipt['revision']
            assert meta['requestSha256'] == request_hash
            allowed_hashes={digest(HERE/'evaluate.py'),digest(HERE/'initial-attempt/evaluate.py')}
            assert meta['evaluatorSha256'] in allowed_hashes
            assert all(r.get('evaluatorSha256',meta['evaluatorSha256']) in allowed_hashes for r in raw['results'])
            assert meta['thinking'] == (mode=='thinking')
            assert meta['maxTokens'] == (4096 if mode=='thinking' else 512)
            assert meta['quantization']=='8-bit' and meta['temperature']==0
            assert meta['seed']==20260907 and meta['prefillStepSize']==256
            assert not meta['training'] and not meta['visualInputs'] and meta['grammar']=='none'
            for r, q in zip(raw['results'],requests):
                assert r['id']==q['id'] and r['requestDigest']==q['requestDigest']
                prompt=tokenizer.apply_chat_template(q['messages'],tokenize=False,add_generation_prompt=True,enable_thinking=mode=='thinking')
                assert r['promptSha256']==hashlib.sha256(prompt.encode()).hexdigest()
                parsed, error = None, None
                try:
                    if r['finishReason']!='stop':raise ValueError('TOKEN_BUDGET_EXHAUSTED')
                    parsed=final_json(r['text'],mode=='thinking',meta['family'])
                except (ValueError,TypeError) as exc:error=str(exc)
                assert r['value']==parsed and r['error']==error
                assert r['seconds']>0 and r['peakMetalBytes']>0
            a=analysis['arms'][key]
            assert a['complete'] and a['count']==96
            evidence[key]={'rawSha256':digest(HERE/f'{key}-raw.json'),
                'passed':a['passed'],'unsafe':a['unsafe'],'errors':a['errors'],
                'revision':receipt['revision']}
    for name,mode in [('9b','thinking'),('12b','plain')]:
        original=read(HERE/'initial-attempt'/f'{name}-{mode}-raw.json.partial')
        final=read(HERE/f'{name}-{mode}-raw.json')
        assert final['results'][:len(original['results'])]==original['results'],'ORIGINAL_RESULTS_CHANGED'
    state=read(HERE/'resume-state.json')
    assert state['status']=='complete' and state['workerPid'] is None
    assert all(v['exitCode']==0 and v['safetyStop'] is None for v in state['models'].values())
    result={'completeExperiment':True,'releaseQualified':False,'requestSha256':request_hash,
            'arms':evidence,'scope':'384 calls, byte-identical requests, pinned unchanged scorer, strict output reparsing, verified download receipts and terminal worker state; not independent Owner Gold or 16GB validation.'}
    (HERE/'VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
