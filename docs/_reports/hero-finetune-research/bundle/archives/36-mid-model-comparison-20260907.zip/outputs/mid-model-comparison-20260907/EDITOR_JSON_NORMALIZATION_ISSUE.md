[重要][improve] 編輯器 AI 共用 JSON 輸出包裝正規化：跨模型去除完整外層 Markdown，保留嚴格驗證

## Objective

Owner 指定先處理 JSON 輸出包裝，交由編輯器端實作，避免模型內容正確卻因外層 Markdown 被拒絕。做成模型無關的共用層；不同供應商的完成狀態及 final/reasoning 分離由各自 adapter 負責。不是每個模型都會提高分數，但所有接入模型都能共用一致的輸出契約與安全邊界。

## Evidence / measured impact

2026-09-08 本機固定 96 題、同一 scorer、8-bit 推論的離線診斷：

| 模型／模式 | 原生嚴格通過 | 僅去完整外層 Markdown 後 | 包裝筆數 |
| --- | ---: | ---: | ---: |
| Gemma 4 12B IT 不推理 | 60/96 | 92/96 | 34，其中 32 筆恢復通過 |
| Gemma 4 12B IT 推理 | 42/96 | 91/96 | 50，另 2 筆截斷仍失敗 |
| Qwen3.5-9B 不推理／推理 | 81/96、78/96 | 不變 | 無此包裝收益 |
| Qwen3.8-27B 不推理／medium 推理 | 91/96、91/96 | 不變 | 無此包裝收益 |

這是既有 raw output 的離線重評，不是新生成、fine-tune 收益、Editor E2E 或正式上線收據。原始主分數、Gold 與失敗紀錄均保留；`releaseQualified=false`。英雄設定與技能機制理解錯誤仍然存在，格式成功不等於語意正確。

本機可重現證據位於工作區 `outputs/mid-model-comparison-20260907/`：`FINAL_RESULT.md`、`INSIGHTS.md`、`analysis.json`（`fencedDiagnostics`）、`VERIFICATION.json`、`report.mjs`。這些是本機研究產物，不宣稱已在遠端 repo；本票不公開上傳完整私有題庫、Owner 原文或模型推理全文。

## Scope

- 僅結構化 JSON 任務：由完成的 provider response → 明確 final answer → 共用包裝正規化 → 嚴格 JSON parse → 現有任務 schema／ID／能力契約 → 候選預覽與人工套用。
- 先串接目前存在的結構化推論消費路徑及測試，不為未支援的 provider 新造 runtime。一般文字補寫及圖像回應不強制 JSON。
- bare JSON 直接驗證；允許完整 final answer 的單一外層三反引號區塊，語言標籤只允許 `json` 或空白標籤，允許外側空白及 LF/CRLF。不接受前後解說、第二個區塊或半截 fence。
- 保留原始輸出與診斷收據：normalizer 版本、是否去包裝、原生 parse 結果、正規化後 schema 結果、模型／provider／request 識別、完成狀態。原始文字限本機受控診斷，不自動上傳或記錄 API key。

## Files / modules likely affected

以下已在本機 `GGD-hero-auto-forge` checkout 實查，接手時須再核對編輯器目標分支，不宣稱與最新 main 相同：

- `apps/editor-desktop/src/ai/byok/openaiAdapter.ts`：`finishProposalBatch` 直接 `JSON.parse(text)` 後套 `zHeroProposalPayloadBatch`；檢查 Responses／Chat Completions 結構化出口與完成狀態傳遞。
- `apps/editor-desktop/src/ai/byok/openaiAdapter.test.ts`：對應 adapter 行為測試。
- `apps/editor-desktop/src/ai/local/llamaCppReleaseClient.ts` 及其測試：本機版本的 content 為空時會 fallback 到 `reasoning_content`；結構化答案不得沿用此 fallback。此為 release client 的程式碼觀察，不宣稱生產事故。
- `apps/editor-desktop/src/ai/local/localWorker.ts`：目前仍有 release gate，不能藉本票開啟未驗收本機模型。
- `packages/shared/src/content/heroForge/proposal.ts`、`proposalJsonSchema.ts`：沿用既有契約，不為提高通過率放寬 schema。
- 新增共用純函式模組及對應測試，具體檔名由接手方依現行分層決定；不要讓 shared import Electron／應用層。

## Implementation constraints

1. Adapter 必須確認正常完成：Chat Completions 的正常 stop、Responses 的 completed 或已驗證的本機等價結束狀態。length、incomplete、取消、逾時、串流尚未結束、拒絕回覆或無法確認完成一律阻擋，不從外觀猜成功。tool-call 結果不屬於本票的 final JSON。
2. 優先使用 provider 明確 final channel。不得從 `reasoning_content`／思考段挖 JSON。原生混合文字協定需要明確、可測試的 adapter；不能用一個跨模型正則猜分隔符，更不能把 JSON 字串內的分隔符當成 channel。
3. 只移除外層包裝；不補括號、引號、逗號、缺欄位，不 coercion，不改 ID、不展開 planId、不換模板、不改 accept/degrade/refuse、不補猜答案、不自動用第二次模型呼叫修 JSON。
4. 正規化後仍驗任務 root type、schema、允許的 ID／組合及能力契約。未知／不准許內容 fail closed；維持編譯與人工確認，不直接寫回技能。
5. 區分輸出錯誤與任務判斷：包裝／截斷／schema 失敗是診斷錯誤，不能偽造一份語意上的「refuse」答案。
6. 第二個住處：BYOK、local release client、研究評測不得各自維護會漂移的寬鬆 parser；正式路徑共用版本化契約，歷史研究 raw 與嚴格主成績不可回寫。UI 結果與診斷收據必須引用同一次驗證結果。

## Acceptance criteria（驗收標準）

- [ ] 使用者在編輯器同一結構化 AI 操作中，收到 bare JSON 或合法單一外層 JSON fence 時，看見內容完全相同的已驗證候選；不需手動刪除反引號。仍須人工確認套用。
- [ ] 以不同 provider adapter 的測試回應驗證共用層；正常 bare JSON 不退步，不建立 Gemma/Qwen 專用答案修補規則。
- [ ] 截斷（即使文字看似合法 JSON）、reasoning-only、多區塊、額外解說、壞 JSON、非法 schema／ID／組合皆被阻擋且顯示可理解的原因；不產生可套用候選，也不改既有英雄／技能。
- [ ] JSON 字串內合法的反引號、花括號、跳脫字元與 channel 標記保持原值，不能被清理程序改寫。
- [ ] 本機诊斷可区分原生有效、僅包裝正規化後有效、無效；失敗 raw 可追溯且不自動外傳。
- [ ] 無需下載模型、重訓、啟用本機 release gate 或增加雲端服務，即可先完成程式整合及 CPU fixture 驗證。格式改善不得被宣布為英雄／技能語意品質驗收通過。

## Test / verification criteria

- 用 synthetic bare/fenced 成對 fixture 驗解析物件深度相同、正規化冪等；覆蓋空白、LF/CRLF、合法字串內特殊符號。
- 同批涵蓋截斷、空 final＋非空 reasoning、分隔符不完整、兩段 fence、尾隨 prose、缺欄位、未知 ID、錯誤 root type。保留既有 schema／安全閘，不讓測試只斷言 JSON.parse 成功。
- Adapter → 共用 normalizer → schema → 編輯器候選／阻擋的整合回放；附使用者端操作結果證據，不能只跑純函式。
- 既有 96 題只能作回歸與歷史重評；若以真模型宣稱泛化品質，另用未參與設計的固定保留題與同 scorer，並分列原生／正規化結果。新 GPU 推論另按 Owner 授權安排，本票開立不啟動推論。
- 一個承重突變：繞過完成狀態檢查後，截斷但合法 JSON 的 fixture 必須使測試變紅；還原後交付紀錄。

## Dependencies

無新增引擎機制或新模型依賴。交由 Editor scope 實作，Main 不需新增技能機制。

開票前已查 open＋closed 的 JSON、包裝、JSON輸出、reasoning、normalization、Markdown，並執行 `scripts/ticket-similar.sh`；未見同範圍票。查重命中的 #322 是 stat-normalization／測試遮蔽，並非 AI 包裝。本票與 #1024 匯出 heroes/vfx、#991 UGC 提交流程範圍不同，不取代它們。

## Non-goals

不訓練、不更換／下載模型、不視覺驗證、不調特效參數、不修模型語意、不修改 Gold、不宣告完整英雄自動鑄造可上線、不改 Main 遊戲機制、不取消任何原有 release／schema／compiler gate。

## Known risks

寬鬆擷取會誤接受思考中的範例或遭截斷的答案；必須限制到已完成且明確的 final answer。供應商結束語意不同，未知狀態應可診斷地拒絕。診斷日誌可能包含 Owner 私有內容，需沿用本機隱私／保存政策。96 題提高 32 題只是格式恢復，不代表一般化準確度增加 33.33 個百分點。

---

[思考策略] 單一事實來源＋使用者看得到才算做完：跨模型共用格式契約，驗到候選预览與失敗阻擋。

[解決模板] 承重守衛＋突變驗證；前例為本機 `outputs/mid-model-comparison-20260907/report.mjs` 的離線 `fencedDiagnostics` 與既有 `openaiAdapter.ts` 的 schema gate。前者只作有限格式診斷參考，不直接照抄其 delimiter 邏輯作通用 production parser。
