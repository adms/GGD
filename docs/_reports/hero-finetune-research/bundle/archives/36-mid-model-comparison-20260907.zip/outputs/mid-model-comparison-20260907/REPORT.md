# 9B／12B／27B 本機英雄與機制推論比較

只測文字分類／機制理解；沒有訓練、視覺驗證或特效參數生成。相同96題、相同messages和scorer；保留3題既有Gold疑義，敏感度排除相同ID。
Qwen3.5-9B、Gemma 4 12B IT：本輪8-bit；27B：先前同批Qwen3.8 8-bit結果。跨架構／世代，不能當成參數量的單因子實驗。
plain最大512 tokens；thinking最大4096 tokens；temperature=0。9B/12B使用原生enable_thinking，並非27B的medium effort等價設定。
模式之間重設Metal峰值計數；27B舊結果未重設。Metal峰值不是整機記憶體；沒有16GB實機驗證。
初次防護因9B連續截斷、12B連續Markdown停止，紀錄保留在initial-attempt/。確認非基礎設施故障後，僅接續未測題；上述已知錯誤仍扣分、不重試或放寬tokens，其餘資源保護不變。

| 模型模式 | 完成 | 正確 | 錯誤放行 | JSON／截斷錯誤 | 推論分鐘 | Metal峰值GiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 9b-plain | 完整 96/96 | 81/96 | 7 | 0 | 1.74 | 10.30 |
| 9b-thinking | 完整 96/96 | 78/96 | 0 | 17 | 69.64 | 10.30 |
| 12b-plain | 完整 96/96 | 60/96 | 0 | 34 | 2.81 | 12.67 |
| 12b-thinking | 完整 96/96 | 42/96 | 0 | 52 | 35.87 | 12.67 |
| 27b-plain | 完整 96/96 | 91/96 | 0 | 0 | 5.33 | 28.39 |
| 27b-thinking | 完整 96/96 | 91/96 | 0 | 0 | 43.95 | 28.39 |

## 分項

| 模型模式 | 任務 | 正確 | 錯誤放行 |
| --- | --- | ---: | ---: |
| 9b-plain | hero-source | 22/24 | 0 |
| 9b-plain | owner-community37 | 17/18 | 0 |
| 9b-plain | owner-historical | 17/18 | 0 |
| 9b-plain | mechanism-stack | 25/36 | 7 |
| 9b-thinking | hero-source | 22/24 | 0 |
| 9b-thinking | owner-community37 | 14/18 | 0 |
| 9b-thinking | owner-historical | 17/18 | 0 |
| 9b-thinking | mechanism-stack | 25/36 | 0 |
| 12b-plain | hero-source | 16/24 | 0 |
| 12b-plain | owner-community37 | 0/18 | 0 |
| 12b-plain | owner-historical | 15/18 | 0 |
| 12b-plain | mechanism-stack | 29/36 | 0 |
| 12b-thinking | hero-source | 19/24 | 0 |
| 12b-thinking | owner-community37 | 0/18 | 0 |
| 12b-thinking | owner-historical | 15/18 | 0 |
| 12b-thinking | mechanism-stack | 8/36 | 0 |
| 27b-plain | hero-source | 22/24 | 0 |
| 27b-plain | owner-community37 | 18/18 | 0 |
| 27b-plain | owner-historical | 16/18 | 0 |
| 27b-plain | mechanism-stack | 35/36 | 0 |
| 27b-thinking | hero-source | 22/24 | 0 |
| 27b-thinking | owner-community37 | 16/18 | 0 |
| 27b-thinking | owner-historical | 18/18 | 0 |
| 27b-thinking | mechanism-stack | 35/36 | 0 |

## 接受／拒絕與結構契約

JSON可解析不代表ID與計畫合法；schemaErrors涵蓋非法模板ID與未允許的組合。錯誤放行包含接受了錯誤計畫，不只將應拒絕題接受。

| 模型模式 | 應接受18題 | 應拒絕18題 | 全部結構契約錯誤 |
| --- | ---: | ---: | ---: |
| 9b-plain | 7/18 | 18/18 | 3 |
| 9b-thinking | 13/18 | 12/18 | 17 |
| 12b-plain | 11/18 | 18/18 | 34 |
| 12b-thinking | 1/18 | 7/18 | 52 |
| 27b-plain | 17/18 | 18/18 | 0 |
| 27b-thinking | 17/18 | 18/18 | 0 |

## 排除既有Gold疑義的敏感度（不取代主分數）

| 模型模式 | 正確 | 錯誤放行 |
| --- | ---: | ---: |
| 9b-plain | 80/93 | 6 |
| 9b-thinking | 78/93 | 0 |
| 12b-plain | 60/93 | 0 |
| 12b-thinking | 42/93 | 0 |
| 27b-plain | 90/93 | 0 |
| 27b-thinking | 91/93 | 0 |

## 與27B不推理逐題對照

| 候選 | 修正 | 退步 | 新增錯誤放行 |
| --- | ---: | ---: | ---: |
| 9b-plain-vs-27b-plain | 2 | 12 | 7 |
| 9b-thinking-vs-27b-plain | 2 | 15 | 0 |
| 12b-plain-vs-27b-plain | 2 | 33 | 0 |
| 12b-thinking-vs-27b-plain | 1 | 50 | 0 |
| 27b-thinking-vs-27b-plain | 2 | 2 | 0 |

## 計畫ID與模板ID混淆診斷

這是離線反事實診斷，不修改原始輸出、不修改主分數、不視為模型自己答對。若只把一個已知多卡planId展開為該計畫的templateIds即可通過，表示可能有可由API設計改善的序列化問題；不證明其他語意能力可靠。
錯誤放行是scorer的錯誤accept分類，其中非法ID／未允許組合應由現行確定性契約阻擋，不等同已在遊戲執行了危險技能。

- 9b-plain：2題，inference-review-01360、inference-review-01392。

## 僅移除外層Markdown的離線診斷（不是主成績）

對所有模型套用相同規則：必須已正常結束；只從最終答案移除完整單一外層JSON程式碼區塊，不從推理找答案、不改ID、不修JSON或語意。僅用以区分格式遵循與內容判斷，未部署這個修復。

| 模式 | 已觀察題數 | 解開外層區塊 | 診斷正確 | 診斷錯誤接受 |
| --- | ---: | ---: | ---: | ---: |
| 9b-plain | 96 | 0 | 81/96 | 7 |
| 9b-thinking | 96 | 0 | 78/96 | 0 |
| 12b-plain | 96 | 34 | 92/96 | 0 |
| 12b-thinking | 96 | 50 | 91/96 | 0 |
| 27b-plain | 96 | 0 | 91/96 | 0 |
| 27b-thinking | 96 | 0 | 91/96 | 0 |

## 執行狀態

```json
{
  "status": "complete",
  "startedAt": 1788794625.6166432,
  "selectedModels": [
    "12b",
    "9b"
  ],
  "pid": 87766,
  "models": {
    "12b": {
      "status": "complete",
      "availableGiB": 48.17588806152344,
      "existingSwapGiB": 17.78936767578125,
      "requiredAvailableGiB": 17.872997955419123,
      "acPower": true,
      "exitCode": 0,
      "safetyStop": null,
      "seconds": 2215.7517368793488,
      "minimumAvailableGiB": 32.51646423339844,
      "maximumSwapGiB": 17.78936767578125
    },
    "9b": {
      "status": "complete",
      "availableGiB": 49.751800537109375,
      "existingSwapGiB": 17.78155517578125,
      "requiredAvailableGiB": 15.73552752751857,
      "acPower": true,
      "exitCode": 0,
      "safetyStop": null,
      "seconds": 3627.5906097888947,
      "minimumAvailableGiB": 35.70799255371094,
      "maximumSwapGiB": 17.78155517578125
    }
  },
  "workerPid": null,
  "policy": {
    "training": false,
    "cloud": false,
    "concurrentGpuWorkers": 1,
    "maxDownloadWaitHours": 4,
    "minAvailableGiB": 4,
    "maxSwapIncreaseGiB": 2,
    "maxCaseSeconds": 250,
    "maxWorkerMinutes": 100
  },
  "currentModel": "9b",
  "workerStartedAt": 1788796841.669464,
  "endedAt": 1788800469.499219
}
```

既有題庫曾被助理覆核，不是独立Owner盲測。96題含36機制案例但只有34種不同需求文字。小樣本高分不代表正式全自動合格。
安全限制：單GPU worker、接電、24GiB Metal上限、最低4GiB系統可用記憶體、swap增量不超過2GiB；不改系統wired limit、不終止他人程式。
原始輸出與逐題分數保留於本目錄。模型權重在/private/tmp，可能被系統清理。
