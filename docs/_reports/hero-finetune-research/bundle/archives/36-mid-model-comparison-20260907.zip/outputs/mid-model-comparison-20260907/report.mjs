import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(here,'../..');
const old=path.resolve(here,'../qwen38-local-comparison-20260907');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const manifest=read(path.join(here,'manifest.json'));
assert.equal(hash(path.join(here,'requests.json')),manifest.requestSha256);
assert.equal(hash(path.join(here,'requests.json')),hash(path.join(old,'requests.json')));
assert.equal(hash(path.join(here,'cases.private.json')),hash(path.join(old,'cases.private.json')));
assert.equal(hash(path.join(here,'gold-review-flags.json')),hash(path.join(old,'gold-review-flags.json')));
for(const pin of manifest.scorerPins)assert.equal(hash(path.join(root,pin.path)),pin.sha256,'SCORER_CHANGED');
const {score}=await import(path.join(root,'GGD-hero-auto-forge/tools/forge-training/r6-score.mjs'));
const cases=read(path.join(here,'cases.private.json'));
const flags=read(path.join(here,'gold-review-flags.json'));
const arms={};
const fencedDiagnostics={};
for(const name of ['9b','12b','27b'])for(const mode of ['plain','thinking']){
 const base=name==='27b'?old:here, key=`${name}-${mode}`;
 let file=path.join(base,key+'-raw.json');
 if(!fs.existsSync(file))file+='.partial';
 if(!fs.existsSync(file))continue;
 const raw=read(file), tasks={}, rows=[], decisions={};
 const fenced={count:raw.results.length,complete:raw.complete,unwrapped:0,passed:0,unsafe:0,rows:[]};
 for(let i=0;i<raw.results.length;i++){
  const c=cases[i],r=raw.results[i];assert.equal(c.id,r.id);assert.equal(c.requestDigest,r.requestDigest);
  const s=score(c,r.value);assert(!r.error||!s.pass);
  const t=tasks[c.comparisonCohort]??={count:0,passed:0,unsafe:0};
  t.count++;t.passed+=+s.pass;t.unsafe+=+s.unsafe;
  const bucket=c.comparisonCohort+':'+(c.target.verdict??c.target.decision);
  const d=decisions[bucket]??={count:0,passed:0,unsafe:0};d.count++;d.passed+=+s.pass;d.unsafe+=+s.unsafe;
  rows.push({id:c.id,task:c.task,cohort:c.comparisonCohort,value:r.value,error:r.error,score:s});
  let diagnosticValue=r.value,unwrapped=false;
  if(r.error&&r.finishReason==='stop'){
   let final=r.text;
   if(mode==='thinking'){
    const delimiter=name==='12b'?'<channel|>':'</think>';
    final=final.includes(delimiter)?final.split(delimiter).slice(1).join(delimiter):'';
   }
   const match=final.trim().match(/^```(?:json)?\s*\n([\s\S]*?)\n```$/);
   if(match){try{diagnosticValue=JSON.parse(match[1]);unwrapped=true;}catch{}}
  }
  const diagnosticScore=score(c,diagnosticValue);
  fenced.unwrapped+=+unwrapped;fenced.passed+=+diagnosticScore.pass;fenced.unsafe+=+diagnosticScore.unsafe;
  fenced.rows.push({id:c.id,unwrapped,value:diagnosticValue,score:diagnosticScore});
 }
 const admitted=rows.filter(r=>!Object.hasOwn(flags,r.id));
 arms[key]={complete:raw.complete&&rows.length===96,count:rows.length,
  passed:rows.filter(r=>r.score.pass).length,unsafe:rows.filter(r=>r.score.unsafe).length,
  errors:rows.filter(r=>r.error).length,schemaErrors:rows.filter(r=>!r.score.schema).length,tasks,decisions,rows,
  generationSeconds:raw.results.reduce((n,r)=>n+r.seconds,0),
  peakMetalGiB:Math.max(0,...raw.results.map(r=>r.peakMetalBytes))/1024**3,
  metadata:raw.metadata,
  sensitivity:{count:admitted.length,passed:admitted.filter(r=>r.score.pass).length,unsafe:admitted.filter(r=>r.score.unsafe).length}};
 fencedDiagnostics[key]=fenced;
}
const comparisons={};
const planIdConfusions={};
for(const [key,a] of Object.entries(arms)){
 planIdConfusions[key]=[];
 for(let i=0;i<a.rows.length;i++){
  const r=a.rows[i];if(r.score.pass||r.task!=='mechanism-stack'||r.value?.decision!=='accept'||r.value.templateIds?.length!==1)continue;
  const input=JSON.parse(cases[i].messages[1].content);
  const plan=input.allowedPlans.find(p=>p.id===r.value.templateIds[0]&&p.templateIds.length>1);
  if(plan){
   const hypothetical={...r.value,templateIds:plan.templateIds};
   if(score(cases[i],hypothetical).pass)planIdConfusions[key].push({id:r.id,planId:plan.id,templateIds:plan.templateIds});
  }
 }
}
for(const [key,a] of Object.entries(arms))if(a.complete&&key!=='27b-plain'){
 const b=arms['27b-plain']; if(!b?.complete)continue;
 comparisons[key+'-vs-27b-plain']={
  better:a.rows.filter((r,i)=>r.score.pass&&!b.rows[i].score.pass).map(r=>r.id),
  worse:a.rows.filter((r,i)=>!r.score.pass&&b.rows[i].score.pass).map(r=>r.id),
  newUnsafe:a.rows.filter((r,i)=>r.score.unsafe&&!b.rows[i].score.unsafe).map(r=>r.id)};
}
const stateFile=fs.existsSync(path.join(here,'resume-state.json'))?'resume-state.json':'state.json';
const state=fs.existsSync(path.join(here,stateFile))?read(path.join(here,stateFile)):null;
const analysis={arms,comparisons,planIdConfusions,fencedDiagnostics,goldFlags:flags,releaseQualified:false,state};
fs.writeFileSync(path.join(here,'analysis.json'),JSON.stringify(analysis,null,2)+'\n');
const lines=['# 9B／12B／27B 本機英雄與機制推論比較','',
 '只測文字分類／機制理解；沒有訓練、視覺驗證或特效參數生成。相同96題、相同messages和scorer；保留3題既有Gold疑義，敏感度排除相同ID。',
 'Qwen3.5-9B、Gemma 4 12B IT：本輪8-bit；27B：先前同批Qwen3.8 8-bit結果。跨架構／世代，不能當成參數量的單因子實驗。',
 'plain最大512 tokens；thinking最大4096 tokens；temperature=0。9B/12B使用原生enable_thinking，並非27B的medium effort等價設定。',
 '模式之間重設Metal峰值計數；27B舊結果未重設。Metal峰值不是整機記憶體；沒有16GB實機驗證。',
 '初次防護因9B連續截斷、12B連續Markdown停止，紀錄保留在initial-attempt/。確認非基礎設施故障後，僅接續未測題；上述已知錯誤仍扣分、不重試或放寬tokens，其餘資源保護不變。','',
 '| 模型模式 | 完成 | 正確 | 錯誤放行 | JSON／截斷錯誤 | 推論分鐘 | Metal峰值GiB |',
 '| --- | --- | ---: | ---: | ---: | ---: | ---: |'];
for(const [k,a] of Object.entries(arms))lines.push(`| ${k} | ${a.complete?'完整':'部分'} ${a.count}/96 | ${a.passed}/${a.count} | ${a.unsafe} | ${a.errors} | ${(a.generationSeconds/60).toFixed(2)} | ${a.peakMetalGiB.toFixed(2)} |`);
lines.push('','## 分項','','| 模型模式 | 任務 | 正確 | 錯誤放行 |','| --- | --- | ---: | ---: |');
for(const [k,a] of Object.entries(arms))for(const [t,v] of Object.entries(a.tasks))lines.push(`| ${k} | ${t} | ${v.passed}/${v.count} | ${v.unsafe} |`);
lines.push('','## 接受／拒絕與結構契約','','JSON可解析不代表ID與計畫合法；schemaErrors涵蓋非法模板ID與未允許的組合。錯誤放行包含接受了錯誤計畫，不只將應拒絕題接受。','',
 '| 模型模式 | 應接受18題 | 應拒絕18題 | 全部結構契約錯誤 |','| --- | ---: | ---: | ---: |');
for(const [k,a] of Object.entries(arms))if(a.complete)lines.push(`| ${k} | ${a.decisions['mechanism-stack:accept'].passed}/18 | ${a.decisions['mechanism-stack:refuse'].passed}/18 | ${a.schemaErrors} |`);
lines.push('','## 排除既有Gold疑義的敏感度（不取代主分數）','','| 模型模式 | 正確 | 錯誤放行 |','| --- | ---: | ---: |');
for(const [k,a] of Object.entries(arms))if(a.complete)lines.push(`| ${k} | ${a.sensitivity.passed}/${a.sensitivity.count} | ${a.sensitivity.unsafe} |`);
lines.push('','## 與27B不推理逐題對照','','| 候選 | 修正 | 退步 | 新增錯誤放行 |','| --- | ---: | ---: | ---: |');
for(const [k,c] of Object.entries(comparisons))lines.push(`| ${k} | ${c.better.length} | ${c.worse.length} | ${c.newUnsafe.length} |`);
lines.push('','## 計畫ID與模板ID混淆診斷','',
 '這是離線反事實診斷，不修改原始輸出、不修改主分數、不視為模型自己答對。若只把一個已知多卡planId展開為該計畫的templateIds即可通過，表示可能有可由API設計改善的序列化問題；不證明其他語意能力可靠。',
 '錯誤放行是scorer的錯誤accept分類，其中非法ID／未允許組合應由現行確定性契約阻擋，不等同已在遊戲執行了危險技能。','');
for(const [k,rs] of Object.entries(planIdConfusions))if(rs.length)lines.push(`- ${k}：${rs.length}題，${rs.map(r=>r.id).join('、')}。`);
lines.push('','## 僅移除外層Markdown的離線診斷（不是主成績）','',
 '對所有模型套用相同規則：必須已正常結束；只從最終答案移除完整單一外層JSON程式碼區塊，不從推理找答案、不改ID、不修JSON或語意。僅用以区分格式遵循與內容判斷，未部署這個修復。',
 '','| 模式 | 已觀察題數 | 解開外層區塊 | 診斷正確 | 診斷錯誤接受 |','| --- | ---: | ---: | ---: | ---: |');
for(const [k,d] of Object.entries(fencedDiagnostics))lines.push(`| ${k} | ${d.count}${d.complete?'':'（部分）'} | ${d.unwrapped} | ${d.passed}/${d.count} | ${d.unsafe} |`);
lines.push('','## 執行狀態','','```json',JSON.stringify(state,null,2),'```','',
 '既有題庫曾被助理覆核，不是独立Owner盲測。96題含36機制案例但只有34種不同需求文字。小樣本高分不代表正式全自動合格。',
 '安全限制：單GPU worker、接電、24GiB Metal上限、最低4GiB系統可用記憶體、swap增量不超過2GiB；不改系統wired limit、不終止他人程式。',
 '原始輸出與逐題分數保留於本目錄。模型權重在/private/tmp，可能被系統清理。','');
fs.writeFileSync(path.join(here,'REPORT.md'),lines.join('\n'));
console.log(JSON.stringify(Object.fromEntries(Object.entries(arms).map(([k,a])=>[k,{count:a.count,passed:a.passed,unsafe:a.unsafe,complete:a.complete}]))));
