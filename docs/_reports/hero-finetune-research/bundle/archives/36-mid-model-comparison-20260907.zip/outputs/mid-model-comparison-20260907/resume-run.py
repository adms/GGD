"""Finite local download-wait/evaluation supervisor; no scheduler, training or network inference."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
import psutil

HERE = Path(__file__).resolve().parent
LOCK = Path('/private/tmp/ggd-forge-training-runtime/gpu.lock')
GiB = 1024**3

def read(path):
    return json.loads(path.read_text())

def memory_gate(expected, available):
    return available >= expected + 6 * GiB

def report():
    subprocess.run(['/usr/local/bin/node', str(HERE / 'report.mjs')],
                   cwd=HERE, check=True, stdout=subprocess.DEVNULL, timeout=60)

def main():
    selected = ['12b', '9b']
    state = {'status': 'waiting-for-downloads', 'startedAt': time.time(),
             'selectedModels': selected,
             'pid': os.getpid(), 'models': {}, 'workerPid': None,
             'policy': {'training': False, 'cloud': False, 'concurrentGpuWorkers': 1,
                        'maxDownloadWaitHours': 4, 'minAvailableGiB': 4,
                        'maxSwapIncreaseGiB': 2, 'maxCaseSeconds': 250,
                        'maxWorkerMinutes': 100}}
    def save():
        tmp = HERE / 'resume-state.json.tmp'
        tmp.write_text(json.dumps(state, indent=2) + '\n')
        tmp.replace(HERE / 'resume-state.json')
    assert not (HERE / 'resume-state.json').exists(), 'REFUSE_RESTART'
    save()
    child = None
    lock_owned = False
    def stop_child():
        nonlocal child
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
        child = None
    def interrupted(signum, frame):
        raise InterruptedError('SUPERVISOR_INTERRUPTED')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        for name in selected:
            state.update(status='waiting-for-download', currentModel=name)
            save()
            while True:
                if (HERE / 'STOP').exists():
                    raise InterruptedError('USER_STOP')
                receipt_path = HERE / (name + '-download.json')
                d = read(receipt_path) if receipt_path.exists() else {'status': 'pending'}
                if d['status'] in ['verified', 'failed']:
                    break
                if time.time() - state['startedAt'] > 4 * 3600:
                    raise TimeoutError('DOWNLOAD_WAIT_EXPIRED')
                time.sleep(10)
            if d['status'] != 'verified':
                state['models'][name] = {'status': 'download-failed', 'error': d.get('error')}
                save()
                report()
                continue
            mem, swap = psutil.virtual_memory(), psutil.swap_memory()
            battery = psutil.sensors_battery()
            admission = {'availableGiB': mem.available / GiB, 'existingSwapGiB': swap.used / GiB,
                         'requiredAvailableGiB': (d['expectedBytes'] + 6 * GiB) / GiB,
                         'acPower': battery is not None and battery.power_plugged}
            if not memory_gate(d['expectedBytes'], mem.available) or not admission['acPower']:
                state['models'][name] = {'status': 'downloaded-test-blocked-resource', **admission}
                save()
                report()
                continue
            try:
                with LOCK.open('x') as stream:
                    json.dump({'pid': os.getpid(), 'task': str(HERE)}, stream)
                lock_owned = True
            except FileExistsError:
                state['models'][name] = {'status': 'downloaded-test-blocked-gpu-lock', **admission}
                save()
                report()
                continue
            state.update(status='evaluating', workerStartedAt=time.time())
            state['models'][name] = {'status': 'evaluating', **admission}
            with (HERE / (name + '-resume-evaluation.log')).open('x') as log:
                child = subprocess.Popen([sys.executable, str(HERE / 'evaluate.py'), name],
                    cwd=HERE, stdout=log, stderr=subprocess.STDOUT,
                    env={**os.environ, 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
                         'HF_HUB_DISABLE_TELEMETRY': '1', 'TOKENIZERS_PARALLELISM': 'false'})
                state['workerPid'] = child.pid
                save()
                violation = None
                minimum_available = mem.available
                peak_swap = swap.used
                while child.poll() is None:
                    time.sleep(2)
                    now = time.time()
                    current_mem, current_swap = psutil.virtual_memory(), psutil.swap_memory()
                    minimum_available = min(minimum_available, current_mem.available)
                    peak_swap = max(peak_swap, current_swap.used)
                    power = psutil.sensors_battery()
                    if (HERE / 'STOP').exists():
                        violation = 'USER_STOP'
                    elif current_mem.available < 4 * GiB:
                        violation = 'LOW_SYSTEM_MEMORY'
                    elif current_swap.used - swap.used > 2 * GiB:
                        violation = 'SWAP_INCREASE'
                    elif power is None or not power.power_plugged:
                        violation = 'AC_POWER_REQUIRED'
                    elif now - state['workerStartedAt'] > 100 * 60:
                        violation = 'WORKER_TIME_LIMIT'
                    progress = HERE / 'worker-progress.json'
                    own_progress = False
                    if progress.exists():
                        progress_data = read(progress)
                        own_progress = progress_data['pid'] == child.pid
                        if own_progress and now - progress_data['caseStartedAt'] > 250:
                            violation = 'CASE_TIME_LIMIT'
                    if not own_progress and now - state['workerStartedAt'] > 300:
                        violation = 'LOAD_TIME_LIMIT'
                    if violation:
                        stop_child()
                        break
                exit_code = child.returncode if child is not None else None
                state['models'][name].update(status='complete' if exit_code == 0 and not violation else 'stopped-or-failed',
                    exitCode=exit_code, safetyStop=violation, seconds=time.time()-state['workerStartedAt'],
                    minimumAvailableGiB=minimum_available/GiB, maximumSwapGiB=peak_swap/GiB)
            child = None
            if lock_owned and read(LOCK)['pid'] == os.getpid():
                LOCK.unlink()
                lock_owned = False
            state['workerPid'] = None
            save()
            report()
            if violation == 'USER_STOP':
                raise InterruptedError('USER_STOP')
        state['status'] = 'complete' if all(v['status'] == 'complete' for v in state['models'].values()) else 'finished-with-incomplete-tests'
    except BaseException as exc:
        state.update(status='stopped-or-failed', error=repr(exc))
    finally:
        stop_child()
        if lock_owned and LOCK.exists() and read(LOCK)['pid'] == os.getpid():
            LOCK.unlink()
        state.update(workerPid=None, endedAt=time.time())
        save()
        report()
        print(json.dumps(state), flush=True)

if __name__ == '__main__':
    main()
