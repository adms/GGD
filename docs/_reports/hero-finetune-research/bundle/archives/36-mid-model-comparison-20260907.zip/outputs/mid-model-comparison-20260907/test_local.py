import unittest
from evaluate import final_json

class Parsing(unittest.TestCase):
    def test_plain(self):
        for family in ['qwen','gemma']:
            self.assertEqual(final_json('{"decision":"refuse"}',False,family),{'decision':'refuse'})
    def test_qwen(self):
        self.assertEqual(final_json('some thought\n</think>\n{"x":1}',True),{'x':1})
    def test_gemma(self):
        self.assertEqual(final_json('<|channel>thought\nnot the answer\n<channel|>{"x":1}',True,'gemma'),{'x':1})
    def test_fail_closed(self):
        for family,text in [('qwen','{"x":1}'),('gemma','{"x":1}'),('gemma','<|channel>thought\n{"x":1}')]:
            with self.assertRaises(ValueError):final_json(text,True,family)
    def test_no_repair(self):
        for text in ['```json\n{"x":1}\n```','prefix {"x":1}','[]']:
            with self.assertRaises(ValueError):final_json(text,False)

if __name__=='__main__':unittest.main()
