# 英雄技能模型整合視覺化報告

主要交付：[report.html](report.html)。2026-09-08 整理，僅本機，沒有新增訓練、推論或發布。

涵蓋 2B／4B 早期 Thinking、4B R1–R8 LoRA、9B／12B／27B、量化與非 LLM 基線；13 章包括同題表現、正規化收益、泛化與拒絕邊界、成本、逐方案場景、改進及分階段實驗設計。歷史診斷與狀態清冊在報告末端可展開。

- `data.json`：機器可讀統計、108 列補充歷史診斷、157 份相關文檔清冊及直接讀入來源指紋。不是 157 次獨立實驗。
- `verification.json`：同 96 題的 9 臂（包含 3 個歷史 4B 臂）重評／摘要／原始結果核對；576 新世代歷史呼叫＋288 個歷史 4B 配對輸出，沒有重跑模型。
- `visual-verification.json`：360／736／1024 寬度的明暗主題、圖表邊界與摺疊區互動檢查。
- `report.template.html`、`build.mjs`：敘述與生成來源。無遠端依賴，成品可離線閱讀；原始證據連結需要工作區檔案仍存在。
- `inline-preview.html`：對話摘要圖的本機檢查載體，不是完整報告。

重建（只讀歷史收據，不啟動 GPU 模型）：

```sh
node outputs/model-research-integrated-20260908/build.mjs
```

## 關鍵界線

原生 JSON 成績與只去包裝的診斷分開。不同題集、generation wall time／worker wall time、BF16／8-bit、Metal／整機 RAM 不混算。R8未訓練、Flash取消；仍有1,072個主題組輸入未完成，不把其狀態填成成功。沒有正式發布合格模型。

報告與本機附件包含內部研究結果及工作區證據路徑，不因本次整理取得公開上傳授權。
