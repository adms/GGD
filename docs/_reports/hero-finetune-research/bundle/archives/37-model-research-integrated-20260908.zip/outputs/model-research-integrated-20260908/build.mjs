import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const out=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(out,'../..');
const pins=[];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function read(p){const b=fs.readFileSync(path.join(root,p));pins.push({path:p,sha256:sha(b),bytes:b.length});return JSON.parse(b);}
const midPath='outputs/mid-model-comparison-20260907',qPath='outputs/qwen38-local-comparison-20260907',fin='outputs/forge-final-three-hours-20260906';
const mid=read(`${midPath}/analysis.json`),historical=read(`${qPath}/historical-reference.json`),cases=read(`${qPath}/cases.private.json`);
const manifest=read(`${qPath}/manifest.json`);
for(const pin of manifest.scorerPins)assert.equal(sha(fs.readFileSync(path.join(root,pin.path))),pin.sha256,'Scorer changed: '+pin.path);
const {score}=await import(path.join(root,'GGD-hero-auto-forge/tools/forge-training/r6-score.mjs'));
const requestsA=fs.readFileSync(path.join(root,qPath,'requests.json')),requestsB=fs.readFileSync(path.join(root,midPath,'requests.json'));
assert.equal(sha(requestsA),sha(requestsB));assert.equal(cases.length,96);
const names={'base':'4B 基底','r3':'4B R3 LoRA','r7':'4B R7 LoRA','9b-plain':'9B 不推理','9b-thinking':'9B 推理','12b-plain':'12B 不推理','12b-thinking':'12B 推理','27b-plain':'27B 不推理','27b-thinking':'27B medium 推理'};
const models96=[];
function tally(rows){return {count:rows.length,passed:rows.filter(x=>x.score.pass).length,unsafe:rows.filter(x=>x.score.unsafe).length};}
function group(rows){const g={};for(const r of rows){const k=cases.find(c=>c.id===r.id).comparisonCohort;(g[k]??=[]).push(r);}return Object.fromEntries(Object.entries(g).map(([k,v])=>[k,tally(v)]));}
for(const [key,a] of Object.entries(historical.results)){
 assert.deepEqual(a.rows.map(x=>x.id),cases.map(x=>x.id));assert.equal(tally(a.rows).passed,a.passed);
 a.rows.forEach((r,i)=>{assert.equal(r.requestDigest,cases[i].requestDigest);assert.deepEqual(score(cases[i],r.value),r.score);});
 models96.push({key,label:names[key],family:'Qwen3.5-4B',precision:'BF16',historical:true,count:96,strict:a.passed,normalized:null,unsafe:a.unsafe,seconds:null,memory:null,cohorts:group(a.rows)});
}
const allRows={};
for(const [key,a] of Object.entries(mid.arms)){
 assert(a.complete);assert.equal(a.count,96);assert.deepEqual(a.rows.map(x=>x.id),cases.map(x=>x.id));assert.deepEqual(tally(a.rows),{count:96,passed:a.passed,unsafe:a.unsafe});
 const d=mid.fencedDiagnostics[key];assert.equal(tally(d.rows).passed,d.passed);assert.equal(tally(d.rows).unsafe,d.unsafe);
 const raw=read(`${key.startsWith('27')?qPath:midPath}/${key}-raw.json`);
 assert.equal(raw.results.length,96);assert.equal(raw.complete,true);
 raw.results.forEach((r,i)=>{assert.equal(r.id,cases[i].id);assert.equal(r.requestDigest,cases[i].requestDigest);assert.deepEqual(r.value,a.rows[i].value);assert.deepEqual(score(cases[i],r.value),a.rows[i].score);assert.deepEqual(score(cases[i],d.rows[i].value),d.rows[i].score);if(d.rows[i].unwrapped)assert.equal(r.finishReason,'stop');});
 const seconds=raw.results.reduce((s,r)=>s+r.seconds,0);assert(Math.abs(seconds-a.generationSeconds)<1e-6);
 allRows[key]=d.rows;
 models96.push({key,label:names[key],family:a.metadata.model,revision:a.metadata.revision,precision:'8-bit',historical:false,count:96,strict:a.passed,normalized:d.passed,unsafe:d.unsafe,rawUnsafe:a.unsafe,errors:a.errors,schemaErrors:a.schemaErrors,truncated:raw.results.filter(x=>x.finishReason!=='stop').length,unwrapped:d.unwrapped,seconds,memory:a.peakMetalGiB,cohorts:group(d.rows)});
}
function paired(a,b){assert.deepEqual(a.map(x=>x.id),b.map(x=>x.id));return{fixed:a.filter((x,i)=>!x.score.pass&&b[i].score.pass).length,regressed:a.filter((x,i)=>x.score.pass&&!b[i].score.pass).length};}
const old=read(`${fin}/inference-review-analysis-power-stop-v1/summary.json`),community=read('outputs/community37-inference-full-20260907-v1/analysis.json'),owner=read('outputs/forge-owner-remaining-inference-20260907-v1/analysis.json'),stack=read('outputs/forge-stack-full-inference-20260907-v1/analysis.json'),supp=read('outputs/forge-composition-supplement-inference-20260907-v1/analysis.json');
const cohortRows=[];
function add(label,stats,source,note=''){cohortRows.push({label,source,note,arms:Object.fromEntries(['base','r3','r7'].map(k=>[k,{total:stats[k].total,passed:stats[k].passed,unsafe:stats[k].unsafe}]))});}
for(const task of ['hero-source','owner-mechanism'])add(task==='hero-source'?'歷史英雄設定':'歷史技能原文・先完成',Object.fromEntries(['base','r3','r7'].map(k=>[k,old.scores[k].tasks[task]])),`${fin}/inference-review-analysis-power-stop-v1/REPORT.md`,'含已見來源及部分訓練輸入');
add('歷史技能原文・最後補完',owner.details,'outputs/forge-owner-remaining-inference-20260907-v1/REPORT.md','與前 606 題不重複；仍含已見來源');
add('新七角色',old.community.scores,`${fin}/SEVEN_HEROES_INFERENCE_FINDINGS.md`,'147 題已包含於前述歷史隊列，不可重複加總');
add('新 37 英雄',community.details,'outputs/community37-inference-full-20260907-v1/REPORT.md','555 題，未用於此次權重訓練；非 Owner 獨立 Gold');
add('完整機制計畫',stack.stats,'outputs/forge-stack-full-inference-20260907-v1/REPORT.md','296 輸入有 1 題撤回，295 題／158 種需求；39 題匹配 R7 訓練');
add('另列組合補充',supp.stats,'outputs/forge-composition-supplement-inference-20260907-v1/REPORT.md','20 題，獨立列示，不併入 295');
const ledger=read(`${fin}/experiment-ledger-inference-only-v1/ledger.json`);
const training=ledger.records.map(r=>({name:r.name,counts:r.counts,status:r.name==='R7'?'部分停止':r.stageStatus,minutes:r.training?.minutes??r.observedIncompleteMetrics?.sumExampleMinutes??null,memory:r.training?.peakMetalGiB??(r.observedIncompleteMetrics?.peakMetalBytes? r.observedIncompleteMetrics.peakMetalBytes/1024**3:null),timeScope:r.training?.timeScope??r.observedIncompleteMetrics?.timeScope??null,lr:r.training?.recipe?.learningRate??null,steps:r.training?.optimizerSteps??null,selected:r.selection?.step!=null?`step ${r.selection.step}`:r.selection?.epoch?`epoch ${r.selection.epoch}`:'未訓練',before:r.training?.beforeTrainProbeLoss??null,after:r.training?.afterTrainProbeLoss??null,note:r.note,candidates:r.selection?.candidates?.map(c=>({epoch:c.epoch,step:c.step,passed:c.score?.passed,total:c.score?.total,preservation:c.preservation?.pass??c.preservation??null}))??[]}));
const early=read('outputs/forge-thinking-benchmark-20260906/fourway-summary.json');
const earlyRows=Object.entries(early.profiles).map(([key,v])=>({key,passed:v.passed,total:v.total,strict:v.strictPassed,strictTotal:v.strictTotal,corePassed:['mechanics','policy','coverage'].reduce((s,k)=>s+v.byCategory[k].passed,0),coreTotal:36,mean:v.meanWallSeconds,p95:v.p95WallSeconds,schema:v.formatValid,categories:v.byCategory}));
const evidence7=read(`${fin}/r7-selected-paired-evidence-v2/summary.json`),evidence4=read('outputs/forge-source-calibration-r4-20260906/final-evidence-v1/summary.json'),evidence5=read('outputs/forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/final-evidence-v1/summary.json');
const diagnosticRows=[];
function diagnostics(round,entries,field,source){for(const e of entries){const arms=e[field]??{};for(const [arm,v]of Object.entries(arms)){if(v.total==null)continue;diagnosticRows.push({round,name:e.name,arm,total:v.total,passed:v.passed,unsafe:v.unsafe,source});}}}
diagnostics('R4 歷史',evidence4.post,'scores','outputs/forge-source-calibration-r4-20260906/final-evidence-v1/REPORT.md');
diagnostics('R5 回收',evidence5.postGroups,'scores','outputs/forge-contrastive-r5-20260906/recovered-checkpoint-eval-v1/final-evidence-v1/REPORT.md');
diagnostics('R7 後測',evidence7.reports,'models',`${fin}/r7-selected-paired-evidence-v2/REPORT.md`);
const classical=evidence7.reports.find(r=>r.name==='core-test').classical;
const coverage=read('outputs/forge-owner-remaining-inference-20260907-v1/main-coverage.json');
const inventory=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isSymbolicLink())continue;if(e.isDirectory()){if(!/node_modules|models|base|adapters|selected-adapter|research-adapter/.test(e.name))walk(p);}else if(/\.md$/i.test(e.name)&&/report|result|review|ledger|status|hold|superseded|cancel|stop|findings|warning|assessment|index/i.test(e.name)&&!/issue|feedback|EDITOR_JSON/i.test(e.name)){const b=fs.readFileSync(p);inventory.push({path:path.relative(root,p),title:b.toString().split('\n').find(x=>x.startsWith('#'))?.replace(/^#+\s*/,'')??e.name,sha256:sha(b)});}}}
for(const e of fs.readdirSync(path.join(root,'outputs'),{withFileTypes:true}))if(e.isDirectory()&&/^(forge-|community37-|qwen38-local|mid-model)/.test(e.name))walk(path.join(root,'outputs',e.name));
inventory.sort((a,b)=>a.path.localeCompare(b.path));
const precision=[{label:'R2 native BF16＋LoRA',dev:31,test:61,unsafe:0},{label:'R2 融合 BF16',dev:31,test:null,unsafe:null},{label:'R2 4-bit group64',dev:22,test:44,unsafe:22},{label:'R2 8-bit group64',dev:31,test:60,unsafe:1}];
const data={schema:'hero-model-research-synthesis@1',date:'2026-09-08',newTrainingCalls:0,newInferenceCalls:0,releaseQualified:false,models96,cohortRows,training,earlyRows,diagnosticRows,classical,precision,stackDecisions:stack.decisionGroups,stackStats:stack.stats,coverage:Object.fromEntries(Object.entries(coverage).filter(([k])=>k!=='remaining')),paired12vs27:paired(allRows['27b-plain'],allRows['12b-plain']),zero18Upper95:1-Math.pow(.05,1/18),zeroFailuresRequiredForOnePercent:Math.ceil(Math.log(.05)/Math.log(.99)),inventory,pins};
assert.deepEqual(models96.map(x=>x.strict),[78,78,83,81,78,60,42,91,91]);
assert.deepEqual(models96.slice(3).map(x=>x.normalized),[81,78,92,91,91,91]);
assert.deepEqual(cohortRows.find(x=>x.label==='完整機制計畫').arms.r7,{total:295,passed:212,unsafe:76});
assert.equal(earlyRows.find(x=>x.key==='4B').corePassed,31);assert.equal(earlyRows.find(x=>x.key==='4B Re').corePassed,32);
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,d=2)=>v==null?'—':Number(v).toFixed(d),pct=(a,n)=>num(a/n*100)+'%';
const link=(p,label)=>`<a href="${esc(path.resolve(root,p))}">${esc(label)}</a>`;
function table(head,rows){return `<div class="table-wrap"><table><thead><tr>${head.map(x=>`<th scope="col">${x}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
function bars(label,rows,max,unit){return `<figure class="bar-chart"><figcaption>${esc(label)}</figcaption><div class="bar-axis"><span>0${unit}</span><span>${max}${unit}</span></div>${rows.map(r=>`<div class="bar-row"><span class="bar-name">${esc(r.label)}</span><div class="bar-track"><span class="bar ${r.tone??''}" style="width:${100*r.value/max}%"></span>${r.extra!=null?`<span class="bar gain" style="left:${100*r.value/max}%;width:${100*(r.extra-r.value)/max}%"></span>`:''}</div><span class="bar-value">${esc(r.text??num(r.value))}</span></div>`).join('')}</figure>`;}
const slots={};
slots.TABLE96=table(['模型／模式','精度／來源','原生嚴格','僅去包裝診斷','錯誤接受†','生成分鐘','Metal GiB'],models96.map(x=>[esc(x.label),x.precision+(x.historical?'・歷史回放':''),`${x.strict}/96<br><small>${pct(x.strict,96)}</small>`,x.normalized==null?'未另重評':`${x.normalized}/96<br><small>${pct(x.normalized,96)}</small>`,String(x.unsafe),num(x.seconds==null?null:x.seconds/60),num(x.memory)]));
slots.BARS96=bars('同 96 題｜原生通過＋僅包裝恢復的額外通過',models96.map(x=>({label:x.label,value:x.strict,extra:x.normalized??x.strict,text:`${x.strict}${x.normalized>x.strict?' → '+x.normalized:''}/96`,tone:x.historical?'historical':''})),96,'題');
slots.COST=bars('相同 96 題｜逐題生成合計（不含載入）',models96.filter(x=>!x.historical).map(x=>({label:x.label,value:x.seconds/60,text:num(x.seconds/60)+' 分'})),70,'分鐘');
slots.MEMORY=bars('Metal 峰值｜不是整機 RAM；27B 為累積計數',models96.filter(x=>!x.historical).map(x=>({label:x.label,value:x.memory,text:num(x.memory)+' GiB'})),32,'GiB');
slots.COHORT96=table(['模型','英雄設定 /24','歷史原文 /18','新英雄原文 /18','機制計畫 /36'],models96.map(x=>[esc(x.label),...['hero-source','owner-historical','owner-community37','mechanism-stack'].map(k=>`${x.cohorts[k].passed}`)]));
slots.FT=table(['相同題組','4B 基底','R3','R7','解讀界線'],cohortRows.map(x=>[link(x.source,x.label),...['base','r3','r7'].map(k=>`${x.arms[k].passed}/${x.arms[k].total}<br><small>${pct(x.arms[k].passed,x.arms[k].total)}・誤放 ${x.arms[k].unsafe}</small>`),esc(x.note)]));
slots.FTCHART=cohortRows.filter(x=>['歷史英雄設定','新 37 英雄','完整機制計畫'].includes(x.label)).map(x=>bars(x.label+'｜正確率',Object.entries(x.arms).map(([k,v])=>({label:names[k],value:v.passed/v.total*100,text:`${num(v.passed/v.total*100,1)}%`,tone:k==='base'?'historical':''})),100,'%')).join('');
slots.DECISIONS=stack.decisionGroups.map(g=>bars(g.expectedDecision==='accept'?'可完成需求：正確推薦 /147':'應拒絕需求：正確拒絕 /148',Object.entries(g.stats).map(([k,v])=>({label:names[k],value:v.passed/v.total*100,text:`${v.passed}/${v.total}`,tone:k==='base'?'historical':''})),100,'%')).join('');
slots.UNSAFE=bars('295 題｜錯誤接受（愈低愈好）',Object.entries(stack.stats).map(([k,v])=>({label:names[k],value:v.unsafe,text:`${v.unsafe}（其中合法但錯 ${v.legalButWrongAccepts}）`,tone:'risk'})),120,'題');
slots.TRAIN=table(['輪次','train / dev / test','初始化／選中','訓練分鐘','Metal GiB','結果'],training.map(x=>[x.name,`${x.counts.train}/${x.counts.dev}/${x.counts.test}`,`${Number(x.name.slice(1))<=4?'base':x.name==='R8'?'未啟動':'R3'}<br>${x.selected}`,num(x.minutes)+(x.name==='R5'?'*':''),num(x.memory),esc(x.note)]));
slots.TRAINCOST=bars('R1–R7 已記錄訓練成本｜R5* 僅逐例計時',training.filter(x=>x.minutes!=null).map(x=>({label:x.name+(x.name==='R5'?'*':''),value:x.minutes,text:num(x.minutes,1)+' 分'})),140,'分鐘');
slots.CONVERGENCE=training.filter(x=>['R3','R4','R6','R7'].includes(x.name)).map(x=>bars(x.name+`｜同輪 dev（${x.counts.dev} 題；不可跨輪當成收斂曲線）`,[...x.candidates].sort((a,b)=>(a.epoch??a.step)-(b.epoch??b.step)).map(c=>({label:c.epoch?'epoch '+c.epoch:'step '+c.step,value:c.passed/c.total*100,text:`${c.passed}/${c.total}${c.preservation===false?'・未保留':''}`})),100,'%')).join('');
slots.EARLY=table(['早期模式','原嚴格 /48','排歧義 /46','不含 VFX /36*','平均／P95 全請求秒'],earlyRows.map(x=>[x.key,String(x.strict),String(x.passed),String(x.corePassed),`${num(x.mean)} / ${num(x.p95)}`]));
slots.PRECISION=table(['R2 同權重精度','dev 機制 /34','test 機制 /68','test 錯誤接受'],precision.map(x=>[x.label,String(x.dev),x.test==null?'未測':String(x.test),x.unsafe==null?'未測':String(x.unsafe)]));
slots.DIAGNOSTICS=table(['歷史階段','題組（不要跨列加總）','模型臂','正確／題數','錯誤接受'],diagnosticRows.map(x=>[x.round,link(x.source,x.name),x.arm,`${x.passed}/${x.total}`,String(x.unsafe)]));
slots.CLASSICAL=table(['同 186 題子任務','最近例 TF-IDF','公開目錄法','4B 基底','R3','R7'],['hero-source','owner-mechanism','mechanism-template','mechanism-stack'].map(task=>[task,...['nearest-accuracy','catalog-accuracy'].map(k=>{const t=classical[k]?.tasks?.[task];return t?`${t.passed}/${t.total}・誤放 ${t.unsafe}`:'不適用／未測';}),...['base','r3','selected'].map(k=>{const t=evidence7.reports.find(r=>r.name==='core-test').models[k].tasks[task];return`${t.passed}/${t.total}・誤放 ${t.unsafe}`;})]));
slots.INVENTORY=`<p>${inventory.length} 份歷史報告／審查／狀態入口；包含失敗、停止、被取代及較早快照。此清冊是追溯索引，不是 ${inventory.length} 個獨立實驗，也不表示本輪重新逐篇審定全部內容。</p>`+table(['文件','原標題'],inventory.map(x=>[link(x.path,x.path.replace('outputs/','')),esc(x.title)]));
slots.PINS=table(['實際讀入的機器收據','SHA-256'],pins.map(p=>[link(p.path,p.path.replace('outputs/','')),`<code>${p.sha256}</code>`]));
slots.PAIR12=`修正 ${data.paired12vs27.fixed} 題、退步 ${data.paired12vs27.regressed} 題`;
slots.UPPER18=num(data.zero18Upper95*100,1);
const template=fs.readFileSync(path.join(out,'report.template.html'),'utf8');
let html=template.replace(/\{\{([A-Z0-9]+)\}\}/g,(_,k)=>{assert(k in slots,'missing slot '+k);return slots[k];});
assert(!/\{\{[A-Z0-9]+\}\}/.test(html));
fs.writeFileSync(path.join(out,'report.html'),html);
fs.writeFileSync(path.join(out,'data.json'),JSON.stringify(data,null,2)+'\n');
fs.writeFileSync(path.join(out,'verification.json'),JSON.stringify({schema:'research-report-verification@1',date:'2026-09-08',newTrainingCalls:0,newInferenceCalls:0,requestDigestsEqual:true,models96:models96.length,rawModelArmsChecked:6,rawCallsChecked:576,historical4BRowsChecked:288,all96ArmsRescoredWithPinnedScorer:true,sourcePins:pins,assertionsPassed:true,htmlSha256:sha(html),releaseQualified:false},null,2)+'\n');
console.log(JSON.stringify({report:path.join(out,'report.html'),models:models96.length,diagnosticRows:diagnosticRows.length,inventory:inventory.length,assertions:'passed',paired12vs27:data.paired12vs27}));
