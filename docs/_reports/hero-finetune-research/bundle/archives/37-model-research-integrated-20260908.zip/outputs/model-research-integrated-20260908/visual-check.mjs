import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {chromium}=require('/Users/Takuro/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const dir=path.dirname(fileURLToPath(import.meta.url));
const browser=await chromium.launch({headless:true,channel:'chrome'});
const results=[];
for(const width of [360,736,1024])for(const colorScheme of ['light','dark']){
 const page=await browser.newPage({viewport:{width,height:950},colorScheme,deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(pathToFileURL(path.join(dir,'report.html')).href);
 const metrics=await page.evaluate(()=>({title:document.title,sections:document.querySelectorAll('main>section').length,bars:document.querySelectorAll('.bar').length,bodyWidth:document.body.scrollWidth,viewport:innerWidth,unresolved:document.body.innerText.includes('{{'),clippedBars:[...document.querySelectorAll('.bar-chart')].filter(x=>x.scrollWidth>x.clientWidth+1).length}));
 await page.locator('#comparison').screenshot({path:path.join(dir,`comparison-${width}-${colorScheme}.png`)});
 if(width===1024&&colorScheme==='light')await page.locator('#finetune').screenshot({path:path.join(dir,'finetune-1024-light.png')});
 const detail=page.locator('details').first();await detail.locator('summary').click();
 const expanded=await detail.evaluate(x=>x.open);await detail.locator('summary').click();
 results.push({width,colorScheme,...metrics,errors,detailInteractionPassed:expanded});
 await page.close();
}
await browser.close();
fs.writeFileSync(path.join(dir,'visual-verification.json'),JSON.stringify(results,null,2)+'\n');
if(results.some(x=>x.errors.length||x.unresolved||x.clippedBars||x.bodyWidth>x.viewport||!x.detailInteractionPassed))throw Error('Visual checks failed');
console.log(JSON.stringify(results));
