import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {chromium}=require('/Users/Takuro/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const dir=path.dirname(fileURLToPath(import.meta.url));
const browser=await chromium.launch({headless:true,channel:'chrome'});
const results=[];
try{
for(const width of [360,736])for(const colorScheme of ['light','dark']){
 const page=await browser.newPage({viewport:{width,height:1050},colorScheme});
 await page.goto(pathToFileURL(path.join(dir,'inline-preview.html')).href);
 const frame=page.frameLocator('iframe');await frame.locator('#hero-model-study').waitFor();
 const metrics=await frame.locator('#hero-model-study').evaluate(el=>({width:el.clientWidth,scroll:el.scrollWidth,rows:el.querySelectorAll('.hm-row').length,bars:[...el.querySelectorAll('.hm-fill,.hm-extra')].map(b=>({color:getComputedStyle(b).backgroundColor,width:b.getBoundingClientRect().width}))}));
 await frame.locator('#hero-model-study').screenshot({path:path.join(dir,`inline-${width}-${colorScheme}.png`)});
 results.push({width,colorScheme,...metrics});await page.close();
}
}finally{await browser.close();}
fs.writeFileSync(path.join(dir,'inline-verification.json'),JSON.stringify(results,null,2)+'\n');
if(results.some(x=>x.scroll>x.width||x.rows!==9||x.bars.some(b=>b.width<=0||b.color==='rgba(0, 0, 0, 0)')))throw Error('Inline check failed');
console.log(JSON.stringify(results));
