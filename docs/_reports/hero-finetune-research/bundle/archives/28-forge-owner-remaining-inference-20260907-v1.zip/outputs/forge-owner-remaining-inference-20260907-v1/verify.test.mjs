import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {compare} from '../../GGD-hero-auto-forge/tools/forge-training/r6-score.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const cases=read('cases.private.json'),requests=read('requests.json'),raw=read('base-raw.json');
test('373 frozen source inputs, targets not included in request objects',()=>{
 assert.equal(cases.length,373);assert.equal(requests.length,373);
 assert.deepEqual(requests,cases.map(({id,messages,requestDigest})=>({id,messages,requestDigest})));
 assert(requests.every(r=>r.messages.length===2&&r.messages.every(m=>m.role!=='assistant')));
 assert(read('mapping.private.json').every(m=>m.scoringQualified));
});
test('scorer accepts aligned control fixture and rejects mismatched IDs/digests/seeds',()=>{
 const run=b=>compare(cases,[{name:'control',raw},{name:'fixture',raw:b}]);
 assert.doesNotThrow(()=>run(structuredClone(raw)));
 for(const key of ['id','requestDigest','seed']){const b=structuredClone(raw);b.results[0][key]=key==='seed'?123:'corrupted';assert.throws(()=>run(b));}
});
test('completed raw replay matches serialized report, including omitted undefined reason',()=>{
 const arms=['base','r3','r7'].map(name=>({name,raw:read(name+'-raw.json')}));
 const replay=JSON.parse(JSON.stringify(compare(cases,arms)));
 assert.deepEqual(replay,read('comparison.json'));
});
