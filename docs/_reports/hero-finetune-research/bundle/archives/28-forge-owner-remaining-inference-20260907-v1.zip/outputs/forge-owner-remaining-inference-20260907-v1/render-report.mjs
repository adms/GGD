import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const a=read('analysis.json'),coverage=read('main-coverage.json'),names=['base','r3','r7'];
assert.equal(a.questions,373);assert.equal(a.errorUnion,a.reviewedErrors);assert.equal(coverage.totalRawPaired,1623);
const lines=['# 尚缺 373 題 Owner 機制原文判讀：推論與覆核','',
 '僅推論現有 4B 不推理基底及 R3／R7 adapter，沒有再訓練、量化、部署或更改原標籤。從旧主隊列的缺測 ID 精確選出全部 373 題 owner-mechanism；輸入、答案、原訓練暴露 metadata 與來源 pins 均保留。這不是新 37 名英雄資料，也不是當前引擎機制驗收。',
 '', '## 本次相同輸入的配對結果','',
 '| 模型 | 正確 | 正確率 | 錯誤放行 | 格式合法 |','| --- | ---: | ---: | ---: | ---: |',
 ...names.map(n=>{const s=a.details[n];return `| ${n} | ${s.passed}/${s.total} | ${s.pct.toFixed(2)}% | ${s.unsafe} | ${s.schema}/${s.total} |`;}),
 '', '錯誤放行指來源不支持的命題被說成 supported；contradicted 與 not-stated 的混淆也算錯，但不混為錯誤放行。數值、對象、條件、否定和時序都按提供的完整來源判讀。',
 '', '## 配對收益與退步',''];
for(const c of a.comparisons){const s=c.byTask['owner-mechanism'];lines.push(`- ${c.before} → ${c.after}：修正 ${s.fixed}、退步 ${s.regressed}、共同正確 ${s.bothCorrect}、共同錯誤 ${s.bothWrong}。`);}
lines.push('', '## 混淆矩陣與來源完整性','',
 '以下整組通過只表示同份完整原文在本次收錄的命題均答對，不表示涵蓋了整招所有要求；按完整來源文字雜湊分組，未跨版本或語意改寫合併。');
for(const n of names){const s=a.details[n];lines.push('',`### ${n}`,'','| 原答案 | 判 supported | 判 contradicted | 判 not-stated | 非法格式 |','| --- | ---: | ---: | ---: | ---: |',
 ...Object.entries(s.confusion).map(([k,v])=>`| ${k} | ${v.supported} | ${v.contradicted} | ${v['not-stated']} | ${v.invalid} |`),
 '',`來源組全對 ${s.sourceGroups.allProvidedClaimsCorrect}/${s.sourceGroups.total}；至少一次錯誤放行 ${s.sourceGroups.anyUnsafe} 組。`);}
lines.push('', '## 合成診斷與其餘來源','', '54 題的來源 ID 明示 synthetic-，另 319 題為其餘釘選來源；這只是 ID 分層，不代表後者全部已經 Owner 人工驗證。','', '| 模型 | 來源分層 | 正確 | 錯誤放行 |','| --- | --- | ---: | ---: |');
for(const n of names)for(const s of a.details[n].sourceKind)lines.push(`| ${n} | ${s.label} | ${s.passed}/${s.total} | ${s.unsafe} |`);
lines.push('', '## 訓練暴露分層','', '完整輸入未匹配不代表來源、語意或機制家族未見；此資料集混合歷史來源與人工診斷，不能統称新英雄或獨立測試。');
for(const model of ['r3','r7']){lines.push('',`### 按 ${model} 訓練輸入匹配分層`,'','| 對照模型 | 完整輸入匹配 | 正確 | 錯誤放行 |','| --- | --- | ---: | ---: |');for(const n of names)for(const s of a.details[n].exposure[model])lines.push(`| ${n} | ${s.exactTrainingInputSeen?'是':'否'} | ${s.passed}/${s.total} | ${s.unsafe} |`);}
lines.push('', '## 原答案歧義與敏感度','',
 'inference-review-01206：表頭 0 秒冷卻是否排除事件內置冷卻，原文本身沒有區分。原 Gold 為 not-stated；contradicted 也有可辯解的解讀。這不是確認的模型錯誤，不改本輪凍結標籤，不作新增訓練正例，待來源或標註政策確認。',
 '', '下表只是事後排除歧義題的敏感度，不替換上方預先固定的 373 題成績，也不是獨立 Gold：',
 '', '| 模型 | 排除歧義後正確 | 錯誤放行 |','| --- | ---: | ---: |',
 ...names.map(n=>{const s=a.sensitivityExcludingFlagged[n];return `| ${n} | ${s.passed}/${s.total} | ${s.unsafe} |`;}));
lines.push('', '## 逐題覆核與資料界線','',
 `失敗聯集 ${a.errorUnion} 題，已逐題回讀原文與 claim 並留下助理覆核理由，詳見 error-review.json／review-notes.json；全部 ${a.questions} 題與三模型輸出見 case-review.json。不是獨立人類 Owner Gold，不把輸出當教師答案，不暗改已凍結標籤。`,
 '', '疑似 Gold 歧義須另列，不以好看的總分消除。只判讀本份鎖定來源，不引入外部作品記憶，也不拿模型錯答當 main 產品 bug。',
 '', '## 實際運算與可重現性','',
 `- 373 × 3 = 1119 次推論，worker 合計 ${a.workerSeconds.toFixed(2)} 秒（${(a.workerSeconds/60).toFixed(2)} 分鐘），另有模型檔案校驗。`,
 ...names.map(n=>`- ${n}：${a.details[n].seconds.toFixed(2)} 秒，Metal 峰值 ${a.details[n].peakGiB.toFixed(2)} GiB；輸出錯誤 ${a.details[n].outputErrors}、非 stop 結束 ${a.details[n].nonStopFinish}。`),
 '- Metal 不是整機記憶體或耗電量；只在此 M5 Max 實測，不代表 16GB MacBook 已驗收。',
 '- CPU tokenizer 全 373 題 348–555 tokens，加 256 輸出預留皆適合 4096 上限；無輸入截斷、無輸出修補。',
 '- 相同基底、版本、逐題種子、順序及輸入；thinking=false，temperature=0，presence penalty=0；逐模型執行、12 GiB 上限、15 分鐘硬截止。',
 '- 新 run 按局部索引生成種子，並非承接舊 run 的全域索引；本輪三臂完全配對，但不將跨 run 差异稱單因素訓練效應。',
 '- 前後模型雜湊一致，worker 與父程序已終止、GPU lock 釋放，訓練呼叫 0。',
 '- 原始輸出經既有 scorer 重播一致；原舊 run failed／CANCEL 保留，没有重新啟動控制器。',
 '', '## 最新主隊列覆蓋','',
 '舊 954 題＋機制計畫 296 題＋本輪 Owner 373 題，合計 1623/2695 輸入有三模型配對；其中 1622 題准予計分，因機制計畫有 1 題事前撤回。尚缺 1072 題（單模板 700、VFX 372）。逐 ID 缺測清單見 main-coverage.json。',
 '', '這裡只合併執行覆蓋，不計算跨任務總準確率，來源、機制與視覺優先度仍分開。新 37 英雄 555 題及補充 20 題不混入主隊列分母；沒有達成全範圍品質門檻，不部署、不恢復訓練。','');
fs.writeFileSync(path.join(dir,'REPORT.md'),lines.join('\n'));
const files=['run.mjs','analyze.mjs','render-report.mjs','review-notes.json','gold-review-flags.json','analysis.json','case-review.json','error-review.json','main-coverage.json','REPORT.md'];
const pins=files.map(name=>({name,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,name))).digest('hex')}));
fs.writeFileSync(path.join(dir,'REPORT_VALIDATION.json'),JSON.stringify({createdAt:new Date().toISOString(),count:373,allErrorCasesReviewed:true,comparisonReplayed:true,releaseQualified:false,pins},null,2)+'\n');
console.log(JSON.stringify({report:path.join(dir,'REPORT.md'),reviewed:a.reviewedErrors}));
