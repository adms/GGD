import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {compare,score} from '../../GGD-hero-auto-forge/tools/forge-training/r6-score.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
const put=(n,v)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(v,null,2)+'\n');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const cases=read('cases.private.json'),mapping=read('mapping.private.json'),names=['base','r3','r7'];
assert.equal(cases.length,373);assert(mapping.every(m=>m.scoringQualified));
const notes=fs.existsSync(path.join(dir,'review-notes.json'))?read('review-notes.json'):{};
const mode=process.argv[2];assert(['snapshot','report'].includes(mode));
if(mode==='snapshot'){
 const errors=new Map();
 for(const name of names){
  const file=[name+'-raw.json',name+'-raw.json.partial'].find(n=>fs.existsSync(path.join(dir,n)));if(!file)continue;
  const raw=read(file);let passed=0,unsafe=0;
  raw.results.forEach((r,i)=>{const c=cases[i];assert.equal(r.id,c.id);assert.equal(r.requestDigest,c.requestDigest);const s=score(c,r.value);passed+=Number(s.pass);unsafe+=Number(s.unsafe);
   if(!s.pass){const input=JSON.parse(c.messages[1].content),e=errors.get(c.id)??{id:c.id,source:input.source,claim:input.claim,gold:c.target.verdict,wrong:{}};e.wrong[name]=r.value;errors.set(c.id,e);}
  });
  console.log(JSON.stringify({model:name,complete:raw.complete??false,count:raw.results.length,passed,unsafe}));
 }
 for(const e of errors.values())if(!process.argv.includes('--new-only')||!notes[e.id])console.log(JSON.stringify(e));
}else{
 const summary=read('summary.json');assert.equal(summary.status,'complete');assert.equal(summary.completedCalls,1119);assert.equal(summary.trainingCalls,0);assert.equal(summary.workerPid,null);assert(summary.lockReleased);
 const arms=names.map(name=>({name,raw:read(name+'-raw.json')})),r=compare(cases,arms);assert.deepEqual(JSON.parse(JSON.stringify(r)),read('comparison.json'));
 const labels=['supported','contradicted','not-stated'],details={};
 for(const {name,raw} of arms){
  const s=r.scores[name],confusion=Object.fromEntries(labels.map(l=>[l,Object.fromEntries([...labels,'invalid'].map(k=>[k,0]))]));
  const sources=new Map();
  raw.results.forEach((out,i)=>{const c=cases[i],sc=s.rows[i],input=JSON.parse(c.messages[1].content);confusion[c.target.verdict][sc.schema?out.value.verdict:'invalid']++;
   const key=sha(input.source.text),g=sources.get(key)??{sourceIds:[],questions:0,correct:0,unsafe:0};g.sourceIds=[...new Set([...g.sourceIds,input.source.id])];g.questions++;g.correct+=Number(sc.pass);g.unsafe+=Number(sc.unsafe);sources.set(key,g);
  });
  const exposure=Object.fromEntries(['r3','r7'].map(model=>[model,[true,false].map(seen=>{const selected=mapping.map((m,i)=>({m,i})).filter(({m})=>m.exposure[model].exactTrainingInputSeen===seen);return {exactTrainingInputSeen:seen,total:selected.length,passed:selected.filter(({i})=>s.rows[i].pass).length,unsafe:selected.filter(({i})=>s.rows[i].unsafe).length};})]));
  const sourceKind=[true,false].map(synthetic=>{const selected=cases.map((c,i)=>({c,i})).filter(({c})=>JSON.parse(c.messages[1].content).source.id.startsWith('synthetic-')===synthetic);return{label:synthetic?'explicit-synthetic-id':'other-pinned-source',total:selected.length,passed:selected.filter(({i})=>s.rows[i].pass).length,unsafe:selected.filter(({i})=>s.rows[i].unsafe).length};});
  details[name]={total:s.total,passed:s.passed,pct:100*s.passed/s.total,unsafe:s.unsafe,schema:s.rows.filter(x=>x.schema).length,confusion,exposure,sourceKind,
   sourceGroups:{total:sources.size,allProvidedClaimsCorrect:[...sources.values()].filter(g=>g.correct===g.questions).length,anyUnsafe:[...sources.values()].filter(g=>g.unsafe).length},sourceDetails:[...sources.entries()].map(([textSha256,g])=>({textSha256,...g})),
   outputErrors:raw.results.filter(x=>x.error).length,nonStopFinish:raw.results.filter(x=>x.finish!=='stop').length,...summary.arms.find(a=>a.name===name)};
 }
 const errors=r.rows.filter(row=>names.some(n=>!row.outputs[n].score.pass)).map(row=>({...row,postInferenceReview:notes[row.id]??null,goldChanged:false,independentHumanReview:false}));
 for(const id of Object.keys(notes))assert(errors.some(e=>e.id===id),'NOTE_FOR_NON_ERROR:'+id);
 const flags=read('gold-review-flags.json');for(const id of Object.keys(flags))assert(cases.some(c=>c.id===id));
 const sensitivity=Object.fromEntries(names.map(n=>{const rows=r.scores[n].rows.filter(x=>!flags[x.id]);return[n,{total:rows.length,passed:rows.filter(x=>x.pass).length,unsafe:rows.filter(x=>x.unsafe).length}];}));
 const analysis={createdAt:new Date().toISOString(),questions:373,details,comparisons:r.comparisons,errorUnion:errors.length,reviewedErrors:errors.filter(e=>e.postInferenceReview).length,goldReviewFlags:flags,sensitivityExcludingFlagged:sensitivity,workerSeconds:summary.arms.reduce((n,a)=>n+a.seconds,0),releaseQualified:false,trainingExecuted:false,scope:'Remaining frozen historical owner-source entailment; not independent Owner Gold, current main runtime, or complete hero coverage'};
 put('analysis.json',analysis);put('error-review.json',errors);put('case-review.json',r.rows);
 const old=JSON.parse(fs.readFileSync(path.resolve(dir,'../forge-final-three-hours-20260906/inference-review-analysis-power-stop-v1/summary.json')));
 const stack=JSON.parse(fs.readFileSync(path.resolve(dir,'../forge-stack-full-inference-20260907-v1/main-coverage.json')));
 const remainingBefore=new Set(stack.remaining.map(x=>x.id));assert(cases.every(c=>remainingBefore.has(c.id)));
 const now=new Set(cases.map(c=>c.id)),remaining=stack.remaining.filter(x=>!now.has(x.id));assert.equal(remaining.length,1072);
 put('main-coverage.json',{createdAt:new Date().toISOString(),planned:2695,oldPaired:old.pairedRequests,stackRawPaired:296,newOwnerRawPaired:373,totalRawPaired:1623,totalScoreAdmitted:1622,remainingRaw:1072,remainingByTask:Object.fromEntries([...new Set(remaining.map(x=>x.task))].map(t=>[t,remaining.filter(x=>x.task===t).length])),remaining,oldRunUnchanged:true,aggregateQualityScoreNotComputed:true,releaseQualified:false});
 console.log(JSON.stringify({...analysis,details:Object.fromEntries(names.map(n=>[n,{...details[n],sourceDetails:undefined}]))},null,2));
}
