# 真實來源／配置候選盤點

Owner 來源 90 筆；找到同 ID 配置 90 筆。全文完全相同 10；僅括號／空白差異 13；其他全文差異 67；無配置說明 0。台詞分離錯誤 0。

這是既有來源 module 的合併解析視圖；保留原始 module／TSV byte hash、完整解析後 Owner 字串、配置原物件及 hash。不改任何來源、台詞或 JSON。
全文差異是待審信號，不自動等同機制衝突；即使全文完全相同，也不表示執行配置已經符合需求。cosmetic 分類只忽略方括號字元及空白，保留括號內所有文字。

## 為什麼仍不是 Gold

同 ID 配置與 provenance 宣告不構成受信任的人類核可。此盤點沒有取得綁定原文、配置、獨立 expectation 的核可 registry；verifiedGold 0 只指此盤點可驗證的數量，不宣稱其他地方不存在核可紀錄。
這些 production ability JSON 也不是目前六欄位 ground-nova IR，不能直接送入既有微調 worker。必須擴充任務契約／驗證器或提供對應核可的研究 IR，不得把完整技能降格改寫成原地震波。

[逐筆原文、配置與待審原因](candidates.private.json) · [來源 hash 與統計](inventory.json)
