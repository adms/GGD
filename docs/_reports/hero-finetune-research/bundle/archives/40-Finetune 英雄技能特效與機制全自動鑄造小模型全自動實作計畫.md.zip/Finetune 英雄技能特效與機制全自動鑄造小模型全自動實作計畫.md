# Finetune 英雄技能特效與機制全自動鑄造小模型全自動實作計畫

本輪最新進度（2026-09-08）：兩位IR4基底GPU推論完成，JSON2/2、契約及編譯0/2；98.40秒、Metal峰值12.774GiB，接電100%、新增swap0，worker已退出。人工配方58/58來源與4/4冷卻政策通過，另34項schema／訓練遮罩檢查完成。新證據要求先分開「必須吟唱」與「未知秒數」，不能直接把研究數值遮罩後入訓；完整六槽SFT新准入與全自動核准仍0。本機GPU授權有效，後續補完整來源對照再做base／LoRA。詳見 [最新基底與遮罩報告](outputs/hero-forge-12b-restart-20260908/IR4_MASK_AND_BASELINE_REPORT.md)。歷史模型成績不回改、不與不同cohort混算。

前次24步本機LoRA的原文判讀71/96→90/96、嚴格判讀契約10/16→13/16仍成立，但完整英雄編譯2/4→2/4、李星負向探針0/3→0/3，adapter僅研究保存。訓練29.96秒，含後測341.31秒；這些收益不能換稱完整英雄成功率。詳見 [LoRA配對報告](outputs/hero-forge-12b-restart-20260908/LORA_FACT_PILOT_REPORT.md)。新版目標保持進行。

**最新授權與方向（2026-09-08）：使用者要求依「12B 基底完整英雄驗證優先、資料品質驅動、必要時才微調」重設目標並持續完成。有效新版範圍及驗收見 [12B 重新啟動計畫](outputs/hero-forge-12b-restart-20260908/PLAN.md)。本輪維持 Mac-only、英雄設定／技能機制優先、特效只推薦模板；歷史時間盒不沿用。使用者清除舊目標後，已正式建立新版 12B goal；沒有將舊目標標為成功。使用者再次明確核准本機 GPU fine-tune，已跑完首批 4 英雄 GPU 小測與 1 步 LoRA 技術相容性驗證；這不是正式資料訓練或成品核准。最新結果及限制見 [開發發現](outputs/hero-forge-12b-restart-20260908/DEVELOPMENT_FINDINGS_V1.md)。以下 4B 訓練、取消與早期藍圖均作歷史保留，不覆蓋新版計畫。**

**最新狀態（2026-09-07）：新增訓練已取消；GPU推論也因充電問題於01:55停止，未經使用者重新同意不得重啟。已完成现有證據的總報告：`outputs/forge-final-three-hours-20260906/FINAL_REPORT.md`。954題三模型配對、1741題主隊列未完成；R8無權重，原穩定更好模型目標未達成。下方執行中、待訓練與原截止均為歷史，不覆蓋最新停止決策。**

**最新決策（2026-09-07 01:20 Taipei）：使用者停止新增訓練，改為整理全部資料集、推論驗證、蒐集證據與分析報告。R8尚未啟動，已加入禁止訓練標記。下方所有R8待啟動／最後一輪訓練安排均已失效，僅保留歷史。** 本階段只用既有模型，不再訓練或調參；原完整模型品質目標仍未證實達成。最新範圍見`outputs/forge-final-three-hours-20260906/INFERENCE_ONLY_DECISION.md`。

文件日期：2026-09-06  
狀態：R5與R6新權重均拒絕採用；R6完整466筆訓練未保住原文／单卡能力，全部報告已重播完成。R7-v2低學習率單因素對照於23:25:28正式開始訓練，兩組158題base/R3輸出與R6完全一致。模型維持 research-only／evidence-insufficient，未達穩定可用／產品發布資格。
本次修訂：依四組 benchmark，改以 Qwen3.5-4B non-thinking 作首個微調候選；Mac-only、無雲端 GPU 的限制不變。  
主要環境：使用者的 Apple M5 Max、128GB 統一記憶體。  
第一階段模型範圍：Qwen3.5-4B 的文字任務監督式微調；2B／0.xB 暫列後續壓縮實驗。  
產品目標：GGD 英雄技能、機制與特效配置的本機製作助手。

**23:41新增資料品質警示：** 真實SimWorld已重現traveling-wave終點爆炸漏打最後一段新目標；目前主線相關排除邏輯仍在。R6/R7兩筆terminal-positive訓練答案撤回「完整能力已驗證」認定，凍結資料及歷史分數不原地改寫。R7僅繼續受控研究，仍禁止部署；逐筆清單與後續校正要求見`outputs/forge-low-lr-r7-v2-20260906/POSTFREEZE_DATA_CAVEAT.md`。不能用fine-tune掩蓋模板實作錯誤。

目前有效授權截止為 **2026-09-07 04:36:10 Asia/Taipei**：使用者23:47再延長三小時並要求整理所有結果、交付報告與成品模型。新工作的GPU最晚04:06:10停止，至少30分鐘留作交付；已在跑的R7釘選截止不原地修改。最新授權及交付清單見`outputs/forge-final-three-hours-20260906/EXTENSION.md`，實際R7程序見`outputs/forge-low-lr-r7-v2-20260906/STATUS.md`。下方早期「結案」與時間盒是保留的實驗歷史，不代表整個目標已完成。当前模型只做來源／機制分類及既有模板推薦，不訓練參數或視覺驗證，不自動啟用Editor。

**9/7 00:04 七角色來源擴充：** 依使用者指定，已從`GGD-community-hero-forge`的`codex/community-hero-forge-integration`支線固定沃維克、卡爾瑟斯、拉克絲、犽宿、好運姐、李星、齊勒斯共42技能槽；包含當時未提交的名稱修改，保存原始內容、差異及SHA256，不動該支線。此為GGD改編設定，不以LoL常識替換。每角色設定及每技能槽各3題，合計147題逐題審查；固定角色切分為84 train／21 dev／42 test。全部來源輸入及token預算檢查通過，**尚未用於神經模型訓練**，不改R7。新增21題dev之base/R3/R7評測程序已實際啟動排隊（exec16508／PID68224），待R7全部程序退出後串行執行；42题神經模型test保持未測。詳見`outputs/forge-final-three-hours-20260906/SEVEN_HEROES_STATUS.md`。

- 卡爾瑟斯死亡後不可施法、犽宿物理護盾不刪投射物、李星Q／EX獨立等明確改編用於來源判斷。
- 沃維克「汲傷」、拉克絲「相交段落」、犽宿「接觸範圍」、好運姐「掩護換位」不補成未說明的回血／重複命中／沿路傷害／瞬移。
- 作者額外effects與模板原生能力分離；本批不訓練參數，也不放行42槽的模板能力。支線新perImpact版本不能混入舊能力表。
- CPU最近例對照已完成：新增84題後，在42題角色保留集accuracy政策為26/42、錯誤放行7；原資料27/42、錯誤放行6。這不是fine-tune結果，更不能假定增加資料必然改善。該script測試已曝光，後续不得據此改標籤或按test選模；神經模型仍只先測dev。

**9/7 00:42 最後一輪及交付準備：** R8資料已另建為550 train／179 dev／228 test，加入七角色、逐欄保留516個舊英雄／Owner來源題，退出2筆有問題的wave訓練正例並補入2筆明確能力正例；原R7不改。R8目前仍**只有資料、尚未訓練**。啟動前必須等待R7 core／post／真入口／收據與新21題dev全部完成且原PID退出，才固定warm-start與有界訓練政策。

- 最終較廣回歸固定8組582題，另存`outputs/forge-final-three-hours-20260906/final-broader-data-v1/`。60題目錄輸入校正，僅1題舊終點爆炸答案依實際SimWorld證據改為line-blast，其餘答案及舊成績不改；不以此重選模型或量化精度。
- 原始base、R3、最終native、融合BF16與固定8bit將在同一新題序重跑；加上完整核心dev/test精度比較及搬移後公開入口，不把CPU工具測試當模型成效。
- 各輪原始收據已整理成`outputs/forge-final-three-hours-20260906/experiment-ledger-snapshot-v1/LEDGER.md`；這是00:41快照，不是R7／R8最終成績。分開記錄準備筆數、實際更新、保存checkpoint、worker總時計与未完成例時計。
- 實作與剩餘驗證清單：`outputs/forge-final-three-hours-20260906/FINAL_DELIVERY_PROTOCOL.md`。目前尚未產出最終融合／量化成品，也沒有全用途品質核可。

### 本次執行決策覆蓋（2026-09-06）

- 正式開始：2026-09-06 03:24:15 Asia/Taipei；絕對截止：同日 11:24:15。包含環境、下載、實作、訓練、評測與報告；至少保留最後一小時結案。
- 四組固定條件比較的品質排序為 4B Re > 4B > 2B Re > 2B；4B non-thinking 為 34/46、平均 1.20 秒，4B Re 為 38/46、11.21 秒。先以短答案專用微調驗證品質／成本假說，而非宣稱微調已有效。
- 新執行採官方 Qwen/Qwen3.5-4B 權重、MLX-LM BF16 + LoRA。先前 GGUF 的結果不能當成新 MLX A/B 基準；A/B 必須在同一新後端重測。
- 第一個可執行切片為既有 `tpl-ground-nova` 單招及最小 VFX 配置，連到原有 schema、compiler 與 SimWorld；不新增引擎能力、不做視覺驗證。
- 目前新造案例只能標為 `synthetic-research`，不能冒充人工 Gold／合格 Silver。合成診斷可驗管線與學習訊號，但缺獨立 Owner 來源時，正式有效性結論保持 `evidence-insufficient`。
- 先前 24 題 benchmark 已用於模型選擇，不作本輪訓練來源或未見評測。16GB 仍是推論設計目標，無實機收據不能宣告已驗證。
- 本節優先於下方尚保留的 1～2B／Qwen3-1.7B 初始規劃與未實作的產品藍圖。未啟動 Editor 接入、發布或雲端備援。
- 執行政策與證據：`outputs/forge-finetune-20260906/`；程式：`GGD-hero-auto-forge/tools/forge-training/`。此處記錄啟動與選型，不預先宣告成功。

## 1. 決策摘要

### 本輪實測結案摘要（2026-09-06）

- 正式訓練 35.0 分鐘，整體實作與實驗約 1.8 小時；選定 epoch 2，沒有雲端 GPU。
- 同協定合成 holdout：未微調 33/48 → 微調 47/48；修好 14、退步 0。可完成題 10/24 → 23/24。剩餘錯誤是過度拒絕合法需求。
- 已知舊題跨接口回歸：19/23 → 19/23，修好 2、退步 2；退步包含擅自新增 VFX 覆寫／圖層。不得把合成收益外推為通用技能理解全面進步。
- 4-bit dev：23/24，與 BF16 同分但修好 1、退步 1；M5 Max 實測 Metal 推論峰值 3.38 GiB、平均 0.55 秒／題，16GB 實機仍未驗證。
- 下一個決策關卡是人工核可的真實 Owner 原文／配置及獨立 source-family holdout，不是自動發布或繼續追求合成滿分。
- 完整證據：[本輪交付報告](outputs/forge-finetune-20260906/FINAL_REPORT.md)；可重跑工具：[README](GGD-hero-auto-forge/tools/forge-training/README.md)。下方完整產品藍圖仍有未實作部分。

建置一條可重跑、可中斷續跑、具資源上限的自動管線：固定引擎規格，整理可信資料，生成與驗證補充案例，微調小模型，比較基準，打包合格候選，再接入英雄鑄造流程。

第一版學習任務為：

> 技能需求＋當前英雄上下文＋合法能力與素材候選 → 結構化製作提案 → 既有編譯器產出機制與特效配置。

小模型負責理解需求、選擇能力、組合模板、提出參數與待確認事項。程式負責格式、能力約束、編譯、模擬與資產引用檢查。視覺模型提供畫面評估；人的偏好資料提供美感與創意判斷依據。

「全自動」表示每次 run 在輸入與政策確定後能自行完成，或以明確原因結束；不表示每次都訓練成功、不表示會自動改寫需求，也不表示自動核准所有生成內容。

最先交付能回答的問題：**與未微調小模型加檢索相比，微調是否提高技能製作正確率、減少人工修改，並縮短取得可用結果的時間？** 若答案是否定的，流程應如實交付比較報告與失敗證據。

**目前優先執行第 26 節的八小時實驗，而非一次完成本文件全部產品功能。** 八小時包含環境準備、下載、資料整理、實作、訓練、評測與報告，從正式啟動實作時開始計時。其他章節保留作完整產品藍圖；若工期、資料量或搜尋次數與第 26 節衝突，首次實驗以第 26 節為準。此文件修訂本身不啟動計時或訓練。

**本次八小時實驗不包含雲端 GPU。** 使用 M5 Max 128GB 與本機 MLX 訓練、推論及評測；不租用、接入或實作雲端 GPU 後端，也不因速度或相容性問題自動轉用遠端 GPU。雲端 GPU 支出上限為 USD 0；先前討論的 USD 400 預算上限不構成雲端 GPU 使用授權。

**本輪只做 Mac 版本，平台範圍為 macOS／Apple Silicon（arm64）。** 訓練機為 M5 Max 128GB；部署設計目標為 16GB 統一記憶體的 M 系列 MacBook，僅執行微調後小模型推論。Windows、Linux 與 Intel Mac 不在本輪交付或驗證範圍，也不阻擋本輪 Mac 實驗結案；不因此放寬既有跨平台發布門檻。沒有 16GB 實機收據時只能宣告設計目標與資源估算，不能宣告已支援所有 16GB MacBook。

## 2. 目標與範圍

### 2.1 第一版必要能力

以下為完整產品第一版的目標。八小時實驗只承接第 26 節所列單一任務與證據交付，不承諾全部 Editor 接入、部署格式或產品品質門檻。

- 理解繁體中文技能描述、條件、數值、方向、目標與時序。
- 保留完整 Owner 原文；原文、台詞、機制解讀與新提案分欄管理。
- 從動態提供的合法模板、effect、素材與 patch 路徑中做選擇。
- 產生單招的機制及特效配置提案，並與既有英雄上下文相容。
- 分辨已支援、資訊不足、不支援及需要明示替代方案的需求。
- 對驗證錯誤進行有限次修正；修正不能削弱原始需求。
- 建立資料、模型、編譯版本、測試與畫面證據的完整關聯。
- 在固定品質門檻下產出本機模型候選與報告。

### 2.2 後續擴充

- PASSIVE、Q、W、E、R、EX 整套技能協作與資源循環。
- 多種相同意圖的設計變體，結合人類偏好做排序。
- 以接受／退回／修改紀錄進行主動學習。
- 壓縮至 0.xB，測試窄任務路由或模板選擇。
- 用大量模擬提供平衡性指標，輔助實際遊玩評估。
- 獨立接入新貼圖、精靈圖或動畫資產生成服務。

### 2.3 本計畫不把下列事項算成第一版成果

- 從零預訓練基礎模型。
- 讓文字小模型直接產生圖片、3D 模型或影片。
- 自動新增引擎底層機制、執行任意模型生成腳本。
- 以單一 AI 評分宣告「好玩、美觀、平衡」。
- 以格式通過、loss 降低或兩張畫面測試宣告領域能力合格。
- 未具備相應平台證據就宣告 Windows 或其他 Mac 架構可發布。

## 3. 工作區現況與接入基礎

以下是 2026-09-06 的檔案檢視結果，只證明程式與契約存在；本輪未跑完整產品測試，也未確認各端點運作。

### 3.1 兩份 checkout 要分開辨認

| 位置 | 當次觀察 | 對計畫的意義 |
|---|---|---|
| `GGD/` | 分支 `feat/ability-review-authoring`；有既有工作變更 | 已有本機 VFX 審查工具，不能把此工作目錄當成乾淨的訓練基準 |
| `GGD-hero-auto-forge/` | 分支 `feat/hero-auto-forge`；HEAD `596b2613c19ee6ac78ded74f99ad0d64f33381f6` | 已有 heroForge 與桌面模型發布相關模組，是優先評估的整合基礎 |

實作啟動時重新確認 Git 狀態、分支與檔案版本；上表不是永久設定。若採另一 checkout，應整合已驗證的必要提交，不能混用兩份工作目錄的 schema 與輸出。

### 3.2 可沿用的元件

下列路徑以 `GGD-hero-auto-forge/` 為相對根目錄，除非另有註記。

| 元件 | 已觀察路徑 | 實作時沿用方式 |
|---|---|---|
| 製作提案契約 | `packages/shared/src/content/heroForge/proposal.ts`、`proposalJsonSchema.ts` | 優先沿用合法模板、能力與 patch 選項，避免另建平行提案格式 |
| 計畫與生成 | `heroForge/plan.ts`、`planner.ts`、`generator.ts` | 作為模型提案落地的既有入口；先確認匯出 API |
| 檢索 | `heroForge/retrieval.ts` | 共用推論與訓練時的候選建構方式 |
| 機制／特效建構 | `heroForge/effectAuthoring.ts`、`presentation.ts`、`validation.ts` | 沿用驗證與配置邏輯；補上缺少的需求對照檢查 |
| 模擬 | `heroForge/scenario.ts`、`packages/shared/src/sim/SimWorld.ts` | 沿用真實 `IntentFrame`、`world.step()` 與事件；擴充語意斷言 |
| 本機模型契約 | `heroForge/localAi.ts` | 模型狀態、推論能力與提案接口相容性 |
| 現有發布測試 | `apps/editor-desktop/src/ai/local/releaseCorpus.ts`、`releaseGate.ts`、`releaseRunner.ts` | 保留為既有產品相容性／回歸套件 |
| 發布指令 | `apps/editor-desktop/scripts/localAiReleaseGate.ts`、`localAiLlamaRun.ts` | 新增候選模型適配，不直接覆蓋原有模型收據 |
| 本機視覺審查 | `GGD/tools/vfx-visual-review/`；另一 checkout 亦有同名工具 | 使用 JSON／Markdown 證據接口；先比對版本 |
| 匯入契約 | `packages/shared/src/content/import/packageSchema.ts` | 輸出包仍走既有匯入與啟用規則 |

### 3.3 現有發布門檻的限制

本次觀察到桌面 `model-manifest.json` 指向 Qwen3-14B Q4_K_M；`release-gate-manifest.json` 為 `released: false`、`LOCAL_AI_E8_GATE_PENDING`。此設定不是已發布或已通過的證明。

該 manifest 記載 216 案例、最低 95 分、重大錯誤 0，並要求 Mac Metal／Windows CUDA 品質證據及更多平台的 runtime smoke。這些是當次檔案設定；實作應讀取其契約與版本，不將數字複製成第二套常數。

小模型的 MLX 訓練成功不能直接填入 GGUF 桌面發布收據。必須完成轉換、量化、實際推論與對應平台驗證，並讓收據綁定新的模型雜湊。

現有評測輸出是能力選擇／判斷類契約，不能直接假設它完整覆蓋新的機制與特效生成品質。需要新增端到端製作套件，並保留舊套件做相容性測試。

## 4. 架構與資料流

```mermaid
flowchart TD
    A[Owner 原文與確認過的案例] --> B[來源整理與家族分組]
    C[引擎與素材版本快照] --> B
    B --> D[隔離 train / dev / sealed test]
    D --> E[僅用 train 來源擴充案例]
    E --> F[格式與能力檢查]
    F --> G[獨立需求斷言與 SimWorld]
    G --> H[預覽擷取與視覺輔助審查]
    H --> I[具品質分級的訓練資料]
    I --> J[小模型 LoRA 訓練]
    J --> K[dev 選模與基準比較]
    K --> L[凍結候選並執行 sealed test]
    L --> M{達到候選門檻}
    M -->|是| N[融合 轉換 量化與重測]
    M -->|否| O[結束並交付失敗報告]
    N --> P[本機候選模型包]
    P --> Q[Editor 草稿推論與驗證]
    Q --> R[人類接受與修改紀錄]
    R --> B
```

### 4.1 分工

- TypeScript：呼叫 GGD 契約、檢索、編譯、SimWorld、預覽與匯入驗證。
- Python／MLX：訓練資料轉換、tokenization、LoRA 訓練與 checkpoint 管理。
- 執行協調器：優先使用 TypeScript CLI 加本機 SQLite，呼叫隔離的 Python subprocess。
- 大模型教師：生成補充訓練提案及需求改寫；預設本機，可配置其他已授權 provider。
- 視覺評估器：使用既有本機工具；評估不是模擬斷言的替代品。
- 模型 registry：管理本機候選、驗證結果、相容性與上一個可用版本。

### 4.2 模組邊界

`packages/shared` 只容納通用契約與純函式，不依賴 Python、SQLite、桌面應用或檔案系統。訓練協調器在 `tools/`，桌面適配在 `apps/editor-desktop/`，渲染擷取在 client／editor 的測試接口。

TypeScript 與 Python 透過有版本的 JSON／JSONL 交換資料。Python 端可做快速檢查，但 GGD 最終契約仍以 TypeScript 的現有 schema 與編譯器為準。

## 5. 模型選擇策略

### 5.1 第一輪比較組

| 組別 | 用途 | 要回答的問題 |
|---|---|---|
| 決定性模板／規則 | 最低成本基準 | 固定模板已能完成多少工作？ |
| 未微調 1～2B＋檢索 | 小模型基準 | 是否只需提供正確範例？ |
| 微調 1～2B＋相同檢索 | 主候選 | 微調本身帶來多少改善？ |
| 現有較大文字模型＋相同上下文 | 品質與延遲參照 | 小模型在何種任務可以承接？ |
| 0.xB | 第二輪可選 | 窄任務可否進一步縮小？ |

第一輪最多兩個小模型基底，避免大規模盲目搜尋。Qwen3-1.7B 是有官方模型卡、可供起步評估的候選，不宣告它是最新或本任務最佳模型。實作啟動時重新查候選、授權、中文表現、MLX 支援及 GGUF 轉換相容性，固定 revision 後再使用。[來源 S1](https://huggingface.co/Qwen/Qwen3-1.7B)

### 5.2 選型必要條件

- 約 1～2B 參數，能穩定輸出繁體中文與結構化結果。
- 權重、tokenizer、chat template、授權與 revision 可追溯。
- 能在目標 MLX 版本載入，完成 loss／梯度／adapter smoke。
- 能在目標部署 runtime 正確處理 tokenizer、結束符號與輸出格式。
- 同意圖不同表述、否定條件、時間與單位換算通過小型基準。
- 不以公開綜合榜單取代 GGD 任務評測。

### 5.3 訓練方式

先做監督式微調 SFT＋LoRA。對此尺寸優先評估 BF16／FP16 底座加 adapter；若資源量測顯示需要，再做 QLoRA 比較。MLX-LM 官方提供 LoRA／QLoRA、資料格式與 adapter 載入／融合工作流；實作必須 pin 套件版本並以該版本 CLI 能力產生參數。[來源 S2](https://github.com/ml-explore/mlx-lm/blob/main/mlx_lm/LORA.md)

初版不加入 DPO 或強化學習。待已累積足夠同一需求的接受／拒絕配對後，才另開偏好訓練實驗，並保留 SFT 基準。TRL 的 SFT 文件僅作訓練概念與資料處理參考；CUDA 後端不是本次八小時實驗的實作或備援範圍，也不假設其 recipe 可原封不動在 Mac 使用。[來源 S3](https://huggingface.co/docs/trl/en/sft_trainer)

## 6. 產品輸入與輸出契約

### 6.1 輸入

- `requestId`、任務類型、目標技能槽與當前英雄 plan revision。
- `sourceLock`：Owner 原文與來源的固定版本／雜湊。
- 原始需求、台詞區段與已確認的機制敘述。
- 相關英雄技能摘要、共享資源與設計限制。
- 檢索出的合法模板、素材、能力與可修改路徑。
- runtime／compiler／schema／catalog 版本及目標平台設定。
- 本次允許的任務範圍：填槽、修正、變體或解釋錯誤。

提示長度超限時，優先裁減非必要檢索範例；不得靜默截掉 Owner 條件、合法能力限制或 JSON 結尾。仍超限則回傳可解釋的 `INPUT_TOO_LONG`，不送入訓練。

### 6.2 輸出

優先對應既有 heroForge 提案契約。若需要新增欄位，版本化擴充並提供適配器，而非繞過現有 `legalPatchPaths`／能力選項。

語意上應能表示：

- `proposed`：提供範圍內合法提案，等待編譯與驗證。
- `needs-clarification`：列出缺少的必要條件；能確定的部分可保留為草稿。
- `unsupported`：列出未支援能力；替代方案另列，不自動套用。
- 選用的模板、能力、素材與版本引用。
- 參數／patch、需求追溯關係與簡短理由。

以上是新訓練工作流的語意狀態，不宣稱與既有 schema 枚舉相同；P1 必須明定映射。模型不能輸出 `human-approved`、啟用指令、任意檔案路徑或執行碼。

### 6.3 生成任務與保留原文要分開

需求轉製作任務不能改寫 Owner 原文。只有明確的「創作新文案」任務才將新文案放到獨立提案欄位；也不能覆蓋來源。`「…」` 內台詞保留供展示與來源比對，不作機制條件。

## 7. 資料設計與品質分級

### 7.1 資料來源優先順序

1. Owner 已確認的需求與最終接受配置。
2. 可追溯的人工修改前後配對與修改原因。
3. 已有測試支持、經來源意圖確認的引擎模板與技能案例。
4. 根據已確認需求規格生成，且通過獨立程式驗證的合成案例。
5. 只有教師／視覺模型同意的案例：列為待審，不自動視為高品質訓練答案。

既有 JSON、Excel 或歷史技能數量不等於可用訓練資料量；先盤點實際可追溯配對。資料來源授權不明、原文缺失、需求與行為衝突者先隔離。

### 7.2 證據分級

| 等級 | 條件 | 用途 |
|---|---|---|
| Gold | 人工確認需求與結果，且必要程式驗證通過 | 核心訓練、dev、封存測試；角色必須先分配 |
| Silver | 有可信的結構化需求來源與獨立斷言，通過程式驗證，未逐筆人工審查 | 合成訓練補充，依家族抽查 |
| Pending | 主要只有模型判斷，或含不可自動確認的美感／創意 | 審查佇列與研究資料 |
| Rejected | 需求不符、證據缺失或驗證失敗 | 失敗分析；不得作正確答案 |

Silver 不能只靠同一個教師生成「需求、答案、判決」取得資格。純機制案例可不要求人類美感標籤；宣稱特效語意合格的案例必須有相應畫面證據與已校準的檢查範圍。

### 7.3 單筆來源資料結構

下例是擬議的資料側 envelope，並非可直接匯入遊戲的 schema。`<...>` 為需由程式計算／替換的值。

```json
{
  "schema": "ggd-forge-training-example@1",
  "id": "example-000001",
  "task": "fill-slot",
  "familyId": "family-guard-counter-001",
  "lineageRootId": "owner-request-001",
  "split": "train",
  "qualityTier": "gold",
  "source": {
    "ownerText": "成功格擋後向前噴出冰霧，命中的敵人減速兩秒。",
    "dialogueSpans": [],
    "ownerTextSha256": "<computed-sha256>",
    "revision": "<source-revision>",
    "licenseRef": "<rights-record>"
  },
  "pins": {
    "engineCommit": "<commit>",
    "capabilityDigest": "<digest>",
    "catalogDigest": "<digest>",
    "contractDigest": "<digest>"
  },
  "requestArtifact": "requests/example-000001.json",
  "targetArtifact": "targets/example-000001.json",
  "expectationArtifact": "expectations/example-000001.json",
  "evidenceRefs": ["evidence/example-000001/sim.json"],
  "review": {
    "status": "human-confirmed",
    "reviewerRef": "<reviewer-id>",
    "reviewedAt": "<timestamp>"
  }
}
```

### 7.4 資料集初始規模

以下為工作量規劃，不是微調成功的最低保證：

- 管線 smoke：20～50 筆人工確認 fixture，只驗證流程。
- 八小時有效性實驗：訓練 100～200 筆配對、dev 20～30 筆、封存測試 40～60 筆；依第 26 節先分家族再擴充，不能把同源變體當成獨立測試。
- 後續擴大 Pilot：200～500 筆具家族差異的確認種子；不足時先縮小機制範圍。
- 擴大 Pilot 合成：上限 2,000～5,000 筆候選，不為湊數接納錯誤資料。
- 擴大 Pilot dev：獨立家族案例，覆蓋一般、邊界、模糊、不支援及反例。
- 擴大 Pilot sealed test：以獨立確認案例為核心，目標 200～400 筆；依家族數與統計精度調整。

以上集合不應從同一小批種子複製取得。若獨立家族不足，報告應降低結論範圍，不以改寫句子灌大樣本數。

## 8. 切分、去重與防止測試資料洩漏

1. 在任何合成、改寫與檢索索引建立前，先按來源家族分組。
2. 以 `lineageRootId`、英雄 ID、技能原型與機制組合建立 group。
3. 同源改寫、修正、數值變體、翻譯與反例繼承同一 split。
4. train／dev／test 的比例以家族分配；初始可採約 70／15／15，仍需滿足各切片最低樣本。
5. 同時做精確 hash、文字近似與結構化機制指紋去重；疑似跨組洩漏由規則攔截並審查。
6. 訓練和評測檢索只讀 train 來源範例；能力清單可共用，答案範例不能共用。
7. 既有公開在 repo 的 release corpus 當作回歸套件，不假裝是未知測試；其內容及衍生案例禁止進新訓練資料。
8. 封存測試的答案不得送給教師生成器或修正器。協調器將其存於獨立路徑，生成程序只獲 train 存取權限。
9. 日常選模只看 dev；凍結模型、prompt、檢索和解碼設定後才執行 sealed test。
10. 看過 sealed test 詳細失敗並據此修正後，該套件只能作回歸；下一輪正式評估要有新的未見案例。

機制組合泛化要另外切片：訓練可以看過 A 與 B，測試保留 A＋B 的新組合；同時保留跨英雄測試。報告分開呈現兩者，不混成一個分數。

## 9. 合成資料產線

### 9.1 生成流程

1. 從 train-only Gold 案例與合法能力快照挑選覆蓋不足的家族。
2. 固定獨立的需求規格與預期行為，再讓教師產生提案。
3. 對需求做語言變體與合法參數變化；以單位、方向、事件條件為主要變化軸。
4. 建構負例與邊界例：例如未格擋不得觸發、友方不得受傷、能力不存在應指出。
5. 經下節驗證後分級入庫。
6. 每個家族設定候選上限、近重複上限與教師修正上限。

### 9.2 修正流程

允許將 schema／編譯／模擬錯誤碼回饋給教師或小模型，最多修正兩次。需求與預期斷言保持固定；任何需求變更都必須建立新版本並重新審查。

每次修正保留原輸出、診斷、修改後輸出及模型資訊。錯誤輸出可作「診斷輸入 → 正確修正」資料，但不能直接當作一般生成的 target。

### 9.3 教師與來源紀錄

記錄 provider、model ID、可取得的 revision／權重 hash、完整 prompt、參數、原始輸出、token usage、時間與費用。若外部 API 不提供可固定權重版本，明記重現限制。

預設採本機教師，已存在的視覺模型是否適合文字教學也要先做基準；不因為能看圖就假定它是最佳教師。外部 provider 以設定明確列出可傳送資料與單次預算。

## 10. 獨立驗證與遊戲行為測試

### 10.1 驗證層次

| 層 | 驗證內容 | 通過仍不代表什麼 |
|---|---|---|
| L0 來源 | 原文完整、版本與雜湊、資料授權、split | 來源描述本身無歧義 |
| L1 格式 | 提案 schema、欄位與長度上限、允許 patch | 機制符合需求 |
| L2 能力 | effect、模板、素材存在且版本相容 | 執行時一定正確 |
| L3 編譯 | 既有編譯器產出、依賴閉包與引用 | 觸發與數值符合需求 |
| L4 模擬 | 真實施放、事件、狀態與獨立斷言 | 畫面已正確呈現 |
| L5 畫面 | 渲染事件、階段擷取、資產載入、視覺評估 | 好玩或最終美感合格 |
| L6 人類 | 意圖、美感、可讀性與設計接受 | 全對局平衡已證明 |

### 10.2 預期行為來源

自然語言 Owner 種子的核心預期先由人確認。大量合成資料則從已確認的結構化規格變化產生；預期斷言由測試建構器依規格產出。模型候選不得修改斷言、scorer 或測試輸入。

獨立性不是「換一個 prompt 再問同一個模型」。若只有模型解讀、沒有可確認的預期規格，案例維持 Pending。

### 10.3 必要場景矩陣

- 觸發：符合條件／不符合條件；成功格擋與普通受傷分開。
- 目標：自己／友方／敵方／空地；範圍內、外與邊界。
- 時序：施放前、施放、命中、持續、中斷、取消與結束。
- 數值：傷害、消耗、狀態強度與持續時間；區分百分比與絕對值。
- 堆疊：刷新、追加、上限、到期、來源歸屬。
- 特殊：無效目標、目標死亡、免疫、資源不足及重複施放。
- 連動：兩招共享資源、buff 消耗、冷卻與事件鏈；整套技能列為 P2 後續。

每案固定亂數 seed 與輸入序列；同時用多 seed 測試隨機機制。時間需求轉成 30Hz tick 斷言時必須記錄取整政策，不能以模糊毫秒容差掩蓋錯誤。

目前 `scenario.ts` 有技能與整套場景入口，但廣泛狀態前後差異不等於已覆蓋所有上述條件。需逐家族補真實行為斷言，不能只檢查 `accepted`。

### 10.4 測試本身的驗證

建立手寫錯誤變體，例如反轉目標、刪除命中階段、改掉持續時間、無條件觸發，驗證測試確實攔截。重大錯誤 fixture 必須全部被攔下；其他 mutation coverage 按家族報告。

SimWorld／註冊表案例優先使用隔離 worker process，防止全域 registry 殘留污染下一案；若改採重用程序，必須有明確 reset 與順序無關性測試。

## 11. 特效資料與視覺評估

### 11.1 第一版特效能力

生成的是既有資產／模板的選擇與參數配置，包括掛點、朝向、縮放、顏色、時序、生命週期與預算。能否調整某欄位，取決於當次 schema／資產能力；不直接承諾任意素材皆可調色或變形。

每筆素材 metadata 應包含：ID、版本、來源與授權、效果家族、錨點與方向慣例、可調參數、預覽參考、資源成本以及已知限制。

### 11.2 擷取流程

1. 以固定場景、角色、相機、解析度、光照與背景執行真實施放。
2. 根據獨立預期與實際事件標記選取施放、命中、持續、消散等階段。
3. 保存事件 trace、tick／frame 對應、PNG 與可選影片。
4. 每次視覺請求遵守工具的 1～16 張影格上限；長技能分段審查，保留完整序列索引。
5. 檢查資產載入失敗、缺畫面、透明通道、缺事件及渲染警告。
6. 將期待的形狀、方向、階段與可讀性送入視覺審查工具。

預覽必須共用 `GameApp` 的 frame owner 與 SimWorld 事件；不得為驗收另外畫一個沒有真實施放的動畫。

### 11.3 校準與限制

用人類標記的清楚通過、清楚失敗、微妙錯位、缺階段、遮擋、低對比與裁切案例做校準。追蹤錯誤放行率、錯誤退回率與轉人工比例。

模型自報 confidence 不能當成已校準機率。既有 `ai-prechecked`、`ai-rejected`、`needs-human-review` 原樣保留；只有人工流程能新增人類接受紀錄。

主觀美感結果不能自動升為 Gold。尚未完成校準時，特效案例可產出候選與報告，但不能宣告視覺品質門檻已驗證。

## 12. 訓練資料匯出與訓練配方

### 12.1 匯出流程

- 來源 envelope 保留完整證據；訓練 JSONL 僅匯出推論時能取得的輸入與合格 target。
- 提示詞使用與產品相同的 chat template、角色順序、候選格式與任務契約。
- 排除 Gold 標記、測試答案、scorer 診斷等推論時不應取得的洩漏資訊。
- 優先只對 assistant completion 計算 loss；在實際後端驗證 masking、EOS 與 padding。
- 保留簡短、可檢查的理由與需求映射；不依賴教師隱藏思考內容。
- 計算 token 分布、超長案例、任務比例、來源比例與家族覆蓋。
- 支援樣本權重或抽樣配比；未實作權重時不能僅在設定檔宣稱有權重。

### 12.2 初始超參數候選

以下是實驗起始值，非已量測的最佳設定。執行器需將設定轉成已 pin 的後端支援參數。

| 參數 | 起始規劃 | 調整依據 |
|---|---|---|
| 方法 | SFT＋LoRA | 基準是否顯示需要微調 |
| rank | 16；可比 32 | dev 品質、訓練記憶體 |
| alpha／scale | 由 adapter backend 明確換算 | 不混用不同工具的參數語意 |
| learning rate | `5e-5` 與 `1e-4` 小範圍 | dev 指標、loss、遺忘情況 |
| context | 初始 4096 tokens；測 8192 相容性 | 真實需求長度，不能截斷必要上下文 |
| micro batch | 1～2 | 實測記憶體與吞吐 |
| effective batch | 初始目標 16 | 後端支援與梯度累積驗證 |
| epochs | 1～3，上限停止 | dev 不再改善或品質下降 |
| checkpoint | 以步數與時間雙門檻 | 恢復成本與磁碟預算 |
| 選模 | dev 任務指標優先 | loss 只作診斷 |

擴大 Pilot 最多 6 個短試驗組合；先用小子集淘汰不合格設定，再訓練最多 2 個完整候選。有改善後，資源允許時以多 seed 確認結果穩定性。八小時實驗只用 1 個基底與 1 個正式 LoRA 配方；只有 dev 顯示明確需要且時間允許時才增加第 2 配方，不進行全面搜尋。

### 12.3 訓練品質與故障判斷

- loss 非有限值、空 target、全被 mask 的樣本立即停止。
- 追蹤訓練／dev loss、有效 tokens、tokens/sec、記憶體與 step time。
- 每個候選同時測否定條件、不支援能力與 Owner 保留；避免只學會熟悉模板。
- OOM 可降低 micro batch 或啟用後端支援的記憶體選項，最多兩次；變更另記 attempt。
- OOM 不得以靜默縮短內容長度或移除必要條件修復。
- 不保證 Metal 訓練跨版本 bitwise 一致；重現標準是完整環境、資料、參數與可解釋的結果差異。

### 12.4 中斷續跑的精確定義

協調器續跑代表不重做已驗證的完成階段。訓練的 exact resume 則需要 optimizer、scheduler、RNG、資料游標與 adapter 狀態全部保存。

P0 必須確認選定 MLX 版本實際能儲存哪些狀態。只有 adapter 載入時應標記 `warm-restart`，不能宣稱是精確續訓。若第一版無 exact resume，採短 epoch／完整 checkpoint 降低重跑損失，並在報告揭露。

## 13. 評測設計與合格門檻

### 13.1 指標

| 指標 | 定義 |
|---|---|
| 原始格式通過率 | 不經修正的輸出可解析且契約通過／全部請求 |
| 能力合法率 | 選擇的能力、素材與版本均合法／全部請求 |
| 首次完成率 | 第一次輸出即通過所需機制與特效檢查／應可完成請求 |
| 修正後完成率 | 在固定最多兩次修正後通過／應可完成請求 |
| 需求符合率 | 獨立語意斷言全部通過／應可完成請求 |
| 不支援攔截率 | 正確指出不支援／真實不支援請求 |
| 過度拒絕率 | 錯誤拒絕／真實可完成請求 |
| Owner 保留 | 比對原文完整 bytes／展示層規定的標準化政策 |
| 人工接受率 | 人類盲評接受／被抽樣審查結果 |
| 修改成本 | 取得可接受草稿的人工分鐘數與修改類型 |
| 延遲 | 冷載入、首 token、生成、端到端 p50／p95，分開記錄 |
| 可用結果成本 | 成功前所有嘗試的時間與資源，包括失敗重試 |

所有比率列分子與分母。`needs-clarification` 在真的資訊不足案例算正確，在條件完整案例則可能是錯誤拒絕。格式失敗與逾時仍進品質分母；基礎設施故障另外列出，並使該輪結果不完整，而不是悄悄刪除失敗樣本。

### 13.2 擴大 Pilot 建議門檻

以下是預先登錄的初始目標，尚未由本專案數據校準；不可宣稱已達成，也不可在看過封存測試後調降以放行。

本節用於後續擴大驗證與候選資格，不是第 26 節小樣本探索的放行條件。小樣本的「有正向訊號」不等於通過本節，也不等於 `candidate-qualified` 或產品發布。

- 最終驗證器必須擋下測試集中全部已知重大錯誤。
- 原始契約通過率目標 ≥99%；驗證後交付物契約違規為 0。
- 需求符合率目標 ≥95%，且報告各機制家族與難例切片。
- 不支援攔截率目標 ≥95%，過度拒絕率目標 ≤5%。
- Owner 來源保留與關鍵條件遺漏：測試中不得出現重大違例。
- 相對未微調＋檢索基準：需求符合率提升至少 5 個百分點；或品質落差不超過 2 個百分點，同時明確降低至少 20% 的可用結果成本。
- 若基準已接近上限，可預先選擇第二條品質／成本判定路徑，不在事後擇優解釋。
- 相對較大模型，目標將同工作負載的可用結果延遲降至約一半；這是效益目標，不是硬體速度保證。

每組使用相同請求、檢索資料、允許重試次數及輸出限制。約束解碼能否使用必須記錄；不同 runtime 不支持相同功能時，另列可比子集。需補足 dev 與 test 的數量，避免 200 筆測試只憑一筆差異就聲稱改善。

### 13.3 統計與選模

比率附信賴區間；兩模型使用配對案例比較，並以家族為重抽樣單位，避免把同源變體當獨立樣本。報告先列全部任務，再列成功子集延遲，不能只展示快的成功案。

在 N 個真正獨立案例中觀察到零錯誤，仍不代表錯誤率為零；例如常用的近似上界 `3/N` 只適合其統計假設成立的情況。樣本高度相關時更需依家族分析，不把 smoke 測試當品質保證。

創意與美感採隱藏模型身份、隨機順序的人工比較，保留理由和評審差異。人類審查尚未完成時，報告 `human-review-pending`，不填造分數。

### 13.4 分開標示交付等級

- `pipeline-complete`：流程完整執行，有報告，可為未合格結果。
- `candidate-qualified`：指定範圍的模型與製作評測通過。
- `local-verified`：指定 Mac、部署格式、runtime 與 Editor 接入驗證通過。
- `release-qualified`：既有產品要求的全部平台收據與發布門檻通過。

這些是擬議新 registry 的狀態，不可直接覆寫既有 `released` 欄位。缺 Windows 主機時仍可完成本機候選，但跨平台發布保持未驗證。

## 14. 協調器、狀態機與儲存

### 14.1 執行階段

`preflight → snapshot → curate → split → synthesize → validate → export → baseline → train → dev-eval → freeze → test → package → deployment-eval → report`

各階段支援 `pending / running / succeeded / failed / skipped / interrupted`。run 另有 `completed / completed-unqualified / blocked-input / failed-infrastructure / cancelled / budget-exhausted`；`completed` 必須列明交付等級，不能暗示已發布。

### 14.2 冪等與失效傳播

階段快取鍵包含：輸入內容 digest、程式版本、契約、設定、模型、prompt、scorer 與依賴輸出。輸出檔寫入暫存後原子 rename，驗 hash 後再提交 DB 狀態。

引擎能力、tokenizer、資料 split 或 scorer 改變時，重新執行所有受影響下游階段。不得因為檔名相同就重用過期證據。

SQLite 保存 run、stage、attempt、artifact、model candidate、review 與 lease；大型 JSONL、權重、PNG／影片在 artifact store，DB 保存路徑與 digest。

### 14.3 中斷與資源故障

- 每個 stage 保存 heartbeat、PID／process group 與 lease 到期時間。
- 使用者取消時先請求優雅結束，再對該 worker group 進行有界終止。
- 重啟後核對遺留程序與 artifact，不能只憑過期 lease 再開第二個訓練。
- 重試使用有上限的退避；把 API 逾時、磁碟滿、OOM、格式錯誤與模型品質失敗分開。
- 沒有進度且未超過合法長運算期限時保持 running；超過該 stage timeout 才判失敗。

### 14.4 預設執行政策

- 訓練、教師推論、視覺大模型與高負載預覽共享 GPU 資源鎖；第一版同時只執行一個重 GPU 階段。
- CPU 輕量格式檢查可有界併發；SimWorld 使用隔離 worker。
- 程序以 argv 呼叫，不把模型輸出拼接成 shell。
- 初始單案修正上限 2 次、API 類重試上限 3 次、OOM 調整上限 2 次。
- 達 run 預算或資料品質不足時結束並報告，不自行放寬驗收條件。

## 15. M5 Max 128GB 的資源規劃

本節數值為可調工程預設，需要 preflight smoke 校準，並非實測硬體效能。

| 項目 | 首次八小時實驗規劃 |
|---|---|
| 運算位置 | M5 Max 128GB 本機；雲端 GPU 與遠端 GPU 備援禁用，雲端 GPU 支出上限 USD 0 |
| GPU 重工作業 | 同時 1 個；訓練時卸載流程自己管理的閒置教師 |
| 記憶體 | 初始程序總工作集軟上限 80GiB；監測 memory pressure 與 swap 增長 |
| 磁碟 | 開始前依模型、checkpoint、影格估算，加至少 20GiB 餘裕；初始 run 上限 100GiB |
| 執行預算 | 實作與運算總牆鐘最多 8 小時，訓練子預算最多 2 小時；依第 26 節保留評測與報告時間 |
| 模型搜尋 | 1 個基底、1 個正式 LoRA 配方；最多 2 配方，須在凍結前完成 |
| 生成 | 補充候選初始上限 400 筆，最終訓練目標 100～200 筆；不足不以低品質資料湊數 |
| 網路 | 權重和依賴下載完成後可離線執行；外部教師另行設定預算 |

不要強制卸載使用者或其他 task 正在使用的模型。無法取得資源鎖時排隊或以資源不足結束。

大型 checkpoint、SQLite 與訓練快取建議放在設定的本機 `artifactRoot`，避開 Dropbox 同步目錄；原始碼、設定範本與小型報告留在 repo。正式實作時設定一個明確路徑並檢查可寫性；本文件不建立新目錄或搬動既有資料。

保留最佳候選、最近恢復 checkpoint 與必要證據。清理只針對本 run 清單中可重建 artifact；Gold、封存測試、人工紀錄與發布模型不自動刪除。

### 15.1 16GB MacBook 推論目標

- 平台假設：M 系列 Apple Silicon、16GB 統一記憶體；最低 macOS 版本依 pin 的 MLX／runtime 實測決定，不包含 Intel Mac。
- 訓練與推論分開：LoRA 融合不改變原權重矩陣尺寸；部署不需要 optimizer、梯度、訓練 activation 或整份資料集。128GB 是訓練機配置，不是小模型的推論最低需求。[來源 S2](https://github.com/ml-explore/mlx-lm/blob/main/mlx_lm/LORA.md)
- 第一部署候選為約 1～2B 的 MLX 4-bit；保留高精度研究用 checkpoint，量化精度以 dev 品質選擇。官方未經本專案微調的 Qwen3-1.7B-MLX-4bit，其權重檔約 914MB，可作容量參照，不是本專案模型的 RAM 實測。[來源 S4](https://huggingface.co/Qwen/Qwen3-1.7B-MLX-4bit/tree/main)
- 初始 profile：單模型、單請求，輸入與輸出合計最多 4096 tokens，其中輸出上限 1024。不得為符合記憶體或 token 預算而默默截斷需求；超限應清楚拒絕或要求縮小任務。
- 模型程序峰值記憶體的設計目標為不超過 6GiB，非速度或記憶體保證。須涵蓋載入、prefill 與生成，分列程序／Metal 記憶體指標並避免重複加總；另記整機 memory pressure、swap 變化與測試時其他程式負載。權重檔案大小不能當成完整 RAM 需求；KV cache 與 prefill 會影響峰值。[來源 S5](https://github.com/ml-explore/mlx-lm#long-prompts-and-generations)
- 最小部署包只包含小模型或其精確基底／adapter、tokenizer、必要推論設定與契約資料；不要求終端使用者同時載入大型教師、視覺評估模型或訓練工具。完整 Editor／3D 同時運作的負載另列，不用模型單獨通過取代整合驗證。
- 有可用 16GB 實機且八小時內可完成時，測冷載入、暖推論、最長允許上下文、連續請求、記憶體與量化後語意。沒有實機則記 `mac16gbVerification: not-tested`；在 128GB 機器限制程序記憶體只能提供初步證據，不能冒充 16GB 實機。

## 16. 設定與 CLI 設計

以下命令、套件與 YAML 為待實作介面，不是現在已可執行的功能。

### 16.1 設定範例

以下為八小時實驗的擬議設定。`budget.wallHours` 管執行器啟動後的 run，不能單獨計入先前的開發時間；`projectDeadline` 必須在正式開工時計算為絕對 UTC 時間，所有 subprocess 取兩種剩餘時間中的較短者。

```yaml
schema: ggd-forge-training-config@1
runName: single-family-effectiveness-pilot
execution:
  computeLocation: local
  cloudGpuEnabled: false
  cloudGpuFallbackEnabled: false
engine:
  checkout: ./
  snapshotPolicy: pinned
  rejectUncapturedDirtyInputs: true
artifacts:
  root: "<configured-local-artifact-root>"
  runLimitGiB: 100
models:
  student:
    repository: Qwen/Qwen3-1.7B
    revision: "<required-exact-revision>"
    backend: mlx
  teacher:
    provider: local
    model: "<verified-local-model-id>"
  vision:
    adapter: vfx-visual-review
    model: "<verified-vision-model-id>"
dataset:
  scope: single-ability
  allowedTiers: [gold, silver]
  splitUnit: lineage-family
  maximumSyntheticCandidates: 400
  syntheticFromSplit: train
training:
  method: lora
  rank: 16
  learningRate: 0.00005
  maxSequenceLength: 4096
  microBatchSize: 1
  effectiveBatchSize: 16
  maxEpochs: 3
  seed: 20260906
evaluation:
  policyFile: ./configs/evaluation-effectiveness-pilot.yaml
  sealedTestAccess: final-candidate-only
budget:
  projectDeadline: "<required-project-start-plus-8h-utc>"
  wallHours: 8
  trainingHours: 2
  maximumGpuJobs: 1
  maximumRepairAttempts: 2
  cloudGpuSpendLimit: 0
  externalSpendLimit: 0
delivery:
  target: local-candidate
  platform: macos-arm64
  format: mlx
  inferenceProfile:
    targetUnifiedMemoryGB: 16
    preferredWeightBits: 4
    maxConcurrentRequests: 1
    maxTotalTokens: 4096
    maxOutputTokens: 1024
    processMemoryTargetGiB: 6
    requirePhysicalDeviceEvidenceFor16GBClaim: true
  publish: false
  activateInEditor: false
```

設定解析必須拒絕 placeholder、未知欄位與不合法路徑。由命令列提供 checkout 絕對路徑或明確以 config 所在目錄解析；不能依意外 cwd 選到另一個 worktree。

本次八小時實驗的 preflight 必須拒絕非本機運算位置、啟用雲端 GPU／備援或非零雲端 GPU 預算；不能只顯示警告後繼續。以上仍是待實作政策，文件欄位不表示已有執行器或帳務限制生效。

### 16.2 擬議 CLI

```text
pnpm forge:train -- doctor --config <config.yaml>
pnpm forge:train -- plan --config <config.yaml>
pnpm forge:train -- run --config <config.yaml>
pnpm forge:train -- status --run <run-id>
pnpm forge:train -- resume --run <run-id>
pnpm forge:train -- cancel --run <run-id>
pnpm forge:train -- report --run <run-id>
pnpm forge:train -- package --candidate <candidate-id>
pnpm forge:train -- verify-deployment --candidate <candidate-id> --target <runtime-target>
```

`doctor` 檢查相容性與資源；`plan` 顯示階段、輸入與預算，不下載或訓練。`run` 依事先設定完成流程，遇到品質不合格仍產出報告。

建議退出碼：0＝所請求工作完成且達到該工作門檻；1＝品質未合格；2＝設定／基礎設施錯誤；3＝缺必要資料／人工判斷；4＝取消或預算耗盡。JSON 狀態為完整資訊來源，不僅看退出碼。

## 17. 模型打包、量化與桌面接入

### 17.1 模型包內容

```text
candidate/<candidate-id>/
  manifest.json
  model-card.md
  training-config.yaml
  provenance.json
  tokenizer/ 或 tokenizer 引用與 digest
  adapter/ 與精確 base 引用
  exports/                 # 可選 MLX、HF、GGUF
  evaluation/              # 摘要、逐案結果、部署收據
  compatibility.json
  licenses/
```

manifest 包含權重／adapter／tokenizer 雜湊、base revision、資料集版本、split digest、compiler／schema／catalog pins、推論設定、prompt／grammar digest、評測政策、限制及交付等級。

### 17.2 匯出順序

1. 在訓練後端載入最佳 adapter 做固定 probe。
2. 必要時融合至相容的高精度權重；驗證 logits／輸出差異在定義容差內。
3. 以已驗證的轉換鏈產生部署格式，確認 tokenizer、special tokens、停止條件與 chat template。
4. 先確認高精度部署結果，再生成目標量化版本。
5. 對每個量化版本跑語意、重大錯誤、長上下文及效能回歸。
6. 最終收據綁定實際部署檔 hash，不能沿用訓練態或另一量化版本的收據。

MLX adapter 不能被假定可直接套到 GGUF。本輪 Mac-only 先驗證 MLX 訓練／融合／重新載入路徑與目標量化版本；GGUF 只在另有明確需要且時間允許時處理，不是 Mac 研究候選結案的必要條件。未執行的 GGUF／Editor 相容性逐項標記未驗證，不能因此聲稱現有桌面 GGUF 後端已可使用此模型，也不可為完成報告而靜默切換桌面後端。

### 17.3 Editor 推論流程

`使用者編輯 → 建立固定 request revision → 共用檢索 → 小模型提案 → 契約驗證 → 編譯 → 模擬 → 預覽 → 草稿差異`

- 接入既有提案與本機 AI 接口，支援取消、進度、逾時和模型未就緒。
- 使用者又修改內容時，舊 revision 的推論結果不得覆蓋新草稿。
- 自動修正僅在固定需求與 patch 範圍內進行。
- 小模型失敗可轉人工，或使用已配置的大模型；記錄路由原因與成本。
- 模型候選切換要原子更新本機 registry，保留上一個版本；不靠覆蓋同名檔案切換。
- 遊戲內容啟用仍走原有 staging、驗證、編譯、CAS、健康檢查與回復流程。

## 18. 建議程式目錄與工作包

以下是目標 checkout 內的擬議位置；已存在的 heroForge 模組應擴充沿用。

```text
tools/forge-training/
  package.json
  README.md
  configs/
  src/
    cli.ts
    config.ts
    orchestration/         # 狀態、lease、重試、預算、取消
    storage/               # SQLite、artifact manifest
    adapters/              # GGD、教師、vision、trainer、runtime
    dataset/               # 收集、家族、split、去重、匯出
    verification/          # 需求斷言、mutation、證據
    evaluation/            # 基準、指標、統計、門檻
    packaging/             # 模型 manifest、轉換、部署驗證
    reporting/
  python/
    pyproject.toml
    uv.lock
    forge_training/
      tokenize.py
      train_mlx.py
      checkpoint.py
      export_model.py
  fixtures/                # 小型可公開／可提交測試資料
packages/shared/src/content/heroForge/
  ...                      # 擴充提案／需求追溯契約
apps/editor-desktop/src/ai/local/
  ...                      # 候選模型適配與既有 gate 整合
docs/forge-training/
  architecture.md
  dataset-policy.md
  evaluation-policy.md
  runbook.md
```

訓練權重、完整原文語料、機器本地設定、SQLite、token cache 與大型影片不進 Git。fixture、schema、程式、可分享的摘要報告與鎖定依賴應可版本管理。

## 19. 分期實作與驗收

**首次八小時工作按第 26 節執行。** 下表是其後的完整產品工程拆分，不是八小時內的工作承諾，也不會在小實驗結束後自動延長執行。

下列階段依賴順序不能省略。工期是單一開發者的初步規劃，須在 P0 後依現有介面可用性修訂；資料審查等待、下載、訓練及跨平台機器準備另計。

| 階段 | 預估工程日 | 主要工作 | 明確驗收 |
|---|---:|---|---|
| P0 可行性 | 2～3 | checkout／schema 盤點，候選 smoke，MLX→部署格式 round-trip，資源量測 | 20～50 筆端到端 fixture、相容性報告、資源估算、確定模型候選 |
| P1 契約與資料 | 3～5 | envelope、來源鎖、家族分組、去重、split、Gold 匯出、需求斷言 | fixture 原文全保留；洩漏測試攔截；資料報告可追溯 |
| P2 驗證產線 | 4～6 | 教師 adapter、合成、編譯、隔離模擬、mutation、畫面擷取 | 每案有判決及證據；重大錯誤 fixture 全攔；AI 結果不冒充人工 |
| P3 自動訓練 | 3～5 | 協調器、資料轉換、LoRA、checkpoint、預算、取消／恢復 | 一次命令完成 pilot；中斷可續階段；OOM／磁碟滿分類正確 |
| P4 評測與打包 | 3～5 | 基準、dev 選模、封存測試、量化重測、報告 | 合格或不合格均可重現；不使用測試答案修正；部署 hash 可驗 |
| P5 本機接入 | 3～5 | Editor adapter、revision、防舊結果覆蓋、切換／回復、修改紀錄 | 指定 Mac 真實操作通過；取消、離線、失敗回退驗證 |
| P6 擴充 | 另估 | 全英雄連動、人類偏好、0.xB、多平台 | 分別通過新套件及原有回歸；不可沿用 P5 當跨平台證據 |

P0～P5 合計約 18～29 個工程日，只作初始排程。若資料未成熟，先停在可用的資料／驗證管線，不應花時間擴大訓練來掩蓋資料不足。

### 19.1 最小垂直切片

先從「施放後產生直線／範圍效果，附加單一狀態」這類當次確認可支援的家族開始。格擋反擊作為重要難例，但只有 runtime 確實能表達相應條件時才加入正例；否則用作不支援／澄清案例。

垂直切片包含真需求、合法提案、編譯、SimWorld、畫面證據、一輪短訓練、基準比較及候選包。完成後才擴大資料和家族。

### 19.2 各角色工作邊界

- 引擎／契約：定義當前能力、適配 heroForge、需求斷言及模擬證據。
- ML／資料：切分、品質分級、匯出、訓練與模型轉換。
- 工具／平台：協調器、資源、快取、報告、打包及 Editor 接入。
- Owner／內容：確認種子意圖、模糊條件、設計偏好與盲評。

工作可以依契約拆分，但同一 checkout 的 schema 與核心檔案需明確 ownership；整合前先固定接口。此角色劃分是實作規劃，不代表本輪已建立代理或分派任務。

## 20. 測試策略

### 20.1 一般 CI，不下載大模型

- 契約與設定：未知欄位、錯誤 pins、非法路徑、過長資料。
- 資料：原文往返、split lineage、近重複洩漏、train-only retrieval。
- 協調器：階段失敗、原子寫入、中斷恢復、lease、取消、預算。
- 驗證：手寫 fixture、反例、mutation、事件與時序斷言。
- 評測：分母、拒絕率、scorer pins、錯誤收據、資料污染。
- 打包：artifact hash、tokenizer／base 不一致、部署相容性。

### 20.2 本機整合測試

- 小模型真實 train smoke，確認 loss mask、adapter 更新與 probe 輸出。
- 教師 malformed JSON、逾時、截斷、推論內容通道差異。
- 真實 SimWorld 與預覽擷取；資產缺失、renderer 失敗不報品質通過。
- 模型匯出、量化、重新載入及相同輸入對照。
- Editor 同時顯示 3D、推論取消、revision 競爭與回復。

### 20.3 發布驗證

在對應目標機器執行既有 runtime 與 quality gates，依目前 manifest 驗收。Windows、不同 GPU、乾淨安裝等未執行項逐項標記，不能用模擬平台標籤或偽造硬體資訊代替。

本次八小時實驗只交付 Mac 研究候選與報告，不做 Windows／Linux／Intel Mac 安裝器、runtime 移植或平台驗收；這些未驗證項不阻擋本次實驗結案，但既有 `released` 與跨平台發布門檻保持不變。16GB 支援聲明須綁定真實機型、macOS、runtime、模型 hash 與上下文 profile；單台 M5 Max 128GB 的成功不能覆蓋所有 Mac。

所有測試報告區分：程式回歸、測試工具故障、平台／資源問題、資料不合格與模型能力不足。

## 21. 持續改進與訓練觸發

第一版只提供手動啟動的一鍵 run。未來若啟用定期訓練，應透過正式排程器，且必須具備以下觸發與停止條件：

- 新增足夠數量且跨家族的人類確認資料。
- 能力／schema 更新後，先完成相容性評測，再判斷是否需重訓。
- 連續兩輪 dev 沒有改善，停止自動嘗試並交付瓶頸分析。
- 沒有新資料、資料不足或資源不足時只記錄 no-op，不能製造無意義新版本。
- 接受／退回紀錄必須連到原請求、候選與修改；不直接把所有模型輸出回灌。
- 更新訓練資料時保留舊家族覆蓋，監測遺忘及偏向高頻模板。

人類偏好資料至少包含同需求候選、盲評結果與原因。引入 DPO 前，先檢查偏好是否穩定、是否只是修正格式錯誤，以及是否需要更簡單的資料篩選。

## 22. 風險、監測與應對

| 風險 | 如何發現 | 應對 |
|---|---|---|
| 合成資料很像但語意錯 | 獨立斷言、來源抽查、反例 | 保持 Pending／淘汰，修資料而非放寬測試 |
| 小模型只背模板 | 未見家族／組合、結構多樣性 | 擴大可信覆蓋；必要時縮小任務或改用較大模型 |
| 評測被改寫資料污染 | lineage、指紋與近重複掃描 | 重新切分並使受污染收據失效 |
| 多次看 test 造成過度調整 | sealed access 紀錄與政策 | 舊 test 降為回歸，建立新測試 |
| 引擎或素材變更 | capability／catalog digest | 失效相容性收據並重測，不盲目重訓 |
| 原文或台詞被改壞 | 全文及來源 hash 比對 | 還原來源欄；新文案另列提案 |
| 視覺審查錯誤放行 | 人類校準集與抽查 | 降低自動接受範圍、提高轉人工比例 |
| 訓練快但結果更難修 | 可用結果成本、修改分鐘 | 不晉級，保留未微調＋檢索方案 |
| 量化後語意退化 | 部署態全套重測 | 改量化精度或保留 adapter 版本 |
| 跨平台 runtime 不支援 | P0 round-trip、發布矩陣 | 明確限制本機交付；補上轉換／平台工作 |
| 共享 GPU／同步目錄干擾 | lease、memory pressure、I/O | 排隊、分階段、本機 artifact store |
| 所有錯誤都靠人工 | Pending 比例與修改原因 | 收斂到可驗證家族，逐步建立可信斷言 |

## 23. 最終交付與完成定義

本節定義完整產品交付；八小時實驗只交付第 26.10 節的實驗產物及完成／未完成狀態。無顯著收益、樣本不足或訓練未完成均可形成誠實的結案報告，不得因此假造合格模型。

### 23.1 工程交付

- 可執行協調器、TypeScript／Python 鎖定依賴、設定與操作手冊。
- 版本化資料契約、來源規則、去重與 split 報告。
- 可重跑的基準、獨立驗證、視覺校準接口與失敗 fixture。
- 單命令 pilot、續跑／取消／資源限制功能。
- 逐案 JSON 結果、可讀 Markdown 報告與 artifact 索引。
- 候選打包與相容性驗證功能；若模型未達標，仍交付完整失敗原因。

### 23.2 模型交付

- 基底、adapter、tokenizer、授權與完整 provenance。
- 凍結的資料集、prompt、檢索與測試政策版本。
- 與三種基準的品質、延遲、修改成本比較。
- 已測的平台、格式、能力範圍及未驗證項。
- 若合格，提供可載入的本機候選包與上一版本回復方法。
- 若不合格，明確列出應改善的資料／任務／模型限制，不發布。

### 23.3 一次完整 run 的完成條件

1. 輸入與所有必要版本已固定。
2. 資料來源可追溯，split／洩漏檢查完成。
3. 基準與候選在相同條件下評測。
4. 成功、失敗與未驗證案例全部出現在報告。
5. 只在所有必要證據到齊後提升對應交付等級。
6. 重跑能重用合法快取，設定改變能正確失效。
7. 結束後不留下未管理的訓練或推論程序。

## 24. 實作啟動清單

- [ ] 優先採第 26 節八小時實驗，記錄正式開始時間、絕對截止時間與必須保留的報告時間。
- [ ] 固定本機運算政策：雲端 GPU／備援禁用且預算為零；驗證違反此政策的設定會在 preflight 被拒絕。
- [ ] 固定 A／B 配對條件、主指標、重大錯誤定義與結果判定規則。
- [ ] 重新確認目標 checkout、branch、HEAD、dirty inputs 與 AGENTS／CLAUDE 指引。
- [ ] 確認沿用 heroForge 版本，建立程式與契約快照。
- [ ] 盤點可用 Gold，確認首個可驗證家族。
- [ ] 固定資料授權與 Owner 原文保留政策。
- [ ] 固定候選模型 revision、套件版本與部署格式。
- [ ] 固定 macOS arm64／MLX 交付與 16GB 推論 profile；確認是否有 16GB 實機，無實機則保留 `not-tested` 狀態。
- [ ] 完成 MLX train smoke 與部署 round-trip。
- [ ] 定義獨立需求斷言及重大錯誤 fixture。
- [ ] 完成 train／dev／sealed test 家族隔離。
- [ ] 預先登錄品質與成本門檻。
- [ ] 實作最小垂直切片後，再擴充合成資料量。
- [ ] 完成基準比較，決定是否繼續投資微調。

## 25. 來源、假設與查核方式

### 25.1 外部技術來源

- S1：[Qwen3-1.7B 官方模型卡](https://huggingface.co/Qwen/Qwen3-1.7B)；2026-09-06 查閱。用途：基底候選與相容性資料入口，非本任務效能證明。
- S2：[MLX-LM LoRA／QLoRA 文件](https://github.com/ml-explore/mlx-lm/blob/main/mlx_lm/LORA.md)；2026-09-06 查閱。用途：Apple Silicon 訓練後端能力與操作參考；實作需另 pin revision。
- S3：[Hugging Face TRL SFT Trainer](https://huggingface.co/docs/trl/en/sft_trainer)；2026-09-06 查閱。用途：SFT 概念與資料處理參考，不代表本輪實作 CUDA 後端。
- S4：[Qwen3-1.7B-MLX-4bit 官方檔案列表](https://huggingface.co/Qwen/Qwen3-1.7B-MLX-4bit/tree/main)；2026-09-06 查閱。用途：約 914MB 權重的容量參照，不是 RAM、效能或本專案微調品質證據。
- S5：[MLX-LM 長提示詞與生成說明](https://github.com/ml-explore/mlx-lm#long-prompts-and-generations)；2026-09-06 查閱。用途：上下文快取、prefill 與記憶體權衡；實作需依 pin 的版本驗證。

### 25.2 專案證據

第 3 節列出的 repo 路徑、heroForge 契約與 release manifest 均於文件建立時直接檢視。現有 VFX 工具 README 所載過往測試，不作本計畫小模型品質或訓練速度的證據。

舊的技能模板設計文件提供背景，但其中數量、能力缺口與降級政策可能過期；實作以當次可執行程式、schema、註冊表和目標 profile 為準。

### 25.3 尚待 P0 驗證

- 可用高品質配對資料的實際數量與家族覆蓋。
- 1～2B 候選在 GGD 中文需求上的品質與上下文長度。
- MLX 訓練和 checkpoint 的實際功能、速度與資源消耗。
- LoRA 融合、格式轉換與 GGUF 部署的相容性。
- 現有 heroForge 場景對特定機制的斷言完整度。
- 視覺評估器在真實技能預覽上的校準結果。
- 桌面平台測試機器的可取得性。

本文件中的資料量、超參數、工期、資源上限與品質門檻均為明示的初始規劃。P0 的產物應更新這些假設，並保留修改原因，讓後續實作始終有可檢查的依據。

## 26. 八小時小範圍 Finetune 有效性對照實驗

### 26.1 核心問題與結論邊界

要驗證的問題是：**同一個 1～2B 小模型，在相同提示詞、檢索、契約與執行條件下，加入 LoRA 後，是否更能正確製作未見過的技能？**

本次是決定是否繼續投資的探索實驗，優先保留公平對照與證據。不能僅因訓練 loss 下降、訓練題答對、JSON 變整齊或 adapter 成功匯出，就判定領域能力改善。SFT 優化的是文字預測目標，遊戲行為與特效語意仍須獨立驗證；技術背景見第 25 節來源 S3。

有效性與完成狀態分開記錄：實驗可能完整跑完但沒有收益，也可能因環境或資料不足而尚無足夠證據。單次負面結果只針對本任務、資料與配方，不代表所有小模型微調都無效。

### 26.2 收斂任務與範圍

輸入為完整技能需求、必要英雄上下文及合法候選；輸出為既有 heroForge 契約能表達的機制配置提案，以及特效模板／參數／事件時序。

第一個家族優先採當次確認可支援的「直線或範圍施放＋單一附加狀態」。在同一任務內測不同目標、方向、持續時間、否定條件與未見組合。格擋等條件若無足夠能力或斷言，不硬塞成正例。

本次不做整套英雄創意評比、平衡性判定、新圖片／影片生成、完整 Editor 接入及跨平台發布。既有預覽可用時才沿用；若只完成機制測試，報告明列特效畫面／美感未驗證，不把文字配置通過算成畫面通過。

本輪不包含付費或免費雲端 GPU 的比較試跑、租用、部署及自動備援，也不為後續雲端方案新增 provider 整合。權重／依賴下載可使用網路；教師預設本機，外部教師 API 須另行確認資料傳送範圍與預算，不能將雲端 GPU 禁用誤解成已授權外部 API 或整個開發過程完全離線。

平台只涵蓋 macOS arm64；部署目標與證據按第 15.1 節的 16GB profile 記錄。量化部署驗證是主 A／B 之外的次要結果，精度選擇只使用 dev；不得看到封存測試後調量化再沿用同一測試宣稱未見泛化。量化或 16GB 實機驗證未完成時，仍交付主實驗報告並明列缺口，不自行延長八小時或偽造支援狀態。

### 26.3 對照組與公平性

| 組別 | 設定 | 是否必要 | 要回答的問題 |
|---|---|---|---|
| A | 未微調的固定小模型基底＋train-only 範例檢索 | 必要 | 提供正確範例是否已足夠？ |
| B | 同一基底＋正式 LoRA＋與 A 相同的檢索結果 | 必要 | adapter 本身是否改善任務表現？ |
| C | 較大模型＋相同可見需求、能力與範例內容 | 可選 | 失敗較像小模型能力限制，還是需求／測試有問題？ |

公平性規則：

1. A／B 固定相同的 base revision、精度、tokenizer、chat template、runtime、prompt、JSON 約束、檢索內容與候選順序。
2. 每個 request 只建構一次並保存 digest，再送 A／B；不能只替 B 提供額外提示或正確答案。
3. 固定輸出上限、解碼參數、可用的 seed 與停止條件；同時記錄確定性限制。
4. 主實驗只比較第一次輸出，不經教師修正。時間足夠時另跑相同最多兩次修正的次要實驗，分開列結果與成本。
5. A／B 在同一台機器依序執行，避開教師／訓練／渲染 GPU 競爭。冷載入與暖推論分列，記錄執行順序，必要時以固定 AB／BA 區塊交錯以減少順序偏差。
6. 正式 A／B 比較期間不量化成不同精度；GGUF 或其他部署轉換結果另列，不能把後端差異當成微調效果。
7. C 不是標準答案，也不參與 B 的封存測試修正；C 若也失敗，需再由獨立需求與斷言判斷原因。

既有固定規則或模板能直接完成的案例，另列規則覆蓋率。若規則已能滿足實際用途，也屬有價值的實驗結果。

### 26.4 小資料與隔離方法

| 集合 | 起始目標 | 用途 |
|---|---:|---|
| train | 100～200 筆可靠配對 | SFT；可包含同一 train 家族的程式化變體 |
| dev | 20～30 筆 | 診斷配方、挑 checkpoint；不作最終結論 |
| sealed test | 40～60 筆 | 凍結候選後的配對比較；不得拿回去調 prompt 或配方 |

上述數字是期望的可用集合，不是要無條件湊滿的配額。先由來源鎖、原始技能／需求家族切分，才產生數值變體、同義改寫或修正資料。所有衍生資料繼承原 split；A、B 的檢索庫只取 train。

可靠性沿用第 7 節：自然語言 Gold 需要既有人工確認；Silver 必須來自已確認、可檢查的規格與獨立斷言。不能自動把 repo JSON 或模型產出的答案改標為「人類確認」。Owner 原文與台詞完整保留，機制訊號仍依既有規則分離。

封存測試至少切出三類：可完成且條件完整、不支援能力、資訊不足。初始規劃分別至少 20／10／10 筆；難例包括錯誤目標、否定條件、時序、單位與台詞干擾。實際樣本數、獨立家族數與不足切片必須如實列出。

只具備 20～50 筆可靠 fixture 時，降為管線 smoke；不得將同一小批 fixture 反覆改寫成三份集合來宣告泛化。即使訓練列數達標，若獨立來源太少，仍判證據不足。

### 26.5 學習訊號檢查與正式訓練

正式訓練前，從 train 取 8～16 筆，另建一次短暫的記憶測試：

- 確認 target 非空、completion mask 正確、梯度有限，且 adapter 參數確實更新。
- 比較固定訓練案例的 target loss／機率與可解析輸出，確認有合理學習訊號。
- 重新載入 adapter 再做 probe，排除訓練成功卻沒有在推論載入的問題。
- 用有限步數／時間執行；若無訊號，先查資料、mask、學習率與 backend，不直接擴大語料。

記憶測試只證明訓練接線能工作，不計入未見題成績。正式 B 從相同乾淨基底、全新 adapter 與 optimizer 開始；不得沿用此記憶測試 checkpoint 冒充正式實驗。

正式訓練採 1 個 LoRA 配方，起點可用 rank 16、learning rate `5e-5`、最多 1～3 epochs。依已 pin 的 backend 支援生成實際指令，所有選模依 dev 任務指標。僅在剩餘時間足夠且 dev 有可診斷問題時增加第 2 配方；不做 DPO、大型超參數搜尋或多基底競賽。

### 26.6 獨立 oracle 與 script 判分

在模型輸出前，先固定需求、可接受解集合與預期行為。測試不能依 A／B 的 JSON 重新推導期望；也不能把同一份答案產生器的輸出當作唯一驗證器。程式化變體的規格應有獨立人工確認錨點與手寫反例。

例如「命中敵人後減速兩秒」，要驗證：

1. 真實施放與命中是否發生；未命中不得套用狀態。
2. 受影響對象是否正確；友方／範圍外目標不得被錯誤影響。
3. 狀態種類、強度、開始與到期 tick 是否符合預期。
4. 特效引用、掛點、朝向與觸發事件是否對應；畫面驗證則另需真實影格證據。
5. 模型是否遺漏條件、把台詞當成機制，或選用不存在的能力。

先放入故意錯誤的 target、持續時間、觸發條件與缺階段配置，確認 scorer 會失敗。若不能攔住已知重大錯誤，整個品質結論標為 `evidence-insufficient`，不因 A／B 都過關而判好。

schema、編譯、SimWorld、失敗分類及 Markdown／JSON 報告以 script 批次執行。大型模型只處理新型歧義或可選 C 參照，不能逐題為自己的答案裁決。

### 26.7 指標、配對表與統計界限

主指標為「可完成且條件完整案例的首次需求符合率」：獨立語意斷言與必要程式檢查全部通過才算成功。若本輪包含特效畫面評測，其通過率另列，不得用純機制成績宣告視覺品質。

另外分開報告格式通過率、能力合法率、不支援攔截率、錯誤拒絕率、澄清正確率、重大錯誤、冷／暖延遲、token 與取得可用結果的成本。解析失敗與模型逾時保留在分母；平台故障使評測不完整，不能悄悄移除。

必要的 A／B 配對表：

| 配對結果 | 計數欄位 | 意義 |
|---|---|---|
| A 對、B 對 | `bothCorrect` | 保留既有能力 |
| A 錯、B 對 | `fixedByFinetune` | 微調修好的案例 |
| A 對、B 錯 | `regressedByFinetune` | 微調新增的退步 |
| A 錯、B 錯 | `bothWrong` | 尚未解決的問題 |

對主指標的固定可完成案例集合，提升百分點為 `100 × (fixedByFinetune - regressedByFinetune) / eligibleCaseCount`。分子、分母及逐案差異全部輸出，不能只報淨分數。

若一個家族有多個變體，統計以家族為重抽樣單位。附帶配對差異的區間或明示未能可靠估計的原因；40～60 題只適合尋找明顯訊號，不能單憑幾題提升宣告統計確證或產品級可靠。

同尺寸與 runtime 的微調不預設會加快每 token 推論速度。效益可能來自更少錯誤、更短有效輸出或更少重試，需分開量測。

### 26.8 預先登錄的判定與停止條件

在查看 sealed test 前固定此政策、主指標、重大錯誤定義與 scorer digest。下表是探索實驗的工程決策門檻，不取代第 13.2 節資格驗證。

| 觀察結果 | 結論 | 後續處理 |
|---|---|---|
| 主指標提升至少 10 個百分點，無新增重大錯誤，且收益分布於不同原始家族或預定義條件切片 | `promising`，有正向訊號 | 報告不確定性，提出下一輪獨立驗證；不自動擴訓或發布 |
| 只有訓練／記憶題改善，未見案例沒有一致改善 | `no-clear-gain` | 查資料覆蓋、過擬合或背模板，不把 loss 當結論 |
| 只改善格式，主指標或可用結果成本沒有改善 | `no-clear-gain` | 優先保留 schema／檢索方案 |
| 新增重大錯誤，或未見題明顯退步 | `regressed` | 保留 A；逐項列出新錯誤，不晉級 B |
| 樣本／獨立家族不足、差距無法判讀、驗證器失效或 A／B 未完整完成 | `evidence-insufficient` | 交付缺口與已有證據，不宣告有效或無效 |

「至少 10 個百分點」只是值得擴大驗證的訊號門檻，不是顯著性的替代。不得在看過 test 後改成只比某幾題、換分母或改用另一個比較容易改善的指標。

若 A 在 dev 已達預先設定的實用標準，例如需求符合率 ≥95%、重大錯誤 0，且延遲可接受，可先停止投資正式微調。此時記錄 `baseline-sufficient-on-dev`；若要對未知案例作結論，仍須對凍結 A 執行封存測試，不能將 dev 當外部效度證據。未訓練 B 則不得填造 A／B 比較結果。

因觀察到 dev 問題而變更配方是允許的；看過 sealed test 明細後的修正屬下一輪工作，原 test 改列回歸，下一輪應有新的未見測試。

### 26.9 八小時時間盒與自動化優先序

以下是相對正式開工時間的預算分配，不是各步必定能完成的速度保證。計畫討論與本次文件編輯不計入尚未啟動的實作時間盒。

| 時間區間 | 優先工作 | 截止時的必要輸出 |
|---|---|---|
| 0:00～0:45 | 環境、權重、checkout 與既有接口檢查 | 固定輸入與絕對 deadline；環境可用性清單 |
| 0:45～2:30 | 資料整理、家族切分、獨立斷言與錯誤 fixture | dataset／split digest、scorer 檢查結果 |
| 2:30～3:15 | A 的 dev 基準、8～16 筆記憶測試 | 基準結果與 adapter 學習接線證據 |
| 3:15～5:00 | 從乾淨基底短程正式訓練 | 至少一個可重載 checkpoint，或可解釋的失敗狀態 |
| 5:00～6:00 | dev 選模、凍結 A／B 與評測設定 | candidate、request、prompt、scorer pins |
| 6:00～7:00 | 封存測試 A／B 配對執行 | 原始輸出、逐案判決、配對表 |
| 7:00～8:00 | 整理證據、實驗包與結案報告 | 已做／未做、成效／不確定性、重跑方法 |

時間管理規則：

- 第 5 小時起不啟動新的正式訓練配方；第 6 小時前凍結候選與測試設定。
- 第 7 小時起優先保存證據、結束受管理的長工作並寫報告；不犧牲報告時間繼續調參。
- 每個 subprocess timeout 不得超過專案絕對 deadline 的剩餘時間。八小時到期時取消本次管理的未完成工作，不留下默默繼續訓練的背景程序。
- 若本機訓練估時超出剩餘時間，或 MLX／記憶體問題在既定重試上限內無法排除，停止該階段並保留失敗與部分成果；不轉雲端 GPU、不自行延長八小時，也不把未完成訓練判為有效性失敗。
- 若環境或資料準備超時，縮減可選 C、修正器比較、GGUF 匯出或 Editor 工作；不刪除必要反例、放寬正確性或提前看 test 來追進度。
- A／B 有任一組未跑完固定測試集，標記 `evidence-insufficient`；可以交付部分結果，但不得選擇性只呈現兩者皆成功的子集。
- 本輪達 `promising` 也在八小時內結束；後續擴大訓練另行安排。

優先自動化的 script：來源掃描、全文比對、去重、split、候選生成、token 統計、訓練呼叫、批次推論、SimWorld、指標計算與報告。對話只接收摘要、錯誤類別及代表案例；完整 log 與輸出存 artifact，避免重複讀入整個 repo 或資料集。

### 26.10 實驗交付與完成定義

必交產物：

- `experiment-policy.json`：範圍、時間盒、A／B 固定條件、指標與判定政策。
- `dataset-manifest.json`、`split-report.json`：來源、品質等級、家族、去重及洩漏檢查。
- `scorer-checks.json`：已知錯誤是否被攔截，以及未覆蓋條件。
- `baseline-dev.json`、`learning-sanity.json`、`training-run.json`：各階段結果與完成狀態。
- `comparison.json`／`comparison.md`：逐案 A／B 原始輸出引用、配對表、分項成績、重大錯誤與不確定性。
- `experiment-report.md`：`promising / no-clear-gain / regressed / evidence-insufficient`、執行起訖、未完成項、下一步與重跑方式。
- 若訓練成功，提供研究用 adapter、精確 base／tokenizer 引用與設定；沒有合格 checkpoint 時不製造空模型包。
- `mac-deployment-report.json`：macOS arm64／MLX 候選的融合、量化、重新載入、模型 hash 與推論 profile；分列 M5 Max 128GB 實測與 16GB 實機結果。未做量化或無 16GB 機器時明列 `not-tested`，不能標為 16GB 已驗證。

上列檔名是擬議接口，可在實作時依既有工具適配，但必須保留相同資訊。訓練或測試未執行的檔案應有 `not-run` 原因，不填虛構分數。

完整跑完的實驗可標 `pipeline-complete`，但小樣本 `promising` 仍不能提升到第 13.4 節的 `candidate-qualified`。只有 smoke 完成時，報告只能說管線已驗證，不能說微調有效。

本階段成功的核心交付是一份能回答 **「微調修好了哪些錯，又新增了哪些錯」** 的可信報告；沒有明顯收益也屬可用結果，讓後續投入有依據。

### 26.11 2026-09-06 實驗交付狀態

已完成 Mac-only Qwen3.5-4B non-thinking LoRA 與固定評估；單模板合成 test 33/48→47/48，但較廣已知機制／VFX 回歸為 19/23→19/23（修正 2、退步 2）。尚未完成使用者要求的「可穩定使用、更好的完整鑄造模型」，不標 candidate-qualified。

正式訓練約 35 分鐘，量化模型約 2.22 GiB；16GB 實機未驗證。研究權重已保存到 `outputs/forge-finetune-20260906/research-model-mlx-4bit/` 並逐檔核對摘要。原八小時截止不延長、沒有雲端 GPU。最終接手索引與缺口：`outputs/forge-finetune-20260906/HANDOFF.md`。

使用者確認沒有人工核可資料，仍授權自主研究；因此缺少 Gold 不應阻止後續程式規格研究。但非人工核可資料必須如實標記，不得冒充真實需求品質保證。若另開時間盒，優先完成多模板與多措辭的第二輪真正訓練／新封存測試，減少周邊工具投入。

## 27. 使用者更新：四小時分類／模板推薦實驗（優先於前述舊範圍）

2026-09-06 11:36:10–15:36:10 Asia/Taipei。Mac-only、Qwen3.5-4B 不推理，不租雲端 GPU。由程式依現有資料出題／產生答案，明確標示研究資料，不要求人工 Gold 才能啟動。

主要工作是英雄／技能／行為分類、選擇和組合已存在的機制模板、支援狀態判斷，以及建議套用既有特效模板。**特效完全不訓練調色、縮放、速度、延遲、透明度或其他參數覆寫**。例如氣功砲需求推薦氣功光束模板，細節由人工調整。

分類／模板選擇按任務分別計分及 macro 平均，參數建議不得加減分類分数；schema／安全是獨立守衛。本輪訓練輸出直接排除參數，優先把分類準度做好。可用預設值仍交由既有編輯器；不把預設參數的重複輸出當成模型能力。

資料入口 `tools/forge-training/broad-data.ts` 已盤點全部 34 個現行機制模板（17 enabled、17 draft）、632 個 VFX 文件、461 份技能、498 筆行為分類（29 類）、53 份英雄分類和 28 項規劃能力。draft 僅教狀態判斷，不當成可執行模板。沒有足夠行為證據或不合法組合的項目隔離並列出原因；不把舊描述與現在 JSON 強行配成正解。

正式資料 `outputs/forge-classification-v3-20260906/`：1,872 train／188 dev／260 test。包含 catalog-aware 的分類與推薦，以及同名技能沿用綁定任務；它們不是獨立美感／未知知識測試。依既有技能來源編號把相同技能的不同英雄版本分在同一側，防止完全相同請求跨 train/test。舊實驗資料與分數不改。

先執行 MLX doctor 與 baseline dev，再從乾淨基底做最多兩次完整資料 epoch（LoRA rank16、最後8層、lr5e-6、accum4），接著 dev 及凍結 test A/B。按第一個 epoch 實際耗時預估；第二個 epoch 若會侵蝕完整評估的30分鐘保留，便在第一個 epoch 完整存檔後停止。另保留最後15分鐘報告，不延長四小時。

v3 明確指定輸出 enums，並分開報模板／分類、decision、格式三項；特效選對 ID 不會因 reasonCode 或 decision 格式錯誤被記成「選錯模板」，但格式／決策仍是獨立必要門檻。前一開發基準曾出現正確氣功模板 ID 配錯 decision 欄位，因此已取消並封存，不能把格式學習膨脹為分類收益。v3 A/B 統一使用 greedy 解碼（temperature=0），不混比舊抽樣分數。

主要門檻：macro≥95%、各任務≥90%、不安全接受為0，並且全部 decision 與輸出格式守衛通過；未達標不晉級、不偽稱完成。未合格前不接入 Editor 或自動啟用技能。

### 27.1 使用者品質要求：筆數不等於正確資料

上述 v3 的 1,872／188／260 已撤回「正式核可」定位，並在 2026-09-06 11:48:16 停止訓練；短暫 checkpoint 不沿用。主助手親自對照有效 expand 行為、既有形態語意表與題目答案，發現答案照抄、ID 猜語意、舊單標籤漏掉位移、真隨機／真射線被近似模板冒充等風險。保留舊資料與逐筆隔離原因，不為湊筆數而訓練。

改採 `outputs/forge-classification-reviewed-20260906/`：268 train／88 dev／132 test。來源有 34 現行機制卡、75 組標準 primitive 元素形態與10個具名特效；34組機制意圖及8組VFX對照需求親自出題核對，其餘278個組合語意題匯出後逐項閱讀。完整紀錄在 `QUALITY_REVIEW.md` 和 `QUESTION_REVIEW.md`。這是助手審查研究集，不是 Owner 人工 Gold；未審英雄定位、歷史單一標籤、任意多卡組合與547個其餘VFX文件先不進訓練目錄。

等價模板用事先固定的 `acceptedTargets` 接受，必要機制不允許偷偷降級；VFX絕不輸出參數。新增品質審查收據綁定資料摘要，沒有准入收據不能開始本版訓練。分類、格式、決策與安全分開報。選模只看 dev，最後固定 A/B 同題配對；新增任何分類退步或決策／格式／安全惡化時不晉級、保留基底。不能把 loss 降低或訓練完成當作更好模型的證明。

原四小時截止、Mac-only和無雲端預算保持不變。

2026-09-06 12:06:14 補記：本版資料審查、來源契約檢查與基底 dev 已完成（分類76/88），但查得目標狀態為 paused，因此停止剛啟動的訓練並釋放 GPU lock；未完成 epoch，不宣稱微調提升。恢復目標後從已審資料建立乾淨的新 run，不沿用半成品 adapter，不自行延長時間盒。

2026-09-06 12:35 補記：目標恢復 active，啟動 `outputs/forge-classification-reviewed-r2-20260906/`。重啟收據確認訓練／驗證／測試與審查資料逐檔一致，不複製模型狀態，從乾淨基底完成對照。原15:36:10截止不變。使用者再次強調品質优先，因此本次不把1872/188/260配額或原始資料通過schema當作收錄理由；不得把本輪研究子集分數外推為完整鑄造品質。

### 27.2 使用者優先順序更新：英雄設定與機制優先，特效最後

2026-09-06 13:46 補記：使用者明確指定「最重視英雄設定、技能機制的正確性，特效是最低優先度」。後續資料審查、模型採用與報告順序均以此為準。

1. **英雄設定忠實性**：不能自行推測英雄定位、背景設定、技能用途或補寫未授權的能力；依完整權威來源核對。現有 488 題沒有完成這一層驗證，因此不得宣稱完整英雄鑄造目標達成。
2. **技能機制正確性**：逐项核對觸發事件與方向、作用對象、時序、位移主體、傷害／控制／資源與多階段必要條件；不可漏條件或擅自降級。支援／授權近似／拒絕必須正確。
3. **特效最低優先**：只推薦既有模板，不訓練參數微調；特效高分不能抵銷上述錯誤，也不是下一輪資料擴充的首要方向。

此更新發生於 R2 第二輪仍在訓練、微調 dev 與 sealed test 尚未開始時。保留已固定資料、原評分規則與原 macro A/B，避免重寫實驗歷史；另外預先保存 `outputs/forge-classification-reviewed-r2-20260906/priority-policy.json`，以 dev 的機制表現優先排序完整 checkpoint，特效僅作同等機制結果的末位比較。不得依 test 選模。

機制研究採用門檻另要求 dev／test 機制正確率至少 95%、全部機制 decision／schema 正確、錯誤接受為零、對基底沒有新增機制分類退步，且不得把只有 VFX 的改善稱為主要目標收益。這是使用者新優先順序下的補充判斷，不把原比較結果改寫成另一組分數。完整英雄設定未驗證時，最多交付有限範圍機制研究候選，不標完整目標完成或自動啟用。

目前有 17 筆歷史技能的逐筆校正建議，見 R2 的 `LEGACY_REVIEW_STATUS.md`；其餘 480 筆歷史機制資料仍待逐筆審查。後續先補權威英雄／Owner 來源與機制覆蓋，再擴充特效；本輪原四小時截止及 Mac-only 限制不變。

### 27.3 R2 實測結果與未通過項目

两個完整 epoch 已完成（約84.7分鐘），固定機制 test 50/68 → 61/68，修正11題、機制分類退步0題；可支援切片18/36 → 29/36，應拒絕切片32/32 → 32/32。尚有7題錯誤拒絕，dev 另有2題錯誤接受，因此未達機制優先門檻，完整英雄設定也未驗證，不標完成。

部署不是「轉檔能跑就通過」：4-bit 的機制 test 為44/68且22題錯誤接受；8-bit 依dev保真選中後，在test為60/68且新增1題錯誤接受，因此均不晉級。原始BF16＋LoRA獨立機制推論成功，單題生成約0.85秒、載入約1.19秒、Metal峰值約9.67GiB（12GiB限制）；16GB實機未驗證。保存精確研究參考，不替換正式模型。

完整證據與7題原文在 `outputs/forge-classification-reviewed-r2-20260906/EXPERIMENT_REPORT.md` 與 `priority-review.json`。若取得延長授權，下一輪優先補英雄設定與Owner來源、機制涵蓋與對照難例，現有test轉為回歸，另建新封存集；不能只加epochs或沿用原test挑配方。截至本補記，延長4小時仍是建議，原15:36:10截止未改。

### 27.4 使用者已授權延長：最多追加六小時

2026-09-06 14:21 起：使用者明確願意增加四小時，若改善資料與訓練迭代有價值則可追加六小時。R2 已呈現機制正向收益，因此採六小時上限：最終截止改為 **21:36:10 Asia/Taipei**，四小時延長檢查點 **19:36:10**。不保證更多時間必然達標；若沒有可驗證改善方向，不為多跑而用滿時間。

本授權開啟新的 R3 迭代，**不修改 R2 的時間盒、policy、舊 test、結果或權重**。資料品質、英雄設定与技能機制優先，不擴充特效；只使用本機、不租雲端。R2 test 從此為回歸集，另建新的來源家族切分與封存測試。

執行規則與完成條件記錄於 `outputs/forge-mechanism-priority-r3-20260906/EXTENSION.md`。新一輪先核對來源／有效能力、親自審查題目，再依實際 token 與訓練速度安排迭代，保留完整驗證與最後十五分鐘交付時間。不得以縮小英雄／機制範圍或用特效高分替代真正完成。

### 27.5 R3 進行中：來源忠實度、主線版本與壞模板隔離

2026-09-06 15:04 補記（進度，非完成報告）：R3 已完成 53 份英雄設定與 90 份歷史 Owner 技能原文的指定命題審查，研究資料為 **434 train／83 dev／108 test**。這不是整份原文的所有機制都能實現的保證，也不是 Owner 人工 Gold。三個 epoch 的本機訓練正在執行，未完成的模型分數不預填。

本輪發現本地「latest Owner TSV」其實是 **2026-08-08 的歷史版本**，不能代表最新 main。R3 每題明確提供來源，仍可檢驗版本限定的閱讀／分類；不把其結果稱作最新英雄規格學習完成。原 R3 資料、答案、dev 選模與 sealed test 保持凍結。

另外釘選 main `4793eaaaf2775b2081f5eca5881db32e0aab0ea8`，獨立盘點 **46 張模板：35 enabled、11 draft**。結果分層報告：

- 35/35 預設參數可展開，但只有 **33/35** 的完整技能可通過 schema。
- `tpl-beam-roll` 的 count=1 卻輸出 spacing；`tpl-dragon-serpent` 的 clipTimeScale 沒有 clip，均遭完整 schema 拒絕。追蹤 [#1047](https://github.com/adms/GGD/issues/1047)。
- `tpl-drain-leech` 的 heal 未指定 self。真正 SimWorld／runEffects 重現：施法者421→421，敵人421→471；測試控制組補 self 後方向反轉。與來源聲明相反，追蹤 [#1046](https://github.com/adms/GGD/issues/1046)。這是 handler 受詞重現，不冒充整招 E2E。
- 三張卡在分類診斷目錄**隔離**，不是暗中修復遊戲，亦不把它們教成正確推薦。剩餘32張是已審查展開語意的診斷候選，不是32張完整遊戲驗收通過。
- 說明版本落差另開 [#1044](https://github.com/adms/GGD/issues/1044)、[#1045](https://github.com/adms/GGD/issues/1045)。開票先核對主線、既有票和證據；不重開已修正問題。

新增兩組 **只作診斷、不進訓練** 的凍結題目：

1. 新 main 目錄適應40題：新版分段波動、真正召喚、週期重取目標、真瞬移突斬、成長／回復、已隔離的錯誤能力，對照 base／R2／R3。
2. 完整提案雙向檢查18組、114次判讀：原文是否支持整段提案，以及提案是否涵蓋逐項必要條件。含完整版、漏項版、反向／數值錯誤版；初號機歷史20%門檻與主線50%門檻分開提供來源，不能混用。

第二組只涵蓋已列出的機制清單，不宣稱英雄背景／原文全部要素已完整分解；部分來源曾進 R3，因此是回歸診斷，不冒充未見泛化 Gold。先以單元測試證明「一律 supported」會錯放12組壞提案，再進實際模型對照。CPU tokenizer 已確認新版目錄題最多2292 token，保留256輸出後仍在4096限制內；不截斷條件。

`r3-post-diagnostics.mjs` 已啟動為同一輪的一次性接續程序：等待目前 R3 **訓練、dev選模及原 sealed test 完成**才取得共用 GPU 鎖，依同一期限執行三模型對照。資料與腳本有雜湊釘選，失敗／取消不自行重啟、不重新挑 checkpoint、不自動啟用。新診斷分數不能替代原 R3 分数或完整目標的驗收。

完整最新清單：`outputs/forge-mechanism-priority-r3-20260906/DATA_QUALITY_STATUS.md`。下一步仍須根據實際對照修正資料與模型缺陷，驗證最新英雄來源與完整用途覆蓋，不能只靠 loss 或少量分類題宣布完成。

### 27.6 英雄設定來源硬化（15:12 進度）

釘選主線的71份英雄文件已建立 `main-hero-inventory-v2.json`：63份有故事、8份缺故事；R3的53份有49份故事逐字相同，另4位已下架且移出當前內容。新增14份故事已親自讀完；當中有同名變身態，不能當成14個新獨立英雄，也不自動把沒有故事的形態補成與本體相同。

主線49位有明確出身，其中39位不等於忽略明確指定後的三圍推導結果。已核對新版 `originOf()` 是**明確 origin 優先、缺省才推導**；早期只靠三圍反推的規則不能拿來覆蓋Owner指定。生成全新角色時仍做屬性／出身往返自洽檢查；讀既有角色時尊重已存在的指定值，兩種情境不混用。

`hero-source-client.mjs` 將完整故事、現在的出身／pitch／玩法標籤及本地roster身分綁到版本與摘要，才建立模型判讀請求。Saber同名文件要求精確ID；變身態不當獨立可選英雄；隱藏只能隨機與下架完全不可選分開。平台白名單／線上覆蓋未查，因此不宣告上線可選。PASSIVE／EX從正式引用欄位解析，136個引用皆找到相符slot。

另備140題英雄診斷（98題出身規則控制、42題新文件設定命題），最多826 token，未推論、未進訓練，不更改正跑中的R3或已釘選接續程序。實際完整流程尚須模型對照與機制涵蓋驗證，來源盤點成功不代表全目標完成。

### 27.7 複合機制與真實事件受詞校正（15:22 進度）

維持「選擇與組合既有模板」的完整目標，不把目前單卡分類實驗當成最終產品範圍。主線已支援最多8張卡；預設衝突政策為 reject，列表串接、不同純量拒絕，不能偷偷 lastWins。

`main-stack-audit-v1.json` 檢查當時32張候選卡的1,024種有序雙卡組合（含重複卡）：180種在預設參數下能解析且通過完整能力schema。這是**結構相容性**，不是180種機制已正確；調參後的組合也不在此矩陣保證內。真實 effect interpreter 證明「拉回＋回復」會在起飛當格回復，不會等待落地；若需求寫「抵達後才回血」，這個堆疊不合格。相同卡重複可變成雙倍傷害，主動效果與被動hook同存也不等於天生技能按鍵施放。

進一步檢查 `fireHooks` 發現 `growth-charge` 未設定 target=self，實際把擊殺計數與屬性收益放在受害者。真實hook分派重現：everyNth=1時受害者敏捷+1、擊殺者不變；預設8次不同受害者各累積1次、擊殺者仍沒有進度；只在記憶體控制組加self後，擊殺者第8次+1、受害者不變。**先前直接將targets=[caster]傳入效果的三圍計數測試不能證明擊殺成長可用**，不得拿來當訓練正例。

已開票 [#1048](https://github.com/adms/GGD/issues/1048)。開票前確認更新後main `14098b7c96ea5a6f0f5ac85e46507d6c6e3d276a` 的相關五個檔案與重現版本內容相同；沒有修改main或重開舊票。新版 `main-catalog-review-v2.json` 才是推薦診斷的有效審查帳本：**31可用候選、4隔離、11draft**。這裡的可用仍非完整runtime／原文Gold核可。

`main-diagnostic-v1` 的 single-stat-growth 正例撤銷，由 `main-diagnostic-v2` 替代，40題保留但目錄及正解已校正，最多2251 prompt token、無截斷。R3原訓練／dev／test沒有該模板正例，因此原訓練不重啟、不改動。

舊 `post-diagnostics-v1` 在等待階段安全取消（0個推論階段、未取得GPU鎖），保留CANCEL與原pins，不假裝當時就已改正。新 `r3-post-diagnostics-v2.mjs` 已接續等待原R3結束，依序執行修正版目錄40題、完整提案114次判讀、英雄設定140題，各對照base／R2／R3；仍dev先選模、不得用新診斷重選checkpoint、不得自動啟用。所有新版輸入另行釘選。

當模型把需求分類成多張模板時，後續驗收要同時檢查：完整需求清單、各卡實際受詞、事件觸發、先後時序、共享計數器／冷卻、副作用、來源版本與編譯契約。不能只按選中了幾張卡打分。

### 27.8 拉扯投擲施法入口驗證與診斷再凍結

完成原本待查的pull-throw受詞路徑。`main-pull-throw-probe.ts` 由真模板expand／完整ability schema／記憶體英雄registry走到 `castAbility`，再讀實際leap狀態：地面小圈內兩名敵人都被拉回並拋至同一施法點，entity指令被拒絕；throwDistance從100改1000，落點完全相同。直接effect且不給point的控制組則有不同落點，證明原本「效果本體會動」不足以保證模板施法入口可用。

已開 [#1050](https://github.com/adms/GGD/issues/1050)，開票前去重並核對最新main相關四檔blob未變。推薦審查帳本改以 `main-catalog-review-v3.json` 為準：**30候選／5隔離／11draft**；不把單體抓取或可調距離前拋列為已支援。沒有修改遊戲機制。

`main-diagnostic-v3/` 40題換用新目錄；沒有題目以pull-throw為正解，因此既有答案不需硬改，但候選能力資訊必須校正。最多2203 prompt token。校正器2項測試通過，驗證原資料不變、控制組必須重現、若遇到該模板正例則要求重新審查而非靜默搬移。

等待中的post-diagnostics-v2在0推論階段安全取消，原訓練不動；post-diagnostics-v3已排隊並釘選本身腳本與資料。順序依使用者優先度調整為**英雄設定140題 → 完整提案114次判讀 → 新版機制目錄40題**，各跑base／R2／R3；仍共用GPU鎖、受21:36:10期限及15分鐘報告reserve限制，不使用這批診斷重選原checkpoint。

下一階段以實際模型結果判斷資料／訓練迭代，不以開票數、隔離數、loss下降或schema通過替代微調成效。

### 27.9 逐題成效報告已自動化

`r3-error-report.mjs` 已對實際base/R2控制dev生成 `baseline-error-report/`，並再次人工逐案複核6題剩餘錯誤。base69/83→R2 77/83是8題模板拒絕被修正，5題英雄／Owner的未知與矛盾區分未改善；不誤稱R3已有結果。

`r3-evidence-finish.mjs` 已作為CPU-only一次性接續程序執行，等待原R3與post-diagnostics-v3的真PID／終止狀態，完成後產出五份配對報告與缺失清單，寫入 `paired-evidence-v1/`。報告要求相同base、runtime、seed、請求摘要與非推理設定；保留全部逐案修正／退步／錯誤放行，來源任務與模板任務分開，禁止總平均掩蓋英雄設定退步。三項報告器測試通過。

程序不使用GPU、不重選checkpoint、不生訓練資料、不啟用模型；缺輸出就標partial。後续仍要親自檢視成效與錯誤，再決定是否以train來源建立新的高品質對照題迭代，而不是把dev/test原題直接搬入訓練。

### 27.10 R3完成，英雄改善但Owner機制尚未合格

2026-09-06 16:42補記：三epoch本機訓練108.63分鐘，dev依既定規則選epoch2（81/83），原sealed test總分102/108。不能只看總分：相對R2，英雄43/48→47/48；模板19/20不變；Owner機制37/40→36/40，且仍有1題把原文沒說明的生命百分比受詞錯誤放行。dev Owner36/38亦未達95%門檻，因此不啟用、不宣告穩定改善。

逐題重新讀原文，記入`outputs/forge-mechanism-priority-r3-20260906/R3_RESULT_REVIEW.md`及`heldout-error-report/`。下一輪優先改善TRAIN來源的主體、受詞、条件、完整正例與未知判斷，不以增加epochs取代資料修正。原R3test從下一輪起只稱回歸；任何新測試需先凍結且說明來源重疊限制。原R3所有資料與選模證據不改。

### 27.11 R3補充結果與R4資料校準已啟動

R3接續診斷和五份逐題報告已完成，缺失0：新版英雄140題base137／R2 138／R3 139，完整提案114次判讀113／113／114，新main目錄40題17／17／33。三組R3皆無錯誤放行；完整提案18組的門檻判斷三模型都是18/18，不能把逐命題修正誤稱多救了一個整組提案。這些是補充診斷，不取代原Owner test失敗。

16:49啟動R4：重新從乾淨BF16基底訓練、相同LoRA配方，最多3epochs；不是接著R3權重續訓。新增158筆親自核對的train，總計**592train／83dev／162test**；test為原108已揭露回歸＋54個事先凍結、同來源家族的新命題。新增212題逐題保存完整來源與理由，來源未跨train/dev/test。Owner訓練三類94支持／94矛盾／72未說明，補強未知與受詞判讀，同時保留正確正例。資料、核准、腳本、token budget全部釘選，最多1181 prompt token，無截斷。

新工作根目錄為`outputs/forge-source-calibration-r4-20260906/`；`PRETRAIN_REVIEW.md`及`new-question-review.json`列出實際審查範圍。原R3保持不變。`r4-run.mjs`依原83dev選模後才跑test，分開報告回歸與新命題。`r4-post.mjs`等本輪結束後串接英雄、完整提案、新main目錄與base/R2/R3/R4 VFX保留測試，不重選checkpoint、不自動啟用。

接續診斷初次preflight抓到舊VFX有24題與train共享情境家族，均非相同需求文字。保留停止紀錄，新版`post-diagnostics-v2/`將已見家族保留與家族隔離分開報告，仍拒絕相同原題外洩。這批不能冒充新家族泛化分數；不影響英雄／Owner既定家族隔離。

所有既有六張票#1044/#1045/#1046/#1047/#1048/#1050再次確認OPEN，尚未修改遊戲。不以開票代替訓練收益。最終截止仍21:36:10，本輪候選尚在訓練，未預填R4結果，未驗16GB實機或宣告全目標完成。

### 27.12 召喚預設實際施法驗證與資料暫停納入

18:36補記：R4第三epoch仍正常；利用等待時間整理的60題新版分類候選尚未核准或訓練，隨後真實施法檢查發現新差異。召喚模板maxAlive預設0的說明是「不設上限」，但真castAbility回傳ok卻沒有單位；只改成上限2或明確省略上限，兩個控制組都生成2具有生命的單位。已开並確認[#1076](https://github.com/adms/GGD/issues/1076) OPEN，附四組重現、最新main原文對照及修正守衛；不擅改遊戲。

最新來源能力審查升為`main-catalog-review-v4.json`：**29候選／6隔離／11draft**。召喚管線並非不存在，但預設契約有缺陷，不能無條件推薦。`main-diagnostic-v4/`40題中兩個召喚正例因卡片隔離改成拒絕；需要新推論，不能將舊v3模型輸出套上新答案美化分數。v3原始資料、既有訓練與評估pins全部保留。

60題候選目錄`outputs/forge-current-main-candidate-20260906/`加上HOLD說明，防止不正確來源進入下一輪訓練。先等待R4實際dev/test與接續診斷，再判斷下一輪是否值得；如需要，重審v4標籤及保留英雄／Owner訓練資料，避免以分類改善換來源忠實度退步。最終報告仍優先英雄設定與技能機制，不以新增開票數宣告目標完成。

### 27.13 R4 已完成，拒絕無收益迭代；R5 單輪對照續訓

19:40補記：R4三輪訓練131.53分鐘，完整核心、post及supplement均已完成，證據在`outputs/forge-source-calibration-r4-20260906/final-evidence-v1/REPORT.md`。相同162題，英雄base43/48、R3與R4均47/48；Owner機制base82/94、R3 **87/94**、R4 **86/94**，後兩者仍有1題錯誤放行。原108題R3/R4逐題不變，新增54個同來源命題則R4新增1題退步。因此不以loss下降或模板得分提高採用R4。

新版v4目錄40題base19、R3 31、R4 36，但R3/R4都有3題錯誤放行；不能抵銷Owner優先層失敗。VFX測試64題base55、R3/R4均60，錯誤放行由6降為4。英雄140題137→139，完整提案114次判讀113→114，均須保留原診斷／已見來源定位。實際source-predict英雄與fidelity入口在R4已成功，12GiB MLX分配限制下峰值約8.9GiB；這仍不是16GB實機或全機制生成證明。

另外只改一般來源判讀system規則的短測已完成：R3的Owner dev由36/38降為35/38，沒有通過預設gate，因此沒有繼續test，也不把這些規則放進R5。失敗介入完整保留在`outputs/forge-source-policy-probe-20260906/`。

19:30:49啟動R5，根目錄`outputs/forge-contrastive-r5-20260906/`。保留R3原434筆train，新增26份明示虛構校準來源的78個支持／矛盾／未知命題，以及重新審查v4的58個分類意圖、各呈現兩種目錄順序共116筆。總計 **628train／83dev／162已揭露回歸**。116呈現不是116個獨立需求；舊60題HOLD資料沒有被直接轉成train。

從R3的精確LoRA權重warm-start，重新建立Adam與RNG，只訓練一輪，保留step80及157。仍是4B非推理／rank16／最後8層／lr5e-6／累積4，不使用雲端。候選包含不變的R3；原83dev先檢查每一個R3答對的英雄／Owner題都不退步，再按既定優先層排名，同分才選較晚step。若原R3勝出，要明確報未選新模型。訓練最晚20:56:10停止，最終21:36:10截止不變；不根據測試結果重新選checkpoint。

### 27.14 R5 新來源診斷與完整接續評估已凍結

19:37:50凍結24招／72題新來源命題（支持、矛盾、未知各24），涵蓋七龍珠、犬夜叉、初音、海賊王及監獄兔。已親自完整閱讀每份選定說明及逐題核對答案；檢查R2–R5和既有英雄／fidelity／main-v4診斷，沒有相同技能ID或完整技能原文曝光。這不是對所有歷史benchmark或基底預訓練的無污染保證；英雄家族本身也不是全新。

這24份取自釘選main的技能description，帶`w3x-import`來源記號，**不冒充2026-08-08 Owner新稿或最新Owner權威**；未解出的`{{dmg}}`／`{{mp}}`保留未知，不拿runtime參數暗補答案。評的是「給定這份來源能否忠實分類」，不是證明遊戲已實現。存於R5的`fresh-source-diagnostic-v1/`，每份原文、檔案摘要、答案理由、來源層級及重疊限制都保留。72題最大538 prompt token，加256輸出保留均未超過4096，無截斷。

`r5-post.mjs`已作為一次性接續程序排隊，等待R5核心完成才取得共用GPU鎖。新來源跑base/R3/R5三臂；新版目錄40題、英雄140題、完整提案114次判讀與VFX118題重用同輸入的既有控制組，再跑選定模型。VFX已見家族與家族隔離分開，舊108／新增54回歸分開。最後跑真實source-predict入口與12GiB分配限制。過程不重選、不訓練測試題、不啟用、不push，21:21:10停止GPU留最後15分鐘報告。

本節仍是進度，R5分數尚未產生。全目標的穩定模型、全部技能用途與必要條件覆蓋、多卡組合正確性、量化後保真及16GB實機等未驗證項目保持未完成；不能用這72題或任何單一高分代替完整驗收。

### 27.15 新版目錄實際推薦入口（19:49準備狀態）

等待R5訓練時補上`current-template-client.mjs`，以呼叫者明確指定的review摘要綁定完整候選與不可用清單，不沿用旧17卡目錄。支援原需求保留、台詞剔除、輸入摘要核對、review／request漂移拒絕，以及隔離／draft／未知ID和多餘參數的拒絕。`classification-predict.py`也補上推論前messages摘要及catalog一致性驗證，避免只回傳呼叫者填寫的摘要。原R5訓練、評分、post釘選檔沒有改動。

真正JS builder→Python preflight及漂移拒絕測試通過，原氣功VFX入口測試仍通過。另準備`manual-entry-check-v1/`四個代表性實際CLI案例：受傷反擊、分段末端爆炸、已隔離召喚、氣功特效推薦；先將不分物件欄位順序的比較固定，未執行的舊準備另存於`manual-entry-preflight-superseded-v1/`，沒有覆写任何GPU結果。

`current-template-entry-check.mjs run`在核心尚未完成時實測以`CORE_NOT_COMPLETE`拒絕，沒有建立run-state或啟動GPU子程序。等R5核心及post均完成後，才在本輪相同截止時間內跑四例與12GiB分配限制。四例只是入口整合，不是新的泛化benchmark；未產生summary前均標未實測。

使用方法在`tools/forge-training/CURRENT_TEMPLATE_INFERENCE.md`。只推薦一張卡的入口仍不能取代完整多卡技能用途覆蓋；契約通過不能判定合法ID的語意一定正確。這次補強是避免用錯來源和資料的工程改善，不算fine-tune準確率收益，不自動啟用模型。

### 27.16 使用者再延長四小時（19:55明確授權）

使用者說「我可以再延長4小時給你」。總截止從2026-09-06 21:36:10改為 **2026-09-07 01:36:10 Asia/Taipei**（UTC 2026-09-06 17:36:10）；GPU最晚01:21:10停止，最後至少十五分鐘交付。授權與執行原則記於`outputs/forge-additional-four-hours-20260906/AUTHORIZATION.json`及`EXTENSION.md`。

既有R5凍結policy、原訓練截止、資料、評分器和選模保持不變，新授權用於後續版本和迭代，不直接篡改執行中的時間檔。R5當時真handle仍live，最新log約173/628，沒有新模型評分。

已備妥`r5-checkpoint-recovery.mjs`，僅在原核心確定因TRAINING_STOP_RESERVE終止、post亦已終止、GPU鎖已釋放且原pins不變時，驗證完整checkpoint與對應metrics後進行dev-only選模及原test評估。輸出到獨立`recovered-checkpoint-eval-v1/`；不恢復optimizer、不新增訓練、不改原failed狀態，並明示trainingComplete=false。它現在會拒絕仍活著的訓練，沒有被用來重啟或搶GPU。完整metrics前綴／截斷拒絕fixture測試通過，不冒充真MLX模型測試。

額外四小時以R5的真實逐題證據決定：優先修正英雄設定及Owner機制理解、對照資料與清楚標籤，再考慮有界新迭代。曖昧題不靜默改答案；已揭露測試不作新Gold或直接回灌train；特效僅保留推薦測試。若品質值得，後段再做量化／重載驗證；不只增加epochs、不保證延長必然提升、不擴張到雲端。

`r5-final-report.mjs`已實作原始輸出重評、dev選模重播、base與adapter摘要核對、各來源／模板題組分列及實際入口證據整理；目前以INCOMPLETE_CORE拒絕未完成的實驗，不提前產生成功報告。後續仍須真實模型结果與完整範圍審查，不能以報告器或流程完成替代模型夠好。

### 27.17 重複錯題的標籤潔淨度複核（20:01）

重新完整閱讀五份Owner來源與舊命題，發現需要分開處理的問題：大怒石舊題將「擴散」改成「分裂」、將「普通攻擊」寫成「攻擊」，而輸入沒有詞彙等價定義；吞噬的舊正例又比來源更明確地加入「低於門檻」。這些是命題歧義風險，不能直接判定模型完全不懂比例／條件，也不直接宣告舊標籤必錯。大師之劍的百分比擁有者未明示、完美盾反的充分條件不等於排他條件、護盾冷卻不等於生命周期等判斷則保留。

逐項紀錄在`outputs/forge-additional-four-hours-20260906/SOURCE_LABEL_AUDIT.md`。另建立`source-label-clarification-v1/`五來源／15題（支持、矛盾、未說明各5），完整原文／理由／舊case對照保留；重建一致、來源摘要、原文前處理和非訓練／非選模檢查通過。

這15題移除了部分含糊或額外假設，**不全部是原命題的等價改寫**；不能將較清楚的新題通過率當作修復舊題，不能替換原分母或改R5選模。待R5選模後作額外診斷，幫助下一輪資料校正；原R3／R4／R5 train/dev/test及原分數完全保持。此複核沒有發現新的已證實遊戲缺陷，不為標籤疑慮開遊戲票。

### 27.18 Owner 訓練題全量重讀與下一版措辭候選（20:12）

這次重新逐份讀完原R3／R5保留的Owner機制train來源與全部120題。精確盤點是 **54份來源**（不是工作中一度口頭估算的48份）：Fate與Negima各12份，其餘五組各6份。逐題原文、實際模型可見原文、舊問句及答案、摘要、人工審查理由與候選都保留在 `outputs/forge-additional-four-hours-20260906/owner-training-wording-review-v1/`。

120題中106題未發現新的措辭疑慮，14題另提改寫候選，不等於14個已證實錯標：主要是「自身最大生命」的主體省略／歧義、將普通攻擊泛稱為攻擊、技能與法術的範圍、隱含等級排列慣例，以及把充分觸發條件當成必要條件。候選只改claim，原來源原文、system、任務、答案標籤及train切分保持；不將dev/test加入train，也不影響R5原始分數。

腳本 `owner-training-wording-review.mjs` 已產生120筆Owner候選與完整逐題審查清單，重建逐物件相等；14筆request改變、106筆逐物件完全不變，來源文字改動0、標籤改動0、dev/test列0。狀態 **HOLD_PENDING_R5_RESULTS**，尚未以此候選開訓，不將資料校正本身宣稱為模型收益；這也不是全英雄／模板資料集已通過品質驗收。

15題澄清診斷另外接上 `paired-diagnostic-run.mjs`，準備目錄 `outputs/forge-additional-four-hours-20260906/source-label-paired-v1/`。使用延長四小時的獨立授權與policy，等原R5核心及post都完成才允許跑base／R3／選定checkpoint三臂的新預測；不重選、不覆寫。兩個CPU防護測試通過，真實R5仍執行時以CORE_NOT_COMPLETE拒絕，未建立執行狀態或啟動GPU。此刻仍是已準備、尚未跑的診斷，不提前計入分數。

### 27.19 多卡用途與時序邊界（20:24）

等待R5訓練期間，以釘選main的真實castAbility／SimWorld普攻與傷害管線補足多卡的代表性證據，不把schema相容直接當成語意相容。`main-composition-runtime-probe.ts`的v4結果11項通過：自我数值增益＋同次自我回復、常駐普攻附傷＋受傷後單體反擊，各有兩seed與兩種卡片順序；另核對瞄準衝突拒絕、天生被動旁的主動增益不能施放、重複斬擊卡確實變成兩次傷害。未驗證全部組合或全部參數範圍。

前三份fixture失敗結果保持，已找出實際原因而非開成遊戲缺陷：錯誤target標記、木樁也自動普攻、把原始傷害當最终傷害、繳械時間超schema上限；最終測量沒有修改production。詳細範圍與限制在 `outputs/forge-additional-four-hours-20260906/COMPOSITION_REVIEW.md`。

新增 `composition-diagnostic-v2/` 20題、32個明列計畫（29單卡＋3已核對組合），輸出 `{decision,templateIds,onConflict:"reject"}`，必須涵蓋全部必要機制，不任意拼裝或去掉必要條件；雙斬擊的重複ID是有意的，不能自動去重。單卡控制題避免一有多卡就無故加卡。這是已知模板語意的研究診斷，**不代表全英雄來源用途或所有有效多卡已覆蓋**。

20題各合法答案／順序共26種通過契約與既有逐題評分器檢查，20個prompt為2915–2939 tokens，另留256輸出均未超過4096。三臂準備在`composition-paired-v1/`，等原R5核心及post完成才跑，沒有模型結果或新訓練。新task契約與目錄不同於舊單卡benchmark，後續需同輸入base／R3／R5比較，不能跨分母宣稱fine-tune收益。v1未跑模型，原資料另留SUPERSEDED說明。

### 27.20 多卡實際呼叫入口（20:36準備狀態）

新增公開 `composition-client.mjs` 與有界 `composition-predict.mjs`，只使用已審查計畫、不匯入答案。20題公開請求重建與凍結 messages／摘要完全一致；保留雙斬擊的重複ID與人工必要設定，拒絕隔離卡、任意組合、參數輸出和lastWins。四項CPU測試通過，真實共享GPU鎖存在時preflight回報GPU_BUSY，沒有建立結果或啟動模型。

單次上限120秒、MLX分配限制12GiB、原始權重與輸入摘要綁定，輸出明示格式合法不等於語意合格，不啟用Editor。三個已知模式的手動入口案例與獨立答案已準備，待R5核心和post完成再實測；不當新泛化測試、不參與選模。使用方式見 `tools/forge-training/COMPOSITION_INFERENCE.md`。此刻新入口尚無GPU結果，不能把工程完成說成模型已學會多卡。

### 27.21 英雄設定訓練題完整複核（20:38）

另將原R3／R5保留的英雄設定train全部重新親自讀完：**30份完整角色說明、90題**。逐來源／逐題原文、問句、答案與理由保存在 `outputs/forge-additional-four-hours-20260906/hero-training-wording-review-v1/`，不是只看標籤或欄位。來源是鎖定repository版本，不以外部作品常識覆寫；例如小叮噹來源寫21世紀就依該文判讀，不擅自改canon。

80題保持逐物件不變，10題另存措辭候選，原文、system、lineage、train切分與答案標籤完全保留。包括巴恩「重要戰役才有機會使用」的可能性、明確否認原文而非假設角色只能有一位授予者／一種武術，以及把「來源已說明精確身高」等後設問句改為直接判斷來源未提供的屬性。部分候選換了待判命題，**不是10個已證實錯標，也不是全數等價改寫**。

重建、原文不變、標籤不變、80題完全一致、來源漂移拒絕與不完整審查拒絕皆通過；90題prompt442–651 tokens，加256保留全部符合4096。腳本／原資料／新候選／逐題清單與token檢查摘要在verification.json綁定。狀態HOLD_PENDING_R5_RESULTS，未訓練、未動dev/test、未改R5分數。必須等R5與追加診斷後才決定新版本，不將資料清理當模型收益。

### 27.22 部署保真歸因與報告守衛（20:41）

重新查看R2匯出原始紀錄，原LoRA、融合BF16與8bit的機制dev均31/34；但缺同一68題的融合BF16 test。因此原LoRA→融合後4/8bit退步不能完全歸因於量化，兩個末token探針重載無差也不證明分類保真。後續需將native→融合、融合→量化分開對照，仍dev選精度、test只作保真驗證。詳見 `outputs/forge-additional-four-hours-20260906/PRECISION_CAUSAL_AUDIT.md`；未進行新量化或更改舊結果。

`r5-final-report.test.mjs`三個CPU測試通過：保留失敗安全門檻、合法格式不冒稱語意正確、R3原控制勝出／部分訓練分支不說成新訓練完成，及不完整core在產生最終目錄前拒絕。這些是render／守衛fixture，沒有真GPU結果；R5完整collect正向仍待實際核心／post／入口全部結束後驗證。

### 27.23 一次性自動接續與checkpoint耐久保存（20:50）

已啟動 `follow-on-evaluation.mjs`，輸出 `outputs/forge-additional-four-hours-20260906/follow-on-evaluation-v1/`。它確認原core/post真正終止且complete、GPU鎖釋放後才依序執行已凍結的四題入口、原R5最終報告、15題來源澄清三臂、20題多卡三臂與三個公開多卡入口。共用原本驗證器和推論worker，不新增模型答案、不重選、不改舊截止。取消／父程序失敗／死亡未完成會停止，不刪鎖或自動重跑；等待判定兩項CPU測試通過，真handle已確認live且仍在等待。

R5 step80的32,480,560-byte adapter、設定檔與320筆完整metrics前綴已複製到工作區 `checkpoint-archive/step-80/`，逐檔hash驗證與來源位置保存在ARCHIVE.json。這是耐久保存，不是採用該checkpoint，也不是完成628筆訓練的證明。原R5模型分數仍尚未產生。

### 27.24 R5與多卡補测結論（21:10，取代先前等待狀態）

原R5於凍結20:56:10訓練停止點結束，最後完成metric為595筆；只完整保存step80／320筆，不能稱整轮完成。原core/post/follow-on失敗紀錄不改；獨立recovery完成原dev選模、162題回歸、72新來源、目前目錄／英雄／fidelity／VFX及真CLI。原dev從R3的81/83到82/83，但新增成功題涉及「擴散／分裂」標籤歧義；Owner87→88/94伴隨錯誤放行1→2，舊機制19→18/20，新來源70→69/72伴隨錯誤放行0→1。因此不採用R5。

額外澄清15題：base12、R3 13、R5 12；錯誤放行2、1、2。多卡20題：base17、R3 12、R5 12；錯誤放行1、8、8。錯誤包括共用冷卻誤當獨立、限時主動誤當常駐被動、回血誤當護盾、單次回血多塞buff、把計畫ID當模板ID。四個單卡／VFX入口4/4，但三個多卡真入口只1/3語意正確。R3在來源任務的收益不能推廣成完整鑄造用途已更好；目前沒有任何模型通過全範圍門檻。

下一輪保留原資料切分與所有測試，針對已知失敗概念另寫高品質訓練，不直接回灌錯題。新增17個原dev來源／51題平衡三類的候選，只可在新政策事前登錄後供dev使用。增加完整checkpoint保存頻率，避免大量更新無法在截止後評估。量化與啟用繼續暫緩，不能先壓縮不合格模型。

### 27.25 R6-v2凍結與實際啟動（21:40）

在完整重讀舊機制train後，發現170份prompt皆攜帶過期17卡目錄，wave/sweep仍稱單枚投射體。將它們排除本輪再訓練，保留原始歷史資料和全部測試，不宣稱170答案全錯。原636題準備草案未訓練；採用v2的466題：英雄90、Owner174（原120加54新未知）、VFX54、目前單卡58、多卡90。90多卡中58是同一批單卡需求的另種契約，不冒充獨立來源。24措辭改寫、54Owner新增未知、58目前需求及32新多卡需求都有逐題理由；資料清單在R6-v2的DATA_ADMISSION檔。

158dev=原83＋51原dev專屬來源新題＋24新多卡；186test=原162回歸＋24新多卡。另21份已稽核資料未曝光的新技能文字，63題三類平衡，僅供post；排除薄弱與混合歷史更正的兩份說明。新來源仍是repository說明和熟悉作品家族，不當Owner Gold或未見家族泛化。

全部對照改用零presence penalty，重測base與R3後才訓練，不把不同解碼設定的分數歸因於微調。新dev：base英雄19/21、Owner80/89、舊單卡15/24、多卡20/24；R3為21/21、83/89、24/24、13/24，多卡有10次錯誤放行。R3来源收益仍不能推廣成多卡能力。

R6從R3權重warm-start、fresh Adam、lr1e-5、單輪、累積4，rank16/scale16/last8/dropout0。每16個完整更新保存，乾淨截止另存最後完整更新；只评48/96/最後checkpoint。必須保住R3所有答對的英雄／Owner題，不能新增任何錯誤放行，各主要任務正確數不得降；平手保留R3。source/template訓練與code/policy全部釘選，不能在執行中調門檻。

core68938、post24285及新零懲罰公開入口54071均真實啟動，依序使用GPU；最新狀態見`outputs/forge-joint-source-stack-r6-v2-20260906/STATUS.md`。21:31:38開始正式訓練，尚無微調後分數。公開v2入口只做來源／提案／單多卡／VFX分類，不改遊戲或參數；10個已知模式實際呼叫會在post後進行。CPU契約檢查通過不等於真GPU整合已成功。

### 27.26 入口接續的CPU預檢修正（21:54）

原入口54071／PID10294在等待期間被CPU預檢抓到準備物件比對誤報：JS的undefined可選欄位序列化為JSON後消失。於21:46明確停止原等待程序，原failed／SIGNAL、零GPU阶段與全部釘選檔案保留；沒有將此當模型退步。

新`r6-entry-recovery.mjs`只以JSON roundtrip比對準備檔，十份spec、prepared及EXPECTED私有答案逐檔位元組不變，公開`research-inference-v2.mjs`不變，不修理任何模型輸出。新增取消watchdog讓等待及單次infer期間都能終止自有worker。CPU測試通過，新接續session14467／PID10926於21:47:57實際啟動，等待原core與post全部完成，輸出在`manual-entry-v3/`。core68938／post24285不受影響，最終報告器已對應新的入口證據路徑。

唯讀最終報告接續`r6-finish.mjs`於21:53:06實際啟動，session80178／PID19497，等待core、post與新入口全部成功且真實PID終止，GPU已釋放後才重播評分、選模及權重摘要。兩個等待守衛與兩個報告fixture測試通過；不呼叫GPU、不重選、不啟用、不將程序成功當模型品質合格。此刻沒有最終R6分數或成功報告。

### 27.27 R6完整訓練完成，固定候選評估開始（22:47）

466／466筆全部完成，117次optimizer更新，trainingComplete=true、stopReason=null；不是時間截斷的部分訓練。實際75.644分鐘、MLX峰值59.007GiB。八個完整checkpoint及訓練紀錄已耐久保存至R6-v2的`checkpoint-archive/`，core逐檔驗證；最後step117摘要為`844e7ac23e80b9c906c33e60c2e7ab87527d0987566d6f85a470411585455f97`。

原core68938未重啟，22:47進入step48的158題dev評估，再依序96、117；對照及守衛選模政策不變。完整訓練與權重不同只證明實驗有執行，不能當成理解能力提升。186題test、八組post、十次公開入口與最終重播報告尚待實際完成。

### 27.28 R6拒絕採用與R7單因素對照（23:10）

R6三個候選48／96／117的Owner正確數83／81／80（89題），單卡19／23／20（24題），多卡16／21／20（24題、錯誤放行6／2／2）；英雄皆21／21。R3為Owner83、單卡24、多卡13（錯誤放行10）。多卡改善伴隨原文與單卡退步，逐題守衛保留step0原R3。明確退步含月牙天衝四個傷害值、破魔／卍解AP條件、樹海降臨的追加AP與回復對象，不能靠修改標籤解除。core已成功结束，post與入口仍接續。

新的R7只將learningRate由1e-5降至2.5e-6。相同466筆、seed／顺序、初始R3、fresh Adam、LoRA、單輪累積4、零懲罰解碼與158dev選模守衛；不把測試錯題回灌、不增加選模checkpoint，不變更R6凍結檔。23個資料／證據檔複製hash一致，公開入口17個請求與R6一致，82項CPU測試通過。prepared不等於已啟動；須等R6全部程序真實成功終止及GPU空閒。新目錄`outputs/forge-low-lr-r7-20260906/`。

只比較相同步數的R6/R7結果，單seed不能宣稱統計顯著或穩定泛化。63來源題及其餘post皆已在R6曝光，本輪明確標為回歸。最晚23:30啟訓，00:45／00:48軟硬停止，原整體GPU01:21:10與報告01:36:10不延長；未通過仍不得採用、量化或啟用Editor。

### 27.29 R6最後證據與R7-v2實際啟動（23:23）

R6核心、八組三臂補測及10次真入口均完成；入口7／10語意正確，機制不足不能被VFX成功遮蓋。原報告器因undefined reason經JSON存檔省略而比對誤報，原finish-v1 failed保留；獨立CPU修正版正規化JSON後重播全部原始報告、選模和權重摘要成功，未改分數、來源或重新呼叫GPU。正式報告為R6-v2的final-evidence-v2，逐題複核包已生成但仍標為待親自複核；實讀17個dev錯與8個post來源錯另有記錄。

選中原R3，在同條件186題中的英雄47／48、Owner87／94（錯誤放行1）、單卡19／20、多卡9／24（錯誤放行15）；這是原R3能力，不是R6收益。新來源63題58／63仍錯誤放行2；140英雄139／140、114句fidelity114／114，18份有界整體checklist與base同為18／18，不能以單句多1分宣稱完整提案更好。全範圍門檻未通過，不啟用。

為保留原R7準備pins，另開forge-low-lr-r7-v2-20260906；第一版未訓練。v2僅工程接續等待R6恢復報告、使用JSON正規化collector，資料、訓練recipe、所有門檻與時限不變。23:21:51核心session18089／PID46738實際啟動，post3316／PID46868、entry97048／PID47378、finish85509／PID47476也真實排隊接續；最新狀態見v2 STATUS.md。92項CPU測試通過，不等於模型品質改善。未加用雲端或再延長截止。

### 27.30 停訓後的新 37 名英雄全量推論（2026-09-07）

本節是較新的執行狀態，不將上方歷史排隊／訓練紀錄視為現行授權。使用者已要求停止訓練，之後另行表示「可以推論了」；此次僅重載既有基底、R3、R7 做推論，沒有 R8 或新訓練，也未重啟因電力問題停止的舊 2695 題隊列。

37 名英雄／222 槽來源經校正後，形成 555 題 train-candidate 來源判讀增補（74 英雄設定、481 技能機制）。原映射模板 222 槽仍隔離，不作原意等價正例；角色原文與實際支援能力分開，不把編譯通過當技能原意完成。555 題既有標籤由助理閱讀產生，不是 Owner Gold 或全歷史去重的獨立測試。

全量 555 × 3 共 1665 次推論完成；首批 43 題包含在內，不重複加權。相同輸入、非推理、temperature=0、presence penalty=0，基底 529/555（95.32%）、R7 511/555（92.07%）、R3 500/555（90.09%）；各有 1 題錯誤放行。相對基底，R7 修正 0／退步 18，R3 修正 0／退步 29。來源技能題分別 459、444、434／481，英雄設定分別 70、67、66／74。此批既有微調權重沒有勝過基底，不支持替換或啟用。

55 題失敗聯集已逐題回讀原文、claim 與輸出，保留原標籤與覆核理由。主要是明確數量、條件、主體、有限／無限被判成未提及；共同錯誤放行是承太郎 R 對決倒數暫停的反例。這不是新引擎缺陷證據，也不證明以新資料再訓練無效，因為本次沒有做那個實驗。

全量程序合計 707.92 秒（11.80 分鐘），Metal 峰值 8.61–9.03 GiB；非整機 RAM／耗電量。555 題原生 tokenizer 358–624 tokens，另留 256 輸出，全部未截斷。推論前後模型雜湊一致、worker 已終止、GPU lock 已釋放，訓練呼叫 0。校正資料 CPU 守衛重跑 1/1 通過，1665 次原始輸出以既有 scorer 重播一致。

資料入口：`outputs/community37-corrected-dataset-20260907-v1/README.md`。完整報告、每名英雄與混淆矩陣、55 題覆核、原始推論及模型完整性證據：`outputs/community37-inference-full-20260907-v1/REPORT.md`。總索引已更新，舊實驗分數與資料均保留。全範圍優質模型目標仍未達成，不以來源分類高分替代完整鑄造驗收，不恢復訓練。

### 27.31 直接機制組合推薦的 20 題補測（2026-09-07）

沿用先前已凍結的 composition-diagnostic-v2 補充：32 個既有候選計畫、20 題（10 接受、10 拒絕），含自身增益＋同時回血、獨立事件被動、即時雙擊三個多卡家族及四個單卡控制。新 run 僅補足基底／R3／R7 的 60 次推論，不改輸入、答案、候選或參數，不視為獨立未見家族。

基底 17/20（85%）、錯誤放行 1；R3／R7 都是 12/20（60%）、錯誤放行 8。各相對基底修正 1、退步 6；不是來源判讀分數，而是更直接的機制計畫推薦失敗。R3 契約合法 17/20、R7 19/20，但合法格式中仍有 5／7 題錯誤放行，不能以修好輸出格式宣稱已符合用途。

主要失敗是忽略共享冷卻、跨目標、護盾、取消原傷害、反擊範圍與第二擊延遲；共同錯誤是只要求回血卻多配增益卡。這些是必要機制，不屬於可交給人工隨意調參的次要細節。9 題失敗聯集已逐題回讀需求與候選計畫覆核。結果只能證明凍結列表上的分類行為，沒有重新驗收現行 main，也不把「拒絕未列計畫」解釋成引擎永遠做不到。

全 60 次程序合計 82.58 秒、Metal 峰值 9.35–9.72 GiB，輸入 2915–2939 tokens 加 256 輸出預留未截斷。原始輸出以既有 scorer 重播一致；模型前後雜湊一致、worker 終止並釋放 GPU lock，訓練呼叫 0。完整報告與20題逐題輸出：`outputs/forge-composition-supplement-inference-20260907-v1/REPORT.md`。不部署／不恢復訓練；原主隊列 1741 題未完整配對仍明列，未將本補充或新37名資料混進舊分母。

### 27.32 主隊列機制計畫全量補測與能力邊界洞察（2026-09-07）

延續使用者「可以推論了」的推論限定授權，另外凍結舊主隊列全部 296 個 mechanism-stack 輸入，完成基底／R3／R7 共 888 次推論，沒有重啟舊訓練或取消隊列。先前已撤回的 inference-review-01536 只留原始輸出稽核，正式分母固定 295，不因模型結果調整標籤。

基底 212/295（71.86%）、錯誤放行 22；R3 180/295（61.02%）、錯誤放行 110；R7 212/295（71.86%）、錯誤放行 76。R7 對基底修正 52／退步 52，R3 修正 36／退步 68。R7 的可接受需求正確推薦由基底 65/147 提升到 116/147，但應拒絕需求正確數由 147/148 降到 96/148：不是完全學不動，而是推薦收益沒有保住拒絕邊界。基底同樣過度拒絕，不因此取得全自動部署資格。

只擋非法計畫後，基底／R3／R7 仍有 9／54／58 題契約合法的錯誤放行。對象、冷卻共享、事件先後、延遲和額外副作用是必要機制，不是可忽略的參數。152 個失敗輸入對應 89 種需求文字，已全數回讀原文及候選計畫寫下覆核理由；同文字不同目錄輸出逐個保留，不冒充多份獨立人類 Gold。

兩版目錄共 296 個原始輸入，計分後僅 158 種需求文字，目錄順序與部分能力說明皆不同，不是純排序消融。R7 完整訓練輸入匹配 39 題，得 34/39，基底 23/39；其他 256 題為 R7 178/256、基底 189/256。非完整匹配不代表全新語意，這一輪不能證明過擬合原因或保證再訓練必然改善。

程序合計 1231.84 秒（20.53 分鐘）；基底／R3／R7 分別 429.09／407.61／395.14 秒，Metal 峰值 9.35／9.72／9.72 GiB。輸入 2910–3065 tokens，加 256 輸出預留全部未截斷。888 次原始輸出重播一致，前後模型摘要一致，程序正常退出、GPU lock 釋放，訓練呼叫 0。Metal 不是整機記憶體或 16GB MacBook 實測。

完整報告：`outputs/forge-stack-full-inference-20260907-v1/REPORT.md`；正式比較用 comparison-qualified.json，含撤回題的 comparison.json 只供原始重播。主隊列覆蓋更新為 1250/2695 已完整三模型配對，其中 1249 可計分；尚缺 1445（Owner 機制 373、單模板 700、VFX 372），逐 ID 帳本是 main-coverage.json。新 37 名英雄 555 題及補充 20 題保持獨立，不混分母。沒有新確認的 main 產品缺陷，不拿模型錯答重複開票；全範圍模型目標仍未達成，不部署、不恢復訓練。

### 27.33 使用者要求收尾：最後原文推論完成，停止新增實驗（2026-09-07）

使用者最新要求「你差不多該收尾了做報告了吧」。只收完當時已啟動的 373 題 Owner 機制原文推論，沒有再開批次。此指示優先於本計畫中歷史的持續訓練／等待描述；後續不得因舊目標自動恢復訓練、GPU 推論或補跑未測題。

本批三模型 1119 次推論正常結束：基底 342/373（91.69%）、R3／R7 均 355/373（95.17%），錯誤放行 14／8／8。R3 對基底修正 15、退步 2；R7 修正 14、退步 1。33 題失敗聯集全部回讀來源覆核，其中 inference-review-01206 的表頭零冷卻是否包含觸發內置冷卻存在 Gold 歧義，維持原標籤、另列排除該題敏感度，不用作新訓練正例。

推論 worker 合計 535.015 秒（8.92 分鐘），Metal 峰值基底 8.528、R3 8.943、R7 8.934 GiB；不是整機 RAM 或 16GB MacBook 驗收。373 題全數 token budget 通過，模型前後摘要一致，父程序及 worker 已退出、GPU lock 釋放。三項 CPU 對齊守衛通過；報告重播僅以 JSON roundtrip 正規化存檔省略的 undefined reason，不更改模型輸出、來源、標籤或分數。

主隊列最終完成 1623/2695 個三模型配對輸入、其中 1622 題准予計分：英雄 348/348、技能原文 979/979、機制計畫 296/296（撤回 1 題）。剩餘單模板 700、VFX 372，共 1072 題明列未測，依收尾要求不再接續。新 555 題及補充 20 題獨立保存，不混入主分母。

根目錄總報告：`Finetune_英雄技能模型_最終研究報告_20260907.md`。本批詳細證據：`outputs/forge-owner-remaining-inference-20260907-v1/REPORT.md`；收尾限制與報告摘要：同目錄 `CLOSURE.json`。研究包與校正資料保存，不再量化、融合、發布或啟用 Editor。總結是微調有局部來源收益，但新英雄和拒絕邊界仍會退步，沒有取得穩定更好的全自動模型；完成的是依使用者要求的研究報告與交付，不追認原模型品質目標達成。

### 27.34 另獲授權的27B基底比較完成（2026-09-07）

使用者另行要求下載測試，隨後選擇「那就 Qwen3.8-27B」；本次只完成Qwen3.8-27B MLX 8-bit不推理／medium兩臂，同一批96題，共192次生成。未恢復4B或27B訓練；Flash-Next下載與測試取消，部分檔案保留。

兩模式均91/96（94.79%）、錯誤放行0；不推理生成5.33分鐘、medium43.95分鐘（約8.25倍）。medium修正2题、退步2题，主分數淨增0。兩臂合計worker約49.60分鐘，共用載入7.16秒；累積Metal峰值28.39 GiB，未分臂重置峰值，不能當獨立RAM對照或16GB機器驗收。

相同96個ID與messages digest對齊的歷史4B基底78/96（錯誤放行5）、R3 78/96（13）、R7 83/96（8）。27B較基底高13.54個百分點，但同時改變世代、參數量、精度、runtime與解碼，不是參數量單因子實驗，更不是27B微調收益。建議先保留27B不推理為研究候選，不急著追加微調。

96題均有助理逐ID來源／候選目錄覆核；36道機制輸入只有34種不同需求文字。保留3個Gold政策疑義（巴恩永久恢復、魔力不足觸發、點心名稱是否推導進食），不改原Gold；全臂一致排除後，不推理90/93、medium91/93，皆無錯誤放行。此敏感度及有輸出暴露的助理覆核不能代替獨立Owner Gold。完整來源理解、所有技能生成、真實遊戲端與穩定全自動目標仍未驗收。

本批已確認所有下載／推論程序退出、GPU鎖釋放、無後續排程；不得因舊目標自動續訓或重啟取消的Flash。最終報告：[Qwen3.8-27B 本機比較](</Users/Takuro/Dropbox/我的 Mac (Moriya.local)/Documents/ABxVFX_EDIT/outputs/qwen38-local-comparison-20260907/FINAL_RESULT.md>)；同目錄VERIFICATION.json及CLOSURE.json保存完成證據與界線。沒有新確認的Main引擎缺陷；Gold疑義僅列待政策確認，不當產品bug開票。
