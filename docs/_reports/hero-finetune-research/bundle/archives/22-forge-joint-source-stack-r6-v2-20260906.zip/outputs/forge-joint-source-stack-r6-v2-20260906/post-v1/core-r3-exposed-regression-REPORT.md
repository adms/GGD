# R6 同條件逐題對照

所有模型使用相同輸入與新解碼設定（presence penalty=0）。舊1.5設定分數不覆寫、不混算。多卡格式包含明列計畫契約檢查；高分不取代零錯誤放行或完整範圍驗收。

| 任務／模型 | 正確 | 錯誤放行 | 格式／計畫合法 |
| --- | ---: | ---: | ---: |
| owner-mechanism / base | 37/40 | 1 | 40/40 |
| mechanism-template / base | 16/20 | 0 | 20/20 |
| hero-source / base | 43/48 | 0 | 48/48 |
| owner-mechanism / r3 | 36/40 | 1 | 40/40 |
| mechanism-template / r3 | 19/20 | 0 | 20/20 |
| hero-source / r3 | 47/48 | 0 | 48/48 |
| owner-mechanism / selected | 36/40 | 1 | 40/40 |
| mechanism-template / selected | 19/20 | 0 | 20/20 |
| hero-source / selected | 47/48 | 0 | 48/48 |

逐題完整來源、需求、預期、原始模型值與修正／退步統計見對應JSON。來源／既有測試多已曝光；新多卡題亦是已知計畫家族，不冒稱独立新來源泛化。
