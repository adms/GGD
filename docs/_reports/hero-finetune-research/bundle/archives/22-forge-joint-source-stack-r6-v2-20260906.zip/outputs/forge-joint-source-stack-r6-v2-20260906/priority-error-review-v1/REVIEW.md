# R6 結果逐題複核待辦

本文件由原始結果產生，**不代表每題已親自複核**；不更改分數、答案、門檻或選模。

選定step 0；保留原R3，不能當新微調收益。

每組獨立列出對R3的变化；「新增錯誤放行」可能出現在前後都答錯的題，不能只看退步數。

| 題組 | 修正 | 答對變錯 | 新增錯誤放行 | 仍錯誤放行 | 仍答錯 |
| --- | ---: | ---: | ---: | ---: | ---: |
| test-report.json | 0 | 0 | 0 | 16 | 24 |
| post-v1/new-source-63-report.json | 0 | 0 | 0 | 2 | 5 |
| post-v1/previous-source-72-report.json | 0 | 0 | 0 | 0 | 2 |
| post-v1/current-main-v4-report.json | 0 | 0 | 0 | 3 | 9 |
| post-v1/hero-140-report.json | 0 | 0 | 0 | 0 | 1 |
| post-v1/fidelity-114-report.json | 0 | 0 | 0 | 0 | 0 |
| post-v1/vfx-118-report.json | 0 | 0 | 0 | 6 | 6 |
| post-v1/composition-regression-20-report.json | 0 | 0 | 0 | 8 | 8 |
| post-v1/source-clarification-15-report.json | 0 | 0 | 0 | 1 | 2 |

## 完整提案／反向遺漏檢查

不是把114個單句正確率當成18份整體提案的通過率。这里只能涵蓋已人工列出的機制需求，不能宣稱完整Owner文字全涵蓋。

| 模型 | 整體決策正確 | 錯誤放行不完整／錯誤提案 |
| --- | ---: | ---: |
| base | 18/18 | 0 |
| r3 | 18/18 | 0 |
| selected | 18/18 | 0 |

JSON提供三類混淆矩陣、逐類precision/recall及完整錯題原文。各題有來源關聯，而且題集經挑選，不以此計算或宣稱母體準度、統計顯著性或所有英雄泛化。

人工複核需另記錄實際看過的題與理由；生成器不自動填入reviewed。
