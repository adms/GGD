# R6 dev 與來源錯題親自複核（2026-09-06 23:12）

這是實際閱讀原文、問句、答案與模型輸出後的判讀，不是腳本自動核准。原始資料、標籤、分母、守衛及選模皆不變。這份紀錄不代表全資料庫或所有補測已親自複核，也不把R3被選回說成R6有收益。

## Step117 全部17個dev失敗

| 題目ID（可省略固定prefix） | 實際判读 |
| --- | --- |
| owner-mechanism-godie-h01n.w-yes | 原文明列破魔100%AP、卍解200%AP；R3 supported→117 not-stated，真退步。 |
| owner-mechanism-godie-h01n.e-yes | 原文明列破魔60%AP、卍解120%AP；R3 supported→not-stated，真退步。 |
| r6-expanded-dev-e00s.ex-0 | 明列千年練成追加500%AP、回復周圍自己與隊友；claim未臆測生命分母，supported→not-stated是真退步。 |
| r6-expanded-dev-h01n.e-1 | 原文明列450/600/750/900；「只列900」是直接矛盾，contradicted→not-stated是真退步。 |
| owner-mechanism-godie-e00s.w-no | 原文擴散，claim用分裂；缺等價詞定義，有先前已記錄的標籤措辭歧義，保留原分数而不聲稱新增退步。 |
| owner-mechanism-godie-e00s.w-yes | 同上另將每次普通攻擊簡化為每次攻擊；沿用已記錄歧義，不為分數重標。 |
| r6-expanded-dev-e00s.passive-2 | 15秒是冷卻，不能借成紮根最長持續時間；R3與117都錯誤supported，真安全缺口。 |
| r6-expanded-dev-ewar.e-2 | 來源只明列混亂條件下追加100%AP；無混亂時必定追加沒有來源支持。not-stated依凍結的非排他邏輯；模型判contradicted不應算錯誤放行。此邏輯口徑與自然語言技能慣例的差異要明示。 |
| r6-expanded-dev-h01n.r-0 | 八秒攻速加成、瞬步CD縮短50%明列；117和R3均not-stated。step48曾答對，不代表最後權重保留該收益。 |
| r3-vertical-landing-yes | 需求原地垂直跳、落地AoE；輸入舊目錄與目前目錄皆明列，117過度拒絕。 |
| r3-ancestral-counter-yes | 跨回合具名可耗層數明列，不是跨帳號；117過度拒絕。 |
| r3-wall-hit-yes | 需求已接受最近合法落點，不要求穿牆；117過度拒絕。 |
| r3-counter-attacker-yes | 受傷後只反擊施害者對應on-hit-react；117過度拒絕。 |
| r6-stack-dev-self-mana | 最大魔力比例加法、封頂、無buff；life-manipulate完整涵蓋，R3和117都過度拒絕。 |
| r6-stack-dev-single-retaliation | 只要受傷反擊、不含普攻增傷；單卡on-hit-react足夠，R3對→117拒絕。 |
| r6-stack-dev-restore-when-hit | 明確等下次受傷才補；即時buff+補血組合不符合，兩者都錯誤放行。 |
| r6-stack-dev-one-toggle | 必須可開關且不可常駐；常駐双hook不符合，兩者都錯誤放行。 |

明確來源退步和單卡退步足以拒絕117，毋須依賴兩個大怒石歧義題。48、96的先前複核也已確認明確退步；不是所有分數差都由訓練資料品質造成。較低學習率是待驗假說，不能先認定根因。

## R6 post：所選R3的全部8個來源／英雄失敗

已讀完new-source-63的5錯、previous-source-72的2錯、hero-140的1錯的完整source、claim及三臂輸出。這些是原R3結果，不是新R6 adapter的未見來源表現。

| 題目ID | 複核 |
| --- | --- |
| r6-fresh-o02p.r-0 | 舞蹈魔法免傷、每2秒施放、共4秒皆明列；R3卻not-stated，base原本答對。 |
| r6-fresh-osam.w-2 | 原文0秒冷卻未區分技能CD／事件ICD；本題依原政策not-stated，但「被動0秒CD是否已涵蓋ICD」有語意口徑風險，保留且標示，不當成肯定數值幻覺。 |
| r6-fresh-hvwd.q-2 | 25是傷害，法力流失量未列；兩個模型都把25移到魔力上而supported，真錯誤放行。 |
| r6-fresh-huth.w-2 | 500是吃餅乾回復量，傷害仍為placeholder；不能推知傷害必定不等於500。兩者contra而非unknown，是判斷類別錯但未錯誤放行。 |
| r6-fresh-o02p.ex-2 | 15秒明綁額外裝甲，不代表攻擊者減速也15秒；兩者supported，真錯誤放行。 |
| r5-fresh-u00v.r-2 | 「受到撞擊停止」未列牆／單位碰撞類別；兩者contradicted，仍缺未知分類能力。 |
| r5-fresh-osam.r-1 | 明列每人只吃一次，claim每段可再次傷害矛盾；兩者not-stated，真判讀錯誤。 |
| main-hero-godie-h02u-setting-yes | 故事原文即「具體的起源尚不明確」，R3卻contradicted；currentSetting.origin為職系，不應否認故事起源，base答對。此為來源欄位作用域錯誤，不是角色退休狀態驗證。 |

不能用新63題58/63的總分掩蓋兩次錯誤放行，亦不能忽略R3相對base在初音舞蹈與草泥馬故事上的實際退步。R7不回灌這些post問題或依此改標籤，全部保留作已曝光回歸。
