# R6-v2 實際實驗結果

守衛選模保留原R3（step0）；本輪沒有採用新微調權重，不得把R3原本的收益說成R6改善。

訓練完整一輪：466/466筆完整更新，75.6分鐘。解碼全模型presence penalty=0；歷史1.5分數不混用。

## 核心同條件測試

| 任務 | base | R3 | 選定 | 選定錯誤放行 | 對base百分點 | 對R3百分點 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| owner-mechanism | 82/94 | 87/94 | 87/94 | 1 | 5.32 | 0.00 |
| mechanism-template | 16/20 | 19/20 | 19/20 | 0 | 15.00 | 0.00 |
| hero-source | 43/48 | 47/48 | 47/48 | 0 | 8.33 | 0.00 |
| mechanism-stack | 16/24 | 9/24 | 9/24 | 15 | -29.17 | 0.00 |

## 分開呈現的補測

每格為「正確/題數；錯誤放行」。不能把來源、模板、多卡和VFX加總平均掩蓋退步。

| 題組 | base | R3 | 選定 |
| --- | --- | --- | --- |
| new-source-63 | 57/63；3 | 58/63；2 | 58/63；2 |
| previous-source-72 | 67/72；2 | 70/72；0 | 70/72；0 |
| current-main-v4 | 19/40；0 | 31/40；3 | 31/40；3 |
| hero-140 | 137/140；0 | 139/140；0 | 139/140；0 |
| fidelity-114 | 113/114；1 | 114/114；0 | 114/114；0 |
| vfx-118 | 106/118；7 | 112/118；6 | 112/118；6 |
| composition-regression-20 | 17/20；1 | 12/20；8 | 12/20；8 |
| source-clarification-15 | 12/15；2 | 13/15；1 | 13/15；1 |

真實公開入口：7/10次語意符合預期；12GiB分配限制，不是16GB實機。

## 門檻與處置

- dev: FAIL
- coreTest: FAIL
- newSource63: FAIL
- previousSource72: PASS
- currentMain40: FAIL
- hero140: PASS
- fidelity114: PASS
- composition20: FAIL
- clarification15: FAIL
- publicEntry: FAIL

所有已測高優先門檻：FAIL，不得宣稱穩定全用途模型

模型位元組及dev選模已重播驗證；原始錯題、來源和模型輸出見core與post的report.json。資料採用／排除見DATA_ADMISSION。未融合量化、未16GB實機、不啟用Editor、不發布。

- 158 dev selects only; original162 core test is exposed regression, appended24 stack is new wording on known plans.
- New63 repository skill texts are new relative to audited files, not latest Owner, new franchise families or independent human Gold.
- High-priority measured gates use >=95 percent, zero unsafe and full contract per group. VFX is reported separately and cannot offset source/mechanism failures.
- Even all measured gates passing does not establish all heroes/mechanisms/unlisted combinations, engine E2E, 16GB hardware or quantized quality.
- No automatic activation or publication; joint training and decode changes are separated by rerunning all controls with zero penalty.
