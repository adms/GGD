# R6-v2 執行與接手（2026-09-06 23:23 Asia/Taipei）

**本輪已結束，未採用新權重。** core68938、post24285、entry14467均exit0，入口7／10語意正確（波浪過拒、self組合計畫ID放錯欄位、限時雙hook誤放行）。原finish80178 exit1，原因是JS undefined reason欄位與JSON缺欄位比對誤報，不是分數或來源漂移。原finish-v1失敗紀錄與釘選腳本保持；獨立r6-report-recovery.mjs／r6-final-report-v2.mjs，session4690／PID46615，23:21零GPU完成重播并exit0，輸出 **final-evidence-v2/REPORT.md**。所有高優先門檻合併FAIL，選定仍原R3。

r6-result-audit-v2.mjs亦實際完成，session8576 exit0，輸出priority-error-review-v1。18份有界checklist整體判斷18／18、無錯誤放行，但不證明完整Owner自動抽取／全涵蓋；base亦18／18，不能宣稱此項整體提案較base提升。自動複核包保留personalReviewComplete=false；親自看過的dev17錯與post來源／英雄8錯另記DEV_AND_SOURCE_PERSONAL_REVIEW.md，不冒稱全庫審核。

R7-v2已在本輪所有程序退出後實際啟動，最新索引`../forge-low-lr-r7-v2-20260906/STATUS.md`。下方狀態全部為歷史，不重啟任何R6程序。

**23:10實際結論**：core已完整成功結束，session68938已取回exit0；step48／96／117全部未通過原逐題保留守衛，選定step0是原R3，不是R6新權重。三個候選的Owner正確數依序83／81／80（分母89、各錯誤放行1），單卡19／23／20（分母24）；多卡16／21／20（分母24、錯誤放行6／2／2）。英雄皆21／21。改善多卡不能抵銷原文判讀與單卡退步；目前沒有合格的新模型。

core186題測試已完成，selected與R3完全相同：英雄47／48、Owner87／94（錯誤放行1）、單卡19／20、多卡9／24（錯誤放行15）。新微調候選未獲採用，所以這些不是R6新增收益。post24285正在VFX第三臂，entry14467與finish80178仍等待前置完成；不可重啟。後續獨立R7低學習率對照已CPU準備但**尚未啟動**，索引`../forge-low-lr-r7-20260906/STATUS.md`。以下較早狀態保留為歷史。

**22:47實際階段切換**：完整單輪訓練已於22:47:18完成，466／466筆、117次optimizer更新，無截止或中止；耗時75.644分鐘，MLX峰值59.007GiB。八個完整checkpoint已保存到工作區`checkpoint-archive/`並由core核對，receipt已存在。最後step117 SHA256=`844e7ac23e80b9c906c33e60c2e7ab87527d0987566d6f85a470411585455f97`。core68938／PID7974現在進入`dev-step-48`，不再訓練；接著評96、117。尚無R6品質结论或選定新模型。下方訓練進度均為歷史。

**22:34最新**：core68938仍live，至少387／466筆已處理、384筆已完整更新。指定候選step96已保存，權重SHA256=`f8de499bd3682dab2ff0db910dcd29779ea8407d0156bf4c14e04dabc251ae70`與前384筆有序metrics已實讀核對。post24285、entry14467、finish80178於22:33–22:34再次由真session確認live。尚在訓練，沒有R6 dev/test分數；等待完整輪次後照原政策比較48／96／最後checkpoint。

**22:24最新**：同一core68938仍live，訓練至少325／466筆、完整更新324筆。step80／320筆已保存，實讀SHA256=`a1809bad15abfcb55d54585f3c70bc2fe438450755d1610d804d9f485d993de1`與receipt相符。post24285、entry14467、finish80178亦以各自真session重新確認live。尚未進入dev選模，沒有R6品質分數；維持原48／96／最後完整checkpoint評估政策。

**22:13最新**：core68938仍由真handle確認執行，訓練至少257／466筆、已完整更新256筆。step16、32、48、64的權重摘要及前256筆有序metrics都已CPU實讀核對。step48 SHA256=`0bff707d0f04d03b5cf1ebeca95067a15e9c9af60d7ef9abc4de911b6466a656`；step64=`a454be2975af93b8bb65acb737a52f26c7d452a17fa28e37bb6c19015a3997b5`。只評48／96／最後完整checkpoint，未增加選模機會。22:10亦以各自真session確認post24285、entry14467、finish80178仍live；不重啟任何階段。R6尚無微調後成績。

仍未取得R6微調後分數，不宣稱改善。原R5及多卡退步已在前輪報告保留。

## 已執行

- core exec session **68938**／PID7974；21:28:18開始，base/R3對照及doctor已完成；21:31:38正式訓練，worker PID8839。21:51 log至少example101／466，step25；step16／64筆已完整保存，尚未評估。完整更新checkpoint每16步保存。
- post exec session **24285**／PID9307；等待core真正完成、PID結束及GPU釋放，再跑8組三臂評估。狀態`post-v1/state.json`。
- 真公開入口接續 exec session **14467**／PID10926；等待core與post全部結束，再用零presence penalty新入口跑10次呼叫／17個模型判斷。狀態`manual-entry-v3/state.json`。
- 唯讀報告接續 exec session **80178**／PID19497；21:53:06實際啟動，等待以上三個程序真正成功結束且GPU釋放，再重播原始評分及選模、核對權重位元組，產生`final-evidence-v1/`。狀態`finish-v1/state.json`，零GPU呼叫，不自動重跑失敗階段。

原入口接續54071／PID10294於21:46明確停止，原`manual-entry-v2`保留failed／SIGNAL及零GPU階段。CPU預檢發現JS記憶體中的undefined欄位在JSON序列化後消失，造成準備檔比對誤報；新接續只將比對雙方正規化為JSON，十份輸入、prepared與私有預期答案逐檔位元組不變，公開推論程式不變。此為工程修正，不是模型答案修理或模型退步。詳`manual-entry-v3/recovery-receipt.json`。

step16 adapter實讀SHA256為`9adb3420dbb85cdb59515a86d837d95ba5d89d2cddd5a2d58ac5ac8e8d96929e`，與完整保存receipt相同。core結束後會自動耐久保存全部checkpoint；此刻未選模，不以loss下降宣稱模型改善。

21:58實際log至少153／466筆、step38，step32／128筆亦已保存。四個程序的161個凍結pins全部實讀吻合。全部forge-training CPU測試70/70通過，新增結果複核工具另2/2；不是全repository E2E或模型品質驗收。

後續人工複核輔助`r6-result-audit.mjs`已備妥，**尚未執行或排隊**。等`final-evidence-v1/summary.json`真實產生後從repo執行`node tools/forge-training/r6-result-audit.mjs <R6-v2絕對路徑>`，會重播主報告與18份fidelity整體提案，再生成各題組對R3／base的修正、退步、新增錯誤放行與三類混淆矩陣，輸出`priority-error-review-v1/`。生成器保留personalReviewComplete=false，必須親自看原文／錯題再另記審查，不自動改標籤、選模或門檻。不要為補報告修改正在等待的finish腳本或其釘選collector。

以上都用真實handle啟動並確認狀態，不重複啟動。core／post／entry任一失敗要看原始原因，不改failed成complete、不刪GPU鎖。若使用者要求停止，對上述已核實的自有PID送SIGTERM，確保正在單次入口內的worker也停止；不要只靠最外層CANCEL檔等待下一個呼叫。

## 冻結配方與資料

466train、158dev、186test。54Owner新未知題、24既有措辭改寫；排除170個攜帶舊能力目錄的再訓練例，目前58單卡需求涵蓋29可用卡，多卡90包含同58需求轉契約與32個新需求。原636筆準備草案沒訓練，保留在前一目錄。清單見DATA_ADMISSION文件。

R3權重warm-start，fresh Adam、lr1e-5、rank16/scale16/last8/dropout0、單輪、累積4；保存每16步與乾淨截止時最後完整更新。只評step48、96及最後完整checkpoint。原文答對逐題保留、不新增錯誤放行、各任務不得退步；平手留R3。詳PRETRAIN_REVIEW及policy，**執行中不得更改已釘選檔案**。

所有對照都重新使用presence penalty=0，不能與歷史1.5成對混算。新dev基底：英雄19/21、Owner80/89（錯誤放行2）、舊單卡15/24、新多卡20/24（錯誤放行0）。R3：英雄21/21、Owner83/89（錯誤放行1）、舊單卡24/24、多卡13/24（錯誤放行10、合法計畫18/24）。關閉懲罰不代表多卡問題已修好。

新來源63題已凍結，21份新技能文字均親自閱讀，相對明列稽核集無ID／解碼後正規化全文重複；但仍是相同held-out作品家族的repository說明，不是最新Owner或獨立人工Gold。薄弱形態敘述與混合歷史更正的兩份來源棄用。新資料不參與選模或訓練。

## 時限与待辦

本輪訓練軟停止9/7 00:15、硬停止00:18；整體GPU最晚01:21:10，報告截止01:36:10。Mac-only，無雲端、push、遊戲修改或Editor啟用。

等真實結果再逐題檢查收益和新增失敗，完成最終報告與可重載模型檢查。未到品質門檻不進量化，不用12GiB分配cap冒充16GB實機。所有模型目前research-only；完整英雄／機制分類穩定改善尚未證明。
