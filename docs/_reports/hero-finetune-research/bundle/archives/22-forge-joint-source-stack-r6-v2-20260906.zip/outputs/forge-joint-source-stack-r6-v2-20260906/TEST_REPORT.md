# R6 同條件逐題對照

所有模型使用相同輸入與新解碼設定（presence penalty=0）。舊1.5設定分數不覆寫、不混算。多卡格式包含明列計畫契約檢查；高分不取代零錯誤放行或完整範圍驗收。

| 任務／模型 | 正確 | 錯誤放行 | 格式／計畫合法 |
| --- | ---: | ---: | ---: |
| owner-mechanism / base | 82/94 | 3 | 94/94 |
| mechanism-template / base | 16/20 | 0 | 20/20 |
| hero-source / base | 43/48 | 0 | 48/48 |
| mechanism-stack / base | 16/24 | 4 | 20/24 |
| owner-mechanism / r3 | 87/94 | 1 | 94/94 |
| mechanism-template / r3 | 19/20 | 0 | 20/20 |
| hero-source / r3 | 47/48 | 0 | 48/48 |
| mechanism-stack / r3 | 9/24 | 15 | 18/24 |
| owner-mechanism / selected | 87/94 | 1 | 94/94 |
| mechanism-template / selected | 19/20 | 0 | 20/20 |
| hero-source / selected | 47/48 | 0 | 48/48 |
| mechanism-stack / selected | 9/24 | 15 | 18/24 |

逐題完整來源、需求、預期、原始模型值與修正／退步統計見對應JSON。來源／既有測試多已曝光；新多卡題亦是已知計畫家族，不冒稱独立新來源泛化。
