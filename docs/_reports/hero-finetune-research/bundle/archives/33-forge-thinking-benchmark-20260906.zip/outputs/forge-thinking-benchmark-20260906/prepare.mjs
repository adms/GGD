import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';

const out = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(out, '../../GGD-hero-auto-forge');
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const sourcePaths = [
  'apps/editor-desktop/src/ai/local/releaseCorpus.ts',
  'packages/shared/src/content/schema/abilityVfx.ts',
  'packages/shared/src/content/heroForge/presentation.ts',
];
const sources = sourcePaths.map(p => ({path:p,sha256:hash(fs.readFileSync(path.join(repo,p)))}));
const raw = fs.readFileSync(path.join(repo, sourcePaths[0]), 'utf8');
const js = stripTypeScriptTypes(raw.replace('import { sha256Hex, stableStringify } from "@ggd/shared/content";', 'const sha256Hex = x => x; const stableStringify = JSON.stringify;'));
const prior = await import('data:text/javascript;base64,' + Buffer.from(js).toString('base64'));
const str = {type:'string'};
const num = {type:'number'};
const arr = items => ({type:'array',items,maxItems:12});
const obj = properties => ({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const enumOf = values => ({type:'string',enum:values});
const decision = enumOf(['accept','degrade','refuse']);
const cases = [];
function add(id,category,prompt,context,schema,expected,checks={}) {cases.push({id,category,prompt,context,schema,expected,checks});}
const policySchema = obj({decision,selectedCapabilityIds:arr(str),selectedDirectionOptionIds:arr(str),selectedFallbackOptionIds:arr(str)});
function fromPrior(id,category,newId) {
  const c = prior.LOCAL_AI_RELEASE_CORPUS.find(x=>x.id===id);
  if (!c) throw Error(id);
  const expected = {decision:c.expected.decision,selectedCapabilityIds:c.expected.selectedCapabilityIds??[],selectedDirectionOptionIds:c.expected.selectedDirectionOptionIds??[],selectedFallbackOptionIds:c.expected.selectedFallbackOptionIds??[]};
  add(newId,category,c.prompt,c.context,policySchema,expected,{critical:true});
}
for(let i=1;i<=4;i++) fromPrior(`direction-0${i}-1`,'mechanics',`mechanics-0${i}`);
const actionSchema = obj({decision,actions:arr(obj({kind:str,target:enumOf(['self','ally','enemy']),trigger:enumOf(['onCast','onHit','onMiss']),amount:num}))});
const actionContract = {allowedKinds:['damage','shield','heal','restoreMana'],note:'本題為語意抽取中介格式，不是可直接匯入引擎的 JSON。amount 為明示數值。引號內是對白，不是機制；否定敘述不得新增 action。actions 保留執行順序。'};
add('mechanics-05','mechanics','「大家都痊癒吧！」只是台詞。這招命中敵人時只回復施法者 20 點魔力；沒有命中就不回復，也不造成治療。抽取實際 action。',actionContract,actionSchema,{decision:'accept',actions:[{kind:'restoreMana',target:'self',trigger:'onHit',amount:20}]},{critical:true});
add('mechanics-06','mechanics','施放時不結算任何數值。命中時先對敵人造成 100 傷害，然後給施法者 40 護盾。未命中兩者都不發生。「拉你過來！」只是台詞，本招沒有位移。',actionContract,actionSchema,{decision:'accept',actions:[{kind:'damage',target:'enemy',trigger:'onHit',amount:100},{kind:'shield',target:'self',trigger:'onHit',amount:40}]},{critical:true});
for (const [i,source] of ['capability-01-1','capability-02-1','capability-03-1','capability-04-1','direction-06-1'].entries()) fromPrior(source,'policy',`policy-0${i+1}`);
const fallbackCase = prior.LOCAL_AI_RELEASE_CORPUS.find(x=>x.id==='capability-03-1');
add('policy-06','policy','我要真正時間停止；即使有暈眩 fallback 也不接受替代。',fallbackCase.context,policySchema,{decision:'refuse',selectedCapabilityIds:[],selectedDirectionOptionIds:[],selectedFallbackOptionIds:[]},{critical:true});

const templateIds = ['tpl-on-attack','tpl-on-hit-react','tpl-single-strike','tpl-ground-nova','tpl-instant-blast','tpl-teleport','tpl-buff-self','tpl-traveling-wave','tpl-charge-push','tpl-leap-strike'];
const templates = templateIds.map(id=>{
  const p=`content/ability-templates/${id}.json`; const text=fs.readFileSync(path.join(repo,p),'utf8');
  sources.push({path:p,sha256:hash(text)}); const t=JSON.parse(text); if(t.status!=='enabled')throw Error(id);
  return {id:t.id,name:t.name,description:t.description,status:t.status};
});
const slots = ['PASSIVE','Q','W','E','R','EX'];
const coverageSchema = obj({decision,skills:{type:'array',minItems:0,maxItems:6,items:obj({slot:enumOf(slots),templateId:str})}});
const briefs = [
 ['普攻命中觸發的被動；單體斬擊；以自身為中心的震波；自己瞬移到地面點；純數值自我強化；沿直線逐步推進的傷害波。', ['tpl-on-attack','tpl-single-strike','tpl-ground-nova','tpl-teleport','tpl-buff-self','tpl-traveling-wave']],
 ['受傷時反制的被動；指定點瞬間範圍爆發；拋物線跳躍落地傷害；純數值自我強化；直線衝鋒並在抵達點推開敵人；沿線前進的傷害波。', ['tpl-on-hit-react','tpl-instant-blast','tpl-leap-strike','tpl-buff-self','tpl-charge-push','tpl-traveling-wave']],
 ['普攻觸發被動；受擊反制不要做。五個主動用途分別是單體斬擊、指定地面點的瞬發爆炸、拋物線跳躍砸地、將隊友拉到施法者腳邊、直線衝鋒落點推敵。', ['tpl-on-attack','tpl-single-strike','tpl-instant-blast','tpl-leap-strike','tpl-teleport','tpl-charge-push']],
 ['受傷反制被動；五個主動用途必須有自身震波、單體斬擊、沿線移動的傷害波、數值自我強化、救援隊友到自己腳邊。「召喚軍團！」只是台詞，不需要召喚。', ['tpl-on-hit-react','tpl-ground-nova','tpl-single-strike','tpl-traveling-wave','tpl-buff-self','tpl-teleport']],
 ['普攻觸發被動；五個主動技能要有指定點瞬爆、自身中心震波、跳躍落地、衝鋒落點推撞、沿直線前進的傷害波。不能用五次震波混過去，也不要瞬移。', ['tpl-on-attack','tpl-instant-blast','tpl-ground-nova','tpl-leap-strike','tpl-charge-push','tpl-traveling-wave']],
 ['受傷反制被動；單體斬擊；指定點瞬爆；自己瞬移到指定點；拋物線跳躍落地；純數值自我強化。跳躍與瞬移是兩個不同用途，都要有；不要移動傷害波。', ['tpl-on-hit-react','tpl-single-strike','tpl-instant-blast','tpl-teleport','tpl-leap-strike','tpl-buff-self']],
];
briefs.forEach(([brief,ids],i)=>add(`coverage-0${i+1}`,'coverage',`設計六槽英雄提案。六個用途各恰好分配一個模板，不可重複或漏掉；被動放 PASSIVE，其他用途任意分配到 Q/W/E/R/EX。只交付槽位與模板，不必文案或數值。需求：${brief}`,{templates},coverageSchema,{decision:'accept',requiredTemplateIds:ids,passiveTemplateId:ids[0]},{critical:false}));

const vfxIds = ['fx.prim.ice.nova','fx.prim.ice.shockwave','fx.prim.fire.nova'];
for(const id of vfxIds){const p=`content/vfx/${id}.json`;const s=fs.readFileSync(path.join(repo,p));sources.push({path:p,sha256:hash(s)});}
const layer = {type:'object',properties:{vfxKey:str,attachTo:enumOf(['caster','point']),delayMs:{type:'number',minimum:0,maximum:8000},alpha:{type:'number',minimum:0,maximum:1},timeScale:num,tint:{type:'array',items:{type:'integer',minimum:0,maximum:255},minItems:3,maxItems:3}},required:['vfxKey'],additionalProperties:false};
const vfxSchema=obj({decision,vfxLayers:{type:'array',items:layer,maxItems:6},gameplayChanges:arr(str),disclosedFallback:enumOf(['none','hit-to-cast'])});
const vfxContext={legalVfxIds:vfxIds,contract:'此 profile 的 vfxLayers 只在 abilityCast 啟動。attachTo 只有 caster／point；沒有骨頭掛點、target 或命中事件。point 無施法落點時依引擎規則回到 caster。delayMs 是相對施法的毫秒，0～8000。省略欄位沿用預設，alpha:0 是完全透明，不等於省略。timeScale 只改視覺播放速度，不改傷害、冷卻或位移。禁止新增 gameplayChanges。未指定的選填欄位必須省略。只有明示允許才降級，不能偽裝成 exact。'};
function vfx(id,prompt,layers,dec='accept',fb='none'){add(id,'vfx',prompt,vfxContext,vfxSchema,{decision:dec,vfxLayers:layers,gameplayChanges:[],disclosedFallback:fb},{critical:true});}
vfx('vfx-01','在施法落點立即播放冰新星，再於施法後 0.35 秒在同一落點播放冰震波。第二層 tint 是 [90,170,255]，第一層不要覆寫顏色；不改玩法。',[{vfxKey:vfxIds[0],attachTo:'point',delayMs:0},{vfxKey:vfxIds[1],attachTo:'point',delayMs:350,tint:[90,170,255]}]);
vfx('vfx-02','兩層都附在 caster。第一層冰新星必須完全透明（alpha 為 0）；第二層火新星保留素材原本透明度，不要輸出 alpha。其他選填欄位不要指定。',[{vfxKey:vfxIds[0],attachTo:'caster',alpha:0},{vfxKey:vfxIds[2],attachTo:'caster'}]);
vfx('vfx-03','火新星附在施法者，僅把視覺播放速度 timeScale 設為 2；技能原本傷害 100、冷卻 8 秒，兩者都不改。其他選填欄位不指定。',[{vfxKey:vfxIds[2],attachTo:'caster',timeScale:2}]);
vfx('vfx-04','冰新星必須綁在敵人右手骨頭，而且隨骨頭移動。不要用 point 或 caster 替代，也不接受其他近似。',[],'refuse');
vfx('vfx-05','冰新星希望命中時播；知道此 profile 不支援命中綁定，我明示同意降級成施法時在 caster 播，delayMs 設為 100。回報 hit-to-cast 降級，不要宣稱它是真的命中時播放。',[{vfxKey:vfxIds[0],attachTo:'caster',delayMs:100}],'degrade','hit-to-cast');
vfx('vfx-06','技能沒有施法落點。我仍要儲存 attachTo:point 的冰震波配置，接受引擎無落點時回到 caster 的既有規則，不要自行把設定改成 caster。其餘欄位沿用預設。',[{vfxKey:vfxIds[1],attachTo:'point'}]);

const system = '你是英雄技能機制與特效配置提案助手。僅使用本題 context 明示的能力與模板；它是此題固定 profile，不可用外部知識擴增。先理解需求與限制，再輸出符合提供 JSON Schema 的最終 JSON。accept=原需求完整可做；degrade=需求明示同意且有合法替代；refuse=無法完整表達且沒有獲准替代。引號內角色對白不是機制。不要輸出安全通過、自我評分或工具動作。可先思考，但最終答案只含 JSON。policy/direction 題只填相關 capability/direction/fallback ID，其他陣列留空；選 fallback 必須 degrade，未同意則 refuse 且所有選擇為空。';
const corpus={version:'forge-thinking-mini-20260906-v1',scope:'text-only controlled proposals; not image validation, not compiler/SimWorld or release gate',system,cases,sources};
if(cases.length!==24)throw Error('case count');
fs.writeFileSync(path.join(out,'corpus.private.json'),JSON.stringify(corpus,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(out,'corpus.public.json'),JSON.stringify({...corpus,cases:cases.map(({expected,checks,...visible})=>visible)},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:cases.length,sha256:hash(JSON.stringify(corpus)),sources:sources.length}));
