import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {spawn,spawnSync,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {once} from 'node:events';

const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const original=read('run/manifest.json');
const corpus=read('corpus.private.json');
const originalSource=fs.readFileSync(path.join(root,'benchmark.mjs'),'utf8');
assert.equal(sha(originalSource),original.scorerSha256);
assert.equal(sha(fs.readFileSync(path.join(root,'corpus.private.json'))),original.corpusSha256);
// Execute the exact frozen scoring functions, not a rewritten equivalent.
const helper=originalSource.slice(originalSource.indexOf('const canonical='),originalSource.indexOf('const models='));
const scoring=originalSource.slice(originalSource.indexOf('function schemaErrors('),originalSource.indexOf('const tests=selfTest();'));
const scorerSource=helper+scoring;
const {grade,selfTest}=vm.runInNewContext(scorerSource+';({grade,selfTest});',{corpus,structuredClone});
const tests=selfTest();
if(process.argv.includes('--self-test')){console.log(JSON.stringify({tests,scorerSourceSha256:sha(scorerSource),originalScorerSha256:sha(originalSource)}));process.exit(0);}
const runDir=path.join(root,'run-nonthinking');
fs.mkdirSync(runDir,{recursive:false});
const write=(name,value)=>fs.writeFileSync(path.join(runDir,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const config={...original.config,mode:'non-thinking-only',reasoningBudget:0};
const models=original.artifacts;
const binary=read('run/1-2B-424242.server-config.json').binary;
assert.equal(sha(fs.readFileSync(binary)),original.binarySha256);
const origin='http://127.0.0.1:18963';
const deadline=Date.now()+config.wholeRunTimeoutMs;
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let child=null,log=null,poll=null,peakRssKiB=0;
async function stop(){
 clearInterval(poll);poll=null;
 if(child&&child.exitCode===null){const p=child,ended=once(p,'exit');try{process.kill(-p.pid,'SIGTERM');}catch{}await Promise.race([ended,sleep(3000)]);if(p.exitCode===null){try{process.kill(-p.pid,'SIGKILL');}catch{}await Promise.race([ended,sleep(2000)]);}}
 child=null;log?.end();log=null;
}
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{stop().finally(()=>process.exit(130));});
async function post(body){
 const r=await fetch(origin+'/v1/chat/completions',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(Math.max(1,Math.min(config.perRequestTimeoutMs,deadline-Date.now())))});
 const text=await r.text();if(!r.ok)throw Error('HTTP '+r.status+' '+text.slice(0,500));return JSON.parse(text);
}
function request(messages,schema,seed){return{messages,stream:false,max_tokens:config.maxTokens,temperature:config.temperature,top_p:config.topP,top_k:config.topK,min_p:config.minP,presence_penalty:config.presencePenalty,seed,cache_prompt:false,chat_template_kwargs:{enable_thinking:false},response_format:{type:'json_schema',json_schema:{name:'forge_proposal',strict:true,schema}}};}
async function start(model,label){
 const sourceArgs=read(`run/${model==='2B'?'1-2B':'2-4B'}-424242.server-config.json`).args;
 const args=[...sourceArgs];
 args[args.indexOf('--port')+1]='18963';args[args.indexOf('--reasoning')+1]='off';args[args.indexOf('--reasoning-budget')+1]='0';
 write(label+'.server-config.json',{binary,args,model});
 log=fs.createWriteStream(path.join(runDir,label+'.server.log'),{flags:'wx'});
 child=spawn(binary,args,{stdio:['ignore','pipe','pipe'],detached:true});
 child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});
 let error;child.on('error',e=>{error=e;});peakRssKiB=0;
 poll=setInterval(()=>{if(child?.pid)try{const n=Number(execFileSync('/bin/ps',['-p',String(child.pid),'-o','rss='],{encoding:'utf8',timeout:1000}).trim());peakRssKiB=Math.max(peakRssKiB,n);}catch{}},1000);
 let ready=false;
 for(let i=0;i<120;i++){
  if(error)throw error;if(child.exitCode!==null)throw Error('server exited '+child.exitCode);
  try{if((await fetch(origin+'/health',{signal:AbortSignal.timeout(800)})).ok){ready=true;break;}}catch{}
  await sleep(500);
 }
 if(!ready)throw Error('startup timeout');
 write(label+'.props.json',await(await fetch(origin+'/props')).json());
 const req=request([{role:'user',content:'計算 17×19。最後只輸出 JSON，answer 是整數答案。'}],{type:'object',properties:{answer:{type:'integer'}},required:['answer'],additionalProperties:false},999);
 const response=await post(req);write(label+'.smoke.json',{request:req,response});
 const m=response.choices?.[0]?.message;
 assert.equal((m?.reasoning_content??'').trim(),'','thinking must be absent');
 assert.equal(response.choices[0].finish_reason,'stop');assert.equal(JSON.parse(m.content).answer,323);
 const logs=fs.readFileSync(path.join(runDir,label+'.server.log'),'utf8');
 assert.match(logs,/using device MTL0 \(Apple M5 Max\)/);assert.match(logs,/offloaded (\d+)\/\1 layers to GPU/);
}
const all=[];
try{
 for(const [name,m] of Object.entries(models)){const h=crypto.createHash('sha256');for await(const chunk of fs.createReadStream(m.path))h.update(chunk);assert.equal(h.digest('hex'),m.sha256,'model hash '+name);assert.equal(fs.statSync(m.path).size,m.bytes);}
 const version=spawnSync(binary,['--version'],{encoding:'utf8'});
 const hardware={cpu:execFileSync('/usr/sbin/sysctl',['-n','machdep.cpu.brand_string'],{encoding:'utf8'}).trim(),memoryBytes:Number(execFileSync('/usr/sbin/sysctl',['-n','hw.memsize'],{encoding:'utf8'})),os:execFileSync('/usr/bin/sw_vers',['-productVersion'],{encoding:'utf8'}).trim()};
 assert.deepEqual(hardware,original.hardware);
 write('manifest.json',{createdAt:new Date().toISOString(),config,artifacts:models,corpusSha256:original.corpusSha256,originalScorerSha256:original.scorerSha256,scorerSourceSha256:sha(scorerSource),runnerSha256:sha(fs.readFileSync(fileURLToPath(import.meta.url))),binarySha256:original.binarySha256,runtime:(version.stdout+version.stderr).trim(),hardware,tests,comparison:'Same prompts, schemas, scorer, weights, seeds, sampling, context and total output cap; only thinking mode/budget changed. Runs occur at different wall-clock times. No per-mode sampling optimization.'});
 let loaded=null;
 for(const [index,[model,seed]] of config.order.entries()){
  const label=`${index+1}-${model}-${seed}`;
  if(loaded!==model){await stop();await start(model,label);loaded=model;}
  console.log(JSON.stringify({event:'ready',model,seed,thinking:false}));
  for(const c of seed===424242?corpus.cases:[...corpus.cases].reverse()){
   if(Date.now()>deadline)throw Error('whole run deadline');
   const visible={id:c.id,category:c.category,prompt:c.prompt,context:c.context,outputSchema:c.schema};
   const req=request([{role:'system',content:corpus.system},{role:'user',content:JSON.stringify(visible)}],c.schema,seed);
   const began=performance.now();const response=await post(req);const wallMs=performance.now()-began;
   const message=response.choices[0].message,finish=response.choices[0].finish_reason;
   const thinkingObserved=(message.reasoning_content??'').trim().length>0;
   if(thinkingObserved||/<think>/.test(message.content??''))throw Error('thinking unexpectedly emitted '+c.id);
   let value=null,score;
   try{value=JSON.parse(message.content);score=grade(c,value);}catch(e){score={pass:false,formatValid:false,critical:false,errors:['final-json:'+e.message]};}
   if(finish!=='stop'){score.pass=false;score.errors.push('finish:'+finish);}
   const row={model,seed,id:c.id,category:c.category,wallMs,peakRssKiB,finish,thinkingObserved,usage:response.usage,timings:response.timings,score,value};
   write(`${model}-${seed}-${c.id}.json`,{...row,request:req,response});all.push(row);
   console.log(JSON.stringify({event:'case',model,seed,id:c.id,wallMs:Math.round(wallMs),pass:score.pass,finish}));
  }
 }
 write('results.json',all);write('status.json',{status:'complete',calls:all.length,completedAt:new Date().toISOString()});
}catch(e){write('failure.json',{status:'incomplete',error:e.stack,completedCalls:all.length});console.error(e);process.exitCode=1;}
finally{await stop();}
