import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const digest=p=>hash(fs.readFileSync(path.join(root,p)));
const re=read('run/manifest.json'),plain=read('run-nonthinking/manifest.json'),corpus=read('corpus.private.json');
assert.equal(read('run/status.json').status,'complete');assert.equal(read('run-nonthinking/status.json').status,'complete');
assert.equal(digest('corpus.private.json'),re.corpusSha256);assert.equal(plain.corpusSha256,re.corpusSha256);
assert.equal(digest('benchmark.mjs'),re.scorerSha256);assert.equal(plain.originalScorerSha256,re.scorerSha256);
assert.equal(digest('nonthinking.mjs'),plain.runnerSha256);assert.equal(plain.binarySha256,re.binarySha256);
assert.deepEqual(plain.hardware,re.hardware);assert.deepEqual(plain.artifacts,re.artifacts);
const expectedConfig={...re.config,mode:'non-thinking-only',reasoningBudget:0};assert.deepEqual(plain.config,expectedConfig);
assert.deepEqual(read('adjudication.json'),read('summary.json').adjudication);
const source=fs.readFileSync(path.join(root,'benchmark.mjs'),'utf8');
const scorerSource=source.slice(source.indexOf('const canonical='),source.indexOf('const models='))+source.slice(source.indexOf('function schemaErrors('),source.indexOf('const tests=selfTest();'));
assert.equal(hash(scorerSource),plain.scorerSourceSha256);
const {grade}=vm.runInNewContext(scorerSource+';({grade});',{corpus,structuredClone});
const rows={plain:read('run-nonthinking/results.json'),re:read('run/results.json')};
for(const entries of Object.values(rows)){assert.equal(entries.length,96);assert.equal(new Set(entries.map(r=>`${r.model}/${r.seed}/${r.id}`)).size,96);}
let requestPairs=0,scoreReplays=0;
for(const r of rows.plain){
 const filename=`${r.model}-${r.seed}-${r.id}.json`;
 const a=read('run/'+filename),b=read('run-nonthinking/'+filename);
 const expectedRequest=structuredClone(a.request);expectedRequest.chat_template_kwargs.enable_thinking=false;
 assert.deepEqual(b.request,expectedRequest);
 assert.equal((b.response.choices[0].message.reasoning_content??'').trim(),'');
 assert.equal(a.response.choices[0].message.reasoning_content.length>0,true);
 const c=corpus.cases.find(c=>c.id===r.id);
 for(const x of [a,b]){
  assert.equal(x.response.choices[0].finish_reason,'stop');
  assert.deepEqual(JSON.parse(x.response.choices[0].message.content),x.value);
  assert.deepEqual(JSON.parse(JSON.stringify(grade(c,x.value))),x.score);
  assert.ok(x.usage.prompt_tokens+x.usage.completion_tokens<=re.config.context);
  scoreReplays++;
 }
 assert.deepEqual(b.score,r.score);requestPairs++;
}
const logs=fs.readdirSync(path.join(root,'run-nonthinking')).filter(n=>n.endsWith('.server.log'));
for(const n of logs){const s=fs.readFileSync(path.join(root,'run-nonthinking',n),'utf8');assert.match(s,/using device MTL0 \(Apple M5 Max\)/);assert.match(s,/offloaded (\d+)\/\1 layers to GPU/);assert.doesNotMatch(s,/activated, budget=1024 tokens/);}
const result={status:'pass',requestPairs,scoreReplays,totalCalls:192,uniqueCases:24,validCohortCases:23,identicalRequestsExceptThinkingSwitch:true,exactFrozenScorerReused:true,originalReceiptsUnchanged:true,privateAnswersExcluded:'Input objects match original audited requests',nonThinkingConfirmed:true,originalThinkingBudgetExhaustions:read('integrity-audit.json').sessions.reduce((s,x)=>s+x.forcedThinkingStops,0),modelAndRuntimeHashesMatch:true,hardwareMatches:true,adjudicationMatchesPriorRun:true,completedAt:new Date().toISOString(),limitation:'Thinking and non-thinking runs were sequential sessions, not temporally randomized four-way blocks; all use temperature 1, not separately optimized per-mode sampling.'};
fs.writeFileSync(path.join(root,'fourway-integrity-audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
