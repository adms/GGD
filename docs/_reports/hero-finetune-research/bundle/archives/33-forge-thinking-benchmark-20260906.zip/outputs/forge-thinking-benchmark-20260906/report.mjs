import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const rows=read('run/results.json'),manifest=read('run/manifest.json'),corpus=read('corpus.private.json'),audit=read('integrity-audit.json');
if(read('run/status.json').status!=='complete'||rows.length!==96)throw Error('incomplete run');
const mean=a=>a.reduce((s,n)=>s+n,0)/a.length;
const pctile=(a,p)=>[...a].sort((a,b)=>a-b)[Math.max(0,Math.ceil(a.length*p)-1)];
const catNames={mechanics:'機制理解／方向',policy:'支援／降級／拒絕',coverage:'六槽用途覆蓋',vfx:'特效配置／玩法分離'};
const summary={scope:corpus.scope,caseCount:24,seeds:manifest.config.seeds,calls:rows.length,models:{},paired:{},limitations:['24 unique cases, two seeds are repeats, not 48 independent cases per model','Controlled proposals only; no rendered images, gameplay compilation, SimWorld or full-hero creative quality assessment','No non-thinking control or finetuning in this run; cannot quantify thinking benefit or finetuning efficacy','Same GGUF hashes as historical tests but different runtime, corpus and profiles; do not compare percentages as an improvement claim','8192 context on M5 Max 128GB; not a 16GB Mac or 4096-context deployment verification','RSS sampled at one second; not total unified GPU memory or Editor co-running footprint']};
for(const model of ['2B','4B']){
 const r=rows.filter(x=>x.model===model);
 const byCategory=Object.fromEntries(Object.keys(catNames).map(cat=>{const a=r.filter(x=>x.category===cat);return[cat,{passed:a.filter(x=>x.score.pass).length,total:a.length,criticalErrors:a.filter(x=>x.score.critical).length}];}));
 const bothSeedsPass=corpus.cases.filter(c=>r.filter(x=>x.id===c.id).every(x=>x.score.pass)).length;
 summary.models[model]={passed:r.filter(x=>x.score.pass).length,total:r.length,scorePct:100*r.filter(x=>x.score.pass).length/r.length,bothSeedsPass,totalUniqueCases:24,validJson:r.filter(x=>x.score.formatValid).length,normalStops:r.filter(x=>x.finish==='stop').length,thinkingObserved:r.filter(x=>x.thinkingObserved).length,criticalErrors:r.filter(x=>x.score.critical).length,meanWallMs:mean(r.map(x=>x.wallMs)),p50WallMs:pctile(r.map(x=>x.wallMs),0.5),p95WallMs:pctile(r.map(x=>x.wallMs),0.95),sampledPeakRssGiB:Math.max(...r.map(x=>x.peakRssKiB))/1024**2,totalCompletionTokens:r.reduce((s,x)=>s+(x.usage?.completion_tokens??0),0),meanCompletionTokens:mean(r.map(x=>x.usage?.completion_tokens??0)),generationTokensPerSecond:r.reduce((s,x)=>s+x.timings.predicted_n,0)/(r.reduce((s,x)=>s+x.timings.predicted_ms,0)/1000),byCategory,failures:r.filter(x=>!x.score.pass).map(x=>({id:x.id,seed:x.seed,errors:x.score.errors,critical:x.score.critical,value:x.value,evidence:`run/${model}-${x.seed}-${x.id}.json`}))};
}
const paired={bothPass:0,only2BPass:0,only4BPass:0,bothFail:0};
for(const a of rows.filter(x=>x.model==='2B')){const b=rows.find(x=>x.model==='4B'&&x.id===a.id&&x.seed===a.seed);paired[a.score.pass?(b.score.pass?'bothPass':'only2BPass'):(b.score.pass?'only4BPass':'bothFail')]++;}
summary.paired=paired;
const adjudication=read('adjudication.json');
summary.adjudication=adjudication;
summary.validCohort={caseCount:23,posthoc:true,models:{}};
for(const model of ['2B','4B']){
 const valid=rows.filter(x=>x.model===model&&!adjudication.excludeFromValidCohort.includes(x.id));
 summary.validCohort.models[model]={passed:valid.filter(x=>x.score.pass).length,total:valid.length,bothSeedsPass:corpus.cases.filter(c=>!adjudication.excludeFromValidCohort.includes(c.id)&&valid.filter(x=>x.id===c.id).every(x=>x.score.pass)).length,byCategory:Object.fromEntries(Object.keys(catNames).map(category=>{const r=valid.filter(x=>x.category===category);return[category,{passed:r.filter(x=>x.score.pass).length,total:r.length}];}))};
}
for(const model of ['2B','4B'])summary.models[model].thinkingBudgetExhausted=audit.sessions.filter(s=>s.model===model).reduce((n,s)=>n+s.forcedThinkingStops,0);
fs.writeFileSync(path.join(root,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const a=summary.models['2B'],b=summary.models['4B'];
const f=n=>n.toFixed(2),rate=x=>`${x.passed}/${x.total}`;
const lines=[
 '# Qwen3.5-2B vs 4B Thinking：英雄機制與特效配置小型 Benchmark',
 '',
 `完成日期：${new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',dateStyle:'medium',timeStyle:'medium'}).format(new Date())}（Asia/Taipei）。未微調、只做文字鑄造提案；不含視覺驗證。`,
 '',
 '判讀：在本輪同等 1024-token 思考預算下，4B 的有效案例通過率為 38/46（82.6%），高於 2B 的 11/46（23.9%），代價是較長延遲。因此 4B 是這個 profile 下較合理的下一輪研究候選，不代表已可上線或微調一定有效。兩者 96 次正式請求全部耗盡思考預算；微調前應先確認增加推理預算能否修復錯誤，不能直接把失敗歸因於參數量或缺乏微調。',
 '',
 '## 結果',
 '',
 '以下保留原始 24 題的嚴格分數，其中含一題事後確認有評分歧義的 VFX 案例；排除該題、兩組一致採計 23 題的診斷結果見下一節。',
 '',
 '| 項目 | 2B Thinking | 4B Thinking |','| --- | ---: | ---: |',
 ...Object.entries(catNames).map(([key,name])=>`| ${name} | ${rate(a.byCategory[key])} | ${rate(b.byCategory[key])} |`),
 `| 整體完整通過 | ${rate(a)} (${f(a.scorePct)}%) | ${rate(b)} (${f(b.scorePct)}%) |`,
 `| 兩個 seed 都通過的獨立案例 | ${a.bothSeedsPass}/24 | ${b.bothSeedsPass}/24 |`,
 `| 有效 JSON | ${a.validJson}/48 | ${b.validJson}/48 |`,
 `| 正常 stop | ${a.normalStops}/48 | ${b.normalStops}/48 |`,
 `| 實際觀察到 thinking | ${a.thinkingObserved}/48 | ${b.thinkingObserved}/48 |`,
 `| 用盡 1024 思考預算、強制轉答案 | ${a.thinkingBudgetExhausted}/48 | ${b.thinkingBudgetExhausted}/48 |`,
 `| 預標記安全／契約重點題失敗 | ${a.criticalErrors} | ${b.criticalErrors} |`,
 `| 平均完整請求延遲 | ${f(a.meanWallMs/1000)} 秒 | ${f(b.meanWallMs/1000)} 秒 |`,
 `| P95 完整請求延遲 | ${f(a.p95WallMs/1000)} 秒 | ${f(b.p95WallMs/1000)} 秒 |`,
 `| 生成吞吐（含思考） | ${f(a.generationTokensPerSecond)} tokens/s | ${f(b.generationTokensPerSecond)} tokens/s |`,
 `| 平均生成 tokens（含思考） | ${f(a.meanCompletionTokens)} | ${f(b.meanCompletionTokens)} |`,
 `| 取樣程序 RSS 峰值 | ${f(a.sampledPeakRssGiB)} GiB | ${f(b.sampledPeakRssGiB)} GiB |`,
 '',
 `同題同 seed 的 48 次配對：兩者都對 ${paired.bothPass}、只有 2B 對 ${paired.only2BPass}、只有 4B 對 ${paired.only4BPass}、兩者都錯 ${paired.bothFail}。兩個 seed 是重複測量，不代表有 48 個獨立案例；不據此宣稱統計顯著。`,
 '',
 '## 評分歧義與有效案例敏感度分析',
 '',
 '覆核發現 vfx-01 的 oracle 要求立即播放時明填 delayMs:0，但題目沒有要求必須序列化這個欄位；現有引擎以 delayMs ?? 0 處理，省略是等價配置。原始嚴格分數不覆寫，也不把這種差異當成實際機制錯誤。',
 '',
 '因此另外對兩模型、兩 seed 一致排除 vfx-01，保留 23 個有效案例（每模型 46 次）。這是事後診斷分析，不是新的封存評測，並不改變 run/ 內任何收據。',
 '',
 '| 有效案例 | 2B Thinking | 4B Thinking |','| --- | ---: | ---: |',
 ...Object.entries(catNames).map(([key,name])=>`| ${name} | ${rate(summary.validCohort.models['2B'].byCategory[key])} | ${rate(summary.validCohort.models['4B'].byCategory[key])} |`),
 `| 合計 | ${rate(summary.validCohort.models['2B'])} | ${rate(summary.validCohort.models['4B'])} |`,
 `| 兩個 seed 都通過 | ${summary.validCohort.models['2B'].bothSeedsPass}/23 | ${summary.validCohort.models['4B'].bothSeedsPass}/23 |`,
 '',
 '[歧義原因與來源](adjudication.json)。下列失敗索引保留原始 vfx-01 判分，閱讀時須套用本節的證據邊界。',
 '',
 '## 方法與邊界',
 '',
 '- 每類 6 題，共 24 題；每模型兩個固定 seed（424242、424243），合計 96 次正式請求。',
 '- 固定 Q4_K_M，與歷史小模型測試的 SHA-256 相同；不載入 mmproj，不送圖片，不租雲端 GPU，不微調。',
 '- 同一 llama.cpp/Metal runtime，單模型、單請求、GPU offload；模型順序 2B → 4B → 4B → 2B，第二 seed 反向題序。下載與權重 hash 校驗在正式計時外。',
 '- Thinking 上限 1024 tokens，總生成上限 2048 tokens，上下文 8192；temperature 1、top_p 0.95、top_k 20、min_p 0、presence_penalty 1.5。只代表這個受限推理預算，不是無限制推理的能力上限。',
 '- 每次換模型用不計分的算術題確認 thinking 非空、最終 JSON 正常；最終答案使用 JSON Schema grammar，思考內容獨立返回。不以模型自我宣稱判分。',
 '- expected/checks 僅在評分程序內使用；模型只收到 system、題目、公開 context、輸出 schema。模型／題庫／scorer／runtime 都在正式出題前記錄 digest。',
 '- 輸出格式、完整語意、重大錯誤分開記錄。格式失敗／length 保留在品質分母；基礎設施錯誤會使整輪 incomplete，不當成模型智力失敗。',
 '- 本輪 score.critical 的定義是：機制、policy、VFX 預標記重點題出現語意／欄位差異，或 coverage 出現非法模板。這包含配置忠實度錯誤，不全等於玩法安全漏洞；不可與既有正式 v4 release gate 的 critical 數量直接相比。',
 '- 機制／policy 部分取材既有 v4 corpus 的固定 profile，並加兩個條件與台詞抽取案例；不是對整個目前引擎能力的盤點。',
 '- 六槽測試只驗證完整用途對應與合法模板，不評文案、數值平衡或完整英雄創意；允許主動槽位任意排列，不能靠自報用途得分。',
 '- 特效題依現有 abilityVfx/presentation 契約測配置，涵蓋秒轉毫秒、0 與省略區別、point fallback、視覺與玩法分離、unsupported bone、明示事件降級。未渲染圖片，也未跑 SimWorld。',
 '- 嚴格欄位比對是本輪預先固定的 rubric；JSON key 順序忽略，selected ID 陣列視為無序但不容許重複，action／VFX 層順序保留。',
 '- RSS 為一秒取樣的程序 resident memory，不是完整 unified GPU memory，也不是 Editor／3D 並行容量；本次不能宣告 16GB Mac 支援。',
 '- 沒有同題 non-thinking 對照，因此不能把本次分數與舊 45 題分數相減宣稱 thinking 改善；也沒有微調前後比較。',
 '- 此題庫是小範圍選型開發集，部分案例重用既有 v4 測試；不是封存泛化測試。後續若依這些結果調整模型、prompt 或訓練資料，正式驗證須另備未見案例。',
 '',
 '## 失敗明細',
 '',
 ...['2B','4B'].flatMap(model=>[`### ${model}`,'',...summary.models[model].failures.map(x=>`- ${x.id} / seed ${x.seed}：${x.errors.join(', ')}${x.critical?'（安全／契約重點題）':''}；[原始輸入與輸出](${x.evidence})`),'']),
 '## 重跑',
 '',
 '保留本目錄為不可覆寫的證據。複製 prepare.mjs／benchmark.mjs／audit.mjs／report.mjs 與 adjudication.json 到 workspace outputs/ 下另一個新的子目錄，核對並更新權重路徑與 runtime 路徑後執行：',
 '',
 '```sh','node prepare.mjs','node benchmark.mjs --self-test','node benchmark.mjs --smoke','node benchmark.mjs','node audit.mjs','node report.mjs','```',
 '',
 '需要本機 loopback／Metal 權限。benchmark 自帶 30 分鐘整輪上限、60 秒單題上限、訊號取消與僅清理自己啟動的 server；不操作 LM Studio 中其他使用者模型。',
 '',
 '## 證據索引',
 '',
 '- [統計 JSON](summary.json)',
 '- [輸入隔離、雜湊與推理預算稽核](integrity-audit.json)',
 '- [固定模型／runtime／硬體／設定](run/manifest.json)',
 '- [24 題完整題库與私有答案](corpus.private.json)',
 '- [公開題庫](corpus.public.json)',
 '- [96 筆精簡結果](run/results.json)',
 '- [完成狀態](run/status.json)',
 '- 原始 response、reasoning、final JSON、request 與 server log 均在 run/。',
 '',
 'Smoke 前兩次中止：第一次預設日誌未暴露 GPU offload；第二次補足日誌後，檢查器誤用大小寫敏感的 Metal 字串，而實際日誌為 MTL0／ggml_metal。兩者均是前置證據檢查問題，不是模型品質失敗。修正為明確 MTL0 裝置與全部層 offload 證據後才開始正式題庫；失敗證據完整保留。正式結果只採 run/。',
];
fs.writeFileSync(path.join(root,'REPORT.md'),lines.join('\n')+'\n',{flag:'wx'});
console.log(JSON.stringify(summary,null,2));
