import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {once} from 'node:events';

const root=path.dirname(fileURLToPath(import.meta.url));
const corpus=JSON.parse(fs.readFileSync(path.join(root,'corpus.private.json'),'utf8'));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const canonical=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
const eq=(a,b)=>canonical(a)===canonical(b);
const models={
 '2B':{path:'/private/tmp/ggd-forge-thinking-20260906.kQFBzB/Qwen3.5-2B-Q4_K_M.gguf',sha256:'57a1085840f497d764a7fc5d346922dbde961efb54cc792ea81d694fd846a1d8',revision:'7d26695454df6de5fbcce2e58681e62dae06ce43',repo:'bartowski/Qwen_Qwen3.5-2B-GGUF'},
 '4B':{path:'/private/tmp/ggd-forge-thinking-20260906.kQFBzB/Qwen3.5-4B-Q4_K_M.gguf',sha256:'13c16f426047e2de38cd075bdade4a7bcbc8c774384876f677740cda65f8a983',revision:'4168f45a16a1290d65a4ec0fa312ae917a4c15d6',repo:'bartowski/Qwen_Qwen3.5-4B-GGUF'},
};
const binary='/Users/Takuro/.cache/lm-studio/extensions/backends/llama.cpp-mac-arm64-apple-metal-advsimd-2.33.0/llama-server';
const origin='http://127.0.0.1:18962';
const config={version:1,mode:'thinking-only',reasoningBudget:1024,maxTokens:2048,context:8192,seeds:[424242,424243],temperature:1,topP:0.95,topK:20,minP:0,presencePenalty:1.5,perRequestTimeoutMs:60000,wholeRunTimeoutMs:30*60*1000,order:[['2B',424242],['4B',424242],['4B',424243],['2B',424243]],finalJsonGrammar:true,cachePrompt:false,images:false,training:false,cloudGpu:false};
function schemaErrors(v,s,p='$') {
 const e=[];
 if(s.type==='object'){
  if(!v||typeof v!=='object'||Array.isArray(v))return [p+':object'];
  for(const k of s.required??[])if(!Object.hasOwn(v,k))e.push(p+'.'+k+':missing');
  for(const k of Object.keys(v)){if(!s.properties[k])e.push(p+'.'+k+':unknown');else e.push(...schemaErrors(v[k],s.properties[k],p+'.'+k));}
 }else if(s.type==='array'){
  if(!Array.isArray(v))return[p+':array'];
  if(v.length<(s.minItems??0)||v.length>(s.maxItems??Infinity))e.push(p+':length');
  v.forEach((x,i)=>e.push(...schemaErrors(x,s.items,p+'['+i+']')));
 }else if(s.type==='string'&&typeof v!=='string')e.push(p+':string');
 else if((s.type==='number'||s.type==='integer')&&(typeof v!=='number'||!Number.isFinite(v)||(s.type==='integer'&&!Number.isInteger(v))))e.push(p+':number');
 if(s.enum&&!s.enum.includes(v))e.push(p+':enum');
 if(typeof v==='number'&&(v<(s.minimum??-Infinity)||v>(s.maximum??Infinity)))e.push(p+':bounds');
 return e;
}
function grade(c,v){
 const errors=schemaErrors(v,c.schema);
 if(errors.length)return{pass:false,formatValid:false,critical:false,errors};
 if(c.category==='coverage'){
  const ids=v.skills.map(s=>s.templateId),slots=v.skills.map(s=>s.slot);
  if(v.decision!=='accept')errors.push('decision');
  if(v.skills.length!==6||new Set(slots).size!==6)errors.push('six-unique-slots');
  if(!eq([...ids].sort(),[...c.expected.requiredTemplateIds].sort()))errors.push('purpose-coverage');
  if(v.skills.find(s=>s.slot==='PASSIVE')?.templateId!==c.expected.passiveTemplateId)errors.push('passive-role');
  if(ids.some(id=>!c.context.templates.some(t=>t.id===id)))errors.push('illegal-template');
 }else{
  for(const [k,want] of Object.entries(c.expected)){
   const actual=v[k];
   if(k.startsWith('selected')){if(!eq([...actual].sort(),[...want].sort()))errors.push(k);}
   else if(!eq(actual,want))errors.push(k);
  }
 }
 return{pass:errors.length===0,formatValid:true,critical:errors.length>0&&(c.checks.critical||errors.includes('illegal-template')),errors};
}
function selfTest(){
 let assertions=0;
 for(const c of corpus.cases){
  const good=c.category==='coverage'?{decision:'accept',skills:c.expected.requiredTemplateIds.map((id,i)=>({slot:['PASSIVE','Q','W','E','R','EX'][i],templateId:id}))}:structuredClone(c.expected);
  if(!grade(c,good).pass)throw Error('oracle failed '+c.id);assertions++;
  const bad=structuredClone(good);bad.decision=good.decision==='accept'?'refuse':'accept';
  if(grade(c,bad).pass)throw Error('decision mutant survived '+c.id);assertions++;
  if(grade(c,{...good,unapproved:true}).pass)throw Error('schema mutant survived '+c.id);assertions++;
  if(c.category==='coverage'){const dup=structuredClone(good);dup.skills[5]=structuredClone(dup.skills[1]);if(grade(c,dup).pass)throw Error('coverage mutant');assertions++;}
 }
 const vfx=corpus.cases.find(c=>c.id==='vfx-02');const bad=structuredClone(vfx.expected);delete bad.vfxLayers[0].alpha;
 if(grade(vfx,bad).pass)throw Error('zero vs absent mutant');assertions++;
 return{assertions,passed:true};
}
const tests=selfTest();
if(process.argv.includes('--self-test')){console.log(JSON.stringify(tests));process.exit(0);}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const runDir=path.join(root,process.argv.includes('--smoke')?'smoke-'+Date.now():'run');
fs.mkdirSync(runDir,{recursive:false});
const write=(name,data)=>fs.writeFileSync(path.join(runDir,name),JSON.stringify(data,null,2)+'\n',{flag:'wx'});
let child=null,logStream=null,peakRssKiB=0,poll=null;
const deadline=Date.now()+config.wholeRunTimeoutMs;
async function stop(){
 clearInterval(poll);poll=null;
 if(child&&child.exitCode===null){const p=child;const ended=once(p,'exit');process.kill(-p.pid,'SIGTERM');await Promise.race([ended,sleep(3000)]);if(p.exitCode===null){try{process.kill(-p.pid,'SIGKILL');}catch{}await Promise.race([ended,sleep(2000)]);}}
 child=null;logStream?.end();logStream=null;
}
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{stop().finally(()=>process.exit(130));});
async function post(endpoint,body,timeout=config.perRequestTimeoutMs){
 const r=await fetch(origin+endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(Math.max(1,Math.min(timeout,deadline-Date.now())))});
 const t=await r.text();if(!r.ok)throw Error('HTTP '+r.status+' '+t.slice(0,500));return JSON.parse(t);
}
async function start(model,label){
 const args=['-m',models[model].path,'--host','127.0.0.1','--port','18962','-c',String(config.context),'-ngl','999','--device','MTL0','--offline','-lv','4','-t','4','--parallel','1','--reasoning','on','--reasoning-format','deepseek','--reasoning-budget',String(config.reasoningBudget),'--cache-ram','0','--ctx-checkpoints','1','--no-webui','--no-agent'];
 write(label+'.server-config.json',{binary,args,model});
 logStream=fs.createWriteStream(path.join(runDir,label+'.server.log'),{flags:'wx'});
 const began=performance.now();
 child=spawn(binary,args,{stdio:['ignore','pipe','pipe'],detached:true});
 child.stdout.pipe(logStream,{end:false});child.stderr.pipe(logStream,{end:false});
 let spawnError;child.on('error',e=>{spawnError=e;});
 peakRssKiB=0;
 poll=setInterval(()=>{if(child?.pid)try{const n=Number(execFileSync('/bin/ps',['-p',String(child.pid),'-o','rss='],{encoding:'utf8',timeout:1000}).trim());peakRssKiB=Math.max(peakRssKiB,n);}catch{}},1000);
 for(let i=0;i<120;i++){
  if(spawnError)throw spawnError;
  if(child.exitCode!==null)throw Error('server exited '+child.exitCode);
  try{const r=await fetch(origin+'/health',{signal:AbortSignal.timeout(800)});if(r.ok){const props=await(await fetch(origin+'/props')).json();write(label+'.props.json',props);return performance.now()-began;}}catch{}
  await sleep(500);
 }
 throw Error('server startup timeout');
}
function request(messages,schema,seed){return{messages,stream:false,max_tokens:config.maxTokens,temperature:config.temperature,top_p:config.topP,top_k:config.topK,min_p:config.minP,presence_penalty:config.presencePenalty,seed,cache_prompt:false,chat_template_kwargs:{enable_thinking:true},response_format:{type:'json_schema',json_schema:{name:'forge_proposal',strict:true,schema}}};}
async function smoke(label){
 const req=request([{role:'user',content:'計算 17×19。最後只輸出 JSON，answer 是整數答案。'}],{type:'object',properties:{answer:{type:'integer'}},required:['answer'],additionalProperties:false},999);
 const response=await post('/v1/chat/completions',req);write(label+'.smoke.json',{request:req,response});
 const m=response.choices?.[0]?.message;
 if(!m?.reasoning_content||m.reasoning_content.length<10)throw Error('thinking not observed');
 if(response.choices[0].finish_reason!=='stop'||JSON.parse(m.content).answer!==323)throw Error('smoke final JSON failed');
 const logs=fs.readFileSync(path.join(runDir,label+'.server.log'),'utf8');
 if(!/using device MTL0 \(Apple M5 Max\)/.test(logs)||!/offloaded (\d+)\/\1 layers to GPU/.test(logs))throw Error('Metal offload not evidenced');
}
const all=[];
try{
 const artifacts={};
 for(const [name,m] of Object.entries(models).filter(([name])=>!process.argv.includes('--smoke')||name==='2B')){
  const h=crypto.createHash('sha256');for await(const chunk of fs.createReadStream(m.path))h.update(chunk);
  const digest=h.digest('hex');if(digest!==m.sha256)throw Error('model hash mismatch '+name);
  artifacts[name]={...m,bytes:fs.statSync(m.path).size};
 }
 const manifest={createdAt:new Date().toISOString(),config,artifacts,corpusSha256:sha(fs.readFileSync(path.join(root,'corpus.private.json'))),scorerSha256:sha(fs.readFileSync(fileURLToPath(import.meta.url))),binarySha256:sha(fs.readFileSync(binary)),runtime:execFileSync(binary,['--version'],{encoding:'utf8'}).trim(),hardware:{cpu:execFileSync('/usr/sbin/sysctl',['-n','machdep.cpu.brand_string'],{encoding:'utf8'}).trim(),memoryBytes:Number(execFileSync('/usr/sbin/sysctl',['-n','hw.memsize'],{encoding:'utf8'})),os:execFileSync('/usr/bin/sw_vers',['-productVersion'],{encoding:'utf8'}).trim()},tests};
 write('manifest.json',manifest);
 const rounds=process.argv.includes('--smoke')?[['2B',424242]]:config.order;
 let loaded=null;
 for(const [index,[model,seed]] of rounds.entries()){
  const label=`${index+1}-${model}-${seed}`;
  let loadMs=null;
  if(loaded!==model){await stop();loadMs=await start(model,label);loaded=model;await smoke(label);}
  console.log(JSON.stringify({event:'ready',model,seed,loadMs}));
  if(process.argv.includes('--smoke'))break;
  const order=seed===424242?corpus.cases:[...corpus.cases].reverse();
  for(const c of order){
   if(Date.now()>deadline)throw Error('whole run deadline');
   // Whitelist serialization: neither expected answers nor scoring checks leave the process.
   const visible={id:c.id,category:c.category,prompt:c.prompt,context:c.context,outputSchema:c.schema};
   const req=request([{role:'system',content:corpus.system},{role:'user',content:JSON.stringify(visible)}],c.schema,seed);
   const began=performance.now();let response=null,value=null,error=null,score=null;
   try{response=await post('/v1/chat/completions',req);try{value=JSON.parse(response.choices[0].message.content);}catch(e){error='final-json:'+e.message;}}catch(e){throw Error('infrastructure failure '+model+' '+c.id+': '+e.message);}
   const wallMs=performance.now()-began;
   score=error?{pass:false,formatValid:false,critical:false,errors:[error]}:grade(c,value);
   const thinkingObserved=(response.choices[0].message.reasoning_content?.length??0)>0;
   const finish=response.choices[0].finish_reason;
   if(finish!=='stop'){score.pass=false;score.errors.push('finish:'+finish);}
   if(!thinkingObserved)throw Error('thinking missing '+c.id);
   const row={model,seed,id:c.id,category:c.category,wallMs,peakRssKiB,finish,thinkingObserved,usage:response.usage,timings:response.timings,score,value};
   write(`${model}-${seed}-${c.id}.json`,{...row,request:req,response});all.push(row);
   console.log(JSON.stringify({event:'case',model,seed,id:c.id,wallMs:Math.round(wallMs),pass:score.pass,finish}));
  }
 }
 write('results.json',all);write('status.json',{status:process.argv.includes('--smoke')?'smoke-complete':'complete',calls:all.length,completedAt:new Date().toISOString()});
}catch(e){write('failure.json',{status:'incomplete',error:e.stack,completedCalls:all.length});console.error(e);process.exitCode=1;}
finally{await stop();}
