import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
if(read('fourway-integrity-audit.json').status!=='pass')throw Error('audit required');
const corpus=read('corpus.private.json'),excluded=read('adjudication.json').excludeFromValidCohort;
const cases=corpus.cases.filter(c=>!excluded.includes(c.id));
const all=[...read('run-nonthinking/results.json').map(r=>({...r,profile:r.model,dir:'run-nonthinking'})),...read('run/results.json').map(r=>({...r,profile:r.model+' Re',dir:'run'}))];
const profiles=['2B','2B Re','4B','4B Re'];
const mean=xs=>xs.reduce((a,b)=>a+b,0)/xs.length;
const p95=xs=>[...xs].sort((a,b)=>a-b)[Math.ceil(xs.length*.95)-1];
const categories={mechanics:'機制理解／方向',policy:'支援／降級／拒絕',coverage:'六槽用途覆蓋',vfx:'特效配置'};
const out={scope:'Controlled text-only hero mechanism and VFX configuration proposals; no image validation or fine-tuning',totalCalls:192,uniqueCases:24,validCases:23,excluded,profiles:{},modePairs:{},caseMatrix:[],limitations:['Thinking budget is capped at 1024 and was exhausted on all 96 thinking requests. Not an unlimited reasoning comparison.','All use temperature 1 / top_p .95 to isolate the mode switch, not official per-mode optimized sampling.','Mode groups were run in separate sessions on the same hardware; timing is not an isolated randomized four-way benchmark.','Two seeds per case are repeats, not independent cases. Development dataset, not sealed generalization evidence.','No training was run; fine-tune benefits remain hypotheses. No SimWorld, full hero creativity, rendering or 16GB deployment validation.']};
for(const profile of profiles){
 const allRows=all.filter(r=>r.profile===profile),rows=allRows.filter(r=>!excluded.includes(r.id));
 const failures=rows.filter(r=>!r.score.pass).map(r=>({id:r.id,category:r.category,seed:r.seed,errors:r.score.errors,value:r.value,expected:cases.find(c=>c.id===r.id).expected,evidence:`${r.dir}/${r.model}-${r.seed}-${r.id}.json`}));
 out.profiles[profile]={passed:rows.filter(r=>r.score.pass).length,total:rows.length,pct:100*rows.filter(r=>r.score.pass).length/rows.length,strictPassed:allRows.filter(r=>r.score.pass).length,strictTotal:allRows.length,bothSeedsPass:cases.filter(c=>rows.filter(r=>r.id===c.id).every(r=>r.score.pass)).length,byCategory:Object.fromEntries(Object.keys(categories).map(cat=>{const r=rows.filter(r=>r.category===cat);return[cat,{passed:r.filter(x=>x.score.pass).length,total:r.length}];})),meanWallSeconds:mean(allRows.map(r=>r.wallMs))/1000,p95WallSeconds:p95(allRows.map(r=>r.wallMs))/1000,meanCompletionTokens:mean(allRows.map(r=>r.usage.completion_tokens)),formatValid:allRows.filter(r=>r.score.formatValid).length,normalStops:allRows.filter(r=>r.finish==='stop').length,thinkingObserved:allRows.filter(r=>r.thinkingObserved).length,overRefusals:rows.filter(r=>cases.find(c=>c.id===r.id).expected.decision==='accept'&&r.value.decision==='refuse').length,unauthorizedDowngrades:rows.filter(r=>cases.find(c=>c.id===r.id).expected.decision==='refuse'&&r.value.decision==='degrade').length,failures};
}
for(const model of ['2B','4B']){
 const pair={bothPass:[],reOnlyPass:[],plainOnlyPass:[],bothFail:[]};
 for(const a of all.filter(r=>r.profile===model&&!excluded.includes(r.id))){const b=all.find(r=>r.profile===model+' Re'&&r.id===a.id&&r.seed===a.seed);pair[a.score.pass?(b.score.pass?'bothPass':'plainOnlyPass'):(b.score.pass?'reOnlyPass':'bothFail')].push({id:a.id,seed:a.seed});}
 out.modePairs[model]=pair;
}
for(const c of cases)out.caseMatrix.push({id:c.id,category:c.category,prompt:c.prompt,profiles:Object.fromEntries(profiles.map(profile=>[profile,all.filter(r=>r.profile===profile&&r.id===c.id&&r.score.pass).length]))});
out.qualityOrder=[...profiles].sort((a,b)=>out.profiles[b].passed-out.profiles[a].passed||out.profiles[a].meanWallSeconds-out.profiles[b].meanWallSeconds);
fs.writeFileSync(path.join(root,'fourway-summary.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});
const f=n=>n.toFixed(2),cells=fn=>profiles.map(p=>fn(out.profiles[p],p)).join(' | ');
const lines=[
 '# 2B／2B Re／4B／4B Re：四組實測與微調前診斷',
 '',
 `同題正確率排序：${out.qualityOrder.join(' > ')}。Re 指同一 Qwen3.5 底座開啟 Thinking，上限 1024 tokens。`,
 '',
 '24 題 × 2 seed × 4 組，共 192 次正式請求。沿用上一輪已記錄的 vfx-01 評分歧義，四組一致排除，以下品質採 23 題／每組 46 次。原始 24 題的全部收據與嚴格分數均保留。',
 '',
 '| 項目 | 2B | 2B Re | 4B | 4B Re |','| --- | ---: | ---: | ---: | ---: |',
 ...Object.entries(categories).map(([key,name])=>`| ${name} | ${cells(s=>`${s.byCategory[key].passed}/${s.byCategory[key].total}`)} |`),
 `| 有效案例合計 | ${cells(s=>`${s.passed}/${s.total} (${f(s.pct)}%)`)} |`,
 `| 兩次都通過的案例 | ${cells(s=>`${s.bothSeedsPass}/23`)} |`,
 `| 原始嚴格分數（含歧義題） | ${cells(s=>`${s.strictPassed}/${s.strictTotal}`)} |`,
 `| 平均完整請求延遲 | ${cells(s=>`${f(s.meanWallSeconds)} 秒`)} |`,
 `| P95 完整請求延遲 | ${cells(s=>`${f(s.p95WallSeconds)} 秒`)} |`,
 `| 平均生成 tokens（含思考） | ${cells(s=>f(s.meanCompletionTokens))} |`,
 `| Schema 驗證通過（含欄位範圍） | ${cells(s=>`${s.formatValid}/48`)} |`,
 '',
 '速度統計包含各組原始 48 次請求；品質有效分母則一致排除歧義題。兩個 seed 為重複測量，不作統計顯著性宣稱。',
 '',
 '192 次輸出皆可解析為 JSON；其中 2B 的 vfx-01 有 delayMs:-1，未通過 schema 範圍檢查。統一排除該題不是說這個輸出正確：原始失敗仍保留。快速的錯答／拒絕也不等於快速取得可用答案。',
 '',
 '## 同尺寸：Thinking 究竟修了什麼、又退步了什麼？',
 '',
 '| 對照 | 都通過 | 只有 Re 通過 | 只有不推理通過 | 都失敗 |','| --- | ---: | ---: | ---: | ---: |',
 ...['2B','4B'].map(m=>`| ${m} vs ${m} Re | ${out.modePairs[m].bothPass.length} | ${out.modePairs[m].reOnlyPass.length} | ${out.modePairs[m].plainOnlyPass.length} | ${out.modePairs[m].bothFail.length} |`),
 '',
 '這是模式差異，不是微調前後差異。不得把 reOnlyPass 命名為 fixedByFinetune。完整配對 ID 與 seed 在 fourway-summary.json。',
 '',
 '## 每題跨 seed 穩定性',
 '',
 '| 題目 | 2B | 2B Re | 4B | 4B Re |','| --- | ---: | ---: | ---: | ---: |',
 ...out.caseMatrix.map(c=>`| ${c.id} | ${profiles.map(p=>`${c.profiles[p]}/2`).join(' | ')} |`),
 '',
 '## 公平性與限制',
 '',
 '- 重用相同 GGUF SHA-256、runtime binary SHA-256、Metal 裝置、8192 context、2048 總生成上限、temperature 1、top_p 0.95、top_k 20、min_p 0、presence_penalty 1.5、兩個 seed、JSON grammar 與 cache_prompt:false。',
 '- 非推理組直接執行原本凍結的 schemaErrors／grade／selfTest 函式；沒有重寫評分邏輯。192 筆輸出重新核對評分，96 組 request 配對除 enable_thinking 外完全相同。',
 '- runtime 參數只因 mode 變成 reasoning off／budget 0；另用本機 port 18963 避免干擾。沒有修改舊收據、模型、題目或生產程式。',
 '- 為控制變因，本次沒有改用官方 non-thinking 建議的 temperature 0.7／top_p 0.8。因此這是相同抽樣條件的模式消融，不是每組最佳配方的排名。[官方模型卡](https://huggingface.co/Qwen/Qwen3.5-4B)',
 '- Re 全部 96 次都用盡 1024 思考預算後轉答案；不代表更長推理預算的品質上限。非推理组每次均確認沒有 reasoning_content。',
 '- 四模式不是同時隨機交錯測量，而是在同一台 M5 Max 128GB 的兩個 session 各以 2B→4B→4B→2B 順序執行；速度可能受背景活動與溫度影響。',
 '- 只有受限提案／語意抽取／模板覆蓋／特效欄位測試，沒有完整技能編譯、SimWorld、畫面驗證、英雄創意／平衡性驗收或 16GB Mac 實機。',
 '- 這是已檢閱的開發題庫，不可再當作微調後的未見封存測試。沒有任何 fine-tune 收據，不能宣告微調有效或無效。',
 '',
 '## 微調決策',
 '',
 '見 [微調缺點分析與建議](FINE_TUNE_ASSESSMENT.md)：區分可學習的語意錯誤、應由 script 保證的契約、引擎能力缺口與推理预算效應。',
 '',
 '## 證據與重跑',
 '',
 '- [四組完整統計、失敗輸出、配對與案例矩陣](fourway-summary.json)',
 '- [192 次呼叫公平性與評分重播稽核](fourway-integrity-audit.json)',
 '- [原始 Thinking 報告](REPORT.md)',
 '- [非推理設定、模型與硬體](run-nonthinking/manifest.json)',
 '- [非推理 96 次結果](run-nonthinking/results.json)',
 '- [評分歧義處理](adjudication.json)',
 '',
 '本次新增 nonthinking.mjs、audit-fourway.mjs、report-fourway.mjs。輸出採 exclusive create，避免覆寫既有證據；重跑請使用新目錄並保留完整原始 corpus、runner 與依賴收據。',
 '',
 '```sh','node nonthinking.mjs --self-test','node nonthinking.mjs','node audit-fourway.mjs','node report-fourway.mjs','```',
];
fs.writeFileSync(path.join(root,'FOUR_WAY_REPORT.md'),lines.join('\n')+'\n',{flag:'wx'});
console.log(JSON.stringify({qualityOrder:out.qualityOrder,profiles:Object.fromEntries(profiles.map(p=>{const s=out.profiles[p];return[p,{passed:s.passed,total:s.total,pct:s.pct,meanSeconds:s.meanWallSeconds,bothSeedsPass:s.bothSeedsPass}];})),pairs:Object.fromEntries(Object.entries(out.modePairs).map(([k,v])=>[k,Object.fromEntries(Object.entries(v).map(([a,b])=>[a,b.length]))]))},null,2));
