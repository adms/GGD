# 2B／2B Re／4B／4B Re：四組實測與微調前診斷

同題正確率排序：4B Re > 4B > 2B Re > 2B。Re 指同一 Qwen3.5 底座開啟 Thinking，上限 1024 tokens。

24 題 × 2 seed × 4 組，共 192 次正式請求。沿用上一輪已記錄的 vfx-01 評分歧義，四組一致排除，以下品質採 23 題／每組 46 次。原始 24 題的全部收據與嚴格分數均保留。

| 項目 | 2B | 2B Re | 4B | 4B Re |
| --- | ---: | ---: | ---: | ---: |
| 機制理解／方向 | 2/12 | 5/12 | 10/12 | 12/12 |
| 支援／降級／拒絕 | 3/12 | 4/12 | 10/12 | 9/12 |
| 六槽用途覆蓋 | 0/12 | 2/12 | 11/12 | 11/12 |
| 特效配置 | 0/10 | 0/10 | 3/10 | 6/10 |
| 有效案例合計 | 5/46 (10.87%) | 11/46 (23.91%) | 34/46 (73.91%) | 38/46 (82.61%) |
| 兩次都通過的案例 | 0/23 | 3/23 | 16/23 | 17/23 |
| 原始嚴格分數（含歧義題） | 5/48 | 11/48 | 34/48 | 38/48 |
| 平均完整請求延遲 | 0.59 秒 | 6.18 秒 | 1.20 秒 | 11.21 秒 |
| P95 完整請求延遲 | 1.09 秒 | 7.08 秒 | 2.10 秒 | 12.83 秒 |
| 平均生成 tokens（含思考） | 94.15 | 1107.35 | 101.54 | 1106.58 |
| Schema 驗證通過（含欄位範圍） | 47/48 | 48/48 | 48/48 | 48/48 |

速度統計包含各組原始 48 次請求；品質有效分母則一致排除歧義題。兩個 seed 為重複測量，不作統計顯著性宣稱。

192 次輸出皆可解析為 JSON；其中 2B 的 vfx-01 有 delayMs:-1，未通過 schema 範圍檢查。統一排除該題不是說這個輸出正確：原始失敗仍保留。快速的錯答／拒絕也不等於快速取得可用答案。

## 同尺寸：Thinking 究竟修了什麼、又退步了什麼？

| 對照 | 都通過 | 只有 Re 通過 | 只有不推理通過 | 都失敗 |
| --- | ---: | ---: | ---: | ---: |
| 2B vs 2B Re | 3 | 8 | 2 | 33 |
| 4B vs 4B Re | 32 | 6 | 2 | 6 |

這是模式差異，不是微調前後差異。不得把 reOnlyPass 命名為 fixedByFinetune。完整配對 ID 與 seed 在 fourway-summary.json。

## 每題跨 seed 穩定性

| 題目 | 2B | 2B Re | 4B | 4B Re |
| --- | ---: | ---: | ---: | ---: |
| mechanics-01 | 1/2 | 1/2 | 2/2 | 2/2 |
| mechanics-02 | 0/2 | 2/2 | 2/2 | 2/2 |
| mechanics-03 | 1/2 | 2/2 | 2/2 | 2/2 |
| mechanics-04 | 0/2 | 0/2 | 2/2 | 2/2 |
| mechanics-05 | 0/2 | 0/2 | 0/2 | 2/2 |
| mechanics-06 | 0/2 | 0/2 | 2/2 | 2/2 |
| policy-01 | 0/2 | 1/2 | 2/2 | 2/2 |
| policy-02 | 0/2 | 1/2 | 2/2 | 2/2 |
| policy-03 | 1/2 | 1/2 | 2/2 | 1/2 |
| policy-04 | 0/2 | 0/2 | 2/2 | 2/2 |
| policy-05 | 1/2 | 0/2 | 0/2 | 0/2 |
| policy-06 | 1/2 | 1/2 | 2/2 | 2/2 |
| coverage-01 | 0/2 | 0/2 | 2/2 | 2/2 |
| coverage-02 | 0/2 | 0/2 | 2/2 | 2/2 |
| coverage-03 | 0/2 | 0/2 | 1/2 | 2/2 |
| coverage-04 | 0/2 | 0/2 | 2/2 | 2/2 |
| coverage-05 | 0/2 | 2/2 | 2/2 | 2/2 |
| coverage-06 | 0/2 | 0/2 | 2/2 | 1/2 |
| vfx-02 | 0/2 | 0/2 | 0/2 | 1/2 |
| vfx-03 | 0/2 | 0/2 | 0/2 | 1/2 |
| vfx-04 | 0/2 | 0/2 | 2/2 | 2/2 |
| vfx-05 | 0/2 | 0/2 | 1/2 | 2/2 |
| vfx-06 | 0/2 | 0/2 | 0/2 | 0/2 |

## 公平性與限制

- 重用相同 GGUF SHA-256、runtime binary SHA-256、Metal 裝置、8192 context、2048 總生成上限、temperature 1、top_p 0.95、top_k 20、min_p 0、presence_penalty 1.5、兩個 seed、JSON grammar 與 cache_prompt:false。
- 非推理組直接執行原本凍結的 schemaErrors／grade／selfTest 函式；沒有重寫評分邏輯。192 筆輸出重新核對評分，96 組 request 配對除 enable_thinking 外完全相同。
- runtime 參數只因 mode 變成 reasoning off／budget 0；另用本機 port 18963 避免干擾。沒有修改舊收據、模型、題目或生產程式。
- 為控制變因，本次沒有改用官方 non-thinking 建議的 temperature 0.7／top_p 0.8。因此這是相同抽樣條件的模式消融，不是每組最佳配方的排名。[官方模型卡](https://huggingface.co/Qwen/Qwen3.5-4B)
- Re 全部 96 次都用盡 1024 思考預算後轉答案；不代表更長推理預算的品質上限。非推理组每次均確認沒有 reasoning_content。
- 四模式不是同時隨機交錯測量，而是在同一台 M5 Max 128GB 的兩個 session 各以 2B→4B→4B→2B 順序執行；速度可能受背景活動與溫度影響。
- 只有受限提案／語意抽取／模板覆蓋／特效欄位測試，沒有完整技能編譯、SimWorld、畫面驗證、英雄創意／平衡性驗收或 16GB Mac 實機。
- 這是已檢閱的開發題庫，不可再當作微調後的未見封存測試。沒有任何 fine-tune 收據，不能宣告微調有效或無效。

## 微調決策

見 [微調缺點分析與建議](FINE_TUNE_ASSESSMENT.md)：區分可學習的語意錯誤、應由 script 保證的契約、引擎能力缺口與推理预算效應。

## 證據與重跑

- [四組完整統計、失敗輸出、配對與案例矩陣](fourway-summary.json)
- [192 次呼叫公平性與評分重播稽核](fourway-integrity-audit.json)
- [原始 Thinking 報告](REPORT.md)
- [非推理設定、模型與硬體](run-nonthinking/manifest.json)
- [非推理 96 次結果](run-nonthinking/results.json)
- [評分歧義處理](adjudication.json)

本次新增 nonthinking.mjs、audit-fourway.mjs、report-fourway.mjs。輸出採 exclusive create，避免覆寫既有證據；重跑請使用新目錄並保留完整原始 corpus、runner 與依賴收據。

```sh
node nonthinking.mjs --self-test
node nonthinking.mjs
node audit-fourway.mjs
node report-fourway.mjs
```
