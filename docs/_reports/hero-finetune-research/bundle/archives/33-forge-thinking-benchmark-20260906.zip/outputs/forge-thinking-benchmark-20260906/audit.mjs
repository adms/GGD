import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const digest=p=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex');
const corpus=read('corpus.private.json'),manifest=read('run/manifest.json'),rows=read('run/results.json');
assert.equal(read('run/status.json').status,'complete');
assert.equal(rows.length,96);
assert.equal(new Set(rows.map(r=>`${r.model}/${r.seed}/${r.id}`)).size,96);
assert.equal(digest('corpus.private.json'),manifest.corpusSha256);
assert.equal(digest('benchmark.mjs'),manifest.scorerSha256);
let checked=0;
for(const r of rows){
 const raw=read(`run/${r.model}-${r.seed}-${r.id}.json`);
 const c=corpus.cases.find(c=>c.id===r.id);
 const input=JSON.parse(raw.request.messages[1].content);
 assert.deepEqual(Object.keys(input).sort(),['category','context','id','outputSchema','prompt']);
 assert.deepEqual(input,{id:c.id,category:c.category,prompt:c.prompt,context:c.context,outputSchema:c.schema});
 assert.equal(raw.request.messages[0].content,corpus.system);
 assert.deepEqual(raw.request.response_format.json_schema.schema,c.schema);
 assert.equal(raw.request.chat_template_kwargs.enable_thinking,true);
 assert.equal(raw.request.seed,r.seed);
 assert.equal(raw.request.max_tokens,manifest.config.maxTokens);
 assert.equal(raw.request.temperature,manifest.config.temperature);
 assert.equal(raw.request.cache_prompt,false);
 assert.equal(raw.response.choices[0].message.reasoning_content.length>0,true);
 assert.deepEqual(raw.score,r.score);
 assert.deepEqual(raw.value,r.value);
 assert.equal(raw.usage.prompt_tokens+raw.usage.completion_tokens<=manifest.config.context,true);
 assert.equal(raw.usage.completion_tokens<=manifest.config.maxTokens,true);
 checked++;
}
const logs=fs.readdirSync(path.join(root,'run')).filter(n=>n.endsWith('.server.log'));
const sessions=logs.map(n=>{
 const s=fs.readFileSync(path.join(root,'run',n),'utf8');
 assert.match(s,/using device MTL0 \(Apple M5 Max\)/);
 assert.match(s,/offloaded (\d+)\/\1 layers to GPU/);
 assert.match(s,/activated, budget=1024 tokens/);
 const requests=[];
 for(const line of s.split('\n')){
  if(/processing task, is_child = 0/.test(line))requests.push({forced:false});
  if(/budget exhausted, forcing end sequence/.test(line)){assert.ok(requests.length);requests.at(-1).forced=true;}
 }
 const measured=requests.slice(1);
 return{log:n,model:n.includes('-2B-')?'2B':'4B',measuredCalls:measured.length,forcedThinkingStops:measured.filter(x=>x.forced).length,smokeForced:requests[0].forced,note:'Excludes the first, unscored arithmetic smoke.'};
});
assert.equal(sessions.reduce((s,r)=>s+r.measuredCalls,0),96);
const result={status:'pass',checkedRequests:checked,uniqueCases:24,modelSeedCaseTuples:96,answerLeakage:false,corpusDigestUnchanged:true,scorerDigestUnchanged:true,thinkingObservedAll:true,allRequestsWithinContext:true,sessions};
fs.writeFileSync(path.join(root,'integrity-audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
